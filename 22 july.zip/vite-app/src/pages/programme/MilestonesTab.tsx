import { useMemo, useState } from "react"
import { addMonths, endOfMonth, format, startOfMonth } from "date-fns"
import { Check, ChevronDown, ChevronRight, Clock3, Pencil, Plus, Trash2 } from "lucide-react"
import { toast } from "sonner"

import {
  MILESTONE_STATUSES,
  type Milestone,
  type PartnerMilestone,
  useAppStore,
} from "@/lib/store"
import { formatDisplayDate } from "@/lib/date"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { DatePicker } from "@/components/ui/date-picker"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Field, FieldError, FieldGroup } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"

type MilestoneDraft = {
  name: string
  t0OffsetStart: number
  t0OffsetEnd: number
  paymentPercentage: number
  status: string
  remarks: string
}

type PartnerDraft = Omit<PartnerMilestone, "partnermilestoneid" | "programmeid">

const blankMilestone: MilestoneDraft = {
  name: "",
  t0OffsetStart: 0,
  t0OffsetEnd: 1,
  paymentPercentage: 0,
  status: "Not Started",
  remarks: "",
}

const STATUS_COLORS: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Completed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  Delayed: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "At Risk": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
}

function scheduleFromOffsets(t0Start: string, startOffset: number, endOffset: number) {
  const t0 = new Date(`${t0Start}T00:00:00`)
  return {
    startdate: format(startOfMonth(addMonths(t0, startOffset)), "yyyy-MM-dd"),
    targetedcompletiondate: format(endOfMonth(addMonths(t0, endOffset)), "yyyy-MM-dd"),
  }
}

function MilestoneStatus({ status }: { status: string }) {
  return <Badge className={`${STATUS_COLORS[status] ?? "bg-muted"} text-[10px]`}>{status}</Badge>
}

export function MilestonesTab() {
  const store = useAppStore()
  const programmeId = store.programmeConfig.programmeid
  const t0Start = store.programmeConfig.t0Start || "2026-09-01"
  const [milestoneDialog, setMilestoneDialog] = useState(false)
  const [partnerDialog, setPartnerDialog] = useState(false)
  const [reasonDialog, setReasonDialog] = useState(false)
  const [historyId, setHistoryId] = useState<string | null>(null)
  const [t0Dialog, setT0Dialog] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingPartnerId, setEditingPartnerId] = useState<string | null>(null)
  const [deliverableParentId, setDeliverableParentId] = useState<string | null>(null)
  const [draft, setDraft] = useState<MilestoneDraft>(blankMilestone)
  const [partnerDraft, setPartnerDraft] = useState<PartnerDraft>({
    partner: "xAI", name: "", startdate: "", targetedcompletiondate: "", status: "Not Started", remarks: "",
  })
  const [reason, setReason] = useState("")
  const [cascade, setCascade] = useState(false)
  const [nextT0, setNextT0] = useState(t0Start)
  const [error, setError] = useState("")
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})

  const items = useMemo(
    () => store.milestones.filter((item) => item.programmeid === programmeId),
    [store.milestones, programmeId]
  )
  const milestones = useMemo(
    () => items.filter((item) => !item.parentMilestoneId).sort((a, b) => a.t0OffsetStart - b.t0OffsetStart),
    [items]
  )
  const partnerMilestones = useMemo(
    () => store.partnerMilestones.filter((item) => item.programmeid === programmeId),
    [store.partnerMilestones, programmeId]
  )
  const dateLogs = useMemo(
    () => store.dateChangeLogs.filter((log) => log.module === "milestone"),
    [store.dateChangeLogs]
  )
  const history = dateLogs.filter((log) => log.recordid === historyId)

  const openMilestone = (item?: Milestone) => {
    setError("")
    setDeliverableParentId(null)
    setEditingId(item?.milestoneid ?? null)
    setDraft(item ? {
      name: item.name,
      t0OffsetStart: item.t0OffsetStart,
      t0OffsetEnd: item.t0OffsetEnd,
      paymentPercentage: item.paymentPercentage,
      status: item.status,
      remarks: item.remarks,
    } : { ...blankMilestone, t0OffsetStart: milestones.at(-1)?.t0OffsetEnd ?? 0, t0OffsetEnd: (milestones.at(-1)?.t0OffsetEnd ?? 0) + 1 })
    setMilestoneDialog(true)
  }

  const openDeliverable = (parent: Milestone, item?: Milestone) => {
    setError("")
    setDeliverableParentId(parent.milestoneid)
    setEditingId(item?.milestoneid ?? null)
    setDraft(item ? {
      name: item.name,
      t0OffsetStart: item.t0OffsetStart,
      t0OffsetEnd: item.t0OffsetEnd,
      paymentPercentage: 0,
      status: item.status,
      remarks: item.remarks,
    } : {
      ...blankMilestone,
      t0OffsetStart: parent.t0OffsetStart,
      t0OffsetEnd: parent.t0OffsetEnd,
    })
    setMilestoneDialog(true)
  }

  const saveMilestone = () => {
    if (!draft.name.trim()) return setError("A milestone name is required.")
    if (draft.t0OffsetStart < 0 || draft.t0OffsetEnd < draft.t0OffsetStart) {
      return setError("The end offset must be on or after the start offset.")
    }
    if (!deliverableParentId && (draft.paymentPercentage < 0 || draft.paymentPercentage > 100)) {
      return setError("Payment percentage must be between 0 and 100.")
    }
    const existing = editingId ? items.find((item) => item.milestoneid === editingId) : undefined
    if (existing && existing.targetedcompletiondate !== scheduleFromOffsets(t0Start, draft.t0OffsetStart, draft.t0OffsetEnd).targetedcompletiondate) {
      setReason("")
      setCascade(false)
      setReasonDialog(true)
      return
    }
    persistMilestone("")
  }

  const persistMilestone = (changeReason: string) => {
    const dates = scheduleFromOffsets(t0Start, draft.t0OffsetStart, draft.t0OffsetEnd)
    const existing = editingId ? items.find((item) => item.milestoneid === editingId) : undefined
    if (!existing) {
      store.addMilestone({
        programmeid: programmeId,
        name: draft.name.trim(),
        ...dates,
        originaltargetedcompletiondate: dates.targetedcompletiondate,
        paymentreleasedate: deliverableParentId ? undefined : dates.targetedcompletiondate,
        ownerorgnodeid: "",
        status: draft.status,
        remarks: draft.remarks.trim(),
        t0OffsetStart: draft.t0OffsetStart,
        t0OffsetEnd: draft.t0OffsetEnd,
        deliverable: "",
        paymentPercentage: deliverableParentId ? 0 : draft.paymentPercentage,
        parentMilestoneId: deliverableParentId,
        assigneeNodeIds: [],
        sequence: deliverableParentId ? undefined : (milestones.at(-1)?.sequence ?? milestones.length) + 1,
      })
      toast.success(deliverableParentId ? "Deliverable added" : "Milestone added")
    } else {
      const batchId = changeReason ? `date_${crypto.randomUUID?.() ?? Date.now()}` : undefined
      const oldEnd = existing.targetedcompletiondate
      const offsetDelta = draft.t0OffsetEnd - existing.t0OffsetEnd
      store.updateMilestone(existing.milestoneid, {
        name: draft.name.trim(), ...dates, status: draft.status, remarks: draft.remarks.trim(),
        t0OffsetStart: draft.t0OffsetStart, t0OffsetEnd: draft.t0OffsetEnd,
        paymentPercentage: existing.parentMilestoneId ? 0 : draft.paymentPercentage,
        changecount: existing.changecount + (changeReason ? 1 : 0),
        lastchangereason: changeReason || existing.lastchangereason,
      })
      if (changeReason) {
        store.addDateChangeLog({
          programmeid: programmeId, module: "milestone", recordid: existing.milestoneid, recordname: existing.name,
          fieldname: "targetedcompletiondate", olddate: oldEnd, newdate: dates.targetedcompletiondate, reason: changeReason,
          changebatchid: batchId, changescope: "single",
        })
      }
      if (changeReason && cascade && offsetDelta !== 0 && !existing.parentMilestoneId) {
        const following = items.filter((item) => {
          const isFollowingParent = !item.parentMilestoneId && item.t0OffsetStart > existing.t0OffsetStart
          const parent = items.find((candidate) => candidate.milestoneid === item.parentMilestoneId)
          return isFollowingParent || Boolean(parent && parent.t0OffsetStart > existing.t0OffsetStart)
        })
        following.forEach((item) => {
          const shifted = scheduleFromOffsets(t0Start, item.t0OffsetStart + offsetDelta, item.t0OffsetEnd + offsetDelta)
          store.updateMilestone(item.milestoneid, {
            t0OffsetStart: item.t0OffsetStart + offsetDelta,
            t0OffsetEnd: item.t0OffsetEnd + offsetDelta,
            ...shifted,
            changecount: item.changecount + 1,
            lastchangereason: changeReason,
          })
          store.addDateChangeLog({
            programmeid: programmeId, module: "milestone", recordid: item.milestoneid, recordname: item.name,
            fieldname: "targetedcompletiondate", olddate: item.targetedcompletiondate, newdate: shifted.targetedcompletiondate,
            reason: changeReason, changebatchid: batchId, changescope: "subsequent",
          })
        })
      }
      toast.success(cascade ? "Milestone and subsequent schedule updated" : "Milestone updated")
    }
    setReasonDialog(false)
    setMilestoneDialog(false)
  }

  const savePartner = () => {
    if (!partnerDraft.name.trim() || !partnerDraft.startdate || !partnerDraft.targetedcompletiondate) {
      toast.error("Partner, milestone name, start date, and end date are required.")
      return
    }
    if (partnerDraft.targetedcompletiondate < partnerDraft.startdate) {
      toast.error("The end date must be on or after the start date.")
      return
    }
    if (editingPartnerId) store.updatePartnerMilestone(editingPartnerId, partnerDraft)
    else store.addPartnerMilestone({ programmeid: programmeId, ...partnerDraft })
    setPartnerDialog(false)
    toast.success(editingPartnerId ? "Partner milestone updated" : "Partner milestone added")
  }

  const updateT0 = () => {
    if (!nextT0) return
    store.updateProgrammeConfig({ t0Start: nextT0 })
    items.forEach((item) => store.updateMilestone(item.milestoneid, scheduleFromOffsets(nextT0, item.t0OffsetStart, item.t0OffsetEnd)))
    setT0Dialog(false)
    toast.success("T0 updated. Schedule dates were recalculated; payment-release dates were preserved.")
  }

  const completedPayments = milestones.filter((item) => item.status === "Completed").reduce((sum, item) => sum + item.paymentPercentage, 0)

  return (
    <div className="flex flex-col gap-5 pt-4">
      <Tabs defaultValue="programme">
        <div className="flex flex-col gap-4 rounded-xl border bg-card p-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold tracking-tight">Milestone control</h2>
            <p className="text-sm text-muted-foreground">Programme schedule is controlled from T0; payment-release dates remain contractual.</p>
          </div>
          <TabsList className="self-start">
            <TabsTrigger value="programme">Programme milestones</TabsTrigger>
            <TabsTrigger value="partner">Partner milestones</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="programme" className="mt-5 space-y-5">
          <div className="grid gap-4 md:grid-cols-3">
            <Card><CardContent className="p-4"><p className="text-xs font-medium text-muted-foreground">T0 baseline</p><p className="mt-1 text-lg font-semibold">{formatDisplayDate(t0Start)}</p><Button variant="link" className="mt-1 h-auto px-0 text-xs" onClick={() => { setNextT0(t0Start); setT0Dialog(true) }}>Change programme T0</Button></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs font-medium text-muted-foreground">Milestone payments released</p><p className="mt-1 text-lg font-semibold">{completedPayments}%</p><p className="mt-1 text-xs text-muted-foreground">Only completed top-level milestones count.</p></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs font-medium text-muted-foreground">Schedule changes</p><p className="mt-1 text-lg font-semibold">{dateLogs.length}</p><p className="mt-1 text-xs text-muted-foreground">Every changed milestone has an audit entry.</p></CardContent></Card>
          </div>
          <div className="flex items-center justify-between"><div><h3 className="font-semibold">Programme milestones</h3><p className="text-sm text-muted-foreground">Milestones run sequentially; deliverables sit beneath each milestone.</p></div><Button onClick={() => openMilestone()}><Plus className="size-4" />Add milestone</Button></div>
          <div className="overflow-hidden rounded-xl border bg-card">
            <Table>
              <TableHeader><TableRow><TableHead className="w-9" /><TableHead>Milestone / deliverable</TableHead><TableHead>Schedule</TableHead><TableHead>Payment release</TableHead><TableHead className="text-center">Payment</TableHead><TableHead>Status</TableHead><TableHead className="w-28 text-right">Actions</TableHead></TableRow></TableHeader>
              <TableBody>
                {milestones.map((milestone) => {
                  const deliverables = items.filter((item) => item.parentMilestoneId === milestone.milestoneid).sort((a, b) => a.t0OffsetStart - b.t0OffsetStart)
                  const isCollapsed = collapsed[milestone.milestoneid]
                  return <MilestoneGroup key={milestone.milestoneid} milestone={milestone} deliverables={deliverables} collapsed={isCollapsed} logs={dateLogs.filter((log) => log.recordid === milestone.milestoneid).length} onToggle={() => setCollapsed((current) => ({ ...current, [milestone.milestoneid]: !isCollapsed }))} onEdit={() => openMilestone(milestone)} onAddDeliverable={() => openDeliverable(milestone)} onEditDeliverable={(item) => openDeliverable(milestone, item)} onDelete={(id) => { store.deleteMilestone(id); toast.success("Milestone removed") }} onHistory={(id) => setHistoryId(id)} />
                })}
                {!milestones.length && <TableRow><TableCell colSpan={7} className="h-28 text-center text-muted-foreground">Add the first programme milestone to begin the T0 schedule.</TableCell></TableRow>}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        <TabsContent value="partner" className="mt-5 space-y-5">
          <div className="flex items-center justify-between"><div><h3 className="font-semibold">Partner milestones</h3><p className="text-sm text-muted-foreground">Independent partner schedule. These dates do not cascade or affect payment releases.</p></div><Button onClick={() => { setEditingPartnerId(null); setPartnerDraft({ partner: "xAI", name: "", startdate: "", targetedcompletiondate: "", status: "Not Started", remarks: "" }); setPartnerDialog(true) }}><Plus className="size-4" />Add partner milestone</Button></div>
          <div className="overflow-hidden rounded-xl border bg-card"><Table><TableHeader><TableRow><TableHead>Partner</TableHead><TableHead>Milestone</TableHead><TableHead>Start date</TableHead><TableHead>End date</TableHead><TableHead>Status</TableHead><TableHead className="w-24 text-right">Actions</TableHead></TableRow></TableHeader><TableBody>{partnerMilestones.map((item) => <TableRow key={item.partnermilestoneid}><TableCell className="font-medium">{item.partner}</TableCell><TableCell>{item.name}</TableCell><TableCell>{formatDisplayDate(item.startdate)}</TableCell><TableCell>{formatDisplayDate(item.targetedcompletiondate)}</TableCell><TableCell><MilestoneStatus status={item.status} /></TableCell><TableCell className="text-right"><Button variant="ghost" size="icon" onClick={() => { setEditingPartnerId(item.partnermilestoneid); setPartnerDraft({ partner: item.partner, name: item.name, startdate: item.startdate, targetedcompletiondate: item.targetedcompletiondate, status: item.status, remarks: item.remarks }); setPartnerDialog(true) }}><Pencil className="size-4" /></Button><Button variant="ghost" size="icon" className="text-destructive" onClick={() => { store.deletePartnerMilestone(item.partnermilestoneid); toast.success("Partner milestone removed") }}><Trash2 className="size-4" /></Button></TableCell></TableRow>)}{!partnerMilestones.length && <TableRow><TableCell colSpan={6} className="h-28 text-center text-muted-foreground">No partner milestones yet.</TableCell></TableRow>}</TableBody></Table></div>
        </TabsContent>
      </Tabs>

      <Dialog open={milestoneDialog} onOpenChange={setMilestoneDialog}><DialogContent className="sm:max-w-lg"><DialogHeader><DialogTitle>{editingId ? "Edit" : "Add"} {deliverableParentId ? "deliverable" : "milestone"}</DialogTitle><DialogDescription>{deliverableParentId ? "Deliverables inherit the schedule context of their milestone and cannot carry a payment percentage." : "Payments are held against the milestone. Its payment-release date is set once and never automatically moved by a schedule change."}</DialogDescription></DialogHeader><FieldGroup><Field><Label>Name</Label><Input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} /></Field><div className="grid grid-cols-2 gap-3"><Field><Label>T0 offset start (months)</Label><Input type="number" min="0" value={draft.t0OffsetStart} onChange={(event) => setDraft({ ...draft, t0OffsetStart: Number(event.target.value) })} /></Field><Field><Label>T0 offset end (months)</Label><Input type="number" min="0" value={draft.t0OffsetEnd} onChange={(event) => setDraft({ ...draft, t0OffsetEnd: Number(event.target.value) })} /></Field></div>{!deliverableParentId && <Field><Label>Payment percentage</Label><Input type="number" min="0" max="100" value={draft.paymentPercentage} onChange={(event) => setDraft({ ...draft, paymentPercentage: Number(event.target.value) })} /></Field>}<Field><Label>Status</Label><Select value={draft.status} onValueChange={(status) => setDraft({ ...draft, status })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{MILESTONE_STATUSES.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></Field><Field><Label>Remarks</Label><Textarea value={draft.remarks} onChange={(event) => setDraft({ ...draft, remarks: event.target.value })} /></Field>{error && <FieldError>{error}</FieldError>}</FieldGroup><DialogFooter><Button variant="outline" onClick={() => setMilestoneDialog(false)}>Cancel</Button><Button onClick={saveMilestone}>Save</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={reasonDialog} onOpenChange={setReasonDialog}><DialogContent className="sm:max-w-md"><DialogHeader><DialogTitle>Record schedule change</DialogTitle><DialogDescription>The milestone date has changed. A reason is required for the append-only audit trail.</DialogDescription></DialogHeader><Field><Label>Reason</Label><Textarea value={reason} onChange={(event) => setReason(event.target.value)} placeholder="Explain why the date moved" /></Field>{!deliverableParentId && <label className="flex cursor-pointer items-start gap-3 rounded-lg border p-3 text-sm"><Input type="checkbox" className="mt-0.5 size-4" checked={cascade} onChange={(event) => setCascade(event.target.checked)} /><span><strong>Shift all subsequent milestones</strong><br /><span className="text-muted-foreground">Move their T0 offsets by the same amount and create an audit entry for every affected record. Payment-release dates stay unchanged.</span></span></label>}<DialogFooter><Button variant="outline" onClick={() => setReasonDialog(false)}>Cancel</Button><Button disabled={!reason.trim()} onClick={() => persistMilestone(reason.trim())}><Check className="size-4" />Confirm change</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={partnerDialog} onOpenChange={setPartnerDialog}><DialogContent className="sm:max-w-lg"><DialogHeader><DialogTitle>{editingPartnerId ? "Edit" : "Add"} partner milestone</DialogTitle><DialogDescription>Partner milestones are an independent, non-cascading schedule.</DialogDescription></DialogHeader><FieldGroup><Field><Label>Partner</Label><Select value={partnerDraft.partner} onValueChange={(partner: "xAI" | "Anthropic") => setPartnerDraft({ ...partnerDraft, partner })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="xAI">xAI</SelectItem><SelectItem value="Anthropic">Anthropic</SelectItem></SelectContent></Select></Field><Field><Label>Milestone</Label><Input value={partnerDraft.name} onChange={(event) => setPartnerDraft({ ...partnerDraft, name: event.target.value })} /></Field><div className="grid grid-cols-2 gap-3"><Field><Label>Start date</Label><DatePicker value={partnerDraft.startdate} onChange={(startdate) => setPartnerDraft({ ...partnerDraft, startdate })} /></Field><Field><Label>End date</Label><DatePicker value={partnerDraft.targetedcompletiondate} onChange={(targetedcompletiondate) => setPartnerDraft({ ...partnerDraft, targetedcompletiondate })} /></Field></div><Field><Label>Status</Label><Select value={partnerDraft.status} onValueChange={(status) => setPartnerDraft({ ...partnerDraft, status })}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{MILESTONE_STATUSES.map((status) => <SelectItem key={status} value={status}>{status}</SelectItem>)}</SelectContent></Select></Field><Field><Label>Remarks</Label><Textarea value={partnerDraft.remarks} onChange={(event) => setPartnerDraft({ ...partnerDraft, remarks: event.target.value })} /></Field></FieldGroup><DialogFooter><Button variant="outline" onClick={() => setPartnerDialog(false)}>Cancel</Button><Button onClick={savePartner}>Save</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={t0Dialog} onOpenChange={setT0Dialog}><DialogContent className="sm:max-w-md"><DialogHeader><DialogTitle>Change programme T0</DialogTitle><DialogDescription>All milestone schedule dates will be recalculated from their offsets. Contractual payment-release dates will not move.</DialogDescription></DialogHeader><DatePicker value={nextT0} onChange={setNextT0} /><DialogFooter><Button variant="outline" onClick={() => setT0Dialog(false)}>Cancel</Button><Button onClick={updateT0}>Update T0</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={Boolean(historyId)} onOpenChange={(open) => !open && setHistoryId(null)}><DialogContent className="sm:max-w-lg"><DialogHeader><DialogTitle>Date change history</DialogTitle><DialogDescription>Individual audit entries are retained even when one change cascades to later milestones.</DialogDescription></DialogHeader><div className="space-y-3">{history.map((log) => <div key={log.datechangelogid} className="rounded-lg border p-3"><div className="flex items-center justify-between"><span className="font-medium">{formatDisplayDate(log.olddate)} → {formatDisplayDate(log.newdate)}</span><Badge variant="outline">{log.changescope === "subsequent" ? "Subsequent" : "Direct"}</Badge></div><p className="mt-2 text-sm text-muted-foreground">{log.reason}</p><p className="mt-2 text-xs text-muted-foreground">{formatDisplayDate(log.changedon)}{log.changebatchid ? " · grouped change" : ""}</p></div>)}{!history.length && <p className="py-6 text-center text-sm text-muted-foreground">No logged date changes.</p>}</div></DialogContent></Dialog>
    </div>
  )
}

function MilestoneGroup({ milestone, deliverables, collapsed, logs, onToggle, onEdit, onAddDeliverable, onEditDeliverable, onDelete, onHistory }: { milestone: Milestone; deliverables: Milestone[]; collapsed: boolean; logs: number; onToggle: () => void; onEdit: () => void; onAddDeliverable: () => void; onEditDeliverable: (item: Milestone) => void; onDelete: (id: string) => void; onHistory: (id: string) => void }) {
  return <><TableRow className="bg-muted/30"><TableCell><Button variant="ghost" size="icon" disabled={!deliverables.length} onClick={onToggle}>{collapsed ? <ChevronRight className="size-4" /> : <ChevronDown className="size-4" />}</Button></TableCell><TableCell className="font-semibold"><div>{milestone.name}</div><div className="mt-1 text-xs font-normal text-muted-foreground">T0+{milestone.t0OffsetStart} to T0+{milestone.t0OffsetEnd} months</div></TableCell><TableCell className="text-sm">{formatDisplayDate(milestone.startdate)} – {formatDisplayDate(milestone.targetedcompletiondate)}</TableCell><TableCell>{formatDisplayDate(milestone.paymentreleasedate ?? milestone.originaltargetedcompletiondate)}</TableCell><TableCell className="text-center font-medium">{milestone.paymentPercentage}%</TableCell><TableCell><MilestoneStatus status={milestone.status} /></TableCell><TableCell className="text-right"><Button variant="ghost" size="icon" onClick={onEdit}><Pencil className="size-4" /></Button><Button variant="ghost" size="icon" onClick={onAddDeliverable}><Plus className="size-4" /></Button>{logs > 0 && <Button variant="ghost" size="icon" onClick={() => onHistory(milestone.milestoneid)}><Clock3 className="size-4" /></Button>}<Button variant="ghost" size="icon" className="text-destructive" onClick={() => onDelete(milestone.milestoneid)}><Trash2 className="size-4" /></Button></TableCell></TableRow>{!collapsed && deliverables.map((item) => <TableRow key={item.milestoneid}><TableCell /><TableCell className="pl-8"><span className="text-muted-foreground">↳</span> {item.name}<p className="mt-1 text-xs text-muted-foreground">T0+{item.t0OffsetStart} to T0+{item.t0OffsetEnd} months</p></TableCell><TableCell className="text-sm">{formatDisplayDate(item.startdate)} – {formatDisplayDate(item.targetedcompletiondate)}</TableCell><TableCell className="text-muted-foreground">—</TableCell><TableCell className="text-center text-muted-foreground">—</TableCell><TableCell><MilestoneStatus status={item.status} /></TableCell><TableCell className="text-right"><Button variant="ghost" size="icon" onClick={() => onEditDeliverable(item)}><Pencil className="size-4" /></Button><Button variant="ghost" size="icon" className="text-destructive" onClick={() => onDelete(item.milestoneid)}><Trash2 className="size-4" /></Button></TableCell></TableRow>)}</>
}
