import { useState, useMemo, useEffect } from "react"
import { useSearchParams } from "react-router-dom"
import {
  useAppStore,
  TEAM_UPDATE_CATEGORIES,
  OVERALL_STATUSES,
  type PlaceholderTeam,
} from "@/lib/store"
import { toast } from "sonner"
import { motion, AnimatePresence } from "motion/react"
import {
  Plus,
  Trash2,
  Save,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Users,
  TrendingUp,
  ArrowLeftRight,
  Pencil,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"
import { Separator } from "@/components/ui/separator"

// ── Date Helpers ─────────────────────────────────────────────
function getISOWeek(date: Date): number {
  const d = new Date(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())
  )
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7)
}

function getCurrentWeekKey(): string {
  const now = new Date()
  const week = getISOWeek(now)
  return `${now.getFullYear()}-W${String(week).padStart(2, "0")}`
}

function getNextWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number)
  const next = w + 1
  if (next > 52) return `${year + 1}-W01`
  return `${year}-W${String(next).padStart(2, "0")}`
}

function getPrevWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number)
  const prev = w - 1
  if (prev < 1) return `${year - 1}-W52`
  return `${year}-W${String(prev).padStart(2, "0")}`
}

function weekKeyToDateRange(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number)
  const jan1 = new Date(year, 0, 1)
  const dayOfWeek = jan1.getDay() || 7
  const monday = new Date(jan1)
  monday.setDate(jan1.getDate() + (w - 1) * 7 - dayOfWeek + 1)
  const sunday = new Date(monday)
  sunday.setDate(monday.getDate() + 6)

  const fmt = (d: Date) =>
    d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" })
  return `${fmt(monday)} – ${fmt(sunday)}, ${year}`
}

// ── Category style definitions ──────────────────────────────
const CATEGORY_STYLES: Record<
  string,
  { border: string; bg: string; text: string; icon: React.ReactNode }
> = {
  Progress: {
    border: "border-l-emerald-500",
    bg: "bg-emerald-500/5",
    text: "text-emerald-700 dark:text-emerald-400",
    icon: <CheckCircle2 className="size-3.5" />,
  },
  Blockers: {
    border: "border-l-red-500",
    bg: "bg-red-500/5",
    text: "text-red-700 dark:text-red-400",
    icon: <XCircle className="size-3.5" />,
  },
  Risks: {
    border: "border-l-amber-500",
    bg: "bg-amber-500/5",
    text: "text-amber-700 dark:text-amber-400",
    icon: <AlertTriangle className="size-3.5" />,
  },
  Decisions: {
    border: "border-l-violet-500",
    bg: "bg-violet-500/5",
    text: "text-violet-700 dark:text-violet-400",
    icon: <Clock className="size-3.5" />,
  },
  "Next Week": {
    border: "border-l-blue-500",
    bg: "bg-blue-500/5",
    text: "text-blue-700 dark:text-blue-400",
    icon: <Clock className="size-3.5" />,
  },
}

const OVERALL_STATUS_STYLES: Record<
  string,
  { bg: string; text: string; icon: React.ReactNode }
> = {
  "On Track": {
    bg: "bg-emerald-100 dark:bg-emerald-900/30",
    text: "text-emerald-700 dark:text-emerald-400",
    icon: <CheckCircle2 className="size-3.5" />,
  },
  "Needs Attention": {
    bg: "bg-amber-100 dark:bg-amber-900/30",
    text: "text-amber-700 dark:text-amber-400",
    icon: <AlertTriangle className="size-3.5" />,
  },
  Blocked: {
    bg: "bg-red-100 dark:bg-red-900/30",
    text: "text-red-700 dark:text-red-400",
    icon: <XCircle className="size-3.5" />,
  },
}

// ── Local entry type for editing ────────────────────────────
type LocalItem = {
  tempId: string
  category: string
  entrytype: "positive" | "negative"
  description: string
}

let tempCounter = 0
const nextTempId = () => `tmp_${++tempCounter}`

// ═══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════
export function TeamWeeklyStatus() {
  const [searchParams, setSearchParams] = useSearchParams()
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid)
  const {
    placeholderTeams,
    updatePlaceholderTeam,
    teamGroupStatuses,
    teamGroupItems,
  } = useAppStore()

  const currentWeek = getCurrentWeekKey()
  const [selectedWeek, setSelectedWeek] = useState(currentWeek)
  const [editingTeamName, setEditingTeamName] = useState<string | null>(null)
  const [editNameValue, setEditNameValue] = useState("")

  // Use placeholder teams instead of org-derived teams
  const teams = useMemo(
    () => placeholderTeams.filter((t) => t.programmeid === programmeId),
    [placeholderTeams, programmeId]
  )

  // URL param team selection
  const teamParam = searchParams.get("team")
  const selectedTeamId =
    teamParam && teams.some((t) => t.placeholderteamid === teamParam)
      ? teamParam
      : null

  const selectedTeam = teams.find(
    (t) => t.placeholderteamid === selectedTeamId
  )

  const handleTeamChange = (id: string | null) => {
    if (id) {
      setSearchParams({ team: id })
    } else {
      setSearchParams({})
    }
  }

  const startEditName = (team: PlaceholderTeam) => {
    setEditingTeamName(team.placeholderteamid)
    setEditNameValue(team.name)
  }

  const saveTeamName = () => {
    if (editingTeamName && editNameValue.trim()) {
      updatePlaceholderTeam(editingTeamName, { name: editNameValue.trim() })
    }
    setEditingTeamName(null)
  }

  // Initials helper
  const getInitials = (name: string) =>
    name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .substring(0, 2)
      .toUpperCase()

  // Calculate status statistics for placeholder teams for selected week
  const teamSummaries = useMemo(() => {
    return teams.map((team) => {
      const statusForWeek = teamGroupStatuses.find(
        (s) =>
          s.programmeid === programmeId &&
          s.teamleadnodeid === team.placeholderteamid &&
          s.weekkey === selectedWeek
      )

      const latestStatus =
        teamGroupStatuses
          .filter(
            (s) =>
              s.programmeid === programmeId &&
              s.teamleadnodeid === team.placeholderteamid
          )
          .sort((a, b) => b.weekkey.localeCompare(a.weekkey))[0] || null

      const items = statusForWeek
        ? teamGroupItems.filter(
            (i) => i.teamgroupstatusid === statusForWeek.teamgroupstatusid
          )
        : []

      return {
        team,
        statusForWeek,
        latestStatus,
        hasUpdateThisWeek: !!statusForWeek,
        itemCount: items.length,
      }
    })
  }, [
    teams,
    teamGroupStatuses,
    teamGroupItems,
    programmeId,
    selectedWeek,
  ])

  const stats = useMemo(() => {
    const updated = teamSummaries.filter((t) => t.hasUpdateThisWeek).length
    const total = teams.length
    const blocked = teamSummaries.filter(
      (t) => t.statusForWeek?.overallstatus === "Blocked"
    ).length
    const attention = teamSummaries.filter(
      (t) => t.statusForWeek?.overallstatus === "Needs Attention"
    ).length
    return { updated, total, blocked, attention }
  }, [teamSummaries, teams.length])

  return (
    <div className="flex flex-col gap-6 pt-4 pb-12">
      {/* ── Page Header ── */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">
            Team Weekly Status
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Week {selectedWeek} · {stats.updated}/{stats.total} teams updated
            {stats.blocked > 0 && (
              <span className="ml-2 text-red-500">
                · {stats.blocked} blocked
              </span>
            )}
            {stats.attention > 0 && (
              <span className="ml-2 text-amber-500">
                · {stats.attention} need attention
              </span>
            )}
          </p>
        </div>

        {/* Global Week Navigator */}
        <div className="flex items-center gap-2 rounded-lg border bg-muted/40 p-1.5">
          <Button
            variant="ghost"
            size="icon"
            className="size-8 rounded-full"
            onClick={() => setSelectedWeek(getPrevWeekKey(selectedWeek))}
          >
            <ChevronLeft className="size-4" />
          </Button>
          <div className="flex min-w-[90px] flex-col items-center px-3">
            <span className="font-mono text-xs font-bold">{selectedWeek}</span>
            <span className="text-[9px] text-muted-foreground">
              {weekKeyToDateRange(selectedWeek).split(",")[0]}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="size-8 rounded-full"
            onClick={() => setSelectedWeek(getNextWeekKey(selectedWeek))}
          >
            <ChevronRight className="size-4" />
          </Button>
          {selectedWeek !== currentWeek && (
            <Button
              variant="outline"
              size="xs"
              className="ml-1 h-7 text-[10px]"
              onClick={() => setSelectedWeek(currentWeek)}
            >
              Current
            </Button>
          )}
        </div>
      </div>

      {/* ── Teams Selection Grid ── */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 md:grid-cols-3">
        {teamSummaries.map(
          ({
            team,
            statusForWeek,
            latestStatus,
            hasUpdateThisWeek,
            itemCount,
          }) => {
            const isSelected = selectedTeamId === team.placeholderteamid
            const overallStatus = statusForWeek?.overallstatus || "Pending"

            const statusColors: Record<
              string,
              { bg: string; border: string; text: string }
            > = {
              "On Track": {
                bg: "bg-emerald-500/8",
                border: "border-emerald-500/30",
                text: "text-emerald-700 dark:text-emerald-400",
              },
              "Needs Attention": {
                bg: "bg-amber-500/8",
                border: "border-amber-500/30",
                text: "text-amber-700 dark:text-amber-400",
              },
              Blocked: {
                bg: "bg-red-500/8",
                border: "border-red-500/30",
                text: "text-red-700 dark:text-red-400",
              },
              Pending: {
                bg: "bg-muted/40",
                border: "border-border/60",
                text: "text-muted-foreground/80",
              },
            }

            const style = statusColors[overallStatus] || statusColors.Pending
            const borderStyle = isSelected
              ? "border-primary ring-2 ring-primary/20 shadow-md"
              : style.border

            return (
              <motion.button
                key={team.placeholderteamid}
                onClick={() => handleTeamChange(team.placeholderteamid)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`relative flex h-[130px] flex-col justify-between rounded-xl border p-4 text-left shadow-sm transition-all hover:shadow-md ${style.bg} ${borderStyle} `}
              >
                {/* Top Row: Team Name and Status */}
                <div className="flex w-full items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary ring-1 ring-primary/20">
                      {getInitials(team.name)}
                    </div>
                    {editingTeamName === team.placeholderteamid ? (
                      <Input
                        value={editNameValue}
                        onChange={(e) => setEditNameValue(e.target.value)}
                        onBlur={saveTeamName}
                        onKeyDown={(e) => e.key === "Enter" && saveTeamName()}
                        className="h-7 w-32 text-xs"
                        autoFocus
                        onClick={(e) => e.stopPropagation()}
                      />
                    ) : (
                      <div
                        className="group/name flex items-center gap-1 cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation()
                          startEditName(team)
                        }}
                      >
                        <span className="truncate text-xs font-bold text-foreground">
                          {team.name}
                        </span>
                        <Pencil className="size-3 text-muted-foreground opacity-0 group-hover/name:opacity-100 transition-opacity" />
                      </div>
                    )}
                  </div>
                  {hasUpdateThisWeek && (
                    <Badge
                      variant="outline"
                      className={`border-0 px-1.5 py-0 text-[8px] font-bold ${style.text}`}
                    >
                      {statusForWeek?.overallstatus}
                    </Badge>
                  )}
                  {!hasUpdateThisWeek && (
                    <Badge
                      variant="secondary"
                      className="px-1.5 py-0 text-[8px] opacity-70"
                    >
                      Pending
                    </Badge>
                  )}
                </div>

                {/* Bottom Row: Stats */}
                <div className="mt-3 flex w-full items-center justify-between border-t border-border/40 pt-2.5">
                  <span className="text-[10px] text-muted-foreground">
                    {team.members.length > 0
                      ? `${team.members.length} members`
                      : "No members assigned"}
                  </span>
                  <span className="font-mono text-[9px] font-medium text-muted-foreground">
                    {hasUpdateThisWeek
                      ? `${itemCount} items`
                      : `Last: ${latestStatus?.weekkey || "None"}`}
                  </span>
                </div>
              </motion.button>
            )
          }
        )}
      </div>

      {/* ── Main Reporting Workspace ── */}
      <AnimatePresence mode="wait">
        {selectedTeamId && selectedTeam ? (
          <motion.div
            key={`${selectedTeamId}-${selectedWeek}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
          >
            <TeamWeeklyEditor
              programmeId={programmeId}
              team={selectedTeam}
              weekKey={selectedWeek}
            />
          </motion.div>
        ) : (
          <Card className="border-dashed py-14">
            <CardContent className="flex flex-col items-center text-center text-muted-foreground">
              <Users className="mb-3 size-10 text-muted-foreground/30" />
              <h4 className="text-sm font-semibold text-foreground">
                Select a Reporting Team
              </h4>
              <p className="mx-auto mt-1 max-w-xs text-xs leading-relaxed">
                Click any team card above to view status history, record
                blockers, capture risks, and document weekly progress.
              </p>
            </CardContent>
          </Card>
        )}
      </AnimatePresence>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// TEAM WEEKLY EDITOR
// ═══════════════════════════════════════════════════════════════
function TeamWeeklyEditor({
  programmeId,
  team,
  weekKey,
}: {
  programmeId: string
  team: PlaceholderTeam
  weekKey: string
}) {
  const {
    teamGroupStatuses,
    teamGroupItems,
    addTeamGroupStatus,
    updateTeamGroupStatus,
    bulkSetTeamGroupItems,
  } = useAppStore()

  const [localItems, setLocalItems] = useState<LocalItem[]>([])
  const [summary, setSummary] = useState("")
  const [overallStatus, setOverallStatus] = useState("On Track")
  const [isSaving, setIsSaving] = useState(false)
  const [isDirty, setIsDirty] = useState(false)
  const [showChanges, setShowChanges] = useState(false)

  // Find status for current selection
  const selectedStatus = useMemo(() => {
    return teamGroupStatuses.find(
      (s) =>
        s.programmeid === programmeId &&
        s.teamleadnodeid === team.placeholderteamid &&
        s.weekkey === weekKey
    )
  }, [teamGroupStatuses, programmeId, team.placeholderteamid, weekKey])

  // Previous week status for carried-forward or comparison
  const prevWeekKey = getPrevWeekKey(weekKey)
  const prevStatus = useMemo(() => {
    return teamGroupStatuses.find(
      (s) =>
        s.programmeid === programmeId &&
        s.teamleadnodeid === team.placeholderteamid &&
        s.weekkey === prevWeekKey
    )
  }, [
    teamGroupStatuses,
    programmeId,
    team.placeholderteamid,
    prevWeekKey,
  ])

  const prevItems = useMemo(() => {
    return prevStatus
      ? teamGroupItems.filter(
          (i) => i.teamgroupstatusid === prevStatus.teamgroupstatusid
        )
      : []
  }, [prevStatus, teamGroupItems])

  // Load or pre-fill items when weekKey/team changes
  useEffect(() => {
    let active = true
    queueMicrotask(() => {
      if (!active) return
      if (selectedStatus) {
        const items = teamGroupItems.filter(
          (i) => i.teamgroupstatusid === selectedStatus.teamgroupstatusid
        )
        setLocalItems(
          items.map((i) => ({
            tempId: nextTempId(),
            category: i.category,
            entrytype: i.entrytype as "positive" | "negative",
            description: i.description,
          }))
        )
        setSummary(selectedStatus.summary)
        setOverallStatus(selectedStatus.overallstatus)
      } else {
        // New update - pre-fill placeholders for each of the 5 categories
        const starters: LocalItem[] = []

        // If there are previous week items, carry them forward as initial state (pre-filled draft)
        if (prevItems.length > 0) {
          prevItems.forEach((i) => {
            starters.push({
              tempId: nextTempId(),
              category: i.category,
              entrytype: i.entrytype as "positive" | "negative",
              description: i.description,
            })
          })
        } else {
          // Fallback starters: one positive and one negative for each category
          TEAM_UPDATE_CATEGORIES.forEach((cat) => {
            starters.push({
              tempId: nextTempId(),
              category: cat,
              entrytype: "positive",
              description: "",
            })
            starters.push({
              tempId: nextTempId(),
              category: cat,
              entrytype: "negative",
              description: "",
            })
          })
        }
        setLocalItems(starters)
        setSummary("")
        setOverallStatus("On Track")
      }
      setIsDirty(false)
      setShowChanges(false)
    })
    return () => {
      active = false
    }
  }, [selectedStatus, teamGroupItems, prevItems])

  const handleAddItem = (
    category: string,
    entrytype: "positive" | "negative"
  ) => {
    setLocalItems((prev) => [
      ...prev,
      { tempId: nextTempId(), category, entrytype, description: "" },
    ])
    setIsDirty(true)
  }

  const handleRemoveItem = (tempId: string) => {
    setLocalItems((prev) => prev.filter((i) => i.tempId !== tempId))
    setIsDirty(true)
  }

  const handleUpdateItem = (tempId: string, desc: string) => {
    setLocalItems((prev) =>
      prev.map((i) => (i.tempId === tempId ? { ...i, description: desc } : i))
    )
    setIsDirty(true)
  }

  // Group items by category
  const itemsByCategory = useMemo(() => {
    const map: Record<
      string,
      { positive: LocalItem[]; negative: LocalItem[] }
    > = {}
    TEAM_UPDATE_CATEGORIES.forEach((cat) => {
      map[cat] = { positive: [], negative: [] }
    })
    localItems.forEach((item) => {
      if (map[item.category]) {
        map[item.category][item.entrytype].push(item)
      }
    })
    return map
  }, [localItems])

  // Group previous items by category for comparison
  const prevItemsByCategory = useMemo(() => {
    const map: Record<string, { positive: string[]; negative: string[] }> = {}
    TEAM_UPDATE_CATEGORIES.forEach((cat) => {
      map[cat] = { positive: [], negative: [] }
    })
    prevItems.forEach((item) => {
      if (map[item.category]) {
        map[item.category][item.entrytype as "positive" | "negative"].push(
          item.description
        )
      }
    })
    return map
  }, [prevItems])

  // Save changes
  const handleSave = async () => {
    setIsSaving(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      const validItems = localItems.filter((i) => i.description.trim())

      if (selectedStatus) {
        updateTeamGroupStatus(selectedStatus.teamgroupstatusid, {
          summary: summary.trim(),
          overallstatus: overallStatus,
          submittedon: new Date().toISOString(),
          memberNodeIds: team.members,
        })
        bulkSetTeamGroupItems(
          selectedStatus.teamgroupstatusid,
          validItems.map((i) => ({
            teamgroupstatusid: selectedStatus.teamgroupstatusid,
            category: i.category,
            entrytype: i.entrytype,
            description: i.description.trim(),
          }))
        )
      } else {
        // Create new
        const createdStatus = addTeamGroupStatus({
          programmeid: programmeId,
          teamleadnodeid: team.placeholderteamid,
          weekkey: weekKey,
          submittedon: new Date().toISOString(),
          overallstatus: overallStatus,
          summary: summary.trim(),
          memberNodeIds: team.members,
        })

        bulkSetTeamGroupItems(
          createdStatus.teamgroupstatusid,
          validItems.map((i) => ({
            teamgroupstatusid: createdStatus.teamgroupstatusid,
            category: i.category,
            entrytype: i.entrytype,
            description: i.description.trim(),
          }))
        )
      }

      setIsDirty(false)
      toast.success(`Week ${weekKey} saved for ${team.name}`)
    } catch {
      toast.error("Failed to save weekly update")
    } finally {
      setIsSaving(false)
    }
  }

  const totalPositive = localItems.filter(
    (i) => i.entrytype === "positive" && i.description.trim()
  ).length
  const totalNegative = localItems.filter(
    (i) => i.entrytype === "negative" && i.description.trim()
  ).length

  return (
    <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[300px_1fr]">
      {/* ── Left Column: Metadata & Controls ── */}
      <div className="space-y-4">
        <Card className="border border-border/80 shadow-xs">
          <CardContent className="space-y-4 p-4">
            <div>
              <Label className="mb-1 block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
                Reporting Unit
              </Label>
              <div className="text-sm font-bold text-foreground">
                {team.name}
              </div>
              <div className="text-xs text-muted-foreground">
                {team.remarks || "No description"}
              </div>
            </div>

            <Separator />

            {/* Team Info */}
            <div>
              <Label className="mb-2 block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
                Team Members ({team.members.length})
              </Label>
              {team.members.length === 0 ? (
                <p className="text-xs text-muted-foreground">No members assigned yet.</p>
              ) : (
                <div className="max-h-[180px] space-y-1.5 overflow-y-auto pr-1">
                  {team.members.map((member, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 text-xs"
                    >
                      <div className="flex size-5 shrink-0 items-center justify-center rounded-full bg-secondary text-[8px] font-bold text-secondary-foreground">
                        {(idx + 1).toString()}
                      </div>
                      <span className="truncate font-medium text-foreground">
                        {member}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Separator />

            {/* Overall Status Selector */}
            <div className="space-y-2">
              <Label className="block text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
                Team Health Status
              </Label>
              <div className="flex flex-col gap-1.5">
                {OVERALL_STATUSES.map((status) => {
                  const style = OVERALL_STATUS_STYLES[status]
                  const isSelected = overallStatus === status
                  return (
                    <button
                      key={status}
                      onClick={() => {
                        setOverallStatus(status)
                        setIsDirty(true)
                      }}
                      className={`flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-left text-xs font-semibold transition-all ${
                        isSelected
                          ? `${style.bg} ${style.text} border-current/25 shadow-xs`
                          : "border-border/50 bg-card text-muted-foreground hover:bg-muted"
                      } `}
                    >
                      {style.icon}
                      {status}
                    </button>
                  )
                })}
              </div>
            </div>

            <Separator />

            {/* Save Update Button */}
            <div className="space-y-2">
              <Button
                onClick={handleSave}
                disabled={isSaving || (!isDirty && !!selectedStatus)}
                className="h-9 w-full text-xs"
              >
                {isSaving ? (
                  <Spinner data-icon="inline-start" />
                ) : (
                  <Save className="mr-1.5 size-3" />
                )}
                Save Team Status
              </Button>
              {prevStatus && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowChanges(!showChanges)}
                  className="w-full text-xs"
                >
                  <ArrowLeftRight className="mr-1.5 size-3.5" />
                  {showChanges ? "Hide Changes" : "Compare Changes"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* History / Timeline shortcut */}
        <Card className="border border-dashed bg-muted/15 p-4 text-center">
          <p className="text-[11px] leading-normal text-muted-foreground">
            Past team submissions are frozen in history based on the team
            composition snapshot recorded at the time of publication.
          </p>
        </Card>
      </div>

      {/* ── Right Column: Categories and Summary ── */}
      <div className="flex-1 space-y-4">
        {/* Week Summary Box */}
        <Card className="border border-border/80 shadow-xs">
          <CardContent className="space-y-1.5 p-4">
            <Label className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
              Executive Summary
            </Label>
            <Textarea
              value={summary}
              onChange={(e) => {
                setSummary(e.target.value)
                setIsDirty(true)
              }}
              placeholder="Highlight key achievements, priority engineering goals, and outstanding blockers for the week..."
              className="min-h-[75px] resize-y text-xs"
            />
          </CardContent>
        </Card>

        {/* Grid of Update Categories */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h4 className="text-sm font-bold text-foreground">
              Updates by Category
            </h4>
            <div className="flex gap-3 font-mono text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-emerald-500" />
                {totalPositive} Positives
              </span>
              <span className="flex items-center gap-1">
                <span className="size-1.5 rounded-full bg-red-500" />
                {totalNegative} Challenges
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {TEAM_UPDATE_CATEGORIES.map((category) => {
              const style =
                CATEGORY_STYLES[category] || CATEGORY_STYLES.Progress
              const items = itemsByCategory[category] || {
                positive: [],
                negative: [],
              }
              const prevItemsForCat = prevItemsByCategory[category]

              return (
                <Card
                  key={category}
                  className={`overflow-hidden border-l-[3px] ${style.border} bg-gradient-to-b ${style.bg} border-t border-r border-b border-border/60 shadow-xs`}
                >
                  <CardContent className="space-y-4 p-4">
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-border/20 pb-2">
                      <div className="flex items-center gap-2">
                        <span className={style.text}>{style.icon}</span>
                        <span className="text-xs font-bold tracking-tight text-foreground">
                          {category}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      {/* Positive Developments */}
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1 text-[10px] font-bold tracking-wider text-emerald-600 uppercase dark:text-emerald-400">
                            <CheckCircle2 className="size-3" />
                            Positives / Accomplished
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-5 text-emerald-600 hover:bg-emerald-500/10"
                            onClick={() => handleAddItem(category, "positive")}
                          >
                            <Plus className="size-3" />
                          </Button>
                        </div>
                        <div className="space-y-1.5">
                          {items.positive.map((item) => {
                            const isNew =
                              showChanges &&
                              prevItemsForCat &&
                              !prevItemsForCat.positive.includes(
                                item.description
                              ) &&
                              item.description.trim()
                            return (
                              <div
                                key={item.tempId}
                                className="group flex items-center gap-1.5"
                              >
                                <div
                                  className={`size-1.5 shrink-0 rounded-full ${item.description.trim() ? "bg-emerald-500" : "bg-muted"}`}
                                />
                                <Input
                                  value={item.description}
                                  onChange={(e) =>
                                    handleUpdateItem(
                                      item.tempId,
                                      e.target.value
                                    )
                                  }
                                  placeholder="Record positive outcome..."
                                  className="h-7 border-transparent bg-transparent text-xs transition-all hover:bg-card/40 focus:border-input focus:bg-card"
                                />
                                {isNew && (
                                  <Badge className="shrink-0 bg-emerald-100 px-1 py-0 text-[8px] text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400">
                                    New
                                  </Badge>
                                )}
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                                  onClick={() => handleRemoveItem(item.tempId)}
                                >
                                  <Trash2 className="size-3" />
                                </Button>
                              </div>
                            )
                          })}
                          {/* Show removed positives */}
                          {showChanges &&
                            prevItemsForCat &&
                            prevItemsForCat.positive
                              .filter(
                                (desc) =>
                                  !items.positive.some(
                                    (i) => i.description === desc
                                  )
                              )
                              .map((desc, idx) => (
                                <div
                                  key={`removed-pos-${idx}`}
                                  className="flex items-center gap-1.5 opacity-55"
                                >
                                  <div className="size-1.5 shrink-0 rounded-full bg-red-400" />
                                  <span className="flex-1 truncate text-xs text-red-500 line-through">
                                    {desc}
                                  </span>
                                  <Badge className="shrink-0 bg-red-100 px-1 py-0 text-[8px] text-red-800 dark:bg-red-900/30 dark:text-red-400">
                                    Removed
                                  </Badge>
                                </div>
                              ))}
                        </div>
                      </div>

                      {/* Challenges */}
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1 text-[10px] font-bold tracking-wider text-red-600 uppercase dark:text-red-400">
                            <XCircle className="size-3" />
                            Challenges / Actions
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-5 text-red-600 hover:bg-red-500/10"
                            onClick={() => handleAddItem(category, "negative")}
                          >
                            <Plus className="size-3" />
                          </Button>
                        </div>
                        <div className="space-y-1.5">
                          {items.negative.map((item) => {
                            const isNew =
                              showChanges &&
                              prevItemsForCat &&
                              !prevItemsForCat.negative.includes(
                                item.description
                              ) &&
                              item.description.trim()
                            return (
                              <div
                                key={item.tempId}
                                className="group flex items-center gap-1.5"
                              >
                                <div
                                  className={`size-1.5 shrink-0 rounded-full ${item.description.trim() ? "bg-red-500" : "bg-muted"}`}
                                />
                                <Input
                                  value={item.description}
                                  onChange={(e) =>
                                    handleUpdateItem(
                                      item.tempId,
                                      e.target.value
                                    )
                                  }
                                  placeholder="Record bottleneck or action..."
                                  className="h-7 border-transparent bg-transparent text-xs transition-all hover:bg-card/40 focus:border-input focus:bg-card"
                                />
                                {isNew && (
                                  <Badge className="shrink-0 bg-emerald-100 px-1 py-0 text-[8px] text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400">
                                    New
                                  </Badge>
                                )}
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="size-5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                                  onClick={() => handleRemoveItem(item.tempId)}
                                >
                                  <Trash2 className="size-3" />
                                </Button>
                              </div>
                            )
                          })}
                          {/* Show removed negatives */}
                          {showChanges &&
                            prevItemsForCat &&
                            prevItemsForCat.negative
                              .filter(
                                (desc) =>
                                  !items.negative.some(
                                    (i) => i.description === desc
                                  )
                              )
                              .map((desc, idx) => (
                                <div
                                  key={`removed-neg-${idx}`}
                                  className="flex items-center gap-1.5 opacity-55"
                                >
                                  <div className="size-1.5 shrink-0 rounded-full bg-red-400" />
                                  <span className="flex-1 truncate text-xs text-red-500 line-through">
                                    {desc}
                                  </span>
                                  <Badge className="shrink-0 bg-red-100 px-1 py-0 text-[8px] text-red-800 dark:bg-red-900/30 dark:text-red-400">
                                    Removed
                                  </Badge>
                                </div>
                              ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        <Separator />

        {/* ── Timeline Section ── */}
        <TeamWeeklyTimeline
          programmeId={programmeId}
          teamLeadId={team.placeholderteamid}
        />
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// TEAM TIMELINE COMPONENT
// ═══════════════════════════════════════════════════════════════
function TeamWeeklyTimeline({
  programmeId,
  teamLeadId,
}: {
  programmeId: string
  teamLeadId: string
}) {
  const { teamGroupStatuses, teamGroupItems } = useAppStore()
  const [expandedStatuses, setExpandedStatuses] = useState<Set<string>>(
    new Set()
  )

  const statuses = useMemo(() => {
    return teamGroupStatuses
      .filter(
        (s) => s.programmeid === programmeId && s.teamleadnodeid === teamLeadId
      )
      .sort((a, b) => b.weekkey.localeCompare(a.weekkey))
  }, [teamGroupStatuses, programmeId, teamLeadId])

  const toggleExpand = (id: string) => {
    setExpandedStatuses((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  if (statuses.length === 0) {
    return (
      <div className="rounded-lg border border-dashed bg-muted/10 py-8 text-center text-xs text-muted-foreground">
        <TrendingUp className="mx-auto mb-2 size-6 opacity-30" />
        No historical weekly updates found for this team.
      </div>
    )
  }

  return (
    <div className="space-y-3">
      <h4 className="flex items-center gap-2 text-sm font-bold">
        <TrendingUp className="size-4" />
        Activity Timeline
      </h4>
      <div className="relative space-y-4 pl-6">
        {/* Timeline bar */}
        <div className="absolute top-2 bottom-2 left-[11px] w-px bg-border" />

        {statuses.map((status) => {
          const isExpanded = expandedStatuses.has(status.teamgroupstatusid)
          const style =
            OVERALL_STATUS_STYLES[status.overallstatus] ||
            OVERALL_STATUS_STYLES["On Track"]
          const items = teamGroupItems.filter(
            (i) => i.teamgroupstatusid === status.teamgroupstatusid
          )

          return (
            <div key={status.teamgroupstatusid} className="relative">
              {/* Timeline Dot */}
              <div
                className={`absolute top-2 -left-6 z-10 size-2.5 rounded-full border-2 ${style.bg} border-current ${style.text} `}
              />

              {/* Status Header Block */}
              <button
                onClick={() => toggleExpand(status.teamgroupstatusid)}
                className="flex w-full flex-col gap-1.5 rounded-lg border border-border/70 bg-card p-3 text-left transition-all hover:shadow-xs"
              >
                <div className="flex w-full items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-foreground">
                      {status.weekkey}
                    </span>
                    <Badge
                      className={`border-0 px-1 py-0 text-[9px] ${style.bg} ${style.text}`}
                    >
                      {status.overallstatus}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                    <span>{items.length} updates</span>
                    <motion.div animate={{ rotate: isExpanded ? 90 : 0 }}>
                      <ChevronRight className="size-3" />
                    </motion.div>
                  </div>
                </div>
                <p className="line-clamp-2 text-xs leading-normal text-muted-foreground">
                  {status.summary}
                </p>
              </button>

              {/* Expanded Category Details */}
              <AnimatePresence>
                {isExpanded && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="space-y-3 pt-2 pl-4">
                      {TEAM_UPDATE_CATEGORIES.map((cat) => {
                        const catItems = items.filter((i) => i.category === cat)
                        if (catItems.length === 0) return null
                        const catStyle =
                          CATEGORY_STYLES[cat] || CATEGORY_STYLES.Progress

                        return (
                          <div
                            key={cat}
                            className={`rounded-lg border-l-2 ${catStyle.border} space-y-1.5 bg-muted/30 p-2.5 text-xs`}
                          >
                            <p className="text-[10px] font-bold text-foreground uppercase">
                              {cat}
                            </p>
                            <div className="space-y-1">
                              {catItems.map((item) => (
                                <div
                                  key={item.teamgroupitemid}
                                  className="flex gap-2 leading-relaxed"
                                >
                                  <span
                                    className={`mt-1.5 size-1.5 shrink-0 rounded-full ${item.entrytype === "positive" ? "bg-emerald-500" : "bg-red-500"}`}
                                  />
                                  <span className="text-muted-foreground">
                                    {item.description}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )
        })}
      </div>
    </div>
  )
}
