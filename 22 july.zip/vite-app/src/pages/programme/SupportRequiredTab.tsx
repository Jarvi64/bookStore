import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useAppStore,
  SUPPORT_CATEGORIES,
  SUPPORT_CRITICALITIES,
} from "@/lib/store";
import { toast } from "sonner";
import { Plus, Pencil, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const schema = z.object({
  supporttext: z.string().min(2, "Support description is required"),
  category: z.string().min(1, "Category is required"),
  criticality: z.string().min(1, "Criticality is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  remarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const CRITICALITY_COLORS: Record<string, string> = {
  Low: "bg-muted text-muted-foreground",
  Medium: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  High: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  Critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export function SupportRequiredTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid);
  const {
    supportRequired,
    programmeOrgNodes,
    addSupportRequired,
    updateSupportRequired,
    deleteSupportRequired,
  } = useAppStore();

  const items = supportRequired.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes",
  );
  const orgNodeNames = orgNodes.map((n) => n.displayname);
  const categoryItems = [...SUPPORT_CATEGORIES];
  const criticalityItems = [...SUPPORT_CRITICALITIES];

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const openAddDialog = () => {
    reset({
      supporttext: "",
      category: "",
      criticality: "",
      ownerorgnodeid: "",
      remarks: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((s) => s.supportrequiredid === id);
    if (item) {
      reset({ ...item });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    setIsSaving(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      if (editingId) {
        updateSupportRequired(editingId, { ...data, programmeid: programmeId, remarks: data.remarks || "" });
        toast.success("Support item updated");
      } else {
        addSupportRequired({ ...data, programmeid: programmeId, remarks: data.remarks || "" });
        toast.success("Support item added");
      }
      setIsDialogOpen(false);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      deleteSupportRequired(deleteTarget);
      toast.success("Support item deleted");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="flex flex-col gap-4 pt-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Support Required</h3>
          <p className="text-sm text-muted-foreground">
            Track support needs across programme categories.
          </p>
        </div>
        <Button onClick={openAddDialog}>
          <Plus data-icon="inline-start" />
          Add Support Item
        </Button>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[200px]">Support</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Criticality</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Remarks</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={6}
                  className="h-24 text-center text-muted-foreground"
                >
                  No support items yet.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => {
                return (
                  <TableRow key={item.supportrequiredid}>
                    <TableCell className="font-medium text-foreground">
                      <p className="line-clamp-2 text-sm">{item.supporttext}</p>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          CRITICALITY_COLORS[item.criticality] ||
                          CRITICALITY_COLORS["Low"]
                        }
                      >
                        {item.criticality}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">
                      {orgNodes.find((n) => n.programmeorgnodeid === item.ownerorgnodeid)?.displayname || "—"}
                    </TableCell>
                    <TableCell className="text-sm max-w-[200px] truncate" title={item.remarks}>
                      {item.remarks || "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            openEditDialog(item.supportrequiredid)
                          }
                        >
                          <Pencil />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() =>
                            setDeleteTarget(item.supportrequiredid)
                          }
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Support Item" : "Add Support Item"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Support required details form.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FieldGroup>
              <Field data-invalid={!!errors.supporttext || undefined}>
                <Label htmlFor="sup-text">Support Description</Label>
                <Textarea
                  id="sup-text"
                  {...register("supporttext")}
                  placeholder="Describe the support needed..."
                  aria-invalid={!!errors.supporttext || undefined}
                />
                {errors.supporttext && (
                  <FieldError>{errors.supporttext.message}</FieldError>
                )}
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.category || undefined}>
                  <Label>Category</Label>
                  <Controller
                    control={control}
                    name="category"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={categoryItems}
                      >
                        <ComboboxInput placeholder="Select category" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.category && (
                    <FieldError>{errors.category.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.criticality || undefined}>
                  <Label>Criticality</Label>
                  <Controller
                    control={control}
                    name="criticality"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={criticalityItems}
                      >
                        <ComboboxInput placeholder="Select level" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.criticality && (
                    <FieldError>{errors.criticality.message}</FieldError>
                  )}
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.ownerorgnodeid || undefined}>
                  <Label>Owner</Label>
                  <Controller
                    control={control}
                    name="ownerorgnodeid"
                    render={({ field }) => {
                      const selectedName =
                        orgNodes.find(
                          (n) => n.programmeorgnodeid === field.value,
                        )?.displayname ?? null;
                      return (
                        <Combobox
                          value={selectedName}
                          onValueChange={(name: string | null) => {
                            const node = orgNodes.find(
                              (n) => n.displayname === name,
                            );
                            field.onChange(node?.programmeorgnodeid ?? "");
                          }}
                          items={orgNodeNames}
                        >
                          <ComboboxInput placeholder="Select owner" />
                          <ComboboxContent>
                            <ComboboxEmpty>No match.</ComboboxEmpty>
                            <ComboboxList>
                              {(name: string) => (
                                <ComboboxItem key={name} value={name}>
                                  {name}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      );
                    }}
                  />
                  {errors.ownerorgnodeid && (
                    <FieldError>{errors.ownerorgnodeid.message}</FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Remarks</Label>
                  <Textarea
                    {...register("remarks")}
                    placeholder="Additional remarks..."
                    rows={2}
                  />
                </Field>
              </div>
            </FieldGroup>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSaving}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <Spinner data-icon="inline-start" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete support item?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
