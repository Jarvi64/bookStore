# Dataverse table schema

This is the proposed logical schema for the wireframe. Replace the placeholder `ada_` prefix with the publisher prefix allocated in your environment before import. Use Dataverse GUID primary keys, not the wireframe IDs.

## Conventions

- Every custom table includes the default Dataverse ID, primary-name, owner, state/status, `createdon`, and `modifiedon` columns.
- Use **Date Only** for business dates and **Date and Time (User Local)** for submission/change timestamps.
- Use lookups for foreign keys. Never persist a display name as a relationship.
- Use choice columns for the listed status/category values. Make required business fields Business Required.

## Tables

| Table                       | Primary name | Custom columns                                                                                                                                                                                                                                                        |
| --------------------------- | ------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ada_programme`             | `ada_name`   | business unit, capability, POC 1, POC 2, last reporting week, notes, T0 start                                                                                                                                                                                         |
| `ada_programmeorgnode`      | display name | programme (lookup), title, sort order, active (yes/no), parent node (self lookup), org type (Admin/Deliverables)                                                                                                                                                      |
| `ada_milestone`             | name         | programme (lookup), sequence (whole number), T0 offset start/end (whole number), schedule start/end (Date Only), contractual payment-release date (Date Only), payment % (decimal), status (Not Started/In Progress/Completed/Delayed/At Risk), remarks, change count, last change reason, parent milestone (self lookup, **deliverables only**) |
| `ada_partnermilestone`      | name         | programme (lookup), partner (choice: xAI/Anthropic), start date (Date Only), end date (Date Only), status (same choice), remarks                                                                                                                                    |
| `ada_supportrequired`       | support text | programme, category, criticality (Low/Medium/High/Critical), owner org node, deadline, status (Open/In Progress/Resolved/Closed)                                                                                                                                      |
| `ada_datechangelog`         | record name  | programme (lookup), module (choice), affected record ID, field name, old date, new date, reason, changed on, change batch ID, change scope (Single/Subsequent)                                                                                                      |
| `ada_manpowergaphiringplan` | role         | programme, required quantity, filled quantity, sourcing channel (IJP/External), target join date, priority, remarks                                                                                                                                                   |
| `ada_manpowerdeliverable`   | role         | programme, qualification, experience, required quantity, remarks                                                                                                                                                                                                      |
| `ada_weeklyupdate`          | week key     | programme, submitted on, status (Draft/Submitted); alternate key on programme + week key                                                                                                                                                                              |
| `ada_weeklyupdateitem`      | name         | weekly update (lookup), category, entry type (Positive/Negative), description                                                                                                                                                                                         |
| `ada_partnerdeliverable`    | deliverable  | programme, partner name, target EDC, current EDC, status, risk remarks, owner org node                                                                                                                                                                                |
| `ada_capexbudget`           | item         | programme, budget CR, actual CR, commissioning date, owner org node                                                                                                                                                                                                   |
| `ada_opexbudget`            | item         | programme, supplier, unit cost CR, target cost CR, deadline, owner org node                                                                                                                                                                                           |
| `ada_certification`         | name         | programme, owner org node, status (Pending/In Review/Approved/Rejected/Expired), validity date, current EDC, risk remarks                                                                                                                                             |
| `ada_supplychainreadiness`  | item         | programme, supplier, actual/target/variance CR, status (Sourcing/Ordered/In Transit/Delivered/Delayed), risk remarks, order/delivery dates, lead time, owner org node, milestone, quantity, PR/PO dates/numbers/value, payment released                               |
| `ada_teamgroupweeklystatus` | week key     | programme, team lead org node, submitted on, overall status (On Track/Needs Attention/Blocked), summary; alternate key on programme + team lead + week key                                                                                                            |
| `ada_teamgroupweeklyitem`   | name         | team group weekly status (lookup), category (Progress/Blockers/Risks/Decisions/Next Week), entry type, description                                                                                                                                                    |

## Relationships

```text
Programme 1—N Org Nodes (self-parent hierarchy)
Programme 1—N Milestones (self-parent hierarchy: milestone 1—N deliverables)
Programme 1—N Partner Milestones
Programme 1—N all remaining programme tables
Weekly Update 1—N Weekly Update Items
Team Group Weekly Status 1—N Team Group Weekly Items
Org Node 1—N records assigned to an owner
Milestone 1—N Supply Chain Readiness records
```

## Server-side validation

- End milestone offset must be at least the start offset; payment percentage is 0–100 and is permitted only on top-level milestones.
- When a schedule change is confirmed with "shift subsequent milestones", update every affected milestone and append one `ada_datechangelog` row per record with a shared change-batch ID. Never automatically move `ada_paymentreleasedate`.
- Filled hiring quantity cannot exceed required quantity.
- An org node cannot reference itself or a descendant as parent.
- Date-change logs are append-only and created atomically with a tracked date change.
- Recalculate supply-chain variance (`target - actual`) server-side. Its UI code was intentionally not changed in this refactor.
