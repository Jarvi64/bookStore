import React from "react";
import { format } from "date-fns";
import { Clock, ArrowRight, AlertTriangle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { DateChangeLog } from "@/lib/store";

interface DateChangePopoverProps {
  logs: DateChangeLog[];
  children: React.ReactNode;
}

export function DateChangePopover({ logs, children }: DateChangePopoverProps) {
  const [recentCutoff] = React.useState(() => new Date(Date.now() - 7 * 86400000));

  if (!logs || logs.length === 0) {
    return <>{children}</>;
  }

  const formatDateTime = (dateStr: string) => {
    try {
      return format(new Date(dateStr), "MMM d, h:mm a");
    } catch {
      return dateStr;
    }
  };

  const formatDateOnly = (dateStr: string) => {
    try {
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        const [y, m, d] = dateStr.split('-');
        return format(new Date(Number(y), Number(m)-1, Number(d)), "MMM d, yyyy");
      }
      return format(new Date(dateStr), "MMM d, yyyy");
    } catch {
      return dateStr;
    }
  };

  const fieldLabel = (fieldname: string) => {
    const mappings: Record<string, string> = {
      targetedcompletiondate: "Target Date",
      currentedc: "Current EDC",
      targetedc: "Target EDC",
      commisiongdate: "Commissioning",
      deadline: "Deadline",
      validitydate: "Validity Date",
      dateoforder: "Order Date",
      dateofdelivery: "Delivery Date",
    };
    return mappings[fieldname.toLowerCase()] || fieldname;
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <button className="flex items-center gap-1.5 hover:underline cursor-pointer group/date transition-colors outline-none ring-primary focus-visible:ring-2 rounded-sm text-amber-600 font-medium">
          {children}
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="size-5 text-amber-500" />
            Date Change History
          </DialogTitle>
          <DialogDescription>
            Historical log of changes made to this date.
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="max-h-[50vh] pr-4 mt-2">
          <div className="flex flex-col gap-3">
            {logs.map((log) => {
              const isRecent = new Date(log.changedon) >= recentCutoff;
              return (
                <div
                  key={log.datechangelogid}
                  className={`rounded-lg border px-4 py-3 transition-colors ${
                    isRecent
                      ? "border-amber-200 bg-amber-50/50 dark:border-amber-800/30 dark:bg-amber-950/10"
                      : "bg-card"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <Badge variant="secondary" className="text-xs font-normal">
                      {fieldLabel(log.fieldname)}
                    </Badge>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="size-3" />
                      {formatDateTime(log.changedon)}
                      {isRecent && (
                        <Badge
                          variant="destructive"
                          className="px-1.5 py-0 text-[10px] leading-4"
                        >
                          Recent
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm mt-3">
                    <span className="line-through text-destructive">
                      {formatDateOnly(log.olddate)}
                    </span>
                    <ArrowRight className="size-3 text-muted-foreground shrink-0" />
                    <span className="font-medium">
                      {formatDateOnly(log.newdate)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2 italic">
                    "{log.reason}"
                  </p>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
