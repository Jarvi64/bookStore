import type { ReactNode } from "react";

export function MarkdownInlineText({ text }: { text: string }) {
  const nodes: ReactNode[] = [];
  const tokenPattern = /(\*\*.+?\*\*|\*.+?\*|`.+?`|\$[^$]+?\$)/g;
  let cursor = 0;

  for (const match of text.matchAll(tokenPattern)) {
    if (match.index > cursor) {
      nodes.push(text.slice(cursor, match.index));
    }

    const token = match[0];
    const key = `${match.index}-${token}`;

    if (token.startsWith("**")) {
      nodes.push(
        <strong key={key} className="font-semibold text-foreground">
          {token.slice(2, -2)}
        </strong>,
      );
    } else if (token.startsWith("*")) {
      nodes.push(<em key={key}>{token.slice(1, -1)}</em>);
    } else if (token.startsWith("`")) {
      nodes.push(
        <code key={key} className="rounded-md bg-muted px-1.5 py-0.5 font-mono text-[11px] text-foreground">
          {token.slice(1, -1)}
        </code>,
      );
    } else {
      nodes.push(
        <span key={key} className="rounded bg-muted/50 px-1 font-mono text-[11px]">
          {token.slice(1, -1)}
        </span>,
      );
    }

    cursor = match.index + token.length;
  }

  if (cursor < text.length) {
    nodes.push(text.slice(cursor));
  }

  return <>{nodes}</>;
}
