import type { SuggestedPrompt } from "./types";

export const SUGGESTED_PROMPTS: SuggestedPrompt[] = [
  {
    icon: "flag",
    title: "At-Risk Milestones",
    text: "Which milestones are at risk or delayed right now?",
  },
  {
    icon: "wallet",
    title: "Budget Status",
    text: "Summarize the CAPEX budget status across all programmes",
  },
  {
    icon: "chart",
    title: "Executive Summary",
    text: "Give me an executive summary of all programmes",
  },
  {
    icon: "alert",
    title: "Critical Support",
    text: "What are the critical open support items?",
  },
  {
    icon: "calendar",
    title: "Date Changes",
    text: "Which milestones have had their dates changed recently?",
  },
  {
    icon: "users",
    title: "Hiring Gaps",
    text: "What's the hiring gap across programmes?",
  },
];

export const SPIN_VERBS = [
  "Thinking...",
  "Analyzing programme data...",
  "Processing your query...",
  "Searching milestones and budgets...",
  "Cross-referencing records...",
  "Crunching the numbers...",
  "Reviewing support items...",
  "Generating insights...",
  "Almost there...",
];
