import type { useAppStore } from "@/lib/store";

type StoreSnapshot = ReturnType<typeof useAppStore.getState>;

const RECENT_WINDOW_MS = 30 * 86400000;

const findOwnerName = (store: StoreSnapshot, ownerId: string) =>
  store.programmeOrgNodes.find((node) => node.programmeorgnodeid === ownerId)?.displayname;

// Keep the model prompt small and predictable. Raw store objects contain UI-only fields
// and IDs that are useful to the app, but noisy for a planning assistant.
export function buildSystemContext(store: StoreSnapshot): string {
  const recentCutoff = new Date(Date.now() - RECENT_WINDOW_MS);

  const sections = [
    "You are an AI assistant for the Programme Tracker application at Adani Defence & Aerospace.",
    "You have access to the single programme named Third Eye. Answer only from the data below.",
    "Be concise, call out risks clearly, and use markdown tables for structured data.",
    `Use INR Crores for financials. Today's date is ${new Date().toISOString().split("T")[0]}.`,
    "",
    "=== PROGRAMME CONFIGURATION ===",
    JSON.stringify({
      id: store.programmeConfig.programmeid,
      name: store.programmeConfig.name,
      businessUnit: store.programmeConfig.businessUnit,
      capability: store.programmeConfig.capability,
      poc1: store.programmeConfig.poc1,
      poc2: store.programmeConfig.poc2,
      lastReportingWeek: store.programmeConfig.lastreportingweek,
      notes: store.programmeConfig.notes,
    }),
    "",
    "=== MILESTONES ===",
    JSON.stringify(
      store.milestones.map((milestone) => ({
        name: milestone.name,
        status: milestone.status,
        start: milestone.startdate,
        originalTarget: milestone.originaltargetedcompletiondate,
        currentTarget: milestone.targetedcompletiondate,
        owner: findOwnerName(store, milestone.ownerorgnodeid),
        remarks: milestone.remarks,
        changeCount: milestone.changecount,
        t0OffsetStart: milestone.t0OffsetStart,
        t0OffsetEnd: milestone.t0OffsetEnd,
        deliverable: milestone.deliverable,
        paymentPercentage: milestone.paymentPercentage,
        parentMilestoneId: milestone.parentMilestoneId,
      })),
    ),
    "",
    "=== MANPOWER DELIVERABLES ===",
    JSON.stringify(
      store.manpowerDeliverables.map((deliverable) => ({
        role: deliverable.role,
        qualification: deliverable.qualification,
        experience: deliverable.experience,
        requiredQty: deliverable.requiredqty,
        remarks: deliverable.remarks,
      })),
    ),
    "",
    "=== SUPPORT REQUIRED ===",
    JSON.stringify(
      store.supportRequired.map((support) => ({
        text: support.supporttext,
        category: support.category,
        criticality: support.criticality,
        status: support.status,
        deadline: support.deadline,
        owner: findOwnerName(store, support.ownerorgnodeid),
      })),
    ),
    "",
    "=== CERTIFICATIONS ===",
    JSON.stringify(
      store.certifications.map((certification) => ({
        name: certification.name,
        status: certification.status,
        validity: certification.validitydate,
        currentEdc: certification.currentedc,
        riskRemarks: certification.riskremarks,
      })),
    ),
    "",
    "=== CAPEX BUDGETS ===",
    JSON.stringify(
      store.capexBudgets.map((budget) => ({
        item: budget.item,
        budgetCr: budget.budgetcr,
        actualCr: budget.actualcr,
      })),
    ),
    "",
    "=== OPEX BUDGETS ===",
    JSON.stringify(
      store.opexBudgets.map((budget) => ({
        item: budget.item,
        supplier: budget.supplier,
        unitCostCr: budget.unitcostcr,
        targetCostCr: budget.targetcostcr,
      })),
    ),
    "",
    "=== SUPPLY CHAIN ===",
    JSON.stringify(
      store.supplyChains.map((item) => ({
        item: item.item,
        supplier: item.supplier,
        status: item.status,
        varianceCr: item.variancecr,
        riskRemarks: item.riskremarks,
      })),
    ),
    "",
    "=== PARTNER DELIVERABLES ===",
    JSON.stringify(
      store.partnerDeliverables.map((deliverable) => ({
        partner: deliverable.partnername,
        deliverable: deliverable.deliverable,
        targetEDC: deliverable.targetedc,
        currentEDC: deliverable.currentedc,
        status: deliverable.status,
        riskRemarks: deliverable.riskremarks,
      })),
    ),
    "",
    "=== MANPOWER / HIRING ===",
    JSON.stringify(
      store.manpowerPlans.map((plan) => ({
        role: plan.role,
        required: plan.requiredqty,
        filled: plan.filledqty,
        gap: plan.requiredqty - plan.filledqty,
        priority: plan.priority,
      })),
    ),
    "",
    "=== RECENT DATE CHANGES (last 30 days) ===",
    JSON.stringify(
      store.dateChangeLogs
        .filter((log) => new Date(log.changedon) >= recentCutoff)
        .map((log) => ({
          module: log.module,
          record: log.recordname,
          field: log.fieldname,
          oldDate: log.olddate,
          newDate: log.newdate,
          reason: log.reason,
        })),
    ),
  ];

  return sections.join("\n");
}
