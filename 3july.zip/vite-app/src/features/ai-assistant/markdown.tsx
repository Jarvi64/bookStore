import type { ReactNode } from "react";
import { MarkdownInlineText } from "./MarkdownInlineText";

function cleanLatex(tex: string): string {
  return tex
    .replace(/\\text\{([^}]+)\}/g, "$1")
    .replace(/\\mathbf\{([^}]+)\}/g, "$1")
    .replace(/\\frac\{([^}]+)\}\{([^}]+)\}/g, "($1 / $2)")
    .replace(/\\left\(/g, "(")
    .replace(/\\left\[/g, "[")
    .replace(/\\right\)/g, ")")
    .replace(/\\right\]/g, "]")
    .replace(/\\times/g, "x")
    .replace(/\\Delta/g, "Delta")
    .replace(/\\%/g, "%")
    .replace(/\\\\/g, " ")
    .trim();
}

export function toPlainText(markdown: string): string {
  return markdown
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/\*(.+?)\*/g, "$1")
    .replace(/`(.+?)`/g, "$1")
    .replace(/^#{1,3}\s/gm, "")
    .replace(/^[-*]\s/gm, "- ")
    .replace(/\$\$[^$]*\$\$/g, (match) => cleanLatex(match.replace(/\$\$/g, "")));
}

export function renderMarkdown(text: string) {
  const lines = text.split("\n");
  const elements: ReactNode[] = [];
  let inCodeBlock = false;
  let codeBuffer: string[] = [];
  let inLatexBlock = false;
  let latexBuffer: string[] = [];

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (trimmed.startsWith("$$") && !inLatexBlock && !inCodeBlock) {
      const rest = trimmed.slice(2);
      if (rest.endsWith("$$") && rest.length > 2) {
        elements.push(
          <div key={`math-${index}`} className="my-2 overflow-x-auto rounded-lg border border-border/30 bg-muted/50 px-4 py-3 font-mono text-xs text-foreground">
            <span className="mr-2 text-[9px] font-semibold text-violet-500">MATH</span>
            {cleanLatex(rest.slice(0, -2).trim())}
          </div>,
        );
      } else {
        inLatexBlock = true;
        if (rest) latexBuffer.push(rest);
      }
      return;
    }

    if (inLatexBlock) {
      if (trimmed.endsWith("$$")) {
        const partial = trimmed.replace(/\$\$$/, "").trim();
        if (partial) latexBuffer.push(partial);
        elements.push(
          <div key={`math-${index}`} className="my-2 overflow-x-auto rounded-lg border border-border/30 bg-muted/50 px-4 py-3 font-mono text-xs text-foreground">
            <span className="mr-2 text-[9px] font-semibold text-violet-500">MATH</span>
            {cleanLatex(latexBuffer.join(" "))}
          </div>,
        );
        latexBuffer = [];
        inLatexBlock = false;
      } else {
        latexBuffer.push(line);
      }
      return;
    }

    if (line.startsWith("```")) {
      if (inCodeBlock) {
        elements.push(
          <pre key={`code-${index}`} className="my-3 overflow-x-auto rounded-xl border border-neutral-800 bg-neutral-950 p-4 font-mono text-xs text-neutral-200">
            <code>{codeBuffer.join("\n")}</code>
          </pre>,
        );
        codeBuffer = [];
        inCodeBlock = false;
      } else {
        inCodeBlock = true;
      }
      return;
    }

    if (inCodeBlock) {
      codeBuffer.push(line);
      return;
    }

    if (line.startsWith("### ")) {
      elements.push(
        <h4 key={index} className="mb-1.5 mt-4 text-sm font-bold text-foreground">
          <MarkdownInlineText text={line.slice(4)} />
        </h4>,
      );
    } else if (line.startsWith("## ")) {
      elements.push(
        <h3 key={index} className="mb-1.5 mt-4 text-base font-bold text-foreground">
          <MarkdownInlineText text={line.slice(3)} />
        </h3>,
      );
    } else if (line.startsWith("# ")) {
      elements.push(
        <h2 key={index} className="mb-1.5 mt-4 text-lg font-bold text-foreground">
          <MarkdownInlineText text={line.slice(2)} />
        </h2>,
      );
    } else if (line.startsWith("|")) {
      const cells = line.split("|").filter((cell) => cell.trim() !== "");
      const isSeparator = cells.every((cell) => /^[-:]+$/.test(cell.trim()));
      const isHeader = lines[index + 1]?.startsWith("|") && lines[index + 1]?.includes("---");

      if (!isSeparator) {
        elements.push(
          <div
            key={index}
            className={`grid gap-0 border-b border-border/40 text-[12px] dark:border-border/60 ${isHeader ? "bg-muted/50 font-semibold text-foreground dark:bg-muted/30" : "text-foreground/70 dark:text-foreground/80"}`}
            style={{ gridTemplateColumns: `repeat(${cells.length}, minmax(60px, 1fr))` }}
          >
            {cells.map((cell, cellIndex) => (
              <span key={cellIndex} className="min-w-0 break-words px-2 py-1.5">
                <MarkdownInlineText text={cell.trim()} />
              </span>
            ))}
          </div>,
        );
      }
    } else if (/^[\s]*[-*]\s/.test(line)) {
      const indent = line.match(/^(\s*)/)?.[1]?.length ?? 0;
      elements.push(
        <div key={index} className="flex items-start gap-2.5 text-[13px] leading-relaxed" style={{ paddingLeft: `${indent * 4 + 4}px` }}>
          <span className="mt-[7px] size-1 shrink-0 rounded-full bg-violet-500 text-violet-500" />
          <span>
            <MarkdownInlineText text={line.replace(/^[\s]*[-*]\s/, "")} />
          </span>
        </div>,
      );
    } else if (/^[\s]*\d+\.\s/.test(line)) {
      const num = line.match(/^[\s]*(\d+)\./)?.[1];
      elements.push(
        <div key={index} className="flex items-start gap-2.5 pl-1 text-[13px] leading-relaxed">
          <span className="shrink-0 font-bold tabular-nums text-violet-500">{num}.</span>
          <span>
            <MarkdownInlineText text={line.replace(/^[\s]*\d+\.\s/, "")} />
          </span>
        </div>,
      );
    } else if (trimmed === "") {
      elements.push(<div key={index} className="h-2.5" />);
    } else {
      elements.push(
        <p key={index} className="text-[13px] leading-relaxed">
          <MarkdownInlineText text={line} />
        </p>,
      );
    }
  });

  return <div className="space-y-0.5">{elements}</div>;
}
