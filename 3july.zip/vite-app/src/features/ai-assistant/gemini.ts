import { GoogleGenAI } from "@google/genai";
import type { ChatMessage } from "./types";

const GEMINI_MODEL = import.meta.env.VITE_GEMINI_MODEL?.trim() || "gemini-2.5-flash";
const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY?.trim();

export const hasGeminiApiKey = Boolean(GEMINI_API_KEY);

function createGeminiClient() {
  if (!GEMINI_API_KEY) {
    throw new Error("Missing VITE_GEMINI_API_KEY. Add it to a local .env file and restart Vite.");
  }

  return new GoogleGenAI({ apiKey: GEMINI_API_KEY });
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => {
      reject(new Error(`Request timed out after ${timeoutMs / 1000} seconds`));
    }, timeoutMs);

    promise
      .then(resolve)
      .catch(reject)
      .finally(() => window.clearTimeout(timeoutId));
  });
}

export async function requestAssistantReply({
  history,
  systemContext,
  userText,
}: {
  history: ChatMessage[];
  systemContext: string;
  userText: string;
}) {
  const ai = createGeminiClient();
  const chatHistory = [
    { role: "user" as const, parts: [{ text: systemContext }] },
    {
      role: "model" as const,
      parts: [{ text: "Understood. I have access to the programme database. How can I help?" }],
    },
    ...history.map((message) => ({
      role: (message.role === "user" ? "user" : "model") as "user" | "model",
      parts: [{ text: message.content }],
    })),
    { role: "user" as const, parts: [{ text: userText }] },
  ];

  const response = await withTimeout(
    ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: chatHistory,
      config: { temperature: 0.4, maxOutputTokens: 4096 },
    }),
    90000,
  );

  return response.text ?? "Sorry, I couldn't generate a response.";
}
