export type ChatRole = "user" | "assistant";

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  timestamp: Date;
}

export interface Conversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
}

export interface SuggestedPrompt {
  icon: "flag" | "wallet" | "chart" | "alert" | "calendar" | "users";
  title: string;
  text: string;
}
