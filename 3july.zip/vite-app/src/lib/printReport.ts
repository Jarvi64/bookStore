import type {
  ProgrammeConfig, Milestone, Certification, SupportRequired,
  CapexBudget, DateChangeLog, ProgrammeOrgNode,
} from "./store";

interface ReportData {
  programmeConfig: ProgrammeConfig;
  milestones: Milestone[];
  certifications: Certification[];
  supportRequired: SupportRequired[];
  capexBudgets: CapexBudget[];
  dateChangeLogs: DateChangeLog[];
  orgNodes: ProgrammeOrgNode[];
}

function ownerName(id: string, nodes: ProgrammeOrgNode[]): string {
  return nodes.find((n) => n.programmeorgnodeid === id)?.displayname ?? "—";
}

function fmt(ds: string | undefined): string {
  if (!ds) return "—";
  try {
    const d = new Date(ds.includes("T") ? ds : ds + "T00:00:00");
    return isNaN(d.getTime()) ? ds : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  } catch { return ds; }
}

const BRAND = "#75679C";
const BLUE  = "#0874B0";
const ROSE  = "#BD3661";

const STATUS_COLOR: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress":  BLUE,
  Completed:      "#10b981",
  Delayed:        "#f59e0b",
  "At Risk":      "#ef4444",
  Approved:       "#10b981",
  "In Review":    "#6366f1",
  Expired:        "#f97316",
  Pending:        "#94a3b8",
};

const CRIT_COLOR: Record<string, string> = {
  Critical: "#ef4444",
  High:     "#f97316",
  Medium:   "#f59e0b",
  Low:      "#94a3b8",
};

function badge(text: string, bg: string): string {
  return `<span style="background:${bg}22;color:${bg};border:1px solid ${bg}44;border-radius:4px;padding:1px 7px;font-size:10px;font-weight:700;white-space:nowrap;">${text}</span>`;
}

function statusBadge(status: string): string {
  return badge(status, STATUS_COLOR[status] ?? BRAND);
}

function table(headers: string[], rows: string[][], accentCol?: number): string {
  if (rows.length === 0) return `<p style="color:#94a3b8;font-size:12px;padding:12px 4px;">No data recorded.</p>`;
  return `
  <table style="width:100%;border-collapse:collapse;font-size:11.5px;margin-top:4px;">
    <thead>
      <tr style="background:${BRAND}18;border-bottom:2px solid ${BRAND}44;">
        ${headers.map((h) => `<th style="text-align:left;padding:7px 10px;font-size:10px;font-weight:700;color:${BRAND};text-transform:uppercase;letter-spacing:0.05em;white-space:nowrap;">${h}</th>`).join("")}
      </tr>
    </thead>
    <tbody>
      ${rows.map((r, ri) => `
        <tr style="border-bottom:1px solid #e2e8f0;background:${ri % 2 === 1 ? "#fafafe" : "white"};">
          ${r.map((c, ci) => `<td style="padding:6px 10px;vertical-align:top;${ci === accentCol ? `color:${BRAND};font-weight:600;` : "color:#334155;"}">${c}</td>`).join("")}
        </tr>
      `).join("")}
    </tbody>
  </table>`;
}

function section(title: string, icon: string, content: string): string {
  return `
  <div style="margin-top:20px;page-break-inside:avoid;">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;padding-bottom:6px;border-bottom:2px solid ${BRAND}33;">
      <span style="font-size:15px;">${icon}</span>
      <span style="font-size:13px;font-weight:700;color:#1e293b;letter-spacing:-0.02em;">${title}</span>
    </div>
    ${content}
  </div>`;
}

export function printProgrammeReport(data: ReportData): void {
  const {
    programmeConfig, milestones, certifications, supportRequired,
    capexBudgets, dateChangeLogs, orgNodes,
  } = data;

  const pid = programmeConfig.programmeid;
  const buName = programmeConfig.businessUnit;
  const poc1   = programmeConfig.poc1;
  const poc2   = programmeConfig.poc2;

  // KPIs
  const pMs         = milestones.filter((m) => m.programmeid === pid);
  const msCompleted = pMs.filter((m) => m.status === "Completed").length;
  const msAtRisk    = pMs.filter((m) => m.status === "At Risk" || m.status === "Delayed").length;
  const msPercent   = pMs.length > 0 ? Math.round((msCompleted / pMs.length) * 100) : 0;
  const pCerts      = certifications.filter((c) => c.programmeid === pid);
  const approvedCerts = pCerts.filter((c) => c.status === "Approved").length;
  const pSup        = supportRequired.filter((s) => s.programmeid === pid && s.status !== "Closed" && s.status !== "Resolved");
  const critSup     = pSup.filter((s) => s.criticality === "Critical").length;
  const pCapex      = capexBudgets.filter((c) => c.programmeid === pid);
  const totalBudget = pCapex.reduce((a, c) => a + c.budgetcr, 0);
  const totalActual = pCapex.reduce((a, c) => a + c.actualcr, 0);
  const variance    = totalBudget - totalActual;
  const recentLogs  = dateChangeLogs.filter(
    (l) => l.programmeid === pid && new Date(l.changedon) >= new Date(Date.now() - 7 * 86400000)
  );

  const today = new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric" });

  const kpiCard = (label: string, value: string, sub: string, color: string) =>
    `<div style="flex:1;min-width:100px;background:${color}12;border:1px solid ${color}33;border-radius:8px;padding:10px 12px;">
      <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;color:${color};margin-bottom:4px;">${label}</div>
      <div style="font-size:20px;font-weight:800;color:#0f172a;line-height:1;">${value}</div>
      <div style="font-size:9px;color:#64748b;margin-top:3px;">${sub}</div>
    </div>`;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>${programmeConfig.name} — Programme Report</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family:'Inter',system-ui,sans-serif; background:#ffffff; color:#1e293b; font-size:12px; line-height:1.5; }
    @media print {
      body { print-color-adjust:exact; -webkit-print-color-adjust:exact; }
      .no-print { display:none !important; }
      .page-break { page-break-before:always; }
    }
    .btn { display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none; }
  </style>
</head>
<body>
  <!-- Print / Download bar -->
  <div class="no-print" style="background:#1e293b;color:white;padding:10px 24px;display:flex;align-items:center;justify-between;gap:12px;position:sticky;top:0;z-index:999;">
    <span style="font-size:13px;font-weight:600;">Programme Report — ${programmeConfig.name}</span>
    <div style="display:flex;gap:8px;">
      <button class="btn" style="background:${BRAND};color:white;" onclick="window.print()">⬇ Save as PDF</button>
      <button class="btn" style="background:#334155;color:white;" onclick="window.close()">✕ Close</button>
    </div>
  </div>

  <div style="max-width:900px;margin:0 auto;padding:32px 32px 48px;">

    <!-- Header gradient band -->
    <div style="background:linear-gradient(135deg,${BRAND} 0%,${BLUE} 100%);border-radius:14px;padding:28px 32px;color:white;margin-bottom:24px;">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;">
        <div>
          <div style="font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;opacity:0.75;margin-bottom:6px;">Programme Status Report</div>
          <h1 style="font-size:26px;font-weight:800;letter-spacing:-0.03em;line-height:1.1;">${programmeConfig.name}</h1>
          <div style="margin-top:8px;display:flex;gap:16px;flex-wrap:wrap;font-size:11px;opacity:0.85;">
            <span><strong>Business Unit:</strong> ${buName}</span>
            <span><strong>POC 1:</strong> ${poc1}</span>
            ${poc2 && poc2 !== "—" ? `<span><strong>POC 2:</strong> ${poc2}</span>` : ""}
            <span><strong>Last Week:</strong> ${programmeConfig.lastreportingweek}</span>
          </div>
        </div>
        <div style="text-align:right;opacity:0.8;font-size:10px;">
          <div>Generated on</div>
          <div style="font-size:13px;font-weight:700;">${today}</div>
        </div>
      </div>
    </div>

    <!-- KPI strip -->
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;">
      ${kpiCard("Milestone Completion", `${msPercent}%`, `${msCompleted} of ${pMs.length} done`, BLUE)}
      ${kpiCard("At Risk / Delayed", `${msAtRisk}`, msAtRisk > 0 ? "Requires attention" : "All on track", msAtRisk > 0 ? "#ef4444" : "#10b981")}
      ${kpiCard("Open Support", `${pSup.length}`, critSup > 0 ? `${critSup} critical` : "No critical items", critSup > 0 ? ROSE : BRAND)}
      ${kpiCard("Certifications", `${approvedCerts}/${pCerts.length}`, "Approved / Total", BRAND)}
      ${kpiCard("CAPEX Variance", `${variance >= 0 ? "+" : ""}${variance.toFixed(1)} CR`, `Budget: ${totalBudget.toFixed(1)} · Actual: ${totalActual.toFixed(1)}`, variance >= 0 ? "#10b981" : "#ef4444")}
      ${kpiCard("Date Changes", `${recentLogs.length}`, "In last 7 days", recentLogs.length > 0 ? BRAND : "#94a3b8")}
    </div>

    <!-- Milestones -->
    ${section("Milestones", "🚩", table(
      ["Milestone", "Start", "Target", "Status", "Owner", "Remarks"],
      pMs.map((m) => [
        `<span style="font-weight:600;">${m.name}</span>`,
        fmt(m.startdate),
        fmt(m.targetedcompletiondate),
        statusBadge(m.status),
        ownerName(m.ownerorgnodeid, orgNodes),
        m.remarks || "—",
      ])
    ))}

    <!-- Open Support Items -->
    ${section("Open Support Items", "⚡", pSup.length === 0
      ? `<p style="color:#94a3b8;font-size:12px;padding:12px 4px;">No open support items. ✓</p>`
      : table(
        ["Description", "Category", "Criticality", "Deadline", "Owner"],
        pSup
          .sort((a, b) => ({ Critical:0, High:1, Medium:2, Low:3 }[a.criticality]??3) - ({ Critical:0, High:1, Medium:2, Low:3 }[b.criticality]??3))
          .map((s) => [
            `<span style="font-weight:500;">${s.supporttext}</span>`,
            s.category,
            badge(s.criticality, CRIT_COLOR[s.criticality] ?? BRAND),
            fmt(s.deadline),
            ownerName(s.ownerorgnodeid, orgNodes),
          ])
      )
    )}

    <!-- Certifications -->
    ${section("Certifications", "🛡️", table(
      ["Name", "Status", "Current EDC", "Validity", "Owner", "Risk Remarks"],
      pCerts.map((c) => [
        `<span style="font-weight:600;">${c.name}</span>`,
        statusBadge(c.status),
        fmt(c.currentedc),
        fmt(c.validitydate),
        ownerName(c.ownerorgnodeid, orgNodes),
        c.riskremarks || "—",
      ])
    ))}

    <!-- CAPEX Budget -->
    ${pCapex.length > 0 ? section("CAPEX Budget", "💰", table(
      ["Item", "Budget (CR)", "Actual (CR)", "Variance (CR)", "Commissioning Date", "Owner"],
      [
        ...pCapex.map((c) => {
          const v = c.budgetcr - c.actualcr;
          return [
            `<span style="font-weight:600;">${c.item}</span>`,
            c.budgetcr.toFixed(2),
            c.actualcr.toFixed(2),
            `<span style="color:${v >= 0 ? "#10b981" : "#ef4444"};font-weight:700;">${v >= 0 ? "+" : ""}${v.toFixed(2)}</span>`,
            fmt(c.commisiongdate),
            ownerName(c.ownerorgnodeid, orgNodes),
          ];
        }),
        [
          "<strong>TOTAL</strong>",
          `<strong>${totalBudget.toFixed(2)}</strong>`,
          `<strong>${totalActual.toFixed(2)}</strong>`,
          `<strong style="color:${variance >= 0 ? "#10b981" : "#ef4444"};">${variance >= 0 ? "+" : ""}${variance.toFixed(2)}</strong>`,
          "", "",
        ],
      ]
    )) : ""}

    <!-- Recent date changes -->
    ${recentLogs.length > 0 ? section("Recent Date Changes (Last 7 Days)", "📅", table(
      ["Module", "Record", "Field", "Old Date", "New Date", "Reason"],
      recentLogs.map((l) => [
        `<span style="text-transform:capitalize;">${l.module.replace("_", " ")}</span>`,
        l.recordname,
        l.fieldname,
        fmt(l.olddate),
        `<strong>${fmt(l.newdate)}</strong>`,
        l.reason || "—",
      ])
    )) : ""}

    <!-- Footer -->
    <div style="margin-top:36px;padding-top:16px;border-top:1px solid #e2e8f0;display:flex;justify-content:space-between;align-items:center;color:#94a3b8;font-size:10px;">
      <span>${programmeConfig.name} · ${buName}</span>
      <span>Generated ${today} · Confidential</span>
    </div>
  </div>

  <script>
    // Auto-trigger print after fonts load
    document.fonts.ready.then(() => {
      // Small delay for layout
      setTimeout(() => {}, 500);
    });
  </script>
</body>
</html>`;

  const win = window.open("", "_blank", "width=1024,height=768");
  if (!win) { alert("Please allow pop-ups to generate the report."); return; }
  win.document.write(html);
  win.document.close();
}
