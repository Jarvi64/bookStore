const DAY_MS = 86_400_000;

export function parseAppDate(value: string | undefined): Date | null {
  if (!value) return null;

  const date = new Date(value.includes("T") ? value : `${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

export function addDays(date: Date, days: number) {
  return new Date(date.getTime() + days * DAY_MS);
}

export function formatDisplayDate(value: string | undefined, fallback = "-") {
  const date = parseAppDate(value);

  if (!date) return fallback;

  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}
