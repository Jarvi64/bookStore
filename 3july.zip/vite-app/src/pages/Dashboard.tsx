import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { useAppStore } from "@/lib/store";
import { printProgrammeReport } from "@/lib/printReport";
import { FileText } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ParticleField } from "@/components/ui/particle-field";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Clock,
  DollarSign,
  Flag,
  Package,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  Users,
  Zap,
  Sparkles,
  UserCheck,
  Layers,
  Briefcase,
  ExternalLink,
} from "lucide-react";
import { differenceInDays } from "date-fns";
import { addDays, parseAppDate } from "@/lib/date";

// Status maps keep domain state separate from presentation details.
const MS_COLOR: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress": "#0874B0",
  "Completed":   "#10b981",
  "Delayed":     "#f59e0b",
  "At Risk":     "#ef4444",
};

const MS_BADGE: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
  "Completed":   "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  "Delayed":     "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  "At Risk":     "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
};

const CRIT_ORDER: Record<string, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };
const CRIT_BADGE: Record<string, string> = {
  Critical: "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300",
  High:     "bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300",
  Medium:   "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  Low:      "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400",
};

export function Dashboard() {
  const {
    programmeConfig,
    milestones,
    certifications,
    supportRequired,
    dateChangeLogs,
    manpowerPlans,
    capexBudgets,
    opexBudgets,
    supplyChains,
    partnerDeliverables,
    programmeOrgNodes,
    weeklyUpdates,
    weeklyUpdateItems,
  } = useAppStore();

  const programmeId = programmeConfig.programmeid;
  const [today] = useState(() => new Date());
  const thirtyDays = addDays(today, 30);
  const sevenDaysAgo = addDays(today, -7);

  // ── Scoped data ─────────────────────────────────────────────
  const pMilestones     = useMemo(() => milestones.filter((m) => m.programmeid === programmeId), [milestones, programmeId]);
  const pCerts          = useMemo(() => certifications.filter((c) => c.programmeid === programmeId), [certifications, programmeId]);
  const pSupport        = useMemo(() => supportRequired.filter((s) => s.programmeid === programmeId), [supportRequired, programmeId]);
  const pLogs           = useMemo(() => dateChangeLogs.filter((l) => l.programmeid === programmeId), [dateChangeLogs, programmeId]);
  const pManpower       = useMemo(() => manpowerPlans.filter((m) => m.programmeid === programmeId), [manpowerPlans, programmeId]);
  const pCapex          = useMemo(() => capexBudgets.filter((c) => c.programmeid === programmeId), [capexBudgets, programmeId]);
  const pOpex           = useMemo(() => opexBudgets.filter((o) => o.programmeid === programmeId), [opexBudgets, programmeId]);
  const pSC             = useMemo(() => supplyChains.filter((s) => s.programmeid === programmeId), [supplyChains, programmeId]);
  const pPartner        = useMemo(() => partnerDeliverables.filter((d) => d.programmeid === programmeId), [partnerDeliverables, programmeId]);
  const orgNodes        = useMemo(() => programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes"), [programmeOrgNodes, programmeId]);

  const ownerName = (id: string) => orgNodes.find((n) => n.programmeorgnodeid === id)?.displayname ?? "—";

  // ── Milestone stats ──────────────────────────────────────────
  const msCompleted  = pMilestones.filter((m) => m.status === "Completed").length;
  const msAtRisk     = useMemo(() => pMilestones.filter((m) => m.status === "At Risk" || m.status === "Delayed"), [pMilestones]);
  const msCompletion = pMilestones.length > 0 ? Math.round((msCompleted / pMilestones.length) * 100) : 0;

  const msByStatus = useMemo(() => {
    const counts: Record<string, number> = {};
    pMilestones.forEach((m) => { counts[m.status] = (counts[m.status] ?? 0) + 1; });
    return counts;
  }, [pMilestones]);

  // ── Upcoming deadlines ────────────────────────────────────────
  const upcomingDeadlines = (() => {
    const items: { label: string; date: Date; daysLeft: number; type: string; status: string; badge: string }[] = [];
    pMilestones.forEach((m) => {
      if (m.status === "Completed") return;
      const d = parseAppDate(m.targetedcompletiondate);
      if (d && d >= today && d <= thirtyDays) {
        items.push({ label: m.name, date: d, daysLeft: differenceInDays(d, today), type: "Milestone", status: m.status, badge: MS_BADGE[m.status] ?? "" });
      }
    });
    pCerts.forEach((c) => {
      if (c.status === "Approved" || c.status === "Expired") return;
      const d = parseAppDate(c.validitydate);
      if (d && d >= today && d <= thirtyDays) {
        items.push({ label: c.name, date: d, daysLeft: differenceInDays(d, today), type: "Certification", status: c.status, badge: "" });
      }
    });
    return items.sort((a, b) => a.daysLeft - b.daysLeft);
  })();

  // ── Support ──────────────────────────────────────────────────
  const openSupport = useMemo(() => pSupport
    .filter((s) => s.status !== "Closed" && s.status !== "Resolved")
    .sort((a, b) => (CRIT_ORDER[a.criticality] ?? 3) - (CRIT_ORDER[b.criticality] ?? 3)), [pSupport]);

  // ── Budget ───────────────────────────────────────────────────
  const totalCapexBudget = pCapex.reduce((a, c) => a + c.budgetcr, 0);
  const totalCapexActual = pCapex.reduce((a, c) => a + c.actualcr, 0);
  const capexVariance    = totalCapexBudget - totalCapexActual;
  const totalOpexTarget  = pOpex.reduce((a, o) => a + o.targetcostcr, 0);
  const totalOpexUnit    = pOpex.reduce((a, o) => a + o.unitcostcr, 0);

  // ── Hiring ──────────────────────────────────────────────────
  const hiringGap    = pManpower.reduce((a, p) => a + Math.max(0, p.requiredqty - p.filledqty), 0);
  const hiringTotal  = pManpower.reduce((a, p) => a + p.requiredqty, 0);
  const hiringFilled = hiringTotal - hiringGap;

  // ── Supply chain ─────────────────────────────────────────────
  const scDelayed   = pSC.filter((s) => s.status === "Delayed").length;
  const scDelivered = pSC.filter((s) => s.status === "Delivered").length;

  // ── Recent date changes ──────────────────────────────────────
  const recentChanges = pLogs
    .filter((l) => new Date(l.changedon) >= sevenDaysAgo)
    .sort((a, b) => new Date(b.changedon).getTime() - new Date(a.changedon).getTime());

  // ── Latest weekly update ─────────────────────────────────────
  const latestUpdate = useMemo(() => weeklyUpdates
    .filter((u) => u.programmeid === programmeId)
    .sort((a, b) => b.weekkey.localeCompare(a.weekkey))[0], [weeklyUpdates, programmeId]);

  const latestUpdateItems = useMemo(() => latestUpdate
    ? weeklyUpdateItems.filter((i) => i.weeklyupdateid === latestUpdate.weeklyupdateid)
    : [], [latestUpdate, weeklyUpdateItems]);

  const positiveItems = useMemo(() => latestUpdateItems.filter((i) => i.entrytype === "positive"), [latestUpdateItems]);
  const negativeItems = useMemo(() => latestUpdateItems.filter((i) => i.entrytype === "negative"), [latestUpdateItems]);

  // Determine overall program health category
  const programHealth = useMemo(() => {
    if (msAtRisk.some((m) => m.status === "At Risk")) return "At Risk";
    if (msAtRisk.some((m) => m.status === "Delayed")) return "Delayed";
    return "On Track";
  }, [msAtRisk]);

  const healthBadgeStyle = {
    "On Track": "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
    "Delayed": "bg-amber-500/20 text-amber-300 border-amber-500/40",
    "At Risk": "bg-red-500/20 text-red-300 border-red-500/40",
  }[programHealth] ?? "bg-slate-500/20 text-slate-300 border-slate-500/40";

  const handlePrint = () => {
    printProgrammeReport({
      programmeConfig,
      milestones,
      certifications,
      supportRequired,
      capexBudgets,
      dateChangeLogs,
      orgNodes,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      {/* ── STUNNING HERO SECTION ── */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 text-white p-6 sm:p-8 md:p-10 shadow-2xl">
        {/* Interactive WebGL particle field */}
        <ParticleField />
        
        {/* Background Gradients */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(99,102,241,0.18),transparent_60%)] pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(8,116,176,0.12),transparent_50%)] pointer-events-none" />

        {/* Content Box */}
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div className="space-y-4 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className={`${healthBadgeStyle} px-3 py-1 font-semibold uppercase tracking-wider text-[11px] animate-pulse`}>
                ● {programHealth}
              </Badge>
              <Badge variant="outline" className="bg-slate-800/80 text-slate-200 border-slate-700/80">
                Reporting: {programmeConfig.lastreportingweek}
              </Badge>
            </div>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
              {programmeConfig.name}
            </h1>
            
            <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
              {programmeConfig.notes || "Advanced defence control panel. Real-time updates, timeline status, and readiness analysis."}
            </p>

            <div className="grid grid-cols-2 gap-x-6 gap-y-2.5 pt-2 border-t border-slate-800/80 max-w-lg">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Briefcase className="size-3.5 text-indigo-400 shrink-0" />
                <span className="truncate"><strong>Unit:</strong> {programmeConfig.businessUnit}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Layers className="size-3.5 text-blue-400 shrink-0" />
                <span className="truncate"><strong>Cap:</strong> {programmeConfig.capability}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <UserCheck className="size-3.5 text-indigo-400 shrink-0" />
                <span className="truncate"><strong>Director:</strong> {programmeConfig.poc1}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Users className="size-3.5 text-blue-400 shrink-0" />
                <span className="truncate"><strong>Lead:</strong> {programmeConfig.poc2}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap md:flex-col gap-3 shrink-0">
            <Button asChild size="lg" className="bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-semibold shadow-lg shadow-indigo-500/20 border-none transition-all duration-200">
              <Link to="/milestones" className="flex items-center gap-2">
                Manage Milestones <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" onClick={handlePrint} className="bg-slate-900/85 hover:bg-slate-900 text-white border-slate-800 hover:border-slate-700 backdrop-blur transition-all duration-200">
              <span className="flex items-center gap-2">
                <FileText className="size-4 text-emerald-400" /> Export PDF Report
              </span>
            </Button>
            <Button asChild variant="outline" size="lg" className="bg-slate-900/85 hover:bg-slate-900 text-white border-slate-800 hover:border-slate-700 backdrop-blur transition-all duration-200">
              <Link to="/ai-assistant" className="flex items-center gap-2">
                <Sparkles className="size-4 text-violet-400" /> Consult AI Assistant
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* ── GLASSMORPHIC KPI STRIP ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: "Milestone Progress", value: `${msCompletion}%`, sub: `${msCompleted}/${pMilestones.length} done`, icon: Flag, color: "var(--primary)" },
          { label: "At Risk Milestones", value: msAtRisk.length, sub: msAtRisk.length > 0 ? "Action required" : "Zero conflicts", icon: AlertTriangle, color: msAtRisk.length > 0 ? "#ef4444" : "#10b981" },
          { label: "Open Support Requests", value: openSupport.length, sub: `${openSupport.filter(s => s.criticality === "Critical").length} critical items`, icon: Zap, color: openSupport.filter(s => s.criticality === "Critical").length > 0 ? "#BD3661" : "#8b5cf6" },
          { label: "Hiring Gap", value: hiringGap, sub: `${hiringFilled}/${hiringTotal} filled`, icon: Users, color: hiringGap > 0 ? "#f59e0b" : "#10b981" },
          { label: "Certifications Approved", value: `${pCerts.filter(c => c.status === "Approved").length}/${pCerts.length}`, sub: "Compliance status", icon: ShieldCheck, color: "#10b981" },
          { label: "CAPEX Variance", value: `${capexVariance >= 0 ? "+" : ""}${capexVariance.toFixed(1)} CR`, sub: `Budget: ${totalCapexBudget.toFixed(0)} CR`, icon: DollarSign, color: capexVariance >= 0 ? "#10b981" : "#ef4444" }
        ].map((kpi, idx) => (
          <Card key={idx} className="relative overflow-hidden border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
            <div className="absolute inset-0 opacity-[0.03]" style={{ background: `radial-gradient(circle at top right, ${kpi.color}, transparent 65%)` }} />
            <CardContent className="pt-4 pb-4 px-4.5 flex flex-col justify-between h-full min-h-[100px]">
              <div className="flex items-center justify-between gap-1.5">
                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider truncate">{kpi.label}</span>
                <div className="size-6 rounded-lg flex items-center justify-center shrink-0" style={{ backgroundColor: `${kpi.color}15` }}>
                  <kpi.icon className="size-3.5" style={{ color: kpi.color }} />
                </div>
              </div>
              <div className="mt-2.5">
                <span className="text-2xl font-extrabold tracking-tight tabular-nums">{kpi.value}</span>
                <p className="text-[10px] text-muted-foreground mt-1 truncate font-medium">{kpi.sub}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ── CORE INSIGHTS GRID ── */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        
        {/* Milestone Status Chart */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <Flag className="size-4 text-violet-500" /> Milestone Status
              </span>
              <Badge className="text-[9px]" variant="secondary">{pMilestones.length} total</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-4 px-5 space-y-3">
            {Object.entries(MS_COLOR).map(([status, color]) => {
              const count = msByStatus[status] ?? 0;
              const pct = pMilestones.length > 0 ? (count / pMilestones.length) * 100 : 0;
              return (
                <div key={status} className="flex items-center gap-3">
                  <span className="text-xs text-muted-foreground w-20 shrink-0 font-medium">{status}</span>
                  <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
                  </div>
                  <span className="text-xs font-bold w-4 text-right tabular-nums">{count}</span>
                </div>
              );
            })}
            
            <div className="pt-3 border-t">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground font-medium">Completion Percentage</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{msCompletion}%</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-emerald-500 transition-all" style={{ width: `${msCompletion}%` }} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Deadlines (30 Days) */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <CalendarDays className="size-4 text-blue-500" /> Deadlines in 30 Days
              </span>
              <Badge className="text-[9px] bg-blue-500/10 text-blue-500 border-none" variant="outline">{upcomingDeadlines.length} items</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-3 px-5 pb-3">
            {upcomingDeadlines.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                <CheckCircle2 className="size-8 text-emerald-500 opacity-40 animate-bounce" />
                <p className="text-xs font-medium">No deadlines in the next 30 days</p>
              </div>
            ) : (
              <ScrollArea className="h-[210px] pr-2">
                <div className="space-y-2">
                  {upcomingDeadlines.map((item, i) => (
                    <div key={i} className="flex items-center gap-2.5 p-2 rounded-lg bg-muted/20 border hover:bg-muted/40 transition-colors">
                      <div className={`size-2 rounded-full shrink-0 ${item.type === "Milestone" ? "bg-blue-500" : "bg-indigo-500"}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold truncate leading-tight">{item.label}</p>
                        <p className="text-[9px] text-muted-foreground">{item.type}</p>
                      </div>
                      <span className={`text-xs font-bold shrink-0 tabular-nums ${item.daysLeft <= 7 ? "text-amber-500" : "text-muted-foreground"}`}>
                        {item.daysLeft === 0 ? "Today" : `${item.daysLeft}d`}
                      </span>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* At Risk & Delayed Details */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <AlertTriangle className="size-4 text-red-500" /> Risks & Bottlenecks
              </span>
              <Badge className="text-[9px] bg-red-500/10 text-red-500 border-none" variant="outline">{msAtRisk.length} active</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-3 px-5 pb-3">
            {msAtRisk.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                <CheckCircle2 className="size-8 text-emerald-500 opacity-40" />
                <p className="text-xs font-medium">All timelines stable and on-target</p>
              </div>
            ) : (
              <ScrollArea className="h-[210px] pr-2">
                <div className="space-y-2">
                  {msAtRisk.map((m) => {
                    const d = parseAppDate(m.targetedcompletiondate);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    return (
                      <div key={m.milestoneid} className="flex flex-col gap-1.5 p-2 rounded-lg bg-red-50/10 dark:bg-red-950/5 border border-red-500/10 hover:bg-red-500/5 transition-colors">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-bold truncate leading-tight flex-1">{m.name}</p>
                          <Badge className={`${MS_BADGE[m.status] ?? ""} text-[8px] px-1.5 py-0`}>{m.status}</Badge>
                        </div>
                        <div className="flex items-center justify-between text-[9px] text-muted-foreground">
                          <span>Owner: {ownerName(m.ownerorgnodeid)}</span>
                          {daysLeft !== null && (
                            <span className={daysLeft < 0 ? "text-red-500 font-bold" : "font-medium"}>
                              {daysLeft < 0 ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d left`}
                            </span>
                          )}
                        </div>
                        {m.remarks && <p className="text-[9.5px] italic text-slate-500 line-clamp-1">"{m.remarks}"</p>}
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── ROW 2: OPERATIONS, BUDGET & SUPPORT ── */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        
        {/* Support items */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <Zap className="size-4 text-amber-500" /> Support Required
              </span>
              <Button variant="ghost" size="icon-sm" asChild>
                <Link to="/support" title="View details"><ExternalLink className="size-3.5" /></Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-3 px-5 pb-3">
            {openSupport.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                <CheckCircle2 className="size-8 text-emerald-500 opacity-40" />
                <p className="text-xs font-medium">No outstanding support blocks</p>
              </div>
            ) : (
              <ScrollArea className="h-[180px] pr-2">
                <div className="space-y-2">
                  {openSupport.map((s) => {
                    const d = parseAppDate(s.deadline);
                    const daysLeft = d ? differenceInDays(d, today) : null;
                    return (
                      <div key={s.supportrequiredid} className="flex items-start gap-2.5 p-2 rounded-lg bg-muted/20 border hover:bg-muted/40 transition-colors">
                        <AlertTriangle className="size-3.5 mt-0.5 text-amber-500 shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold leading-snug line-clamp-2">{s.supporttext}</p>
                          <p className="text-[9px] text-muted-foreground mt-1">Cat: {s.category} · Owner: {ownerName(s.ownerorgnodeid)}</p>
                        </div>
                        <div className="shrink-0 text-right">
                          <Badge className={`${CRIT_BADGE[s.criticality] ?? ""} text-[8px] px-1 py-0`}>{s.criticality}</Badge>
                          {daysLeft !== null && (
                            <p className={`text-[9px] mt-1 ${daysLeft < 0 ? "text-red-500 font-bold" : "text-muted-foreground"}`}>
                              {daysLeft < 0 ? "Overdue" : `${daysLeft}d`}
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Budget Details */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <DollarSign className="size-4 text-emerald-500" /> Capital & Operations
              </span>
              <Button variant="ghost" size="icon-sm" asChild>
                <Link to="/budget" title="Budget allocation"><ExternalLink className="size-3.5" /></Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-4 px-5 space-y-3.5">
            <div className="rounded-lg bg-muted/30 p-3.5 space-y-2.5 border">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground font-medium">CAPEX Allocated</span>
                <span className="font-bold tabular-nums">{totalCapexBudget.toFixed(1)} CR</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground font-medium">CAPEX Expended</span>
                <span className="font-bold tabular-nums">{totalCapexActual.toFixed(1)} CR</span>
              </div>
              <div className="h-px bg-muted" />
              <div className={`flex items-center justify-between text-xs font-bold ${capexVariance >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
                <span className="flex items-center gap-1">
                  {capexVariance >= 0 ? <TrendingUp className="size-3.5" /> : <TrendingDown className="size-3.5" />}
                  Budget Variance
                </span>
                <span className="tabular-nums">{capexVariance >= 0 ? "+" : ""}{capexVariance.toFixed(2)} CR</span>
              </div>
            </div>
            {pOpex.length > 0 ? (
              <div className="rounded-lg bg-muted/30 p-3.5 space-y-2.5 border">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground font-medium">OPEX Allocations Target</span>
                  <span className="font-bold tabular-nums">{totalOpexTarget.toFixed(1)} CR</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground font-medium">Total OPEX Unit Cost</span>
                  <span className="font-bold tabular-nums">{totalOpexUnit.toFixed(1)} CR</span>
                </div>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-2.5">No OPEX metrics seeded.</p>
            )}
          </CardContent>
        </Card>

        {/* Partner deliverables & supply chain */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <Package className="size-4 text-blue-500" /> SCM & Partner Readiness
              </span>
              <Button variant="ghost" size="icon-sm" asChild>
                <Link to="/partners" title="Partners info"><ExternalLink className="size-3.5" /></Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent className="pt-3 px-5 pb-3">
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="rounded-lg bg-muted/20 border p-2 text-center">
                <div className="text-base font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">{scDelivered}</div>
                <div className="text-[9px] text-muted-foreground font-semibold">SCM Delivered</div>
              </div>
              <div className="rounded-lg bg-muted/20 border p-2 text-center">
                <div className="text-base font-extrabold text-red-500 tabular-nums">{scDelayed}</div>
                <div className="text-[9px] text-muted-foreground font-semibold">SCM Delayed</div>
              </div>
            </div>
            
            {pPartner.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-4">No partner actions tracked</p>
            ) : (
              <ScrollArea className="h-[95px] pr-2">
                <div className="space-y-1.5">
                  {pPartner.map((pd) => {
                    const isDelayed = pd.currentedc !== pd.targetedc;
                    return (
                      <div key={pd.partnerdeliverableid} className="flex items-center gap-2 text-xs p-1.5 rounded bg-muted/10 border border-muted/20">
                        <div className={`size-1.5 rounded-full shrink-0 ${isDelayed ? "bg-amber-500" : "bg-slate-400"}`} />
                        <span className="flex-1 truncate font-medium">{pd.deliverable}</span>
                        <span className="text-[10px] text-muted-foreground font-bold shrink-0">{pd.partnername}</span>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── ROW 3: REPORTING & LOGS ── */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* Latest Weekly Update */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md lg:col-span-2">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <BarChart3 className="size-4 text-violet-500" /> Latest Weekly Summary
              </span>
              {latestUpdate ? (
                <div className="flex items-center gap-1.5">
                  <Badge variant="outline" className="bg-violet-500/10 text-violet-500 border-none text-[10px]">{latestUpdate.weekkey}</Badge>
                  <Badge variant="outline" className="bg-slate-500/10 text-slate-500 border-none text-[10px]">{latestUpdate.status}</Badge>
                </div>
              ) : null}
            </div>
          </CardHeader>
          <CardContent className="pt-4 px-5 pb-4">
            {!latestUpdate || latestUpdateItems.length === 0 ? (
              <p className="text-xs text-muted-foreground text-center py-6">No weekly items updated for this cycle.</p>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {positiveItems.length > 0 && (
                  <div className="space-y-2 bg-emerald-500/5 p-3 rounded-lg border border-emerald-500/10">
                    <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">Highlight Achievements</p>
                    <div className="space-y-1.5">
                      {positiveItems.map((item) => (
                        <div key={item.weeklyupdateitemid} className="flex items-start gap-2 text-xs leading-normal">
                          <span className="text-emerald-500 shrink-0 font-bold">✓</span>
                          <span className="text-slate-600 dark:text-slate-300">{item.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {negativeItems.length > 0 && (
                  <div className="space-y-2 bg-rose-500/5 p-3 rounded-lg border border-rose-500/10">
                    <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider">Critical Concerns</p>
                    <div className="space-y-1.5">
                      {negativeItems.map((item) => (
                        <div key={item.weeklyupdateitemid} className="flex items-start gap-2 text-xs leading-normal">
                          <span className="text-red-500 shrink-0 font-bold">✗</span>
                          <span className="text-slate-600 dark:text-slate-300">{item.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent date change logs */}
        <Card className="border border-slate-100/10 bg-white/40 dark:bg-slate-900/40 backdrop-blur-md">
          <CardHeader className="pb-3 pt-4 px-5 border-b border-muted/30">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-sm flex items-center gap-2">
                <Clock className="size-4 text-indigo-500" /> Recent Schedule Shifts
              </span>
              <Badge className="text-[9px] bg-slate-500/10 text-slate-500 border-none" variant="outline">{recentChanges.length} changes</Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-3 px-5 pb-3">
            {recentChanges.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                <CheckCircle2 className="size-8 text-emerald-500 opacity-40" />
                <p className="text-xs font-medium">No scheduling changes this reporting week</p>
              </div>
            ) : (
              <ScrollArea className="h-[180px] pr-2">
                <div className="space-y-2">
                  {recentChanges.map((log) => (
                    <div key={log.datechangelogid} className="p-2 rounded-lg bg-amber-500/5 border border-amber-500/10">
                      <div className="flex items-center justify-between gap-1 text-[9px] text-muted-foreground mb-1">
                        <span className="capitalize font-bold text-slate-700 dark:text-slate-300">{log.module.replace("_", " ")}</span>
                        <span>{new Date(log.changedon).toLocaleDateString()}</span>
                      </div>
                      <p className="text-xs font-semibold truncate leading-none">{log.recordname}</p>
                      <div className="flex items-center gap-1.5 mt-1.5 text-[10px] font-mono">
                        <span className="line-through text-muted-foreground">{log.olddate}</span>
                        <ArrowRight className="size-2.5 text-muted-foreground" />
                        <span className="font-bold text-amber-600 dark:text-amber-400">{log.newdate}</span>
                      </div>
                      {log.reason && (
                        <p className="text-[10px] text-slate-500 italic mt-1 bg-black/5 dark:bg-white/5 p-1 rounded">
                          "{log.reason}"
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
