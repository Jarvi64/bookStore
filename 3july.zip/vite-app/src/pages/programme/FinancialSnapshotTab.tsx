/**
 * FinancialSnapshotTab
 *
 * Three sections:
 *  1. Programme P&L Cumulative (INR Cr)
 *  2. Rolling 4/5-week Cashflow (INR Cr) — week columns derived from selected month
 *  3. Key Financial Flags — fixed rows, editable INR Cr / Owner / Action
 */

import { useState, useMemo } from "react";
import { useAppStore } from "@/lib/store";
import {
  format,
  startOfMonth,
  endOfMonth,
  addDays,
  getDay,
} from "date-fns";
import {
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

// ─── Types ────────────────────────────────────────────────────────────────────

interface PLRow {
  id: string;
  name: string;
  contractValue: number | string;
  invoiced: number | string;
  received: number | string;
  cost: number | string;
  /** computed as ((contractValue - cost) / contractValue * 100) — or can be overridden */
  marginOverride?: number | string;
  fixed: boolean; // fixed rows cannot be deleted
}

interface FlagRow {
  id: string;
  label: string;
  inrCr: string;
  owner: string;
  action: string;
  fixed: true;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Compute Mon→Sun week ranges that cover an entire calendar month.
 *  The first week always starts on the 1st (even if mid-week).
 *  Subsequent weeks are Mon–Sun, capped at month-end.
 */
function getWeeksForMonth(year: number, month: number): { label: string; start: Date; end: Date }[] {
  const firstDay = startOfMonth(new Date(year, month));
  const lastDay  = endOfMonth(firstDay);
  const weeks: { label: string; start: Date; end: Date }[] = [];

  let cursor = firstDay;
  while (cursor <= lastDay) {
    const weekStart = cursor;
    // Find the next Sunday (day 0) after weekStart, or month-end, whichever is first
    let weekEnd = weekStart;
    // advance to end of week (Sunday)
    while (getDay(weekEnd) !== 0 && weekEnd < lastDay) {
      weekEnd = addDays(weekEnd, 1);
    }
    // If we hit month-end before Sunday, stop there
    if (weekEnd > lastDay) weekEnd = lastDay;

    weeks.push({
      label: `${format(weekStart, "d MMM")}–${format(weekEnd, "d MMM")}`,
      start: weekStart,
      end: weekEnd,
    });

    // Move to Monday of next week
    cursor = addDays(weekEnd, 1);
    if (getDay(cursor) !== 1 && cursor <= lastDay) {
      // already a Monday; in our scheme weekEnd is Sunday, so +1 = Monday
    }
  }
  return weeks;
}

function toNum(v: number | string): number {
  const n = parseFloat(String(v));
  return isNaN(n) ? 0 : n;
}

function fmt(v: number | string): string {
  const n = toNum(v);
  return n === 0 ? "" : n.toFixed(2);
}

// ─── Inline number cell (editable) ────────────────────────────────────────────

function NumCell({
  value,
  onChange,
  readOnly = false,
  highlight,
}: {
  value: number | string;
  onChange: (v: string) => void;
  readOnly?: boolean;
  highlight?: "green" | "red" | "neutral";
}) {
  const colorClass =
    highlight === "green" ? "text-emerald-600 dark:text-emerald-400 font-semibold" :
    highlight === "red"   ? "text-rose-600 dark:text-rose-400 font-semibold" : "";

  if (readOnly) {
    return (
      <div className={`text-right text-xs px-2 py-1.5 ${colorClass}`}>
        {fmt(value) || "—"}
      </div>
    );
  }

  return (
    <Input
      type="number"
      step="0.01"
      value={value === "" || value === 0 ? "" : String(value)}
      onChange={(e) => onChange(e.target.value)}
      className={`h-7 text-xs text-right border-transparent bg-transparent focus:border-input focus:bg-background rounded px-1.5 ${colorClass}`}
      placeholder="0.00"
    />
  );
}

function TextCell({
  value,
  onChange,
  placeholder = "",
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <Input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className={`h-7 text-xs border-transparent bg-transparent focus:border-input focus:bg-background rounded px-1.5 ${className}`}
      placeholder={placeholder}
    />
  );
}

// ─── Default initial data ─────────────────────────────────────────────────────

const DEFAULT_PL_ROWS: PLRow[] = [
  {
    id: "pl-1",
    name: "Contracted Order Value (Total)",
    contractValue: "",
    invoiced: "",
    received: "",
    cost: "",
    fixed: true,
  },
  {
    id: "pl-2",
    name: "Capex (Program Total)",
    contractValue: "",
    invoiced: "",
    received: "",
    cost: "",
    fixed: true,
  },
];

const CASHFLOW_ROW_DEFS: { id: string; label: string }[] = [
  { id: "cf-opening", label: "Opening Cash Balance" },
  { id: "cf-collections", label: "+ Customer Collections" },
  { id: "cf-payments", label: "− Vendor / OEM Payments" },
  { id: "cf-net", label: "Net Cash Flow" },
  { id: "cf-closing", label: "Closing Cash Balance" },
];

const FLAG_ROWS: Omit<FlagRow, "inrCr" | "owner" | "action">[] = [
  { id: "flag-1", label: "Receivables Outstanding >90 Days", fixed: true },
  { id: "flag-2", label: "Payment Milestone at Risk This Period", fixed: true },
  { id: "flag-3", label: "LD / Penalty Exposure This Period", fixed: true },
  { id: "flag-4", label: "Working Capital Gap / Credit Facility Needed", fixed: true },
];

// ─── Component ────────────────────────────────────────────────────────────────

export function FinancialSnapshotTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid);
  void programmeId; // may be used later for persistence

  const today = new Date();

  // ── State: P&L ──
  const [plRows, setPlRows] = useState<PLRow[]>(DEFAULT_PL_ROWS);

  // ── State: Cashflow month picker ──
  const [cfYear, setCfYear]   = useState(today.getFullYear());
  const [cfMonth, setCfMonth] = useState(today.getMonth()); // 0-indexed

  // Derive week bands for selected month
  const weeks = useMemo(() => getWeeksForMonth(cfYear, cfMonth), [cfYear, cfMonth]);

  // weekKey = ISO date string of Monday of that week (or 1st of month for first week)
  const weekKeys = weeks.map((w) => format(w.start, "yyyy-MM-dd"));

  // ── State: Cashflow values [rowId][weekKey] ──
  const [cfValues, setCfValues] = useState<Record<string, Record<string, string>>>({});

  const getCfVal = (rowId: string, wk: string) => cfValues[rowId]?.[wk] ?? "";
  const setCfVal = (rowId: string, wk: string, val: string) =>
    setCfValues((prev) => ({
      ...prev,
      [rowId]: { ...(prev[rowId] ?? {}), [wk]: val },
    }));

  // Row totals
  const cfRowTotal = (rowId: string): number =>
    weekKeys.reduce((s, wk) => s + toNum(getCfVal(rowId, wk)), 0);

  // ── State: Financial Flags ──
  const [flags, setFlags] = useState<FlagRow[]>(
    FLAG_ROWS.map((f) => ({ ...f, inrCr: "", owner: "", action: "" }))
  );

  const updateFlag = (id: string, field: keyof FlagRow, val: string) =>
    setFlags((prev) =>
      prev.map((f) => (f.id === id ? { ...f, [field]: val } : f))
    );

  // ─── P&L helpers ──────────────────────────────────────────────────────────

  const addPlRow = () => {
    const newRow: PLRow = {
      id: `pl-${Date.now()}`,
      name: "",
      contractValue: "",
      invoiced: "",
      received: "",
      cost: "",
      fixed: false,
    };
    setPlRows((prev) => [...prev, newRow]);
  };

  const updatePlRow = (id: string, field: keyof PLRow, val: string | number) =>
    setPlRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [field]: val } : r))
    );

  const deletePlRow = (id: string) =>
    setPlRows((prev) => prev.filter((r) => r.id !== id || r.fixed));

  // Totals row
  const plTotals = useMemo(() => {
    const tot = { contractValue: 0, invoiced: 0, received: 0, cost: 0 };
    plRows.forEach((r) => {
      tot.contractValue += toNum(r.contractValue);
      tot.invoiced      += toNum(r.invoiced);
      tot.received      += toNum(r.received);
      tot.cost          += toNum(r.cost);
    });
    return tot;
  }, [plRows]);

  const plMargin = (row: PLRow) => {
    if (row.marginOverride !== undefined && row.marginOverride !== "")
      return toNum(row.marginOverride);
    const cv = toNum(row.contractValue);
    if (cv === 0) return null;
    return ((cv - toNum(row.cost)) / cv) * 100;
  };

  const totalMargin = () => {
    const cv = plTotals.contractValue;
    if (cv === 0) return null;
    return ((cv - plTotals.cost) / cv) * 100;
  };

  const fmtMargin = (m: number | null) =>
    m === null ? "—" : `${m.toFixed(1)}%`;

  // ─── Month nav ────────────────────────────────────────────────────────────

  const prevMonth = () => {
    if (cfMonth === 0) { setCfMonth(11); setCfYear((y) => y - 1); }
    else setCfMonth((m) => m - 1);
  };
  const nextMonth = () => {
    if (cfMonth === 11) { setCfMonth(0); setCfYear((y) => y + 1); }
    else setCfMonth((m) => m + 1);
  };

  const monthLabel = format(new Date(cfYear, cfMonth), "MMMM yyyy");

  // ─── Render ───────────────────────────────────────────────────────────────

  const thCls = "px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground text-right whitespace-nowrap";
  const thLeftCls = "px-3 py-2.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground text-left whitespace-nowrap";
  const tdFixedCls = "px-3 py-1.5 text-xs font-semibold text-foreground bg-muted/20 border-b";
  const tdUserCls  = "px-1 py-0.5 text-xs border-b";
  const tdTotalCls = "px-3 py-2 text-xs font-bold text-right bg-muted/30 border-t-2 border-border";

  return (
    <div className="space-y-8">

      {/* ═══════════════════════════════════════════════════════════════════ */}
      {/* 1. PROGRAMME P&L CUMULATIVE                                        */}
      {/* ═══════════════════════════════════════════════════════════════════ */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-bold tracking-tight text-foreground flex items-center gap-2">
              <TrendingUp className="size-4 text-primary" />
              Programme P&amp;L Cumulative
              <span className="text-[10px] font-normal text-muted-foreground">(INR Cr)</span>
            </h2>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              Fixed rows: Contracted Order Value and Capex totals. Add milestone rows as needed.
            </p>
          </div>
          <Button size="sm" variant="outline" onClick={addPlRow} className="gap-1.5 text-xs h-8">
            <Plus className="size-3.5" />
            Add Milestone Row
          </Button>
        </div>

        <div className="rounded-xl border border-border overflow-x-auto shadow-sm">
          <table className="w-full min-w-[700px]">
            <thead>
              <tr className="bg-muted/40 border-b">
                <th className={thLeftCls} style={{ minWidth: 220 }}>Name</th>
                <th className={thCls}>Contract Value</th>
                <th className={thCls}>Invoiced (Cumul)</th>
                <th className={thCls}>Received (Cumul)</th>
                <th className={thCls}>Cost (Cumul)</th>
                <th className={thCls}>Margin %</th>
                <th className="w-8" />
              </tr>
            </thead>
            <tbody>
              {plRows.map((row, idx) => {
                const margin = plMargin(row);
                const marginColor: "green" | "red" | "neutral" =
                  margin === null ? "neutral" : margin >= 0 ? "green" : "red";

                return (
                  <tr
                    key={row.id}
                    className={`group transition-colors ${row.fixed ? "bg-muted/10" : idx % 2 === 0 ? "" : "bg-muted/5"} hover:bg-primary/5`}
                  >
                    {/* Name */}
                    <td className={row.fixed ? tdFixedCls : tdUserCls} style={{ minWidth: 220 }}>
                      {row.fixed ? (
                        <span className="flex items-center gap-1.5">
                          <span className="size-1.5 rounded-full bg-primary/60 shrink-0" />
                          {row.name}
                        </span>
                      ) : (
                        <TextCell
                          value={row.name}
                          onChange={(v) => updatePlRow(row.id, "name", v)}
                          placeholder="Milestone name…"
                        />
                      )}
                    </td>

                    {/* Contract Value */}
                    <td className={row.fixed ? `${tdFixedCls} text-right` : tdUserCls}>
                      <NumCell
                        value={row.contractValue}
                        onChange={(v) => updatePlRow(row.id, "contractValue", v)}
                      />
                    </td>

                    {/* Invoiced */}
                    <td className={row.fixed ? `${tdFixedCls} text-right` : tdUserCls}>
                      <NumCell
                        value={row.invoiced}
                        onChange={(v) => updatePlRow(row.id, "invoiced", v)}
                      />
                    </td>

                    {/* Received */}
                    <td className={row.fixed ? `${tdFixedCls} text-right` : tdUserCls}>
                      <NumCell
                        value={row.received}
                        onChange={(v) => updatePlRow(row.id, "received", v)}
                        highlight={
                          toNum(row.received) >= toNum(row.invoiced) && toNum(row.invoiced) > 0
                            ? "green"
                            : undefined
                        }
                      />
                    </td>

                    {/* Cost */}
                    <td className={row.fixed ? `${tdFixedCls} text-right` : tdUserCls}>
                      <NumCell
                        value={row.cost}
                        onChange={(v) => updatePlRow(row.id, "cost", v)}
                      />
                    </td>

                    {/* Margin % */}
                    <td className={row.fixed ? `${tdFixedCls} text-right` : tdUserCls}>
                      {row.fixed ? (
                        <span className={`text-xs font-semibold ${marginColor === "green" ? "text-emerald-600 dark:text-emerald-400" : marginColor === "red" ? "text-rose-600 dark:text-rose-400" : "text-muted-foreground"}`}>
                          {fmtMargin(margin)}
                        </span>
                      ) : (
                        <Input
                          type="number"
                          step="0.1"
                          value={row.marginOverride ?? ""}
                          onChange={(e) => updatePlRow(row.id, "marginOverride", e.target.value)}
                          className={`h-7 text-xs text-right border-transparent bg-transparent focus:border-input focus:bg-background rounded px-1.5 ${marginColor === "green" ? "text-emerald-600" : marginColor === "red" ? "text-rose-600" : ""}`}
                          placeholder={margin !== null ? `${margin.toFixed(1)}` : "—"}
                        />
                      )}
                    </td>

                    {/* Delete */}
                    <td className="px-1 py-0.5 border-b">
                      {!row.fixed && (
                        <button
                          onClick={() => deletePlRow(row.id)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-rose-50 dark:hover:bg-rose-900/20 text-rose-500"
                        >
                          <Trash2 className="size-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>

            {/* Totals row */}
            <tfoot>
              <tr className="bg-muted/30">
                <td className="px-3 py-2 text-xs font-bold text-foreground border-t-2 border-border">
                  Total
                </td>
                <td className={tdTotalCls}>{fmt(plTotals.contractValue) || "—"}</td>
                <td className={tdTotalCls}>{fmt(plTotals.invoiced) || "—"}</td>
                <td className={tdTotalCls}>{fmt(plTotals.received) || "—"}</td>
                <td className={tdTotalCls}>{fmt(plTotals.cost) || "—"}</td>
                <td className={`${tdTotalCls} ${
                  (totalMargin() ?? 0) >= 0 ? "text-emerald-600" : "text-rose-600"
                }`}>
                  {fmtMargin(totalMargin())}
                </td>
                <td className="border-t-2 border-border bg-muted/30" />
              </tr>
            </tfoot>
          </table>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════════════ */}
      {/* 2. ROLLING 4/5-WEEK CASHFLOW                                       */}
      {/* ═══════════════════════════════════════════════════════════════════ */}
      <section>
        {/* Header + month nav */}
        <div className="flex items-center justify-between mb-3 flex-wrap gap-3">
          <div>
            <h2 className="text-sm font-bold tracking-tight text-foreground flex items-center gap-2">
              <TrendingDown className="size-4 text-primary" />
              Rolling Cashflow
              <span className="text-[10px] font-normal text-muted-foreground">(INR Cr)</span>
            </h2>
            <p className="text-[11px] text-muted-foreground mt-0.5">
              {weeks.length}-week view for {monthLabel}. Weeks run Mon–Sun; first week starts on the 1st.
            </p>
          </div>

          {/* Month picker */}
          <div className="flex items-center gap-1.5 border rounded-lg px-1 py-0.5">
            <button onClick={prevMonth} className="p-1.5 rounded hover:bg-muted transition-colors">
              <ChevronLeft className="size-3.5" />
            </button>
            <span className="text-xs font-semibold px-2 min-w-[110px] text-center">{monthLabel}</span>
            <button onClick={nextMonth} className="p-1.5 rounded hover:bg-muted transition-colors">
              <ChevronRight className="size-3.5" />
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-border overflow-hidden shadow-sm">
          {/* Month context banner */}
          <div className="px-4 py-2 bg-gradient-to-r from-primary/8 via-primary/4 to-transparent border-b flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-primary/70">
                {format(new Date(cfYear, cfMonth), "MMM yyyy")}
              </span>
              <div className="flex items-center gap-1.5">
                {weeks.map((w, i) => (
                  <div key={i} className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-background/80 border border-border/50">
                    <span className="size-1.5 rounded-full bg-primary/50" />
                    <span className="text-[9px] font-medium text-muted-foreground">{w.label}</span>
                  </div>
                ))}
              </div>
            </div>
            <Badge variant="outline" className="text-[9px]">{weeks.length} Weeks</Badge>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px]">
              <thead>
                <tr className="bg-muted/30 border-b">
                  <th className={thLeftCls} style={{ minWidth: 220 }}>
                    <span className="flex items-center gap-1.5">Particulars</span>
                  </th>
                  {weeks.map((_, i) => (
                    <th key={weekKeys[i]} className={thCls}>
                      <span className="block text-[9px] font-semibold text-primary/60">W{i + 1}</span>
                    </th>
                  ))}
                  <th className={`${thCls} border-l-2 border-primary/20`}>
                    Total
                  </th>
                </tr>
              </thead>
              <tbody>
                {CASHFLOW_ROW_DEFS.map((row) => {
                  const isNet     = row.id === "cf-net";
                  const isClosing = row.id === "cf-closing";
                  const isInflow  = row.id === "cf-collections";
                  const isOutflow = row.id === "cf-payments";
                  const isSummary = isNet || isClosing;
                  const rowTotal  = cfRowTotal(row.id);

                  // Row indicator color
                  const indicatorColor = isInflow  ? "bg-emerald-500"
                    : isOutflow ? "bg-rose-500"
                    : isSummary ? "bg-primary"
                    : "bg-muted-foreground/30";

                  // Row totals color
                  const totalColor = isSummary
                    ? rowTotal >= 0
                      ? "text-emerald-600 dark:text-emerald-400"
                      : "text-rose-600 dark:text-rose-400"
                    : "text-foreground";

                  // Max value across all row totals for spark bar scaling
                  const maxRowTotal = Math.max(
                    ...CASHFLOW_ROW_DEFS.map((r) => Math.abs(cfRowTotal(r.id))),
                    0.01
                  );
                  const sparkPct = Math.min(100, (Math.abs(rowTotal) / maxRowTotal) * 100);

                  return (
                    <tr
                      key={row.id}
                      className={`group transition-colors ${
                        isSummary
                          ? "bg-primary/[0.04] border-t border-border/60"
                          : "hover:bg-muted/30"
                      }`}
                    >
                      {/* Label with colored indicator */}
                      <td className={`py-2 border-b`} style={{ minWidth: 220 }}>
                        <span className="flex items-center gap-2.5 px-3">
                          <span className={`w-[3px] h-5 rounded-full ${indicatorColor} shrink-0`} />
                          <span className={`text-xs ${isSummary ? "font-bold" : "font-medium"} text-foreground`}>
                            {row.label}
                          </span>
                        </span>
                      </td>

                      {/* Week input cells */}
                      {weekKeys.map((wk) => {
                        const val = getCfVal(row.id, wk);
                        const n = toNum(val);
                        const cellColor: "green" | "red" | "neutral" =
                          isSummary ? (n > 0 ? "green" : n < 0 ? "red" : "neutral")
                          : isInflow ? (n > 0 ? "green" : "neutral")
                          : isOutflow ? (n > 0 ? "red" : "neutral")
                          : "neutral";

                        return (
                          <td key={wk} className="px-1 py-0.5 border-b">
                            <NumCell
                              value={val}
                              onChange={(v) => setCfVal(row.id, wk, v)}
                              highlight={cellColor}
                            />
                          </td>
                        );
                      })}

                      {/* Row total with spark bar */}
                      <td className={`px-3 py-1.5 border-b border-l-2 border-primary/20`}>
                        <div className="flex flex-col items-end gap-0.5">
                          <span className={`text-xs font-bold ${totalColor}`}>
                            {rowTotal === 0 ? "—" : rowTotal.toFixed(2)}
                          </span>
                          {rowTotal !== 0 && (
                            <div className="w-full h-1 rounded-full bg-muted overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  isSummary
                                    ? rowTotal >= 0 ? "bg-emerald-400" : "bg-rose-400"
                                    : isInflow ? "bg-emerald-300"
                                    : isOutflow ? "bg-rose-300"
                                    : "bg-primary/30"
                                }`}
                                style={{ width: `${sparkPct}%` }}
                              />
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════════════════════════════ */}
      {/* 3. KEY FINANCIAL FLAGS                                              */}
      {/* ═══════════════════════════════════════════════════════════════════ */}
      <section>
        <div className="mb-3">
          <h2 className="text-sm font-bold tracking-tight text-foreground flex items-center gap-2">
            <AlertTriangle className="size-4 text-amber-500" />
            Key Financial Flags
            <Badge variant="outline" className="text-[10px] font-normal">
              This Programme
            </Badge>
          </h2>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Fixed items — enter INR value, owner, and any action/note.
          </p>
        </div>

        <div className="rounded-xl border border-border overflow-x-auto shadow-sm">
          <table className="w-full min-w-[680px]">
            <thead>
              <tr className="bg-muted/40 border-b">
                <th className={thLeftCls} style={{ minWidth: 280 }}>Financial Flag</th>
                <th className={thCls} style={{ minWidth: 120 }}>INR (Cr)</th>
                <th className={thLeftCls} style={{ minWidth: 150 }}>Owner</th>
                <th className={thLeftCls}>Action / Note</th>
              </tr>
            </thead>
            <tbody>
              {flags.map((flag, idx) => {
                const hasVal = flag.inrCr !== "" && toNum(flag.inrCr) !== 0;
                return (
                  <tr
                    key={flag.id}
                    className={`group transition-colors ${idx % 2 === 0 ? "" : "bg-muted/5"} hover:bg-amber-50/30 dark:hover:bg-amber-900/10`}
                  >
                    {/* Label */}
                    <td className="px-3 py-2 text-xs font-semibold text-foreground border-b" style={{ minWidth: 280 }}>
                      <span className="flex items-center gap-2">
                        {hasVal && (
                          <span className="size-1.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
                        )}
                        {!hasVal && (
                          <span className="size-1.5 rounded-full bg-muted-foreground/30 shrink-0" />
                        )}
                        {flag.label}
                      </span>
                    </td>

                    {/* INR Cr */}
                    <td className="px-1 py-0.5 border-b" style={{ minWidth: 120 }}>
                      <NumCell
                        value={flag.inrCr}
                        onChange={(v) => updateFlag(flag.id, "inrCr", v)}
                        highlight={toNum(flag.inrCr) > 0 ? "red" : "neutral"}
                      />
                    </td>

                    {/* Owner */}
                    <td className="px-1 py-0.5 border-b" style={{ minWidth: 150 }}>
                      <TextCell
                        value={flag.owner}
                        onChange={(v) => updateFlag(flag.id, "owner", v)}
                        placeholder="Owner…"
                      />
                    </td>

                    {/* Action */}
                    <td className="px-1 py-0.5 border-b">
                      <TextCell
                        value={flag.action}
                        onChange={(v) => updateFlag(flag.id, "action", v)}
                        placeholder="Action / note…"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
