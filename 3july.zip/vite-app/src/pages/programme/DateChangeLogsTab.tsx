import { useAppStore } from "@/lib/store";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CalendarDays, Clock, ArrowRight } from "lucide-react";

export function DateChangeLogsTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid);
  const { dateChangeLogs } = useAppStore();
  const [recentCutoff] = useState(() => new Date(Date.now() - 7 * 86400000));

  const logs = dateChangeLogs
    .filter((l) => l.programmeid === programmeId)
    .sort(
      (a, b) =>
        new Date(b.changedon).getTime() - new Date(a.changedon).getTime(),
    );

  const formatDate = (d: string) => {
    if (!d) return "—";
    // Check if it's a full ISO datetime or just a date
    const date = d.includes("T") ? new Date(d) : new Date(d + "T00:00:00");
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const formatDateTime = (d: string) => {
    if (!d) return "—";
    const date = new Date(d);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const fieldLabel = (field: string) => {
    const map: Record<string, string> = {
      startdate: "Start Date",
      originaltargetedcompletiondate: "Original Target",
      targetedcompletiondate: "Target Completion",
      deadline: "Deadline",
    };
    return map[field] || field;
  };

  const tableLabel = (moduleName: string) => {
    const map: Record<string, string> = {
      milestone: "Milestone",
      support_required: "Support",
      partner_deliverable: "Partner",
      capex: "CAPEX",
      opex: "OPEX",
      certification: "Certification",
      supply_chain: "Supply Chain",
    };
    return map[moduleName] || moduleName;
  };

  return (
    <div className="flex flex-col gap-4 pt-4">
      <div>
        <h3 className="text-lg font-semibold">Date Change Logs</h3>
        <p className="text-sm text-muted-foreground">
          Append-only audit trail of date changes. Recent changes (last 7 days)
          are highlighted.
        </p>
      </div>

      <div className="rounded-md border bg-card overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Source</TableHead>
              <TableHead>Record</TableHead>
              <TableHead>Field</TableHead>
              <TableHead>Date Change</TableHead>
              <TableHead className="min-w-[200px]">Reason</TableHead>
              <TableHead>Changed On</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={6}
                  className="h-24 text-center text-muted-foreground"
                >
                  No date changes recorded yet.
                </TableCell>
              </TableRow>
            ) : (
              logs.map((log) => {
                const isRecent = new Date(log.changedon) >= recentCutoff;
                return (
                  <TableRow
                    key={log.datechangelogid}
                    className={isRecent ? "bg-amber-50/50 dark:bg-amber-950/10" : ""}
                  >
                    <TableCell>
                      <Badge variant="outline" className="font-normal">
                        {tableLabel(log.module)}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium text-foreground text-sm">
                      {log.recordname}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="font-normal">
                        <CalendarDays className="size-3 mr-1" />
                        {fieldLabel(log.fieldname)}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="line-through text-destructive whitespace-nowrap">
                          {formatDate(log.olddate)}
                        </span>
                        <ArrowRight className="size-3 text-muted-foreground shrink-0" />
                        <span className="font-medium whitespace-nowrap">
                          {formatDate(log.newdate)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {log.reason}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-sm whitespace-nowrap">
                        <Clock className="size-3 text-muted-foreground" />
                        {formatDateTime(log.changedon)}
                        {isRecent && (
                          <Badge
                            variant="destructive"
                            className="ml-1 px-1.5 py-0 text-[10px] leading-4"
                          >
                            Recent
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
