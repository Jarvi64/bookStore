import { useState, useMemo, useEffect } from "react";
import { useForm, Controller } from "react-hook-form";
import { useSearchParams } from "react-router-dom";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore, type SupplyChainReadiness } from "@/lib/store";
import { toast } from "sonner";
import {
  Plus,
  Pencil,
  Trash2,
  AlertTriangle,
  ChevronRight,
  FileText,
  ShieldCheck,
  Truck,
  CheckCircle2,
  DollarSign,
  Boxes,
  Link2,
  Search,
  Package,
  Clock,
  CircleDot,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldError } from "@/components/ui/field";
import { DatePicker } from "@/components/ui/date-picker";
import {
  Combobox,
  ComboboxContent,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
  ComboboxEmpty
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { DateChangePopover } from "@/components/ui/date-change-popover";
import { Separator } from "@/components/ui/separator";

const STATUSES = ["Sourcing", "Ordered", "In Transit", "Delivered", "Delayed"];

const schema = z.object({
  item: z.string().min(1, "Item is required"),
  supplier: z.string().min(1, "Supplier is required"),
  actualcostcr: z.coerce.number().min(0, "Must be positive"),
  targetcostcr: z.coerce.number().min(0, "Must be positive"),
  status: z.string().min(1, "Status is required"),
  dateoforder: z.string().optional().nullable(),
  dateofdelivery: z.string().min(1, "Delivery date is required"),
  leadtime: z.string().min(1, "Lead time is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  riskremarks: z.string().optional().nullable(),
  milestoneid: z.string().optional().nullable(),
  quantity: z.coerce.number().min(0, "Quantity must be positive").optional(),
  prDate: z.string().optional().nullable(),
  prNumber: z.string().optional().nullable(),
  poDate: z.string().optional().nullable(),
  poNumber: z.string().optional().nullable(),
  poValueCr: z.coerce.number().min(0, "PO value must be positive").optional(),
  paymentReleasedCr: z.coerce.number().min(0, "Payment released must be positive").optional(),
});

type FormData = z.infer<typeof schema>;

// ── Secondary Components ──────────────────────────────────────
function ProcurementPipeline({ item }: { item: SupplyChainReadiness }) {
  const steps = [
    {
      title: "Purchase Requisition",
      status: item.prNumber ? "Released" : "Not Started",
      ref: item.prNumber || "—",
      date: item.prDate || "—",
      icon: <FileText className="size-4 text-violet-500" />,
      colorClass: "from-violet-500/10 to-violet-500/5 border-violet-500/20 text-violet-700 dark:text-violet-400"
    },
    {
      title: "Purchase Order",
      status: item.poNumber ? "Released" : (item.prNumber ? "Active" : "Not Started"),
      ref: item.poNumber || "—",
      date: item.poDate || "—",
      icon: <ShieldCheck className="size-4 text-indigo-500" />,
      colorClass: "from-indigo-500/10 to-indigo-500/5 border-indigo-500/20 text-indigo-700 dark:text-indigo-400"
    },
    {
      title: "In Transit",
      status: item.status === "In Transit" ? "Active" : (item.status === "Delivered" ? "Completed" : "Not Started"),
      ref: item.leadtime ? `Lead Time: ${item.leadtime}` : "—",
      date: item.dateoforder ? `Ordered: ${item.dateoforder}` : "—",
      icon: <Truck className="size-4 text-cyan-500" />,
      colorClass: "from-cyan-500/10 to-cyan-500/5 border-cyan-500/20 text-cyan-700 dark:text-cyan-400"
    },
    {
      title: "Receipt & Delivery",
      status: item.status === "Delivered" ? "Completed" : (item.status === "Delayed" ? "Delayed" : "Not Started"),
      ref: item.status === "Delivered" ? "Received at Warehouse" : (item.status === "Delayed" ? "Delayed" : "Pending"),
      date: item.dateofdelivery || "—",
      icon: <CheckCircle2 className="size-4 text-emerald-500" />,
      colorClass: "from-emerald-500/10 to-emerald-500/5 border-emerald-500/20 text-emerald-700 dark:text-emerald-400"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5 w-full">
      {steps.map((step, idx) => {
        const isDone = step.status === "Completed" || step.status === "Released";
        const isActive = step.status === "Active";
        const isDelayed = step.status === "Delayed";

        return (
          <div
            key={idx}
            className={`
              relative rounded-xl border p-3.5 flex flex-col justify-between bg-gradient-to-b transition-all duration-300 shadow-sm
              ${isDone
                ? "bg-emerald-500/[0.01] border-emerald-500/30 text-foreground"
                : isActive
                  ? "bg-blue-500/[0.02] border-blue-500/40 shadow-[0_0_12px_rgba(59,130,246,0.06)] text-foreground"
                  : isDelayed
                    ? "bg-rose-500/[0.02] border-rose-500/40 shadow-[0_0_12px_rgba(244,63,94,0.06)] text-foreground"
                    : "bg-muted/30 border-border/50 text-muted-foreground opacity-60"
              }
            `}
          >
            {/* Step header */}
            <div className="flex items-center justify-between gap-2">
              <span className="text-[10px] uppercase font-bold tracking-wider opacity-60">Step 0{idx + 1}</span>
              <Badge
                variant="outline"
                className={`
                  text-[9px] px-1.5 py-0 border-0 font-bold tracking-wide uppercase
                  ${isDone ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : ""}
                  ${isActive ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 animate-pulse" : ""}
                  ${isDelayed ? "bg-rose-500/10 text-rose-600 dark:text-rose-400" : ""}
                  ${step.status === "Not Started" ? "bg-muted text-muted-foreground/60 font-semibold" : ""}
                `}
              >
                {step.status}
              </Badge>
            </div>

            {/* Icon & Title */}
            <div className="flex items-center gap-2 mt-3">
              <div className={`p-1.5 rounded-lg border ${isDone || isActive ? "bg-card shadow-sm border-current/10" : "bg-transparent"}`}>
                {step.icon}
              </div>
              <span className="text-xs font-extrabold leading-tight">{step.title}</span>
            </div>

            <Separator className="my-2.5 bg-border/40" />

            {/* Info details */}
            <div className="space-y-1.5 font-mono text-[9px]">
              <div className="flex items-center justify-between gap-2">
                <span className="text-muted-foreground">REF:</span>
                <span className="font-semibold truncate max-w-[125px]" title={step.ref}>{step.ref}</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-muted-foreground">DATE:</span>
                <span className="font-semibold">{step.date}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function PaymentProgress({ item }: { item: SupplyChainReadiness }) {
  const poVal = item.poValueCr || 0;
  const payReleased = item.paymentReleasedCr || 0;
  const pct = poVal > 0 ? Math.min(100, Math.round((payReleased / poVal) * 100)) : 0;

  return (
    <div className="flex flex-col gap-3 p-4.5 border rounded-xl bg-card min-w-[240px] md:min-w-[280px] shadow-sm justify-between">
      <div className="flex items-center justify-between text-xs font-semibold">
        <span className="text-muted-foreground uppercase tracking-wider text-[10px] font-bold">Payment Progress</span>
        <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-0">{pct}% Released</Badge>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-1">
        <div className="space-y-0.5">
          <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-wider">PO Value</span>
          <span className="text-sm font-extrabold font-mono text-foreground leading-none">{poVal.toFixed(2)} Cr</span>
        </div>
        <div className="space-y-0.5 border-l pl-3">
          <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-wider">Released</span>
          <span className="text-sm font-extrabold font-mono text-emerald-600 dark:text-emerald-400 leading-none">{payReleased.toFixed(2)} Cr</span>
        </div>
      </div>

      <div className="w-full bg-muted rounded-full h-2 mt-2 overflow-hidden relative">
        <div
          className="bg-gradient-to-r from-emerald-500 to-teal-500 h-2 rounded-full transition-all duration-500"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex justify-between text-[9px] text-muted-foreground mt-0.5 font-mono">
        <span>0.00 Cr</span>
        <span>Balance: {(poVal - payReleased).toFixed(2)} Cr</span>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════
export function SupplyChainReadinessTab() {
  const [searchParams, setSearchParams] = useSearchParams();
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid);
  const {
    supplyChains,
    programmeOrgNodes,
    milestones,
    addSupplyChain,
    updateSupplyChain,
    deleteSupplyChain,
    addDateChangeLog,
    dateChangeLogs,
  } = useAppStore();

  const items = supplyChains.filter((s) => s.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes");
  const deliverables = useMemo(
    () => milestones.filter((m) => m.programmeid === programmeId && m.parentMilestoneId !== null),
    [milestones, programmeId],
  );

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [expandedItemId, setExpandedItemId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [quickAdd, setQuickAdd] = useState({ item: "", supplier: "", status: "Sourcing", dateofdelivery: "", leadtime: "", ownerorgnodeid: "", targetcostcr: 0 });

  // Filtered items
  const filteredItems = useMemo(() => {
    let filtered = items;
    if (statusFilter !== "All") {
      filtered = filtered.filter((i) => i.status === statusFilter);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (i) => i.item.toLowerCase().includes(q) || i.supplier.toLowerCase().includes(q)
      );
    }
    return filtered;
  }, [items, statusFilter, searchQuery]);

  // Totals calculations
  const totalTarget = items.reduce((acc, i) => acc + i.targetcostcr, 0);
  const totalActual = items.reduce((acc, i) => acc + i.actualcostcr, 0);
  const totalVariance = totalTarget - totalActual;

  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChangeData, setPendingDateChangeData] = useState<{
    formData: FormData;
    changes: { field: string; oldDate: string; newDate: string }[];
  } | null>(null);
  const [showReasonDialog, setShowReasonDialog] = useState(false);

  const { register, handleSubmit, reset, control, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema) as any
  });

  // Calculate Variance dynamically on the form
  const watchActual = watch("actualcostcr", 0);
  const watchTarget = watch("targetcostcr", 0);
  const currentVariance = useMemo(() => watchTarget - watchActual, [watchActual, watchTarget]);

  // Handle auto-add deep links from milestones tab
  useEffect(() => {
    const addDeliverableId = searchParams.get("add_linked_deliverable");
    if (addDeliverableId && deliverables.some(d => d.milestoneid === addDeliverableId)) {
      // open dialog prefilled
      reset({
        item: "", supplier: "", actualcostcr: 0, targetcostcr: 0,
        status: "Sourcing", dateoforder: "", dateofdelivery: "",
        leadtime: "", ownerorgnodeid: "", riskremarks: "",
        milestoneid: addDeliverableId, quantity: 0,
        prDate: "", prNumber: "", poDate: "", poNumber: "",
        poValueCr: 0, paymentReleasedCr: 0
      });
      setEditingId(null);
      setIsDialogOpen(true);

      // Clear URL params safely
      setSearchParams({});
    }
  }, [searchParams, deliverables, reset, setSearchParams]);

  const openAddDialog = () => {
    reset({
      item: "", supplier: "", actualcostcr: 0, targetcostcr: 0,
      status: "Sourcing", dateoforder: "", dateofdelivery: "",
      leadtime: "", ownerorgnodeid: "", riskremarks: "",
      milestoneid: null, quantity: 0,
      prDate: "", prNumber: "", poDate: "", poNumber: "",
      poValueCr: 0, paymentReleasedCr: 0
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // prevent expanding row on edit click
    const item = items.find((s) => s.supplychainreadinessid === id);
    if (item) {
      reset({
        ...item,
        riskremarks: item.riskremarks || "",
        milestoneid: item.milestoneid || null,
        quantity: item.quantity || 0,
        prDate: item.prDate || "",
        prNumber: item.prNumber || "",
        poDate: item.poDate || "",
        poNumber: item.poNumber || "",
        poValueCr: item.poValueCr || 0,
        paymentReleasedCr: item.paymentReleasedCr || 0,
      });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    if (editingId) {
      const existing = items.find((s) => s.supplychainreadinessid === editingId);
      if (existing) {
        const changes = [];
        if (existing.dateoforder !== data.dateoforder) {
          changes.push({ field: "dateoforder", oldDate: existing.dateoforder || "N/A", newDate: data.dateoforder || "N/A" });
        }
        if (existing.dateofdelivery !== data.dateofdelivery) {
          changes.push({ field: "dateofdelivery", oldDate: existing.dateofdelivery, newDate: data.dateofdelivery });
        }

        if (changes.length > 0) {
          setPendingDateChangeData({ formData: data, changes });
          setShowReasonDialog(true);
          return;
        }
      }
    }
    await saveItem(data);
  };

  const saveItem = async (data: FormData, reason?: string) => {
    setIsSaving(true);
    try {
      const variancecr = data.targetcostcr - data.actualcostcr;
      const payload = {
        ...data,
        variancecr,
        programmeid: programmeId,
        riskremarks: data.riskremarks || "",
        dateoforder: data.dateoforder || "",
        prDate: data.prDate || "",
        prNumber: data.prNumber || "",
        poDate: data.poDate || "",
        poNumber: data.poNumber || "",
        quantity: data.quantity || 0,
        poValueCr: data.poValueCr || 0,
        paymentReleasedCr: data.paymentReleasedCr || 0
      };

      if (editingId) {
        updateSupplyChain(editingId, payload);
        if (pendingDateChangeData && reason) {
          for (const change of pendingDateChangeData.changes) {
            addDateChangeLog({
              programmeid: programmeId,
              module: "supply_chain",
              recordid: editingId,
              recordname: data.item,
              fieldname: change.field,
              olddate: change.oldDate,
              newdate: change.newDate,
              reason: reason,
            });
          }
        }
        toast.success("Supply chain item updated");
      } else {
        addSupplyChain(payload);
        toast.success("Supply chain item added");
      }
      setIsDialogOpen(false);
      setPendingDateChangeData(null);
      setDateChangeReason("");
    } catch {
      toast.error("Failed to save");
    } finally {
      setIsSaving(false);
    }
  };

  const confirmDateChange = async () => {
    if (dateChangeReason.trim().length < 5) return toast.error("Please provide a valid reason");
    if (pendingDateChangeData) {
      await saveItem(pendingDateChangeData.formData, dateChangeReason);
      setShowReasonDialog(false);
    }
  };

  const triggerDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeleteTarget(id);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      deleteSupplyChain(deleteTarget);
      toast.success("Supply item deleted");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete");
    } finally {
      setIsDeleting(false);
    }
  };

  const getOwnerName = (nodeId: string) => {
    const node = programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId);
    return node ? node.displayname : "Unknown";
  };

  const toggleRowExpand = (id: string) => {
    setExpandedItemId(expandedItemId === id ? null : id);
  };

  const quickAddSubmit = () => {
    if (!quickAdd.item.trim() || !quickAdd.supplier.trim()) {
      toast.error("Item and Supplier are required");
      return;
    }
    addSupplyChain({
      programmeid: programmeId,
      item: quickAdd.item,
      supplier: quickAdd.supplier,
      actualcostcr: 0,
      targetcostcr: quickAdd.targetcostcr,
      variancecr: quickAdd.targetcostcr,
      status: quickAdd.status,
      riskremarks: "",
      dateoforder: "",
      dateofdelivery: quickAdd.dateofdelivery,
      leadtime: quickAdd.leadtime,
      ownerorgnodeid: quickAdd.ownerorgnodeid || orgNodes[0]?.programmeorgnodeid || "",
      milestoneid: null,
      quantity: 0,
      prDate: "",
      prNumber: "",
      poDate: "",
      poNumber: "",
      poValueCr: 0,
      paymentReleasedCr: 0,
    });
    setQuickAdd({ item: "", supplier: "", status: "Sourcing", dateofdelivery: "", leadtime: "", ownerorgnodeid: "", targetcostcr: 0 });
    setShowQuickAdd(false);
    toast.success("Item added — click Edit to add full details");
  };

  // Status counts for filter badges
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { All: items.length };
    for (const s of STATUSES) counts[s] = items.filter((i) => i.status === s).length;
    return counts;
  }, [items]);

  // Summary stats
  const delayedCount = items.filter((i) => i.status === "Delayed").length;
  const pendingCount = items.filter((i) => i.status !== "Delivered").length;
  const totalPOValue = items.reduce((s, i) => s + (i.poValueCr || 0), 0);
  const totalReleased = items.reduce((s, i) => s + (i.paymentReleasedCr || 0), 0);

  return (
    <div className="space-y-5 mt-6">
      {/* ── Page Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold leading-none tracking-tight">Supply Chain & Material Readiness</h3>
          <p className="text-xs text-muted-foreground mt-1.5">Procurement tracking, vendor management, and PR/PO status. Click rows to expand procurement timelines.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowQuickAdd(!showQuickAdd)}>
            <Plus className="size-3.5 mr-1.5" />
            Quick Add
          </Button>
          <Button onClick={openAddDialog} size="sm">
            <Plus className="size-4 mr-1.5" />
            Full Entry
          </Button>
        </div>
      </div>

      {/* ── Summary Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="rounded-xl border bg-card p-4 space-y-1.5 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Package className="size-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Items</span>
          </div>
          <div className="text-2xl font-extrabold font-mono">{items.length}</div>
          <div className="text-[10px] text-muted-foreground">{items.reduce((s, i) => s + (i.quantity || 0), 0).toLocaleString()} units across all items</div>
        </div>
        <div className="rounded-xl border bg-card p-4 space-y-1.5 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <DollarSign className="size-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Spend</span>
          </div>
          <div className="text-2xl font-extrabold font-mono">{totalActual.toFixed(1)} <span className="text-sm font-bold text-muted-foreground">Cr</span></div>
          <div className={`text-[10px] font-semibold ${totalVariance >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-500"}`}>
            {totalVariance >= 0 ? "▲" : "▼"} {Math.abs(totalVariance).toFixed(2)} Cr variance vs target ({totalTarget.toFixed(1)} Cr)
          </div>
        </div>
        <div className="rounded-xl border bg-card p-4 space-y-1.5 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <AlertTriangle className="size-4 text-amber-500" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Delayed / At Risk</span>
          </div>
          <div className={`text-2xl font-extrabold font-mono ${delayedCount > 0 ? "text-red-500" : "text-emerald-600"}`}>{delayedCount}</div>
          <div className="text-[10px] text-muted-foreground">{items.filter(i => i.riskremarks).length} items with risk remarks</div>
        </div>
        <div className="rounded-xl border bg-card p-4 space-y-1.5 shadow-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Clock className="size-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Pending Deliveries</span>
          </div>
          <div className="text-2xl font-extrabold font-mono">{pendingCount}</div>
          <div className="text-[10px] text-muted-foreground">PO Released: {totalReleased.toFixed(1)} / {totalPOValue.toFixed(1)} Cr</div>
        </div>
      </div>

      {/* ── Quick Add Bar ── */}
      {showQuickAdd && (
        <div className="rounded-xl border border-primary/20 bg-primary/[0.02] p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-primary">
            <Plus className="size-3.5" />
            Quick Add Material Request
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <Input placeholder="Item name *" value={quickAdd.item} onChange={(e) => setQuickAdd(prev => ({ ...prev, item: e.target.value }))} className="text-xs h-9" />
            <Input placeholder="Supplier / Vendor *" value={quickAdd.supplier} onChange={(e) => setQuickAdd(prev => ({ ...prev, supplier: e.target.value }))} className="text-xs h-9" />
            <select
              value={quickAdd.status}
              onChange={(e) => setQuickAdd(prev => ({ ...prev, status: e.target.value }))}
              className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-xs transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <Input type="number" step="0.01" placeholder="Target Cost (Cr)" value={quickAdd.targetcostcr || ""} onChange={(e) => setQuickAdd(prev => ({ ...prev, targetcostcr: Number(e.target.value) }))} className="text-xs h-9" />
            <Input placeholder="Lead Time (e.g. 8 Weeks)" value={quickAdd.leadtime} onChange={(e) => setQuickAdd(prev => ({ ...prev, leadtime: e.target.value }))} className="text-xs h-9" />
            <div className="flex gap-2">
              <Button size="sm" className="h-9 flex-1 text-xs" onClick={quickAddSubmit}>
                <Plus className="size-3 mr-1" /> Add
              </Button>
              <Button size="sm" variant="ghost" className="h-9 text-xs" onClick={() => setShowQuickAdd(false)}>Cancel</Button>
            </div>
          </div>
        </div>
      )}

      {/* ── Filter Bar + Search ── */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="flex items-center gap-1 flex-wrap">
          {["All", ...STATUSES].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`
                px-3 py-1.5 rounded-full text-xs font-semibold transition-all border
                ${statusFilter === s
                  ? "bg-primary text-primary-foreground border-primary shadow-sm"
                  : "bg-card border-border/60 text-muted-foreground hover:bg-muted hover:text-foreground"
                }
              `}
            >
              {s}
              <span className={`ml-1.5 text-[10px] font-mono ${statusFilter === s ? "opacity-80" : "opacity-50"}`}>
                {statusCounts[s] || 0}
              </span>
            </button>
          ))}
        </div>
        <div className="relative ml-auto">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground" />
          <Input
            placeholder="Search items or vendors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 h-8 w-[220px] text-xs"
          />
        </div>
      </div>

      {/* ── Table ── */}
      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[32px]"></TableHead>
              <TableHead>Item</TableHead>
              <TableHead>Supplier / Vendor</TableHead>
              <TableHead className="text-center">Qty</TableHead>
              <TableHead>Target (CR)</TableHead>
              <TableHead>Actual (CR)</TableHead>
              <TableHead>Variance</TableHead>
              <TableHead>Delivery Date</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-[100px] text-right"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredItems.length === 0 ? (
              <TableRow>
                <TableCell colSpan={11} className="text-center py-12 text-muted-foreground">
                  <Boxes className="size-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm font-medium">
                    {searchQuery || statusFilter !== "All" ? "No items match your filters." : "No supply chain items recorded."}
                  </p>
                  {(searchQuery || statusFilter !== "All") && (
                    <button onClick={() => { setSearchQuery(""); setStatusFilter("All"); }} className="text-xs text-primary hover:underline mt-1">
                      Clear all filters
                    </button>
                  )}
                </TableCell>
              </TableRow>
            ) : (
              filteredItems.map((item) => {
                const isExpanded = expandedItemId === item.supplychainreadinessid;
                const deliveryLogs = dateChangeLogs.filter((l) => l.recordid === item.supplychainreadinessid && l.module === "supply_chain" && l.fieldname === "dateofdelivery");
                const hasHistory = deliveryLogs.length > 0;
                const variance = item.targetcostcr - item.actualcostcr;
                const linkedMilestone = milestones.find(m => m.milestoneid === item.milestoneid);

                return (
                  <>
                    <TableRow
                      key={item.supplychainreadinessid}
                      onClick={() => toggleRowExpand(item.supplychainreadinessid)}
                      className="cursor-pointer hover:bg-muted/40 transition-colors select-none"
                    >
                      <TableCell className="p-0 text-center">
                        <ChevronRight className={`size-4 text-muted-foreground/60 transition-transform mx-auto ${isExpanded ? "rotate-90 text-foreground" : ""}`} />
                      </TableCell>
                      <TableCell className="font-semibold text-foreground">{item.item}</TableCell>
                      <TableCell>{item.supplier}</TableCell>
                      <TableCell className="text-center font-mono text-xs font-semibold bg-muted/15">{item.quantity || "—"}</TableCell>
                      <TableCell>{item.targetcostcr.toFixed(2)} Cr</TableCell>
                      <TableCell>{item.actualcostcr.toFixed(2)} Cr</TableCell>
                      <TableCell className={variance < 0 ? 'text-red-500 font-medium' : 'text-emerald-500 font-medium'}>
                        {variance.toFixed(2)} Cr
                      </TableCell>
                      <TableCell>
                        {hasHistory ? (
                          <DateChangePopover logs={deliveryLogs}>
                            <div className="flex items-center gap-1.5 text-amber-600 font-medium cursor-pointer hover:underline" onClick={e => e.stopPropagation()}>
                              {item.dateofdelivery}
                              <AlertTriangle className="size-3.5 text-amber-500" />
                            </div>
                          </DateChangePopover>
                        ) : (
                          item.dateofdelivery
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{getOwnerName(item.ownerorgnodeid)}</TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={`text-[10px] border-0 ${item.status === "Delivered" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" :
                            item.status === "In Transit" ? "bg-cyan-500/10 text-cyan-600 dark:text-cyan-400" :
                              item.status === "Ordered" ? "bg-blue-500/10 text-blue-600 dark:text-blue-400" :
                                item.status === "Delayed" ? "bg-red-500/10 text-red-600 dark:text-red-400" :
                                  "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                            }`}
                        >
                          {item.status === "Delivered" && <CheckCircle2 className="size-3 mr-1" />}
                          {item.status === "In Transit" && <Truck className="size-3 mr-1" />}
                          {item.status === "Delayed" && <AlertTriangle className="size-3 mr-1" />}
                          {item.status === "Sourcing" && <CircleDot className="size-3 mr-1" />}
                          {item.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-muted" onClick={(e) => openEditDialog(item.supplychainreadinessid, e)}>
                            <Pencil className="size-3.5 text-muted-foreground" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:bg-destructive/10" onClick={(e) => triggerDeleteClick(item.supplychainreadinessid, e)}>
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Detailed Expander View */}
                    {isExpanded && (
                      <TableRow className="bg-slate-500/[0.01] hover:bg-slate-500/[0.01]">
                        <TableCell colSpan={11} className="p-4.5 border-b">
                          <div className="flex flex-col gap-4">
                            {/* Deliverable link block */}
                            {linkedMilestone && (
                              <div className="flex items-center gap-2 text-xs font-semibold bg-primary/5 text-primary border border-primary/10 rounded-lg px-3 py-1.5 w-fit">
                                <Link2 className="size-3.5" />
                                <span>Linked Deliverable: {linkedMilestone.name}</span>
                              </div>
                            )}

                            <div className="flex flex-col xl:flex-row items-stretch gap-4">
                              <div className="flex-1">
                                <ProcurementPipeline item={item} />
                              </div>
                              <PaymentProgress item={item} />
                            </div>

                            {/* Additional metadata info */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-3 bg-muted/20 rounded-lg text-xs">
                              <div>
                                <span className="text-muted-foreground block mb-0.5 font-bold uppercase tracking-wider text-[8px]">Order Placement Date</span>
                                <span className="font-semibold">{item.dateoforder || "Not Ordered yet"}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground block mb-0.5 font-bold uppercase tracking-wider text-[8px]">Lead Time Baseline</span>
                                <span className="font-semibold">{item.leadtime}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground block mb-0.5 font-bold uppercase tracking-wider text-[8px]">Vendor Representative</span>
                                <span className="font-semibold">{item.supplier} Account Manager</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground block mb-0.5 font-bold uppercase tracking-wider text-[8px]">Audit Risk Flag</span>
                                <span className="font-semibold text-amber-600 dark:text-amber-400">{item.riskremarks ? "⚠️ Active Risk logged" : "✅ Normal"}</span>
                              </div>
                            </div>

                            {item.riskremarks && (
                              <div className="rounded-lg border-l-[3px] border-l-amber-500 bg-amber-500/5 p-3 text-xs text-amber-700 dark:text-amber-400">
                                <strong>Risk Flag:</strong> {item.riskremarks}
                              </div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                );
              })
            )}
            {filteredItems.length > 0 && (
              <TableRow className="bg-muted/50 font-bold border-t-2">
                <TableCell colSpan={2} className="pl-6">
                  {statusFilter !== "All" || searchQuery ? `Filtered Total (${filteredItems.length} items)` : "Total Supply Chain"}
                </TableCell>
                <TableCell colSpan={2} className="text-center font-mono">{filteredItems.reduce((s, i) => s + (i.quantity || 0), 0)} units</TableCell>
                <TableCell>{filteredItems.reduce((s, i) => s + i.targetcostcr, 0).toFixed(2)} Cr</TableCell>
                <TableCell>{filteredItems.reduce((s, i) => s + i.actualcostcr, 0).toFixed(2)} Cr</TableCell>
                <TableCell className={filteredItems.reduce((s, i) => s + (i.targetcostcr - i.actualcostcr), 0) < 0 ? 'text-red-500 font-medium' : 'text-emerald-500 font-medium'}>
                  {filteredItems.reduce((s, i) => s + (i.targetcostcr - i.actualcostcr), 0).toFixed(2)} Cr
                </TableCell>
                <TableCell colSpan={4}></TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[720px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Supply Item Details" : "Add Supply Item Details"}</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 py-4 px-1">
            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Item Name</Label>
                <Input {...register("item")} placeholder="e.g. Aluminum Alloys Casing" />
                {errors.item && <FieldError>{errors.item.message}</FieldError>}
              </Field>
              <Field>
                <Label>Supplier / Vendor</Label>
                <Input {...register("supplier")} placeholder="e.g. Vedanta Ltd" />
                {errors.supplier && <FieldError>{errors.supplier.message}</FieldError>}
              </Field>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Linked Deliverable (Milestone)</Label>
                <Controller
                  control={control}
                  name="milestoneid"
                  render={({ field }) => {
                    const selectedName = deliverables.find(d => d.milestoneid === field.value)?.name ?? null;
                    return (
                      <Combobox
                        value={selectedName}
                        onValueChange={(name: string | null) => {
                          const found = deliverables.find(d => d.name === name);
                          field.onChange(found?.milestoneid ?? null);
                        }}
                        items={deliverables.map(d => d.name)}
                      >
                        <ComboboxInput placeholder="Choose milestone deliverable..." />
                        <ComboboxContent>
                          <ComboboxEmpty>No deliverables found.</ComboboxEmpty>
                          <ComboboxList>
                            {(name: string) => <ComboboxItem key={name} value={name}>{name}</ComboboxItem>}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    );
                  }}
                />
              </Field>
              <Field>
                <Label>Allotted Quantity</Label>
                <Input type="number" {...register("quantity")} placeholder="e.g. 500" />
                {errors.quantity && <FieldError>{errors.quantity.message}</FieldError>}
              </Field>
            </div>

            {/* Financial tracking inputs */}
            <div className="grid grid-cols-3 gap-4 p-4 border rounded-lg bg-muted/20">
              <Field>
                <Label>Target Cost (CR)</Label>
                <Input type="number" step="0.01" {...register("targetcostcr")} />
                {errors.targetcostcr && <FieldError>{errors.targetcostcr.message}</FieldError>}
              </Field>
              <Field>
                <Label>Actual Cost (CR)</Label>
                <Input type="number" step="0.01" {...register("actualcostcr")} />
                {errors.actualcostcr && <FieldError>{errors.actualcostcr.message}</FieldError>}
              </Field>
              <Field>
                <Label className="text-muted-foreground">Variance (Auto-calc)</Label>
                <div className={`mt-2 font-mono text-lg font-bold ${currentVariance < 0 ? 'text-red-500' : 'text-emerald-500'}`}>
                  {currentVariance.toFixed(2)} Cr
                </div>
              </Field>
            </div>

            {/* PR & PO Timelines inputs */}
            <div className="border rounded-lg p-4 space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">PR / PO Timeline & Numbers</h4>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>PR Reference Number</Label>
                  <Input {...register("prNumber")} placeholder="e.g. PR-2026-042" />
                </Field>
                <Field>
                  <Label>PR Requisition Date</Label>
                  <Controller
                    control={control}
                    name="prDate"
                    render={({ field }) => <DatePicker value={field.value ?? ""} onChange={field.onChange} />}
                  />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>PO Reference Number</Label>
                  <Input {...register("poNumber")} placeholder="e.g. PO-2026-088" />
                </Field>
                <Field>
                  <Label>PO Placement Date</Label>
                  <Controller
                    control={control}
                    name="poDate"
                    render={({ field }) => <DatePicker value={field.value ?? ""} onChange={field.onChange} />}
                  />
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>PO Value (CR)</Label>
                  <Input type="number" step="0.01" {...register("poValueCr")} placeholder="0.00" />
                </Field>
                <Field>
                  <Label>Actual Payment Released (CR)</Label>
                  <Input type="number" step="0.01" {...register("paymentReleasedCr")} placeholder="0.00" />
                </Field>
              </div>
            </div>

            {/* Logistic updates */}
            <div className="grid grid-cols-2 gap-4">
              <Field>
                <Label>Order Placement Date (Actual/Contractual)</Label>
                <Controller
                  control={control}
                  name="dateoforder"
                  render={({ field }) => <DatePicker value={field.value ?? ""} onChange={field.onChange} />}
                />
                {errors.dateoforder && <FieldError>{errors.dateoforder.message}</FieldError>}
              </Field>
              <Field>
                <Label>Delivery Date (Baseline/EDC)</Label>
                <Controller
                  control={control}
                  name="dateofdelivery"
                  render={({ field }) => <DatePicker value={field.value} onChange={field.onChange} />}
                />
                {errors.dateofdelivery && <FieldError>{errors.dateofdelivery.message}</FieldError>}
              </Field>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <Field>
                <Label>Lead Time</Label>
                <Input {...register("leadtime")} placeholder="e.g. 8 Weeks" />
                {errors.leadtime && <FieldError>{errors.leadtime.message}</FieldError>}
              </Field>
              <Field>
                <Label>Logistics Status</Label>
                <Controller
                  control={control}
                  name="status"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={STATUSES}>
                      <ComboboxInput placeholder="Select status..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(s) => <ComboboxItem key={s} value={s}>{s}</ComboboxItem>}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.status && <FieldError>{errors.status.message}</FieldError>}
              </Field>
              <Field>
                <Label>SCM Team Owner</Label>
                <Controller
                  control={control}
                  name="ownerorgnodeid"
                  render={({ field }) => (
                    <Combobox value={field.value} onValueChange={field.onChange} items={orgNodes.map((n) => n.programmeorgnodeid)}>
                      <ComboboxInput placeholder="Select owner..." />
                      <ComboboxContent>
                        <ComboboxList>
                          {(id) => {
                            const n = orgNodes.find((x) => x.programmeorgnodeid === id);
                            return <ComboboxItem key={id} value={id}>{n?.displayname}</ComboboxItem>;
                          }}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  )}
                />
                {errors.ownerorgnodeid && <FieldError>{errors.ownerorgnodeid.message}</FieldError>}
              </Field>
            </div>

            <Field>
              <Label>Risk Flag / Remarks (Optional)</Label>
              <Textarea {...register("riskremarks")} rows={2} placeholder="Detail any delays or supply chain blockers..." />
            </Field>

            <DialogFooter className="mt-6">
              <DialogClose asChild><Button type="button" variant="outline">Cancel</Button></DialogClose>
              <Button type="submit" disabled={isSaving}>Save Item</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showReasonDialog} onOpenChange={(open) => !open && setShowReasonDialog(false)}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Date Change Justification</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {pendingDateChangeData?.changes.map((c, i) => (
              <div key={i} className="text-sm p-3 bg-muted/40 rounded-md border">
                <strong>{c.field}:</strong> <span className="line-through">{c.oldDate}</span> {" -> "}
                <span className="font-semibold text-primary">{c.newDate}</span>
              </div>
            ))}
            <div className="space-y-2">
              <Label>Reason</Label>
              <Textarea value={dateChangeReason} onChange={(e) => setDateChangeReason(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReasonDialog(false)}>Cancel</Button>
            <Button onClick={confirmDateChange} disabled={isSaving || dateChangeReason.trim().length < 5}>Confirm Change</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Supply Item?</AlertDialogTitle>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button variant="destructive" onClick={confirmDelete} disabled={isDeleting}>Delete</Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
