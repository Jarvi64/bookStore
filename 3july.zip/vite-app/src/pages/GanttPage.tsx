import { useCallback, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useAppStore, type Milestone } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CalendarDays,
  ChevronDown,
  Flag,
  CircleDollarSign,
  Award,
  Layers,
  Sparkles,
  Info
} from "lucide-react";
import {
  format,
  addMonths,
} from "date-fns";

// ─── Layout Constants ──────────────────────────────────────────
const ROW_H    = 36;
const HEADER_H = 56;
const BAR_H    = 20;
const BAR_R    = 5;

// Widths of Left Grid Columns
const COL_WIDTHS = { 
  name: 240, 
  offset: 90, 
  date: 100, 
  payment: 75,
  status: 90,
};
const LEFT_W = Object.values(COL_WIDTHS).reduce((a, b) => a + b, 0); // 595px

// Colour and status maps
const MS_CLR: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress": "#0874B0",
  Completed:     "#10b981",
  Delayed:        "#f59e0b",
  "At Risk":     "#ef4444",
};

const MS_BADGE: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300 border-blue-200",
  Completed:     "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300 border-emerald-200",
  Delayed:       "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300 border-amber-200",
  "At Risk":     "bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300 border-red-200",
};

type TimelineRow = {
  id: string;
  name: string;
  type: "parent" | "sub";
  offsetStart: number;
  offsetEnd: number;
  startDate: string;
  endDate: string;
  deliverable: string;
  payment: number;
  status: string;
  ownerId: string;
  parentId: string | null;
  raw: Milestone;
};

type MilestoneDetail = Milestone & {
  ownerName: string;
  calendarStart: string;
  calendarEnd: string;
};

/*
function safeParse(ds: string | undefined): Date | null {
  if (!ds) return null;
  try {
    const d = new Date(ds.includes("T") ? ds : ds + "T00:00:00");
    return isValid(d) ? d : null;
  } catch {
    return null;
  }
}
*/

export function GanttPage() {
  const { programmeConfig, milestones, programmeOrgNodes } = useAppStore();
  const t0StartStr = programmeConfig.t0Start || "2026-09-01";
  const t0Date = useMemo(() => new Date(t0StartStr + "T00:00:00"), [t0StartStr]);

  // Zoom Modes: "Months" | "Quarters" | "Years"
  const [zoomMode, setZoomMode] = useState<"Months" | "Quarters" | "Years">("Quarters");
  
  // Accordion collapsed state for the 10 main milestones
  const [collapsedMilestones, setCollapsedMilestones] = useState<Record<string, boolean>>({});

  // Interactive details modal state
  const [activeDetail, setActiveDetail] = useState<MilestoneDetail | null>(null);

  // Timeline Scroll Sync
  const leftScrollRef = useRef<HTMLDivElement>(null);
  const rightScrollRef = useRef<HTMLDivElement>(null);
  const syncingRef = useRef(false);

  // 1. Group Milestones Hierarchical
  const items = useMemo(() => {
    return milestones
      .filter((m) => m.programmeid === programmeConfig.programmeid)
      .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd);
  }, [milestones, programmeConfig.programmeid]);

  const mainMilestones = useMemo(() => {
    return items.filter((m) => m.parentMilestoneId === null);
  }, [items]);

  const getSubMilestones = useCallback((parentId: string) => {
    return items.filter((m) => m.parentMilestoneId === parentId);
  }, [items]);

  const isCollapsed = useCallback((id: string) => collapsedMilestones[id] === true, [collapsedMilestones]);
  const toggleCollapse = (id: string) => {
    setCollapsedMilestones((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // 2. Calculations for Payments and Cashflow
  const paymentStats = useMemo(() => {
    const advance = 20; // 20% advance payment
    const completedPayments = items
      .filter((m) => m.parentMilestoneId !== null && m.status === "Completed")
      .reduce((s, m) => s + m.paymentPercentage, 0);

    const released = advance + completedPayments;
    const pending = 100 - released;

    const completedGates = mainMilestones.filter((m) => {
      const subs = getSubMilestones(m.milestoneid);
      return subs.length > 0 && subs.every((s) => s.status === "Completed");
    }).length;

    return {
      released,
      pending,
      completedGates,
    };
  }, [getSubMilestones, items, mainMilestones]);

  // 3. Define Month Column Grid (T0 to T0+82)
  const monthColumns = useMemo(() => {
    const cols = [];
    for (let i = 0; i <= 82; i++) {
      const date = addMonths(t0Date, i);
      cols.push({
        offset: i,
        date,
        label: format(date, "MMM yy"),
        year: format(date, "yyyy"),
        quarter: `Q${Math.floor(date.getMonth() / 3) + 1}`,
      });
    }
    return cols;
  }, [t0Date]);

  // Pixel offsets calculations based on Zoom Mode
  const monthWidth = useMemo(() => {
    if (zoomMode === "Months") return 65;
    if (zoomMode === "Quarters") return 25; // 75px per quarter (3 months)
    return 8; // 96px per year (12 months)
  }, [zoomMode]);

  const timelineWidth = useMemo(() => {
    return monthColumns.length * monthWidth;
  }, [monthColumns, monthWidth]);

  // Position translators
  const getXFromOffset = useCallback((offset: number) => {
    return offset * monthWidth;
  }, [monthWidth]);

  /*
  const getXFromDate = (dateStr: string) => {
    const d = safeParse(dateStr);
    if (!d) return 0;
    const diffMonths = (d.getFullYear() - t0Date.getFullYear()) * 12 + (d.getMonth() - t0Date.getMonth());
    const dayFraction = (d.getDate() - 1) / 30;
    return (diffMonths + dayFraction) * monthWidth;
  };
  */

  // Build rows array to keep matching indices on left & right
  const flatRows = useMemo(() => {
    const rows: TimelineRow[] = [];

    mainMilestones.forEach((parent) => {
      const subs = getSubMilestones(parent.milestoneid);
      const collapsed = isCollapsed(parent.milestoneid);
      
      // Determine overall status based on child statuses
      let overallStatus = "Not Started";
      if (subs.length > 0) {
        if (subs.some((s) => s.status === "At Risk")) overallStatus = "At Risk";
        else if (subs.some((s) => s.status === "Delayed")) overallStatus = "Delayed";
        else if (subs.every((s) => s.status === "Completed")) overallStatus = "Completed";
        else if (subs.some((s) => s.status === "In Progress" || s.status === "Completed")) overallStatus = "In Progress";
      } else {
        overallStatus = parent.status;
      }

      rows.push({
        id: parent.milestoneid,
        name: parent.name,
        type: "parent",
        offsetStart: parent.t0OffsetStart,
        offsetEnd: parent.t0OffsetEnd,
        startDate: parent.startdate,
        endDate: parent.targetedcompletiondate,
        deliverable: parent.deliverable,
        payment: 0,
        status: overallStatus,
        ownerId: parent.ownerorgnodeid,
        parentId: null,
        raw: parent,
      });

      if (!collapsed) {
        subs.forEach((sub) => {
          rows.push({
            id: sub.milestoneid,
            name: sub.name,
            type: "sub",
            offsetStart: sub.t0OffsetStart,
            offsetEnd: sub.t0OffsetEnd,
            startDate: sub.startdate,
            endDate: sub.targetedcompletiondate,
            deliverable: sub.deliverable,
            payment: sub.paymentPercentage,
            status: sub.status,
            ownerId: sub.ownerorgnodeid,
            parentId: parent.milestoneid,
            raw: sub,
          });
        });
      }
    });

    return rows;
  }, [getSubMilestones, isCollapsed, mainMilestones]);

  const totalH = HEADER_H + flatRows.length * ROW_H;

  // Scroll Sync
  const onLeftScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (syncingRef.current) return;
    syncingRef.current = true;
    if (rightScrollRef.current) rightScrollRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    syncingRef.current = false;
  };
  const onRightScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (syncingRef.current) return;
    syncingRef.current = true;
    if (leftScrollRef.current) leftScrollRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    syncingRef.current = false;
  };

  const getOwnerName = (nodeId: string) =>
    programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId)?.displayname || "—";

  const formatDateString = (d: string) => {
    if (!d) return "—";
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "2-digit",
    });
  };

  // Dynamic calculations for timeline ticks
  const timelineHeaders = useMemo(() => {
    const result: Array<{ label: string; x: number; w: number; subLabel: string }> = [];
    
    if (zoomMode === "Months") {
      // Month layout
      monthColumns.forEach((col) => {
        result.push({
          label: `T0+${col.offset}`,
          subLabel: col.label,
          x: col.offset * monthWidth,
          w: monthWidth,
        });
      });
    } else if (zoomMode === "Quarters") {
      // Quarters layout (every 3 columns)
      for (let i = 0; i < monthColumns.length; i += 3) {
        const col = monthColumns[i];
        result.push({
          label: `T0+${i}M`,
          subLabel: `${col.quarter} '${col.year.substring(2)}`,
          x: i * monthWidth,
          w: monthWidth * 3,
        });
      }
    } else {
      // Years layout (every 12 columns)
      for (let i = 0; i < monthColumns.length; i += 12) {
        const col = monthColumns[i];
        const yearIdx = Math.floor(i / 12) + 1;
        result.push({
          label: `Year ${yearIdx}`,
          subLabel: col.year,
          x: i * monthWidth,
          w: monthWidth * 12,
        });
      }
    }
    return result;
  }, [zoomMode, monthColumns, monthWidth]);

  // Major Milestone Gates - vertical dashed lines
  const gateLines = useMemo(() => {
    return mainMilestones.map((m) => ({
      name: `Gate ${m.name.split(" ")[1] || ""}`,
      offset: m.t0OffsetEnd,
      x: getXFromOffset(m.t0OffsetEnd + 1),
      status: m.status,
    }));
  }, [getXFromOffset, mainMilestones]);

  // Current calendar "Today" projection relative to T0
  const todayX = useMemo(() => {
    const now = new Date();
    if (now < t0Date) return -1;
    const diffMonths = (now.getFullYear() - t0Date.getFullYear()) * 12 + (now.getMonth() - t0Date.getMonth());
    const dayFraction = (now.getDate() - 1) / 30;
    const totalOffset = diffMonths + dayFraction;
    if (totalOffset > 83) return -1;
    return totalOffset * monthWidth;
  }, [t0Date, monthWidth]);

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-background overflow-hidden relative">
      {/* ─── STICKY HEADER SUMMARY WIDGETS ─── */}
      <div className="px-5 pt-3 pb-3 border-b bg-slate-900/5 dark:bg-slate-900/40 shrink-0">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-xl font-bold tracking-tight flex items-center gap-2">
              <CalendarDays className="size-5 text-indigo-500" />
              Surveillance System Gates & Payments Roadmap
            </h1>
            <p className="text-xs text-muted-foreground leading-none">
              Baseline horizon: T0 (Sep 2026) to T0+79 (Apr 2033). Timeline gates and payment percentages mapped relative to milestones.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Cashflow release widget */}
            <div className="flex items-center gap-2 border bg-card dark:bg-slate-900/50 px-3 py-1.5 rounded-lg shadow-sm">
              <CircleDollarSign className="size-4.5 text-indigo-500 shrink-0" />
              <div className="text-xs">
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider block leading-none">Project Cashflow Released</span>
                <span className="font-extrabold text-indigo-600 dark:text-indigo-400 tabular-nums">
                  {paymentStats.released}% <span className="text-[10px] text-muted-foreground font-normal">({paymentStats.pending}% pending)</span>
                </span>
              </div>
            </div>

            {/* Program Gates completed */}
            <div className="flex items-center gap-2 border bg-card dark:bg-slate-900/50 px-3 py-1.5 rounded-lg shadow-sm">
              <Award className="size-4.5 text-emerald-500 shrink-0" />
              <div className="text-xs">
                <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider block leading-none">Completed Gates</span>
                <span className="font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {paymentStats.completedGates} <span className="text-[10px] text-muted-foreground font-normal">of 10 main phases</span>
                </span>
              </div>
            </div>

            {/* Zoom presets */}
            <div className="flex items-center border bg-card rounded-lg overflow-hidden h-9 shadow-sm">
              {(["Months", "Quarters", "Years"] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setZoomMode(mode)}
                  className={`px-3 py-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                    zoomMode === mode
                      ? "bg-primary text-primary-foreground font-bold"
                      : "hover:bg-muted text-muted-foreground"
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-5 mt-3 flex-wrap">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Legend</span>
          {Object.entries(MS_CLR).map(([status, color]) => (
            <div key={status} className="flex items-center gap-1.5">
              <div className="size-2 rounded-full" style={{ backgroundColor: color }} />
              <span className="text-[10px] text-muted-foreground font-medium">{status}</span>
            </div>
          ))}
          <div className="h-4 w-px bg-border" />
          <div className="flex items-center gap-1.5">
            <CircleDollarSign className="size-3.5 text-indigo-500" />
            <span className="text-[10px] text-muted-foreground font-medium">Payment Milestone Link</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 bg-dashed border border-slate-400 border-dashed" />
            <span className="text-[10px] text-muted-foreground font-medium">Fixed Stage Gate</span>
          </div>
        </div>
      </div>

      {/* ─── SCROLLABLE GANTT ROADMAP GRID ─── */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        
        {/* ──── LEFT PANEL: HIARARCHICAL GRID ──── */}
        <div className="shrink-0 border-r flex flex-col bg-card" style={{ width: LEFT_W }}>
          {/* Column headers */}
          <div className="flex shrink-0 border-b bg-slate-50 dark:bg-slate-900/40" style={{ height: HEADER_H }}>
            <div className="flex items-end pb-2 px-3 shrink-0 border-r" style={{ width: COL_WIDTHS.name }}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Deliverables Phases</span>
            </div>
            <div className="flex items-end pb-2 px-2 shrink-0 border-r justify-center" style={{ width: COL_WIDTHS.offset }}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground text-center">Offset</span>
            </div>
            <div className="flex items-end pb-2 px-2 shrink-0 border-r justify-center" style={{ width: COL_WIDTHS.date }}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground text-center">Target (Cal)</span>
            </div>
            <div className="flex items-end pb-2 px-2 shrink-0 border-r justify-center" style={{ width: COL_WIDTHS.payment }}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground text-center">Payment</span>
            </div>
            <div className="flex items-end pb-2 px-2 shrink-0" style={{ width: COL_WIDTHS.status }}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Status</span>
            </div>
          </div>

          {/* Rows */}
          <div 
            ref={leftScrollRef} 
            onScroll={onLeftScroll} 
            className="overflow-y-scroll flex-1 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          >
            {flatRows.map((row) => {
              const isParent = row.type === "parent";
              const collapsed = isCollapsed(row.id);
              return (
                <div 
                  key={row.id}
                  className={`flex items-center border-b shrink-0 ${
                    isParent 
                      ? "bg-slate-50/50 dark:bg-slate-900/20 hover:bg-slate-100/50 dark:hover:bg-slate-900/30 font-bold" 
                      : "hover:bg-muted/30 font-medium"
                  } transition-colors`}
                  style={{ height: ROW_H }}
                >
                  {/* Name cell */}
                  <div className="border-r flex items-center gap-1.5 px-3 shrink-0 min-w-0 h-full" style={{ width: COL_WIDTHS.name }}>
                    {!isParent && <span className="shrink-0 w-3" />}
                    {isParent && (
                      <button 
                        onClick={() => toggleCollapse(row.id)} 
                        className="shrink-0 p-0.5 hover:bg-muted rounded"
                      >
                        <ChevronDown className={`size-3.5 text-slate-500 transition-transform ${collapsed ? "-rotate-90" : ""}`} />
                      </button>
                    )}
                    <div className="size-2 rounded-full shrink-0" style={{ backgroundColor: MS_CLR[row.status] }} />
                    <span className="truncate text-xs text-foreground block" title={row.name}>
                      {row.name}
                    </span>
                  </div>

                  {/* Offset cell */}
                  <div className="border-r flex items-center justify-center shrink-0 h-full font-mono text-[10px] text-muted-foreground" style={{ width: COL_WIDTHS.offset }}>
                    {isParent 
                      ? `T0+${row.offsetStart} to T0+${row.offsetEnd}` 
                      : `T0+${row.offsetEnd}`}
                  </div>

                  {/* Date Target cell */}
                  <div className="border-r flex items-center justify-center shrink-0 h-full text-xs tabular-nums" style={{ width: COL_WIDTHS.date }}>
                    {formatDateString(row.endDate)}
                  </div>

                  {/* Payment cell */}
                  <div className="border-r flex items-center justify-center shrink-0 h-full font-mono text-xs font-bold text-indigo-500" style={{ width: COL_WIDTHS.payment }}>
                    {row.payment > 0 ? `${row.payment}%` : "—"}
                  </div>

                  {/* Status cell */}
                  <div className="flex items-center px-2 shrink-0 h-full" style={{ width: COL_WIDTHS.status }}>
                    <Badge variant="outline" className={`${MS_BADGE[row.status] || "bg-muted"} text-[9px] px-1.5 py-0`}>
                      {row.status}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ──── RIGHT PANEL: TIMELINE CHART ──── */}
        <div 
          ref={rightScrollRef} 
          onScroll={onRightScroll}
          className="flex-1 overflow-auto bg-white dark:bg-slate-950 relative"
        >
          <div style={{ width: timelineWidth, minWidth: timelineWidth }}>
            <svg width={timelineWidth} height={totalH} className="select-none" style={{ display: "block" }}>
              {/* ─── Grid Timeline Columns ─── */}
              {timelineHeaders.map((hdr, idx) => (
                <g key={idx}>
                  {/* Grid background alternates */}
                  <rect 
                    x={hdr.x} 
                    y={0} 
                    width={hdr.w} 
                    height={totalH}
                    className="fill-slate-500/[0.015] dark:fill-white/[0.01] pointer-events-none" 
                  />
                  {/* Header text */}
                  <text 
                    x={hdr.x + hdr.w / 2} 
                    y={18} 
                    textAnchor="middle"
                    className="text-[11px] font-bold fill-slate-700 dark:fill-slate-350"
                  >
                    {hdr.label}
                  </text>
                  <text 
                    x={hdr.x + hdr.w / 2} 
                    y={38} 
                    textAnchor="middle"
                    className="text-[9px] font-semibold fill-muted-foreground"
                  >
                    {hdr.subLabel}
                  </text>
                  {/* Grid boundary vertical line */}
                  <line 
                    x1={hdr.x} 
                    y1={0} 
                    x2={hdr.x} 
                    y2={totalH} 
                    className="stroke-slate-200/40 dark:stroke-slate-800/40" 
                    strokeWidth={0.5} 
                  />
                </g>
              ))}

              {/* Horizontal divider under headers */}
              <line x1={0} y1={HEADER_H} x2={timelineWidth} y2={HEADER_H} className="stroke-slate-200 dark:stroke-slate-800" strokeWidth={1.5} />

              {/* ─── Swimlanes (Data Bars) ─── */}
              {flatRows.map((row, ri) => {
                const rowY = HEADER_H + ri * ROW_H;
                const barY = rowY + (ROW_H - BAR_H) / 2;
                const isParent = row.type === "parent";

                // Stretch end X to finish cleanly at offset end
                const sx = getXFromOffset(row.offsetStart);
                const ex = getXFromOffset(row.offsetEnd + 1);
                const barWidth = Math.max(ex - sx, 8);

                return (
                  <g key={row.id}>
                    {/* Row background highlighting */}
                    <rect 
                      x={0} 
                      y={rowY} 
                      width={timelineWidth} 
                      height={ROW_H}
                      fill={isParent ? "rgba(99, 102, 241, 0.03)" : "transparent"}
                    />
                    <line x1={0} y1={rowY + ROW_H} x2={timelineWidth} y2={rowY + ROW_H} className="stroke-slate-200/40 dark:stroke-slate-800/40" strokeWidth={0.5} />

                    {/* Timeline Bar */}
                    <g 
                      className="cursor-pointer"
                      onClick={() => setActiveDetail({
                        ...row.raw,
                        ownerName: getOwnerName(row.ownerId),
                        calendarStart: formatDateString(row.startDate),
                        calendarEnd: formatDateString(row.endDate),
                      })}
                    >
                      {/* Drop shadow */}
                      <rect x={sx + 1} y={barY + 1.5} width={barWidth - 2} height={BAR_H - 1.5} rx={BAR_R} fill="rgba(0,0,0,0.1)" />
                      {/* Bar Fill */}
                      <rect 
                        x={sx} 
                        y={barY} 
                        width={barWidth} 
                        height={BAR_H}
                        rx={BAR_R}
                        fill={isParent ? (
                          row.status === "Completed" ? "rgba(16, 185, 129, 0.08)" :
                          row.status === "In Progress" ? "rgba(8, 116, 176, 0.08)" :
                          row.status === "Not Started" ? "rgba(148, 163, 184, 0.08)" :
                          row.status === "At Risk" ? "rgba(239, 68, 68, 0.08)" :
                          "rgba(245, 158, 11, 0.08)"
                        ) : MS_CLR[row.status]}
                        fillOpacity={1}
                        stroke={MS_CLR[row.status]}
                        strokeWidth={isParent ? 1.2 : 0}
                      />

                      {/* Payment release label marker inside sub-milestones */}
                      {!isParent && row.payment > 0 && barWidth > 50 && (
                        <g transform={`translate(${sx + barWidth - 32}, ${barY + 3})`}>
                          <rect 
                            width="28" 
                            height="14" 
                            rx="3" 
                            fill="white" 
                            stroke={MS_CLR[row.status]} 
                            strokeWidth="1" 
                          />
                          <text 
                            x="14" 
                            y="10.5" 
                            textAnchor="middle" 
                            fontSize="8" 
                            fontWeight="bold" 
                            fill={MS_CLR[row.status] === "#94a3b8" ? "#64748b" : MS_CLR[row.status]}
                          >
                            {row.payment}%
                          </text>
                        </g>
                      )}

                      {/* Title clipping inside bar */}
                      {barWidth > 60 && (
                        <g>
                          <clipPath id={`clip-gantt-${row.id}`}>
                            <rect x={sx + 6} y={barY} width={row.payment > 0 ? barWidth - 42 : barWidth - 14} height={BAR_H} />
                          </clipPath>
                          <text 
                            x={sx + 8} 
                            y={barY + BAR_H / 2 + 1}
                            fontFamily="inherit"
                            fontSize="8.5"
                            fontWeight={isParent ? 800 : 700}
                            fill={isParent ? (
                              row.status === "Completed" ? "#065f46" :
                              row.status === "In Progress" ? "#075985" :
                              row.status === "Not Started" ? "#475569" :
                              row.status === "At Risk" ? "#991b1b" :
                              "#9a3412"
                            ) : "white"}
                            className={isParent ? "dark:fill-slate-200" : ""}
                            dominantBaseline="middle"
                            clipPath={`url(#clip-gantt-${row.id})`}
                          >
                            {row.name}
                          </text>
                        </g>
                      )}
                    </g>
                  </g>
                );
              })}

              {/* ─── Fixed Major Stage Gates ─── */}
              {gateLines.map((gate, gidx) => (
                <g key={gidx} className="opacity-70 hover:opacity-100 transition-opacity">
                  {/* Vertical dashed line */}
                  <line 
                    x1={gate.x} 
                    y1={52} 
                    x2={gate.x} 
                    y2={totalH} 
                    stroke="#6366f1" 
                    strokeWidth={1.5} 
                    strokeDasharray="4,6" 
                  />
                  {/* Gate flag marker centered at gate.x and in the header zone */}
                  <g transform={`translate(${gate.x - 28}, 8)`}>
                    <rect width="56" height="36" rx="6" className="fill-indigo-600 dark:fill-indigo-500 shadow-sm" />
                    <text x="28" y="16" textAnchor="middle" fontSize="9" fontWeight="bold" fill="white">
                      {gate.name}
                    </text>
                    <text x="28" y="27" textAnchor="middle" fontSize="8" fontWeight="bold" fill="rgba(255, 255, 255, 0.8)">
                      T0+{gate.offset}M
                    </text>
                  </g>
                </g>
              ))}

              {/* ─── Today Timeline Indicator ─── */}
              {todayX > 0 && todayX < timelineWidth && (
                <g>
                  <line 
                    x1={todayX} 
                    y1={0} 
                    x2={todayX} 
                    y2={totalH} 
                    stroke="#ef4444" 
                    strokeWidth={1.5} 
                    strokeOpacity={0.8} 
                  />
                  <rect x={todayX - 22} y={1.5} width={44} height={16} rx="4" fill="#ef4444" />
                  <text x={todayX} y="12" textAnchor="middle" fontSize="9" fontWeight="bold" fill="white">
                    Today
                  </text>
                </g>
              )}
            </svg>
          </div>
        </div>
      </div>

      {/* ─── INTERACTIVE GANTT NODE DETAILS DIALOG ─── */}
      <Dialog open={!!activeDetail} onOpenChange={(o) => !o && setActiveDetail(null)}>
        <DialogContent className="sm:max-w-md p-0 overflow-hidden">
          <div className="h-2 w-full bg-gradient-to-r from-violet-600 to-indigo-600" />
          {activeDetail && (
            <div className="p-6">
              <DialogHeader className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Flag className="size-4 text-indigo-500" />
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                    {activeDetail.parentMilestoneId ? "Sub-Milestone Deliverable" : "Major Phase Gate"}
                  </span>
                  <span className="ml-auto text-[10px] font-mono text-indigo-600 bg-indigo-500/10 px-2 py-0.5 rounded">
                    T0 + {activeDetail.t0OffsetEnd}M
                  </span>
                </div>
                <DialogTitle className="text-lg font-bold leading-snug">{activeDetail.name}</DialogTitle>
                <div className="text-[11px] text-muted-foreground mt-1 flex items-center gap-1.5">
                  Owner: <span className="font-semibold text-foreground">{activeDetail.ownerName}</span>
                </div>
              </DialogHeader>

              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b">
                  <span className="text-xs font-semibold text-muted-foreground">Current status</span>
                  <Badge variant="outline" className={`${MS_BADGE[activeDetail.status]} text-xs px-2.5 py-0.5`}>
                    {activeDetail.status}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-xl border bg-muted/20 p-3 flex flex-col">
                    <span className="text-[9px] uppercase font-bold text-muted-foreground mb-1">Offset Timeline</span>
                    <span className="text-xs font-bold font-mono">
                      T0 + {activeDetail.t0OffsetStart}M to T0 + {activeDetail.t0OffsetEnd}M
                    </span>
                  </div>
                  <div className="rounded-xl border bg-muted/20 p-3 flex flex-col">
                    <span className="text-[9px] uppercase font-bold text-muted-foreground mb-1">Baseline Dates</span>
                    <span className="text-xs font-bold font-mono">
                      {activeDetail.calendarStart} to {activeDetail.calendarEnd}
                    </span>
                  </div>
                </div>

                <div className="p-3 bg-muted/30 border rounded-lg flex flex-col gap-1">
                  <span className="text-[9px] uppercase font-bold text-slate-500 flex items-center gap-1">
                    <Layers className="size-3 text-indigo-500" /> Contractual Deliverable
                  </span>
                  <p className="text-xs font-medium text-foreground">{activeDetail.deliverable || "No deliverables registered."}</p>
                </div>

                {activeDetail.paymentPercentage > 0 && (
                  <div className="p-3 bg-indigo-500/5 border border-indigo-500/20 rounded-lg flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-500 flex items-center gap-1">
                      <CircleDollarSign className="size-4 text-indigo-500" /> Payment release associated
                    </span>
                    <Badge className="bg-indigo-500 text-white font-bold">{activeDetail.paymentPercentage}%</Badge>
                  </div>
                )}

                {activeDetail.remarks && (
                  <div className="p-3 bg-slate-500/5 border rounded-lg flex flex-col gap-1">
                    <span className="text-[9px] uppercase font-bold text-slate-500 flex items-center gap-1">
                      <Info className="size-3.5 text-slate-400" /> Remarks
                    </span>
                    <p className="text-xs italic text-muted-foreground">"{activeDetail.remarks}"</p>
                  </div>
                )}

                <div className="pt-2">
                  <Button asChild className="w-full">
                    <Link to="/milestones">
                      Go to Milestones Control <Sparkles className="size-4 ml-1.5 text-amber-300" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
