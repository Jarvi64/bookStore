import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AppLayout } from "./components/layout/AppLayout";
import { Dashboard } from "./pages/Dashboard";
import { MilestonesTab } from "./pages/programme/MilestonesTab";
import { BudgetTab } from "./pages/programme/BudgetTab";
import { OrganisationTab } from "./pages/programme/OrganisationTab";
import { CertificationsTab } from "./pages/programme/CertificationsTab";
import { FinancialSnapshotTab } from "./pages/programme/FinancialSnapshotTab";
import { PartnerDeliverablesTab } from "./pages/programme/PartnerDeliverablesTab";
import { SupplyChainReadinessTab } from "./pages/programme/SupplyChainReadinessTab";
import { SupportRequiredTab } from "./pages/programme/SupportRequiredTab";
import { WeeklyUpdatesTab } from "./pages/programme/WeeklyUpdatesTab";
import { DateChangeLogsTab } from "./pages/programme/DateChangeLogsTab";
import { TeamWeeklyStatus } from "./pages/programme/TeamWeeklyStatus";
import { GanttPage } from "./pages/GanttPage";
import { AiAssistant } from "./pages/AiAssistant";

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/milestones" element={<MilestonesTab />} />
          <Route path="/gantt" element={<GanttPage />} />
          <Route path="/budget" element={<BudgetTab />} />
          <Route path="/financial" element={<FinancialSnapshotTab />} />
          <Route path="/partners" element={<PartnerDeliverablesTab />} />
          <Route path="/supply-chain" element={<SupplyChainReadinessTab />} />
          <Route path="/certifications" element={<CertificationsTab />} />
          <Route path="/organisation" element={<OrganisationTab />} />
          <Route path="/support" element={<SupportRequiredTab />} />
          <Route path="/weekly-updates" element={<WeeklyUpdatesTab />} />
          <Route path="/changes" element={<DateChangeLogsTab />} />
          <Route path="/team-status" element={<TeamWeeklyStatus />} />
          <Route path="/ai-assistant" element={<AiAssistant />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
