/**
 * CV Screening Dashboard - Data Processing Module
 * Handles data import, transformation, scoring, and filtering
 */

const DataProcessor = (() => {
    /**
     * Processes uploaded Excel file.
     * @param {Event} event - File input change event
     * @returns {Promise<void>}
     */
    const handleFileUpload = async (event) => {
        const file = event.target.files?.[0];
        if (!file) return;

        AppState.setLoading(true);

        try {
            const data = await readExcelFile(file);
            if (data.length > 0) {
                // Assign unique IDs
                const dataWithIds = data.map(row => ({
                    ...row,
                    _id: Utils.generateId()
                }));

                AppState.setRawData(dataWithIds);
                AppState.clearStatusOverrides();
                setupColumns(dataWithIds[0]);
                
                // Show table UI
                toggleDataView(true);
                UIRenderer.renderHeaders();
                recalculateAndRender();
                Utils.Toast.success(`Successfully uploaded ${data.length} candidates`);
            }
        } catch (error) {
            console.error('File upload error:', error);
            Utils.Toast.error('Error reading file. Please ensure it\'s a valid Excel file.');
        } finally {
            AppState.setLoading(false);
            // Reset input for re-upload of same file
            event.target.value = '';
        }
    };

    /**
     * Reads Excel file and returns JSON data.
     * @param {File} file - Excel file
     * @returns {Promise<object[]>}
     */
    const readExcelFile = (file) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                    const jsonData = XLSX.utils.sheet_to_json(firstSheet, { defval: '' });
                    resolve(jsonData);
                } catch (err) {
                    reject(err);
                }
            };
            
            reader.onerror = () => reject(new Error('File read failed'));
            reader.readAsArrayBuffer(file);
        });
    };

    /**
     * Checks if education requirement is matched.
     * @param {object} row - Data row
     * @returns {boolean} True if education matches or no data
     */
    const checkEducationMatch = (row) => {
        const eduMatch = flexibleGet(row, ['education_match', 'education match', 'edu_match', 'eduMatch']);
        if (eduMatch === '-' || eduMatch === null || eduMatch === undefined) return true; // No data, assume match
        return Utils.isTruthy(eduMatch);
    };

    /**
     * Checks if domain requirement is matched.
     * @param {object} row - Data row
     * @returns {boolean} True if domain matches or no data
     */
    const checkDomainMatch = (row) => {
        const domainMatch = flexibleGet(row, ['domain_match', 'domain match', 'domainMatch']);
        if (domainMatch === '-' || domainMatch === null || domainMatch === undefined) return true; // No data, assume match
        return Utils.isTruthy(domainMatch);
    };

    /**
     * Parses date string into Date object.
     * @param {string} dateStr - Date string (e.g., "Jan 2020", "2020", "Present")
     * @returns {Date|null} Parsed date or null
     */
    const parseCareerDate = (dateStr) => {
        if (!dateStr || typeof dateStr !== 'string') return null;
        const str = dateStr.trim().toLowerCase();
        if (str === 'present' || str === 'current') return new Date();
        
        // Try parsing "Month Year" format
        const monthYearMatch = str.match(/(\w+)\s+(\d{4})/);
        if (monthYearMatch) {
            const date = new Date(`${monthYearMatch[1]} 1, ${monthYearMatch[2]}`);
            if (!isNaN(date.getTime())) return date;
        }
        
        // Try parsing just year
        const yearMatch = str.match(/(\d{4})/);
        if (yearMatch) {
            return new Date(`Jan 1, ${yearMatch[1]}`);
        }
        
        return null;
    };

    /**
     * Detects career gaps from career timeline.
     * @param {object} row - Data row
     * @returns {boolean} True if career gaps > 1 month detected
     */
    const hasCareerGaps = (row) => {
        // First check explicit employment_gaps field
        const explicitGaps = flexibleGet(row, ['employment_gaps', 'career_gaps', 'employment gaps']);
        if (explicitGaps && explicitGaps !== '-') {
            if (typeof explicitGaps === 'string') {
                const gapStr = explicitGaps.toLowerCase();
                // Check for "yes", "true", or any duration mention
                if (gapStr === 'yes' || gapStr === 'true' || 
                    gapStr.includes('month') || gapStr.includes('year') ||
                    gapStr.includes('gap')) {
                    return true;
                }
            } else if (typeof explicitGaps === 'boolean') {
                return explicitGaps;
            }
        }
        
        // Parse career timeline to detect gaps
        const timeline = flexibleGet(row, ['career_timeline', 'career timeline', 'employment_history']);
        if (!timeline || typeof timeline !== 'string') return false;
        
        // Parse format: "Role @ Company (StartDate - EndDate) | Role @ Company (StartDate - EndDate)"
        const entries = timeline.split('|').map(s => s.trim()).filter(Boolean);
        if (entries.length < 2) return false;
        
        const parsedJobs = entries.map(entry => {
            const match = entry.match(/\(([^)]+)\)\s*$/);
            if (!match) return null;
            const dateRange = match[1].trim();
            const parts = dateRange.split('-').map(d => d.trim());
            return {
                start: parseCareerDate(parts[0]),
                end: parts.length > 1 ? parseCareerDate(parts.slice(1).join('-').trim()) : null
            };
        }).filter(j => j && j.start);
        
        // Sort by start date descending
        parsedJobs.sort((a, b) => (b.start?.getTime() || 0) - (a.start?.getTime() || 0));
        
        // Check gaps between consecutive jobs
        for (let i = 0; i < parsedJobs.length - 1; i++) {
            const currentEnd = parsedJobs[i].start; // Current job's start is the "end" of the gap
            const prevEnd = parsedJobs[i + 1].end; // Previous job's end
            
            if (currentEnd && prevEnd) {
                const gapMonths = (currentEnd.getTime() - prevEnd.getTime()) / (1000 * 60 * 60 * 24 * 30);
                if (gapMonths > 1) return true;
            }
        }
        
        return false;
    };

    /**
     * Checks if candidate is currently unemployed.
     * @param {object} row - Data row
     * @returns {boolean} True if currently unemployed
     */
    const isUnemployed = (row) => {
        // Check explicit employment_status field
        const status = flexibleGet(row, ['employment_status', 'employment status', 'current_status']);
        if (status && status !== '-') {
            const statusStr = String(status).toLowerCase();
            if (statusStr.includes('unemployed') || statusStr.includes('not employed') ||
                statusStr.includes('seeking') || statusStr.includes('available')) {
                return true;
            }
        }
        
        // Check red_flags for unemployment indicators
        const redFlags = flexibleGet(row, ['red_flags', 'red flags', 'redflags']);
        if (redFlags && redFlags !== '-') {
            const flagsStr = String(redFlags).toLowerCase();
            if (flagsStr.includes('unemployed') || flagsStr.includes('currently not working')) {
                return true;
            }
        }
        
        // Check career timeline - if no "Present" or "Current" in most recent job
        const timeline = flexibleGet(row, ['career_timeline', 'career timeline']);
        if (timeline && timeline !== '-' && typeof timeline === 'string') {
            const firstEntry = timeline.split('|')[0].toLowerCase();
            if (firstEntry && !firstEntry.includes('present') && !firstEntry.includes('current')) {
                // Most recent job is not current, might be unemployed
                return true;
            }
        }
        
        return false;
    };

    /**
     * Gets all mismatch reasons for a candidate (regardless of auto-rejection settings).
     * @param {object} row - Data row
     * @returns {string[]} Array of mismatch reasons ('education', 'domain')
     */
    const getMismatches = (row) => {
        const reasons = [];
        if (!checkEducationMatch(row)) reasons.push('education');
        if (!checkDomainMatch(row)) reasons.push('domain');
        return reasons;
    };

    /**
     * Toggles between empty state and data view.
     * @param {boolean} showData - Whether to show data view
     */
    const toggleDataView = (showData) => {
        const emptyState = document.getElementById('empty-state');
        const tableWrapper = document.getElementById('table-wrapper');
        const toolbar = document.getElementById('table-toolbar');
        const pagination = document.getElementById('pagination-container');

        if (emptyState) emptyState.style.display = showData ? 'none' : 'flex';
        if (tableWrapper) tableWrapper.style.display = showData ? 'flex' : 'none';
        if (toolbar) toolbar.style.display = showData ? 'flex' : 'none';
        if (pagination) pagination.style.display = showData ? 'flex' : 'none';
    };

    /**
     * Sets up column definitions from data sample.
     * @param {object} rowSample - First row of data
     */
    const setupColumns = (rowSample) => {
        const keys = Object.keys(rowSample);

        // Build field mapping
        AppState.setFieldMapping({
            candidate: Utils.findKeyByPartialMatch(rowSample, ['name']) || '',
            experience: Utils.findKeyByPartialMatch(rowSample, ['years of experience'], ['relevant']) || '',
            domainMatch: Utils.findKeyByPartialMatch(rowSample, ['domain match']) || '',
            skills: Utils.findKeyByPartialMatch(rowSample, ['skill']) || '',
            email: Utils.findKeyByPartialMatch(rowSample, ['email']) || '',
            phone: Utils.findKeyByPartialMatch(rowSample, ['phone', 'mobile']) || ''
        });

        // Map columns with data keys
        const mappedCols = AppState.CORE_COLUMNS.map(col => {
            if (['contact', 'subcards', 'score', 'status'].includes(col.type)) {
                return { ...col };
            }
            const foundKey = keys.find(k => {
                const lower = k.toLowerCase();
                return col.keyMatches?.some(m => lower.includes(m) && !lower.includes('score'));
            });
            return { ...col, dataKey: foundKey };
        });

        AppState.setColumns(mappedCols);
        UIRenderer.renderColumnToggles();
        UIRenderer.renderHeaders();
    };

    /**
     * Calculates final score for a single row.
     * @param {object} row - Data row
     * @returns {number} Calculated score (0-100)
     */
    const calculateFinalScore = (row) => {
        const keys = Object.keys(row);
        let weightedSum = 0;
        const totalWeight = AppState.getTotalWeight();

        if (totalWeight === 0) return 0;

        AppState.SCORING_PARAMS.forEach(param => {
            const key = keys.find(k => {
                const lower = k.toLowerCase();
                return lower.includes('score') && param.keywords.some(kw => lower.includes(kw));
            });
            const value = key ? Utils.safeFloat(row[key]) : 0;
            weightedSum += value * AppState.weights[param.id];
        });

        return Math.round((weightedSum / totalWeight) * 10);
    };

    /**
     * Extracts subscores for a row.
     * @param {object} row - Data row
     * @returns {object[]} Array of subscore objects
     */
    const extractSubscores = (row) => {
        const keys = Object.keys(row);
        return AppState.SCORING_PARAMS.map(param => {
            const key = keys.find(k => {
                const lower = k.toLowerCase();
                return lower.includes('score') && param.keywords.some(kw => lower.includes(kw));
            });
            return {
                id: param.id,
                label: param.label,
                abbr: param.abbr,
                value: key ? Utils.safeFloat(row[key]) : 0
            };
        });
    };

    /**
     * Recalculates all scores and statuses, then renders.
     */
    const recalculateAndRender = () => {
        const counts = { Shortlisted: 0, Borderline: 0, Rejected: 0 };
        const criteria = AppState.rejectionCriteria;
        let autoRejectedCount = 0;

        const processed = AppState.rawData.map(row => {
            const score = calculateFinalScore(row);
            const override = AppState.statusOverrides.get(row._id);
            
            // Mismatches are detected regardless of toggle
            const mismatches = getMismatches(row);
            
            // Calculate what the status WOULD be without any override (natural status)
            const scoreBasedStatus = AppState.getStatusFromScore(score);
            const shouldAutoReject = (mismatches.includes('education') && criteria.rejectOnEduMismatch) || 
                                   (mismatches.includes('domain') && criteria.rejectOnDomainMismatch);
            const naturalStatus = shouldAutoReject ? 'Rejected' : scoreBasedStatus;

            // Robustness: If an override exists but it matches the current natural status 
            // (e.g. user saved a candidate from auto-rejection, but then auto-rejection was turned off),
            // we should clear the override so they aren't marked as "Overridden" anymore.
            let activeOverride = override;
            if (override && override === naturalStatus) {
                AppState.statusOverrides.delete(row._id);
                activeOverride = undefined;
            }

            // Determine final status
            const status = activeOverride || naturalStatus;
            if (status === 'Rejected' && !activeOverride && shouldAutoReject) {
                autoRejectedCount++;
            }
            
            counts[status]++;
            
            // Detect career indicators
            const _hasCareerGaps = hasCareerGaps(row);
            const _isUnemployed = isUnemployed(row);

            return {
                ...row,
                _calculatedScore: score,
                _calculatedStatus: status,
                _hasOverride: !!activeOverride,
                _subscores: extractSubscores(row),
                _autoRejectionReasons: mismatches,
                _isAutoRejected: shouldAutoReject && !activeOverride,
                _hasCareerGaps,
                _isUnemployed
            };
        });

        AppState.setProcessedData(processed);
        updateSidebarCounts(counts);
        updateAutoRejectedCount(autoRejectedCount);
        
        // Apply sort if any
        applyCurrentSort();
        updateFilteredData();
        
        // Render based on view mode
        if (AppState.viewMode === 'table') {
            document.getElementById('table-wrapper').style.display = 'flex';
            document.getElementById('kanban-view').style.display = 'none';
            document.getElementById('pagination-container').style.display = 'flex';
            UIRenderer.renderTable();
        } else {
            document.getElementById('table-wrapper').style.display = 'none';
            document.getElementById('kanban-view').style.display = 'flex';
            document.getElementById('pagination-container').style.display = 'none';
            UIRenderer.renderKanban();
        }
    };

    /**
     * Updates the auto-rejected count in the sidebar.
     * @param {number} count - Number of auto-rejected candidates
     */
    const updateAutoRejectedCount = (count) => {
        const statsEl = document.getElementById('rejection-stats');
        const countEl = document.getElementById('auto-rejected-count');
        
        if (statsEl) {
            statsEl.style.display = count > 0 ? 'flex' : 'none';
        }
        if (countEl) {
            countEl.textContent = count;
        }
    };

    /**
     * Updates sidebar count displays.
     * @param {object} counts - Status counts
     */
    const updateSidebarCounts = (counts) => {
        const shortEl = document.getElementById('count-shortlisted');
        const borderEl = document.getElementById('count-borderline');
        const rejectEl = document.getElementById('count-rejected');

        if (shortEl) shortEl.textContent = counts.Shortlisted;
        if (borderEl) borderEl.textContent = counts.Borderline;
        if (rejectEl) rejectEl.textContent = counts.Rejected;
    };

    /**
     * Applies current sort to processed data.
     */
    const applyCurrentSort = () => {
        const { colId, dir } = AppState.currentSort;
        if (!colId) return;

        const colDef = AppState.columns.find(c => c.id === colId);
        if (!colDef) return;

        const data = [...AppState.processedData];

        if (colId === 'Exp' && colDef.dataKey) {
            data.sort((a, b) => (Utils.safeFloat(a[colDef.dataKey]) - Utils.safeFloat(b[colDef.dataKey])) * dir);
        } else if (colId === 'Score') {
            data.sort((a, b) => (a._calculatedScore - b._calculatedScore) * dir);
        } else if (colDef.sortable && colDef.dataKey) {
            data.sort((a, b) => {
                const vA = String(a[colDef.dataKey] || '').toLowerCase();
                const vB = String(b[colDef.dataKey] || '').toLowerCase();
                return vA.localeCompare(vB) * dir;
            });
        }

        AppState.setProcessedData(data);
    };

    /**
     * Filters data based on current filter state.
     */
    const updateFilteredData = () => {
        const { search, minExp, domainMatch, status } = AppState.filters;
        const { experience, domainMatch: domainKey } = AppState.fieldMapping;

        const filtered = AppState.processedData.filter(item => {
            // Hide rejected filter
            if (AppState.rejectionCriteria.hideRejected && item._calculatedStatus === 'Rejected') {
                return false;
            }
            
            // Search filter
            if (search) {
                const searchLower = search.toLowerCase();
                const matchesSearch = Object.values(item).some(val => 
                    String(val).toLowerCase().includes(searchLower)
                );
                if (!matchesSearch) return false;
            }

            // Experience filter
            if (minExp !== null && experience) {
                const expVal = Utils.safeFloat(item[experience]);
                if (expVal < minExp) return false;
            }

            // Domain filter
            if (domainMatch !== 'all' && domainKey) {
                const domVal = Utils.isTruthy(item[domainKey]);
                if (domainMatch === 'true' && !domVal) return false;
                if (domainMatch === 'false' && domVal) return false;
            }

            // Status filter
            if (status !== 'all' && item._calculatedStatus !== status) {
                return false;
            }

            return true;
        });

        AppState.setFilteredData(filtered);
        
        const countEl = document.getElementById('result-count');
        if (countEl) countEl.textContent = `Showing ${filtered.length} candidates`;
    };

    /**
     * Clears all filters and resets to defaults.
     */
    const clearFilters = () => {
        // Reset UI elements
        const searchEl = document.getElementById('search-text');
        const expEl = document.getElementById('filter-exp');
        const domainEl = document.getElementById('filter-domain');
        const statusEl = document.getElementById('filter-status');

        if (searchEl) searchEl.value = '';
        if (expEl) expEl.value = '';
        if (domainEl) domainEl.value = 'all';
        if (statusEl) statusEl.value = 'all';

        AppState.resetFilters();
        updateFilteredData();
        Utils.Toast.info('All filters cleared');
        
        if (AppState.viewMode === 'table') {
            UIRenderer.renderTable();
        } else {
            UIRenderer.renderKanban();
        }
    };

    /**
     * Sorts table by column.
     * @param {string} colId - Column ID
     * @param {number} [forceDir] - Force specific direction
     */
    const sortTable = (colId, forceDir = null) => {
        const current = AppState.currentSort;
        let newDir = forceDir;
        
        if (newDir === null) {
            newDir = current.colId === colId ? -current.dir : 1;
        }

        AppState.setSort(colId, newDir);
        AppState.setCurrentPage(1);
        
        applyCurrentSort();
        updateFilteredData();
        UIRenderer.renderHeaders();
        UIRenderer.renderTable();
    };

    /**
     * Exports processed data to Excel.
     */
    const exportToExcel = () => {
        const data = AppState.processedData;
        if (data.length === 0) {
            alert('No data to export!');
            return;
        }

        // Clean data for export (remove internal fields)
        const exportData = data.map(row => {
            const cleaned = { ...row };
            delete cleaned._id;
            delete cleaned._calculatedScore;
            delete cleaned._calculatedStatus;
            delete cleaned._subscores;
            
            // Add calculated fields with readable names
            cleaned['Final Score'] = row._calculatedScore;
            cleaned['Status'] = row._calculatedStatus;
            
            return cleaned;
        });

        const filename = `Screening_Results_${new Date().toISOString().split('T')[0]}.xlsx`;
        
        // Create worksheet and workbook
        const ws = XLSX.utils.json_to_sheet(exportData);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Screening Results');
        
        // Generate file content
        const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([wbout], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        
        // Create a temporary link to trigger download with correct filename
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        setTimeout(() => {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 100);

        Utils.Toast.success('Results exported to Excel');
    };

    /**
     * Flexible field value getter - handles both snake_case and space-separated field names
     * @param {object} row - Data row
     * @param {string[]} keys - Array of possible key names to try
     * @param {*} defaultVal - Default value if not found
     * @returns {*} Field value or default
     */
    const flexibleGet = (row, keys, defaultVal = '-') => {
        for (const key of keys) {
            // Try exact match
            if (row[key] !== undefined && row[key] !== null && row[key] !== '') return row[key];
            
            // Try lowercase
            const lowerKey = key.toLowerCase();
            const found = Object.keys(row).find(k => {
                const kLower = k.toLowerCase();
                const kNormalized = kLower.replace(/[\s-]+/g, '_');
                const keyNormalized = lowerKey.replace(/[\s-]+/g, '_');
                return kLower === lowerKey || kNormalized === keyNormalized;
            });
            if (found && row[found] !== undefined && row[found] !== null && row[found] !== '') {
                return row[found];
            }
        }
        return defaultVal;
    };

    /**
     * PDF Column configuration - defines all available columns for PDF export
     */
    const PDF_COLUMNS = [
        { id: 'candidate', label: 'Candidate Name', essential: true, getValue: (row, fm) => row[fm.candidate] || flexibleGet(row, ['candidate_name', 'Candidate Name'], 'Unknown') },
        { id: 'email', label: 'Email', essential: false, getValue: (row, fm) => row[fm.email] || flexibleGet(row, ['email', 'Email'], '-') },
        { id: 'phone', label: 'Phone', essential: false, getValue: (row, fm) => row[fm.phone] || flexibleGet(row, ['phone', 'Phone'], '-') },
        { id: 'roleCompany', label: 'Role & Company', essential: true, getValue: (row) => {
            const role = flexibleGet(row, ['current_designation', 'Current Designation', 'current_role'], '-');
            const company = flexibleGet(row, ['current_company', 'Current Company'], '-');
            return `${role}\n${company}`;
        }},
        { id: 'experience', label: 'Experience (Yrs)', essential: true, getValue: (row, fm) => flexibleGet(row, ['years_of_experience', 'Years of Experience', fm?.experience], '0') },
        { id: 'relExp', label: 'Relevant Exp', essential: false, getValue: (row) => flexibleGet(row, ['relevant_experience_years', 'Relevant Experience Years', 'relevant_experience'], '-') },
        { id: 'education', label: 'Highest Education', essential: true, getValue: (row) => flexibleGet(row, ['highest_education', 'Highest Education'], '-') },
        { id: 'domain', label: 'Domain Match', essential: false, getValue: (row) => {
            const val = flexibleGet(row, ['domain_match', 'Domain Match'], null);
            if (val === null) return '-';
            return val === true || val === 'true' || val === 'Yes' || val === 1 ? 'Yes' : 'No';
        }},
        { id: 'skills', label: 'Key Skills', essential: true, getValue: (row, fm) => {
            let skills = flexibleGet(row, ['skills', 'Skills', fm?.skills], '');
            return skills.length > 60 ? skills.substring(0, 60) + '...' : skills || '-';
        }},
        { id: 'certifications', label: 'Certifications', essential: false, getValue: (row) => {
            let certs = flexibleGet(row, ['certifications', 'Certifications'], '');
            return certs.length > 40 ? certs.substring(0, 40) + '...' : certs || '-';
        }},
        { id: 'criticalSkills', label: 'Critical Skills Match', essential: false, getValue: (row) => {
            let skills = flexibleGet(row, ['critical_skills_match', 'Critical Skills Match', 'critical_skills'], '');
            return skills.length > 40 ? skills.substring(0, 40) + '...' : skills || '-';
        }},
        { id: 'missingSkills', label: 'Missing Skills', essential: false, getValue: (row) => {
            let skills = flexibleGet(row, ['missing_critical_skills', 'Missing Critical Skills', 'missing_skills'], '');
            return skills.length > 40 ? skills.substring(0, 40) + '...' : skills || '-';
        }},
        { id: 'redFlags', label: 'Red Flags', essential: false, getValue: (row) => flexibleGet(row, ['red_flags', 'Red Flags', 'redflag'], '-') },
        { id: 'pros', label: 'Why Hire', essential: false, getValue: (row) => {
            let pros = flexibleGet(row, ['pros', 'Pros'], '');
            return pros.length > 50 ? pros.substring(0, 50) + '...' : pros || '-';
        }},
        { id: 'cons', label: 'Concerns', essential: false, getValue: (row) => {
            let cons = flexibleGet(row, ['cons', 'Cons'], '');
            return cons.length > 50 ? cons.substring(0, 50) + '...' : cons || '-';
        }},
        { id: 'resumeLink', label: 'Resume', essential: false, getValue: (row) => {
            const link = flexibleGet(row, ['resume_link', 'Resume Link', 'resume_url', 'Resume URL', 'resume'], '');
            if (!link) return '-';
            return 'View';  // Simple text - the cell itself is clickable
        }},
        { id: 'status', label: 'Status', essential: true, isStatus: true, getValue: (row) => row._calculatedStatus },
        { id: 'score', label: 'Score', essential: true, isScore: true, getValue: (row) => row._calculatedScore }
    ];

    // Track selected columns for PDF
    let selectedPdfColumns = new Set(PDF_COLUMNS.filter(c => c.essential).map(c => c.id));

    /**
     * Shows PDF column selector modal
     */
    const showPdfModal = () => {
        const data = AppState.processedData;
        if (data.length === 0) {
            Utils.Toast.warning('No data to export!');
            return;
        }

        const modal = document.getElementById('pdf-modal');
        const grid = document.getElementById('pdf-columns-grid');
        
        if (!modal || !grid) return;

        // Populate column grid
        grid.innerHTML = PDF_COLUMNS.map(col => `
            <div class="pdf-column-item ${selectedPdfColumns.has(col.id) ? 'selected' : ''}" data-col="${col.id}">
                <input type="checkbox" id="pdf-col-${col.id}" ${selectedPdfColumns.has(col.id) ? 'checked' : ''}>
                <label for="pdf-col-${col.id}">${col.label}</label>
            </div>
        `).join('');

        updatePdfSelectedCount();

        modal.classList.add('show');
        document.body.style.overflow = 'hidden';

        if (typeof lucide !== 'undefined') {
            lucide.createIcons({ icons: lucide.icons });
        }
    };

    /**
     * Closes PDF modal
     */
    const closePdfModal = () => {
        const modal = document.getElementById('pdf-modal');
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }
    };

    /**
     * Updates selected count display
     */
    const updatePdfSelectedCount = () => {
        const countEl = document.getElementById('pdf-selected-count');
        if (countEl) {
            countEl.textContent = `${selectedPdfColumns.size} selected`;
        }
    };

    /**
     * Handles PDF modal interactions
     */
    const initPdfModalHandlers = () => {
        document.addEventListener('click', (e) => {
            // Column item click - handle both item and checkbox clicks
            const colItem = e.target.closest('.pdf-column-item');
            if (colItem) {
                const colId = colItem.dataset.col;
                const checkbox = colItem.querySelector('input[type="checkbox"]');
                const clickedCheckbox = e.target.tagName === 'INPUT' && e.target.type === 'checkbox';
                
                // If clicked on checkbox, it already toggled, so sync state from checkbox
                if (clickedCheckbox) {
                    if (checkbox.checked) {
                        selectedPdfColumns.add(colId);
                        colItem.classList.add('selected');
                    } else {
                        selectedPdfColumns.delete(colId);
                        colItem.classList.remove('selected');
                    }
                } else {
                    // Clicked on item (not checkbox), manually toggle
                    if (selectedPdfColumns.has(colId)) {
                        selectedPdfColumns.delete(colId);
                        colItem.classList.remove('selected');
                        if (checkbox) checkbox.checked = false;
                    } else {
                        selectedPdfColumns.add(colId);
                        colItem.classList.add('selected');
                        if (checkbox) checkbox.checked = true;
                    }
                }
                updatePdfSelectedCount();
                return;
            }

            // Preset buttons
            const presetBtn = e.target.closest('[data-preset]');
            if (presetBtn) {
                const preset = presetBtn.dataset.preset;
                if (preset === 'essential') {
                    selectedPdfColumns = new Set(PDF_COLUMNS.filter(c => c.essential).map(c => c.id));
                } else if (preset === 'all') {
                    selectedPdfColumns = new Set(PDF_COLUMNS.map(c => c.id));
                } else if (preset === 'none') {
                    selectedPdfColumns = new Set();
                }
                
                // Update UI
                document.querySelectorAll('.pdf-column-item').forEach(item => {
                    const colId = item.dataset.col;
                    const checkbox = item.querySelector('input[type="checkbox"]');
                    const isSelected = selectedPdfColumns.has(colId);
                    item.classList.toggle('selected', isSelected);
                    if (checkbox) checkbox.checked = isSelected;
                });
                updatePdfSelectedCount();
                return;
            }

            // Close button
            if (e.target.closest('#pdf-modal-close') || e.target.closest('#pdf-cancel-btn')) {
                closePdfModal();
                return;
            }

            // Export button
            if (e.target.closest('#pdf-export-btn')) {
                if (selectedPdfColumns.size === 0) {
                    Utils.Toast.warning('Please select at least one column');
                    return;
                }
                generatePdfWithColumns();
                closePdfModal();
                return;
            }

            // Click outside modal
            if (e.target.id === 'pdf-modal') {
                closePdfModal();
            }
        });
    };

    // Initialize handlers when module loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPdfModalHandlers);
    } else {
        initPdfModalHandlers();
    }

    /**
     * Generates PDF with selected columns - Enhanced with Quick Wins
     */
    const generatePdfWithColumns = () => {
        const data = AppState.processedData;
        const { fieldMapping } = AppState;
        const { jsPDF } = window.jspdf;

        // Get selected column definitions in order
        const selectedCols = PDF_COLUMNS.filter(c => selectedPdfColumns.has(c.id));
        
        // Determine orientation - always landscape for better table fit
        const orientation = 'l';
        const doc = new jsPDF(orientation, 'mm', 'a4');
        const pageWidth = 297;
        const pageHeight = 210;
        const margin = 14;

        // === SUMMARY STATS ===
        const shortlisted = data.filter(d => d._calculatedStatus === 'Shortlisted').length;
        const borderline = data.filter(d => d._calculatedStatus === 'Borderline').length;
        const rejected = data.filter(d => d._calculatedStatus === 'Rejected').length;
        const avgScore = data.length > 0 
            ? Math.round(data.reduce((sum, d) => sum + (d._calculatedScore || 0), 0) / data.length) 
            : 0;

        // === HEADER ===
        doc.setFontSize(20);
        doc.setTextColor(24, 24, 27);
        doc.setFont(undefined, 'bold');
        doc.text('CV Screening Report', margin, 18);

        // Date and meta info
        doc.setFontSize(9);
        doc.setTextColor(113, 113, 122);
        doc.setFont(undefined, 'normal');
        const dateStr = new Date().toLocaleDateString('en-US', { 
            year: 'numeric', month: 'long', day: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
        doc.text(`Generated: ${dateStr}`, margin, 25);

        // === SUMMARY STATS BAR ===
        const statsY = 32;
        doc.setFillColor(248, 250, 252); // Light gray background
        doc.roundedRect(margin, statsY - 4, pageWidth - margin * 2, 12, 2, 2, 'F');
        
        doc.setFontSize(9);
        doc.setTextColor(24, 24, 27);
        
        // Total candidates
        doc.setFont(undefined, 'bold');
        doc.text(`Total: ${data.length}`, margin + 4, statsY + 3);
        
        // Shortlisted (green)
        doc.setTextColor(16, 185, 129);
        doc.text(`Shortlisted: ${shortlisted}`, margin + 35, statsY + 3);
        
        // Borderline (amber)
        doc.setTextColor(245, 158, 11);
        doc.text(`Borderline: ${borderline}`, margin + 85, statsY + 3);
        
        // Rejected (red)
        doc.setTextColor(239, 68, 68);
        doc.text(`Rejected: ${rejected}`, margin + 135, statsY + 3);
        
        // Avg Score
        doc.setTextColor(99, 102, 241);
        doc.text(`Avg Score: ${avgScore}`, margin + 180, statsY + 3);

        // Active Filters indicator
        const activeFilters = [];
        if (AppState.filters.status !== 'all') activeFilters.push(`Status: ${AppState.filters.status}`);
        if (AppState.filters.search) activeFilters.push(`Search: "${AppState.filters.search}"`);
        
        if (activeFilters.length > 0) {
            doc.setTextColor(113, 113, 122);
            doc.setFont(undefined, 'italic');
            doc.text(`Filters: ${activeFilters.join(', ')}`, margin + 210, statsY + 3);
        }

        // Build table headers and rows
        const headers = selectedCols.map(c => c.label);
        const rows = data.map(row => selectedCols.map(col => col.getValue(row, fieldMapping)));

        // Store original URLs for creating clickable links
        const resumeUrls = data.map(row => {
            const link = flexibleGet(row, ['resume_link', 'Resume Link', 'resume_url', 'Resume URL', 'resume'], '');
            return link || null;
        });

        // Find status and score column indices for color coding
        const statusColIdx = selectedCols.findIndex(c => c.isStatus);
        const scoreColIdx = selectedCols.findIndex(c => c.isScore);
        const resumeLinkColIdx = selectedCols.findIndex(c => c.id === 'resumeLink');

        // === SMART COLUMN WIDTHS ===
        const availableWidth = pageWidth - margin * 2;
        const columnStyles = {};
        
        // Define preferred widths for specific columns
        const colWidthMap = {
            'candidate': 32,
            'email': 38,
            'phone': 28,
            'roleCompany': 35,
            'experience': 18,
            'relExp': 18,
            'education': 30,
            'domain': 16,
            'skills': 50,
            'certifications': 35,
            'criticalSkills': 35,
            'missingSkills': 30,
            'redFlags': 35,
            'pros': 45,
            'cons': 40,
            'status': 22,
            'score': 16,
            'resumeLink': 25
        };

        // Calculate total preferred width
        let totalPreferred = 0;
        selectedCols.forEach(col => {
            totalPreferred += colWidthMap[col.id] || 25;
        });

        // Scale proportionally if needed
        const scaleFactor = totalPreferred > availableWidth ? availableWidth / totalPreferred : 1;

        selectedCols.forEach((col, idx) => {
            const baseWidth = (colWidthMap[col.id] || 25) * scaleFactor;
            columnStyles[idx] = { cellWidth: baseWidth };
            
            if (col.id === 'candidate') {
                columnStyles[idx].fontStyle = 'bold';
            }
            if (col.isScore) {
                columnStyles[idx].halign = 'center';
                columnStyles[idx].fontStyle = 'bold';
            }
            if (col.isStatus) {
                columnStyles[idx].halign = 'center';
                columnStyles[idx].fontStyle = 'bold';
            }
            if (col.id === 'resumeLink') {
                columnStyles[idx].halign = 'center';
                columnStyles[idx].textColor = [59, 130, 246]; // Blue for links
            }
        });

        // === GENERATE TABLE WITH ALTERNATING ROWS ===
        doc.autoTable({
            head: [headers],
            body: rows,
            startY: statsY + 12,
            theme: 'grid',
            headStyles: {
                fillColor: [24, 24, 27],
                textColor: [255, 255, 255],
                fontSize: 7,
                fontStyle: 'bold',
                halign: 'center',
                cellPadding: 2
            },
            styles: {
                fontSize: 6.5,
                cellPadding: 1.5,
                valign: 'middle',
                overflow: 'linebreak',
                lineWidth: 0.1
            },
            alternateRowStyles: {
                fillColor: [249, 250, 251] // Light gray for alternate rows
            },
            columnStyles,
            didParseCell: function(cellData) {
                // Color code Status
                if (statusColIdx >= 0 && cellData.section === 'body' && cellData.column.index === statusColIdx) {
                    const status = cellData.cell.raw;
                    if (status === 'Shortlisted') {
                        cellData.cell.styles.textColor = [16, 185, 129];
                        cellData.cell.styles.fillColor = [236, 253, 245]; // Light green bg
                    } else if (status === 'Rejected') {
                        cellData.cell.styles.textColor = [239, 68, 68];
                        cellData.cell.styles.fillColor = [254, 242, 242]; // Light red bg
                    } else {
                        cellData.cell.styles.textColor = [245, 158, 11];
                        cellData.cell.styles.fillColor = [255, 251, 235]; // Light amber bg
                    }
                }
                
                // Color code Score with background intensity
                if (scoreColIdx >= 0 && cellData.section === 'body' && cellData.column.index === scoreColIdx) {
                    const score = parseInt(cellData.cell.raw);
                    if (score >= 70) {
                        cellData.cell.styles.textColor = [16, 185, 129];
                        cellData.cell.styles.fillColor = [236, 253, 245];
                    } else if (score < 40) {
                        cellData.cell.styles.textColor = [239, 68, 68];
                        cellData.cell.styles.fillColor = [254, 242, 242];
                    } else {
                        cellData.cell.styles.textColor = [245, 158, 11];
                        cellData.cell.styles.fillColor = [255, 251, 235];
                    }
                }

                // Style resume links
                if (resumeLinkColIdx >= 0 && cellData.section === 'body' && cellData.column.index === resumeLinkColIdx) {
                    const link = cellData.cell.raw;
                    if (link && link !== '-') {
                        cellData.cell.styles.textColor = [59, 130, 246];
                        cellData.cell.styles.fontStyle = 'italic';
                    }
                }
            },
            // === CLICKABLE LINKS ===
            didDrawCell: function(cellData) {
                // Add clickable link to resume cells
                if (resumeLinkColIdx >= 0 && cellData.section === 'body' && cellData.column.index === resumeLinkColIdx) {
                    const rowIndex = cellData.row.index;
                    const url = resumeUrls[rowIndex];
                    if (url && url !== '-') {
                        // Create clickable link area over the cell
                        doc.link(
                            cellData.cell.x,
                            cellData.cell.y,
                            cellData.cell.width,
                            cellData.cell.height,
                            { url: url }
                        );
                    }
                }
            },
            // === PAGE NUMBERS ===
            didDrawPage: function(data) {
                // Footer with page numbers
                const pageCount = doc.internal.getNumberOfPages();
                doc.setFontSize(8);
                doc.setTextColor(150);
                doc.setFont(undefined, 'normal');
                
                // Page number on bottom right
                doc.text(
                    `Page ${data.pageNumber} of ${pageCount}`,
                    pageWidth - margin - 20,
                    pageHeight - 8
                );
                
                // Footer note on bottom left
                doc.text(
                    'Generated by CV Screening Dashboard',
                    margin,
                    pageHeight - 8
                );
            }
        });

        doc.save(`CV_Screening_Report_${new Date().toISOString().split('T')[0]}.pdf`);
        Utils.Toast.success('PDF Report generated successfully!');
    };

    /**
     * Legacy exportToPDF - now shows modal
     */
    const exportToPDF = () => {
        showPdfModal();
    };

    return {
        handleFileUpload,
        recalculateAndRender,
        updateFilteredData,
        clearFilters,
        sortTable,
        exportToExcel,
        exportToPDF,
        extractSubscores,
        toggleDataView,
        showPdfModal,
        closePdfModal,
        initPdfModalHandlers
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = DataProcessor;
} else {
    window.DataProcessor = DataProcessor;
}
