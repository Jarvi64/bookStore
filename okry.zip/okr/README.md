# OKR Application

Production-oriented Objectives and Key Results app built with React, TypeScript, Zustand, Shadcn/UI, and a swappable service layer.

The important product idea: this is not just a task list. It models OKR alignment across company, department, team, and individual objectives, with progress coming either from direct check-ins or from weighted rollups of key results and child objectives.

## Current Product Model

### Objective Levels

| Level | Meaning | Can have parent? | Can have child objectives? | Can have direct KRs? |
| --- | --- | --- | --- | --- |
| Company | CEO/admin strategic objective | No | Yes | No |
| Department | Department-level OKR | Optional, company only | Yes | Yes |
| Team | Team-level OKR owned by an org team | Optional, company or department | Yes | Yes |
| Individual | Personal OKR owned by one or more people | Optional, company/department/team | No | Yes |

Important distinction: teams are organization records inside departments. A department can have any number of teams. A "Team Objective" is an OKR owned at team level; it is not the same thing as creating a new team.

### Allowed Cascade Rules

Valid parent-child objective relationships:

```text
Company -> Department
Company -> Team
Company -> Individual

Department -> Team
Department -> Individual

Team -> Individual
```

Invalid relationships:

```text
Company -> Key Result directly
Department -> Department
Team -> Team
Individual -> anything
Any objective -> itself
Any objective -> one of its descendants
```

Why Department -> Department is disallowed: it mixes org structure with strategy alignment. If the business needs subdepartments, model them in the organization layer first, then decide what objective level they create.

## Progress Model

Objectives have a `progressMode`:

| Mode | Meaning | When to use |
| --- | --- | --- |
| `rollup` | Objective progress is calculated from child objectives and/or KRs | Cascaded OKRs, objectives with KRs |
| `manual` | Objective progress is updated directly from its own metric | Leaf objectives or objectives without KRs yet |

Company objectives must use `rollup`.

The UI also has a user-facing `targetTrackingType`, inspired by Teamflect-style OKR tracking:

| Tracking type | Internal behavior | Purpose |
| --- | --- | --- |
| `reach` | Manual | Reach a numerical, currency, or percentage target |
| `stay_above` | Manual | Keep a metric above a threshold |
| `stay_below` | Manual | Keep a metric below a threshold |
| `completed` | Manual | Mark an objective as done or not done |
| `rollup_key_results` | Rollup | Calculate progress from direct KRs |
| `rollup_children` | Rollup | Calculate progress from child objectives |

Company objectives should use `rollup_children`, because this product does not allow direct KRs under company objectives.

Manual progress uses:

```text
progress = (currentValue - initialValue) / (targetValue - initialValue)
```

Rollup progress uses weighted children:

```text
objective progress =
  weighted average of direct key results and direct child objectives
```

Key results and child objectives share the same 100-point contribution pool under a parent objective.

Example:

```text
Marketing Department Objective
  KR: Paid and organic acquisition performance     20%
  KR: Lead-to-SQL funnel conversion                20%
  Team Objective: Marketing strategy               25%
  Team Objective: Product marketing campaign       20%
  Individual Objective: Website inbound leads      15%
```

Total contribution = 100%.

## Dummy Data Scenario Matrix

The dummy data is intentionally a product test matrix, not random seed data.

### Objectives

| ID | Scenario |
| --- | --- |
| `obj-1` | Company objective, no parent, no direct KRs, rollup-only |
| `obj-2` | Department objective aligned to company, with KRs and child objectives |
| `obj-3` | Department objective aligned to company, manual progress, no KRs yet |
| `obj-13` | Team objective aligned directly to company |
| `obj-10` | Individual objective aligned directly to company |
| `obj-14` | Standalone department objective with direct KRs |
| `obj-4` | Team objective aligned to department, measured by KRs |
| `obj-6` | Team objective aligned to department, with KRs and a child individual objective |
| `obj-7` | Individual objective aligned to department, measured by KRs |
| `obj-15` | Team objective aligned to department, manual progress, private comments |
| `obj-9` | Individual objective aligned to team, manual currency metric |
| `obj-5` | Standalone team objective |
| `obj-8` | Standalone individual objective with percent metric |
| `obj-11` | Standalone individual objective with number metric and no status |
| `obj-12` | Standalone individual objective with private comments |

### Key Results

Company objectives intentionally have no direct key results.

KRs currently cover:

- Department objective with direct KRs plus child objectives: `obj-2`
- Team objective measured only by KRs: `obj-4`
- Team objective with KRs plus child individual objective: `obj-6`
- Individual objective measured by KRs: `obj-7`
- Team objective directly aligned to company: `obj-13`
- Standalone department objective measured by KRs: `obj-14`

## Domain Files

| File | Purpose |
| --- | --- |
| `src/models/enums.ts` | Union types like objective type, status, metric type, progress mode |
| `src/models/objective.model.ts` | Objective entity and create/update DTOs |
| `src/models/key-result.model.ts` | Key result entity and create/update DTOs |
| `src/lib/okr-validation.ts` | Cascade and payload validation rules |
| `src/lib/progress-calculator.ts` | Manual and weighted rollup progress helpers |
| `src/lib/constants.ts` | Display config for statuses, objective types, metrics, time periods |
| `src/services/dummy/data/objectives.data.ts` | Scenario-rich objective seed data |
| `src/services/dummy/data/key-results.data.ts` | Scenario-rich KR seed data |

## Architecture

```text
React pages/components
        |
        v
Zustand stores
        |
        v
Service interfaces
        |
        v
Dummy services now, real backend later
        |
        v
TypeScript models
```

Rules:

- Components should not call APIs directly.
- Stores call services.
- Services enforce domain rules, even when the UI already validates them.
- Shared OKR logic belongs in `src/lib`, not inside a component.
- Dummy data should remain realistic enough to test real product behavior.

## Add Objective Flow

The create/edit objective dialog should guide users through these decisions:

1. Objective title and optional description.
2. Objective level: Company, Department, Team, or Individual.
3. Owners and ownership mode.
4. Target and progress tracking:
   - Reach
   - Stay above
   - Stay below
   - Completed/Not completed
   - Roll-up from key result progress
   - Roll-up from child objective progress
5. Time period.
6. Optional parent objective, filtered by valid cascade rules.
7. Optional contribution weight when a parent exists.
8. Labels, visibility, and comment privacy.

Manual metric fields are only useful when the selected tracking type is manual. Rollup objectives do not need their own number/currency/percent target because their progress comes from direct KRs and child objectives.

When creating a non-company objective with `rollup_key_results`, the create dialog supports inline draft KRs. This lets the user create the objective and its first measurable KRs in one workflow. Draft KR weights are shown inline and must not exceed 100%.

Editing an existing objective should eventually be a dedicated objective workspace, not just the create dialog reused forever. The current detail sheet is moving in that direction: it supports KR add/edit/delete, progress updates, metadata, parent, labels, comments, and child objective navigation.

## Add Key Result Flow

KRs are measurable outcomes under non-company objectives.

A KR has:

- title
- optional description
- parent objective id
- owner
- contribution weight
- metric type
- initial value
- target value
- current value
- progress
- status
- date range

KRs are not allowed directly under company objectives in this product model.

## Backend Integration Notes

The app currently uses dummy in-memory services through `src/services/service-registry.ts`.

To connect a real backend:

1. Implement the service interfaces in `src/services/interfaces`.
2. Keep the same DTO shapes from `src/models`.
3. Enforce the same cascade rules from `src/lib/okr-validation.ts` on the backend.
4. Recalculate rollup progress server-side or in a reliable domain service.
5. Replace dummy service exports in `src/services/service-registry.ts`.

Backend schema should include:

```text
Objective
  id
  title
  description
  type
  status
  progress
  progressMode
  parentObjectiveId
  weight
  ownerIds
  ownershipMode
  labelIds
  groupId
  visibility
  commentsPrivate
  metricType
  initialValue
  targetValue
  currentValue
  startDate
  endDate
  quarter
  createdBy
  createdAt
  updatedAt

KeyResult
  id
  title
  description
  objectiveId
  ownerId
  weight
  metricType
  initialValue
  targetValue
  currentValue
  progress
  status
  startDate
  endDate
  createdAt
  updatedAt
```

## Known Production Follow-Ups

- Add real rollup recalculation when KRs or child objective progress changes.
- Add weight management UI for balancing a parent's full 100% contribution pool.
- Add backend persistence and authorization.
- Add route-level code splitting; the current production build still warns that the main JS bundle is large.
- Add tests for cascade validation and progress calculation.
- Add custom date range polish in the objective form.

## Commands

```bash
npm install
npm run dev
npm run lint
npm run build
```

On Windows PowerShell, use `npm.cmd` if script execution policy blocks `npm`:

```bash
npm.cmd run lint
npm.cmd run build
```
