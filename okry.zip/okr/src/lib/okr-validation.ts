import type {
  CreateObjectiveDTO,
  MetricType,
  Objective,
  ObjectiveType,
  UpdateObjectiveDTO,
} from '@/models';

const ALLOWED_PARENT_TYPES: Record<ObjectiveType, ObjectiveType[]> = {
  company: [],
  department: ['company'],
  team: ['company', 'department'],
  individual: ['company', 'department', 'team'],
};

export function canObjectiveHaveParent(type: ObjectiveType): boolean {
  return ALLOWED_PARENT_TYPES[type].length > 0;
}

export function canObjectiveHaveChildren(type: ObjectiveType): boolean {
  return type !== 'individual';
}

export function canObjectiveHaveKeyResults(type: ObjectiveType): boolean {
  return type !== 'company';
}

export function isValidParentType(parentType: ObjectiveType, childType: ObjectiveType): boolean {
  return ALLOWED_PARENT_TYPES[childType].includes(parentType);
}

export function getObjectiveValidationError(
  data: CreateObjectiveDTO,
  existingObjectives: Objective[],
): string | null {
  return validateObjectivePayload(data, existingObjectives);
}

export function getObjectiveUpdateValidationError(
  id: string,
  data: UpdateObjectiveDTO,
  existingObjectives: Objective[],
): string | null {
  const current = existingObjectives.find((objective) => objective.id === id);

  if (!current) return `Objective ${id} was not found.`;

  return validateObjectivePayload(
    {
      ...current,
      ...data,
      title: data.title ?? current.title,
      description: data.description ?? current.description,
      type: data.type ?? current.type,
      startDate: data.startDate ?? current.startDate,
      endDate: data.endDate ?? current.endDate,
      quarter: data.quarter ?? current.quarter,
      parentObjectiveId:
        data.parentObjectiveId === undefined
          ? current.parentObjectiveId
          : data.parentObjectiveId,
      ownerIds: data.ownerIds ?? current.ownerIds,
      ownershipMode: data.ownershipMode ?? current.ownershipMode,
      labelIds: data.labelIds ?? current.labelIds,
      groupId: data.groupId ?? current.groupId,
      visibility: data.visibility ?? current.visibility,
      commentsPrivate: data.commentsPrivate ?? current.commentsPrivate,
      progressMode: data.progressMode ?? current.progressMode,
      targetTrackingType: data.targetTrackingType ?? current.targetTrackingType,
      metricType: data.metricType ?? current.metricType,
      initialValue: data.initialValue ?? current.initialValue,
      targetValue: data.targetValue ?? current.targetValue,
    },
    existingObjectives,
    id,
  );
}

function validateObjectivePayload(
  data: CreateObjectiveDTO,
  existingObjectives: Objective[],
  editingId?: string,
): string | null {
  if (!data.title.trim()) return 'Objective title is required.';
  if (data.ownerIds.length === 0) return 'Select at least one owner.';
  if (data.startDate > data.endDate) {
    return 'End date must be on or after the start date.';
  }
  if (data.type === 'company' && data.parentObjectiveId) {
    return 'Company objectives cannot have a parent objective.';
  }
  if (data.type === 'company' && data.progressMode !== 'rollup') {
    return 'Company objective progress must roll up from child objectives.';
  }
  if (data.progressMode === 'manual') {
    if (!Number.isFinite(data.initialValue) || !Number.isFinite(data.targetValue)) {
      return 'Initial and target values must be valid numbers.';
    }
    if (data.initialValue === data.targetValue) {
      return 'Target value must be different from the initial value.';
    }
    if (data.metricType === 'percent' && (data.initialValue < 0 || data.targetValue > 100)) {
      return 'Percent metrics must stay between 0 and 100.';
    }
  }
  if (data.weight !== undefined && (data.weight < 0 || data.weight > 100)) {
    return 'Objective contribution weight must be between 0 and 100.';
  }

  if (data.parentObjectiveId) {
    const parent = existingObjectives.find((objective) => objective.id === data.parentObjectiveId);

    if (!parent) return 'Selected parent objective no longer exists.';
    if (parent.id === editingId) return 'An objective cannot be its own parent.';
    if (!canObjectiveHaveChildren(parent.type)) {
      return 'Individual objectives cannot have child objectives.';
    }
    if (!isValidParentType(parent.type, data.type)) {
      return getParentRuleMessage(data.type);
    }
    if (editingId && isDescendant(parent.id, editingId, existingObjectives)) {
      return 'Parent objective cannot be a descendant of this objective.';
    }
  }

  return null;
}

function isDescendant(
  candidateId: string,
  ancestorId: string,
  objectives: Objective[],
): boolean {
  let cursor = objectives.find((objective) => objective.id === candidateId);

  while (cursor?.parentObjectiveId) {
    if (cursor.parentObjectiveId === ancestorId) return true;
    cursor = objectives.find((objective) => objective.id === cursor?.parentObjectiveId);
  }

  return false;
}

export function getMetricBounds(metricType: MetricType): { initial: number; target: number } {
  if (metricType === 'percent') return { initial: 0, target: 100 };
  return { initial: 0, target: 1 };
}

export function getParentRuleMessage(type: ObjectiveType): string {
  switch (type) {
    case 'company':
      return 'Company objectives cannot have a parent objective.';
    case 'department':
      return 'Department objectives can only align to company objectives.';
    case 'team':
      return 'Team objectives can align to department or company objectives.';
    case 'individual':
      return 'Individual objectives can align to team, department, or company objectives.';
  }
}
