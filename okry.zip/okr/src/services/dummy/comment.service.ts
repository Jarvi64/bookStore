import { v4 as uuidv4 } from 'uuid';
import type { Comment, CreateCommentDTO } from '@/models';
import type { ICommentService } from '../interfaces/comment.service.interface';
import { DUMMY_COMMENTS } from './data/comments.data';
import { CURRENT_USER_ID } from './data/users.data';

/**
 * Dummy implementation of ICommentService.
 */
export class DummyCommentService implements ICommentService {
  private comments: Comment[] = [...DUMMY_COMMENTS];

  async getByObjectiveId(objectiveId: string): Promise<Comment[]> {
    return this.comments
      .filter((c) => c.objectiveId === objectiveId)
      .sort(
        (a, b) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
  }

  async create(data: CreateCommentDTO): Promise<Comment> {
    const newComment: Comment = {
      id: uuidv4(),
      objectiveId: data.objectiveId,
      authorId: CURRENT_USER_ID,
      content: data.content,
      createdAt: new Date().toISOString(),
    };
    this.comments.push(newComment);
    return { ...newComment };
  }

  async delete(id: string): Promise<void> {
    this.comments = this.comments.filter((c) => c.id !== id);
  }
}
