import type { Label } from '@/models';

/** Default labels matching the Viva Goals reference screenshots */
export const DUMMY_LABELS: Label[] = [
  { id: 'label-1', name: 'Business as usual', color: '#facc15' },
  { id: 'label-2', name: 'Innovation', color: '#4ade80' },
  { id: 'label-3', name: 'Aspirational', color: '#c084fc' },
  { id: 'label-4', name: 'High priority', color: '#60a5fa' },
  { id: 'label-5', name: 'Onboarding', color: '#f472b6' },
  { id: 'label-6', name: 'High risk', color: '#f87171' },
  { id: 'label-7', name: 'Medium risk', color: '#fb923c' },
  { id: 'label-8', name: 'Low risk', color: '#86efac' },
  { id: 'label-9', name: 'Professional development', color: '#a78bfa' },
  { id: 'label-10', name: 'Strategic outcome', color: '#818cf8' },
  { id: 'label-11', name: 'Strategic priority', color: '#7c3aed' },
];
