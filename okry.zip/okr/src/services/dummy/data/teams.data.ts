import type { Team } from '@/models';

export const DUMMY_TEAMS: Team[] = [
  {
    id: 'team-1',
    name: 'Growth Marketing',
    departmentId: 'dept-1',
    memberIds: ['user-2', 'user-5', 'user-6'],
  },
  {
    id: 'team-2',
    name: 'Content Marketing',
    departmentId: 'dept-1',
    memberIds: ['user-7', 'user-8'],
  },
  {
    id: 'team-3',
    name: 'Frontend Engineering',
    departmentId: 'dept-2',
    memberIds: ['user-3', 'user-9'],
  },
  {
    id: 'team-4',
    name: 'Talent Acquisition',
    departmentId: 'dept-4',
    memberIds: ['user-4', 'user-10'],
  },
  {
    id: 'team-5',
    name: 'Sales Operations',
    departmentId: 'dept-3',
    memberIds: ['user-11', 'user-12'],
  },
];
