import type { Comment } from '@/models';

export const DUMMY_COMMENTS: Comment[] = [
  {
    id: 'comment-1',
    objectiveId: 'obj-2',
    authorId: 'user-2',
    content:
      'Overall progress is strong and the objective remains on track. Two key results are performing well, and we\'re focusing on accelerating content-driven pipeline contribution.',
    createdAt: '2026-02-05T11:46:00Z',
  },
  {
    id: 'comment-2',
    objectiveId: 'obj-1',
    authorId: 'user-1',
    content:
      'Great progress across the board. Marketing and HR departments are both tracking well. Let\'s keep the momentum going into the second half of Q1.',
    createdAt: '2026-02-10T09:30:00Z',
  },
  {
    id: 'comment-3',
    objectiveId: 'obj-6',
    authorId: 'user-5',
    content:
      'Landing page is complete and live. MQL generation is slightly behind target — we need to ramp up paid promotion.',
    createdAt: '2026-02-15T14:00:00Z',
  },
  {
    id: 'comment-4',
    objectiveId: 'obj-7',
    authorId: 'user-5',
    content:
      'Organic traffic growth is slower than expected. We\'re pivoting to focus on long-tail keyword content to catch up.',
    createdAt: '2026-03-01T10:00:00Z',
  },
];
