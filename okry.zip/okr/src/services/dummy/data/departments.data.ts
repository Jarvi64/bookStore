import type { Department } from '@/models';

export const DUMMY_DEPARTMENTS: Department[] = [
  { id: 'dept-1', name: 'Marketing' },
  { id: 'dept-2', name: 'Engineering' },
  { id: 'dept-3', name: 'Sales' },
  { id: 'dept-4', name: 'HR' },
  { id: 'dept-5', name: 'Product' },
];
