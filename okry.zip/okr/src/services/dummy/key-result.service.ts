import { v4 as uuidv4 } from 'uuid';
import type {
  KeyResult,
  CreateKeyResultDTO,
  UpdateKeyResultDTO,
} from '@/models';
import {
  calculateKeyResultProgress,
  distributeWeightsEvenly,
} from '@/lib/progress-calculator';
import type { IKeyResultService } from '../interfaces/key-result.service.interface';
import { DUMMY_KEY_RESULTS } from './data/key-results.data';

/**
 * Dummy implementation of IKeyResultService.
 */
export class DummyKeyResultService implements IKeyResultService {
  private keyResults: KeyResult[] = [...DUMMY_KEY_RESULTS];

  async getAll(): Promise<KeyResult[]> {
    return [...this.keyResults];
  }

  async getById(id: string): Promise<KeyResult | null> {
    return this.keyResults.find((kr) => kr.id === id) ?? null;
  }

  async create(data: CreateKeyResultDTO): Promise<KeyResult> {
    if (!data.title.trim()) throw new Error('Key result title is required.');
    if (data.initialValue === data.targetValue) {
      throw new Error('Target value must be different from the initial value.');
    }
    if (data.startDate > data.endDate) {
      throw new Error('End date must be on or after the start date.');
    }

    const now = new Date().toISOString();
    const siblings = this.keyResults.filter((kr) => kr.objectiveId === data.objectiveId);
    const distributedWeights =
      data.weight === undefined ? distributeWeightsEvenly(siblings.length + 1) : null;

    if (distributedWeights) {
      siblings.forEach((kr, index) => {
        kr.weight = distributedWeights[index];
        kr.updatedAt = now;
      });
    }

    const newKR: KeyResult = {
      id: uuidv4(),
      title: data.title,
      description: data.description ?? null,
      objectiveId: data.objectiveId,
      ownerId: data.ownerId,
      weight: data.weight ?? distributedWeights?.[distributedWeights.length - 1] ?? 100,
      metricType: data.metricType,
      initialValue: data.initialValue,
      targetValue: data.targetValue,
      currentValue: data.initialValue,
      progress: 0,
      startDate: data.startDate,
      endDate: data.endDate,
      status: 'no_status',
      createdAt: now,
      updatedAt: now,
    };
    this.keyResults.push(newKR);
    return { ...newKR };
  }

  async update(id: string, data: UpdateKeyResultDTO): Promise<KeyResult> {
    const index = this.keyResults.findIndex((kr) => kr.id === id);
    if (index === -1) throw new Error(`Key Result ${id} not found`);

    const updated: KeyResult = {
      ...this.keyResults[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };

    if (
      data.currentValue !== undefined ||
      data.initialValue !== undefined ||
      data.targetValue !== undefined
    ) {
      updated.progress = calculateKeyResultProgress(
        updated.currentValue,
        updated.initialValue,
        updated.targetValue,
      );
    }

    this.keyResults[index] = updated;
    return { ...updated };
  }

  async delete(id: string): Promise<void> {
    this.keyResults = this.keyResults.filter((kr) => kr.id !== id);
  }

  async getByObjectiveId(objectiveId: string): Promise<KeyResult[]> {
    return this.keyResults.filter((kr) => kr.objectiveId === objectiveId);
  }

  async updateWeights(
    objectiveId: string,
    weights: { id: string; weight: number }[],
  ): Promise<void> {
    for (const { id, weight } of weights) {
      const kr = this.keyResults.find(
        (k) => k.id === id && k.objectiveId === objectiveId,
      );
      if (kr) kr.weight = weight;
    }
  }
}
