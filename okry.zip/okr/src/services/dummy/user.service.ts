import type { User } from '@/models';
import type { IUserService } from '../interfaces/user.service.interface';
import { DUMMY_USERS, CURRENT_USER_ID } from './data/users.data';

/**
 * Dummy implementation of IUserService.
 */
export class DummyUserService implements IUserService {
  private users: User[] = [...DUMMY_USERS];

  async getAll(): Promise<User[]> {
    return [...this.users];
  }

  async getById(id: string): Promise<User | null> {
    return this.users.find((u) => u.id === id) ?? null;
  }

  async getByDepartmentId(departmentId: string): Promise<User[]> {
    return this.users.filter((u) => u.departmentId === departmentId);
  }

  async getByTeamId(teamId: string): Promise<User[]> {
    return this.users.filter((u) => u.teamId === teamId);
  }

  async getCurrentUser(): Promise<User> {
    const user = this.users.find((u) => u.id === CURRENT_USER_ID);
    if (!user) throw new Error('Current user not found');
    return { ...user };
  }
}
