import { v4 as uuidv4 } from 'uuid';
import type { Label, CreateLabelDTO } from '@/models';
import type { ILabelService } from '../interfaces/label.service.interface';
import { DUMMY_LABELS } from './data/labels.data';

/**
 * Dummy implementation of ILabelService.
 */
export class DummyLabelService implements ILabelService {
  private labels: Label[] = [...DUMMY_LABELS];

  async getAll(): Promise<Label[]> {
    return [...this.labels];
  }

  async getById(id: string): Promise<Label | null> {
    return this.labels.find((l) => l.id === id) ?? null;
  }

  async create(data: CreateLabelDTO): Promise<Label> {
    const newLabel: Label = { id: uuidv4(), ...data };
    this.labels.push(newLabel);
    return { ...newLabel };
  }

  async update(id: string, data: Partial<CreateLabelDTO>): Promise<Label> {
    const index = this.labels.findIndex((l) => l.id === id);
    if (index === -1) throw new Error(`Label ${id} not found`);

    const updated = { ...this.labels[index], ...data };
    this.labels[index] = updated;
    return { ...updated };
  }

  async delete(id: string): Promise<void> {
    this.labels = this.labels.filter((l) => l.id !== id);
  }
}
