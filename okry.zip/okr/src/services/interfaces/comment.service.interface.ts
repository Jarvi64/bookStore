import type { Comment, CreateCommentDTO } from '@/models';

/**
 * Service contract for Comment operations.
 */
export interface ICommentService {
  getByObjectiveId(objectiveId: string): Promise<Comment[]>;
  create(data: CreateCommentDTO): Promise<Comment>;
  delete(id: string): Promise<void>;
}
