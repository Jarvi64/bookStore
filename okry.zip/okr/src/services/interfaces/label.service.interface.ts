import type { Label, CreateLabelDTO } from '@/models';

/**
 * Service contract for Label operations.
 */
export interface ILabelService {
  getAll(): Promise<Label[]>;
  getById(id: string): Promise<Label | null>;
  create(data: CreateLabelDTO): Promise<Label>;
  update(id: string, data: Partial<CreateLabelDTO>): Promise<Label>;
  delete(id: string): Promise<void>;
}
