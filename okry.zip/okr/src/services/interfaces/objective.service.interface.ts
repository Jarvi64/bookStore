import type {
  Objective,
  CreateObjectiveDTO,
  UpdateObjectiveDTO,
} from '@/models';

/**
 * Service contract for Objective operations.
 * Implement this interface for each data backend (dummy, Dataverse, etc.)
 */
export interface IObjectiveService {
  getAll(): Promise<Objective[]>;
  getById(id: string): Promise<Objective | null>;
  create(data: CreateObjectiveDTO): Promise<Objective>;
  update(id: string, data: UpdateObjectiveDTO): Promise<Objective>;
  delete(id: string): Promise<void>;

  /** Get all child objectives (sub-objectives) of a parent */
  getByParentId(parentId: string): Promise<Objective[]>;

  /** Get all objectives owned by a specific user */
  getByOwnerId(ownerId: string): Promise<Objective[]>;

  /** Get all objectives for a specific department */
  getByDepartment(departmentId: string): Promise<Objective[]>;

  /** Get all company-level objectives */
  getCompanyObjectives(): Promise<Objective[]>;
}
