import type { User } from '@/models';

/**
 * Service contract for User operations.
 */
export interface IUserService {
  getAll(): Promise<User[]>;
  getById(id: string): Promise<User | null>;
  getByDepartmentId(departmentId: string): Promise<User[]>;
  getByTeamId(teamId: string): Promise<User[]>;
  getCurrentUser(): Promise<User>;
}
