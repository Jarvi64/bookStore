import type {
  KeyResult,
  CreateKeyResultDTO,
  UpdateKeyResultDTO,
} from '@/models';

/**
 * Service contract for Key Result operations.
 */
export interface IKeyResultService {
  getAll(): Promise<KeyResult[]>;
  getById(id: string): Promise<KeyResult | null>;
  create(data: CreateKeyResultDTO): Promise<KeyResult>;
  update(id: string, data: UpdateKeyResultDTO): Promise<KeyResult>;
  delete(id: string): Promise<void>;

  /** Get all key results for a specific objective */
  getByObjectiveId(objectiveId: string): Promise<KeyResult[]>;

  /** Bulk update weights for all KRs of an objective */
  updateWeights(
    objectiveId: string,
    weights: { id: string; weight: number }[],
  ): Promise<void>;
}
