/**
 * Service Registry — Central dependency injection point.
 *
 * This file is the ONLY place where concrete service implementations
 * are instantiated. All stores and components import services from here,
 * never directly from implementation files.
 *
 * To switch from dummy (in-memory) data to a real backend:
 * ─────────────────────────────────────────────────────────
 * 1. Create new service classes in `services/dataverse/` or `services/api/`
 *    that implement the interfaces in `services/interfaces/`
 * 2. Swap the imports below to point at the new implementations
 * 3. Everything else (stores, components, pages) stays unchanged
 *
 * This pattern ensures zero coupling between UI code and data access.
 */

import { DummyObjectiveService } from './dummy/objective.service';
import { DummyKeyResultService } from './dummy/key-result.service';
import { DummyUserService } from './dummy/user.service';
import { DummyLabelService } from './dummy/label.service';
import { DummyCommentService } from './dummy/comment.service';

// ── Singleton instances — one per service for the app lifetime ──────────
export const objectiveService = new DummyObjectiveService();
export const keyResultService = new DummyKeyResultService();
export const userService = new DummyUserService();
export const labelService = new DummyLabelService();
export const commentService = new DummyCommentService();
