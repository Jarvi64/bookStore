import { cn } from '@/lib/utils';
import { getProgressBarColor } from '@/lib/constants';
import type { ObjectiveStatus } from '@/models';
import { motion } from 'framer-motion';

interface ObjectiveProgressBarProps {
  progress: number;
  status: ObjectiveStatus;
  showLabel?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

/**
 * ProgressBar — Animated progress bar with status-based coloring.
 * Uses framer-motion for smooth fill animation on mount/update.
 */
export function ObjectiveProgressBar({
  progress,
  status,
  showLabel = true,
  size = 'sm',
  className,
}: ObjectiveProgressBarProps) {
  const barColor = getProgressBarColor(status);
  const clampedProgress = Math.max(0, Math.min(100, progress));

  return (
    <div className={cn('flex items-center gap-2.5', className)}>
      <div
        className={cn(
          'relative flex-1 overflow-hidden rounded-full bg-muted/60',
          size === 'sm' ? 'h-1.5' : 'h-2.5',
        )}
      >
        <motion.div
          className={cn('absolute inset-y-0 left-0 rounded-full', barColor)}
          initial={{ width: 0 }}
          animate={{ width: `${clampedProgress}%` }}
          transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
        />
      </div>
      {showLabel && (
        <span className="min-w-[3ch] text-right text-xs font-medium tabular-nums text-muted-foreground">
          {Math.round(clampedProgress * 10) / 10}%
        </span>
      )}
    </div>
  );
}
