import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { UserAvatar } from '@/components/shared/user-avatar';
import { useUserStore } from '@/store/user.store';
import { commentService } from '@/services/service-registry';
import type { Comment } from '@/models';
import { toast } from 'sonner';

interface CommentsSectionProps {
  objectiveId: string;
}

/**
 * CommentsSection — List of comments with add form.
 * Lives inside the ObjectiveDetailSheet.
 */
export function CommentsSection({ objectiveId }: CommentsSectionProps) {
  const { getUserById, currentUser } = useUserStore();
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch comments for this objective
  useEffect(() => {
    commentService.getByObjectiveId(objectiveId).then(setComments);
  }, [objectiveId]);

  const handleSubmit = async () => {
    if (!newComment.trim()) return;

    setIsSubmitting(true);
    try {
      const created = await commentService.create({
        objectiveId,
        content: newComment.trim(),
      });
      setComments((prev) => [created, ...prev]);
      setNewComment('');
      toast.success('Comment added');
    } catch {
      toast.error('Failed to add comment');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-semibold">
        Comments
        <span className="text-muted-foreground font-normal ml-1">
          ({comments.length})
        </span>
      </h3>

      {/* Add comment form */}
      <div className="rounded-lg border bg-card p-3">
        <div className="flex gap-3">
          <UserAvatar user={currentUser ?? undefined} size="sm" showTooltip={false} />
          <div className="flex-1">
            <textarea
              placeholder="Type a comment... (Ctrl+Enter to send)"
              className="w-full resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground min-h-[2.5rem]"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyDown={handleKeyDown}
              rows={2}
            />
            <div className="flex justify-end pt-1">
              <Button
                size="xs"
                onClick={handleSubmit}
                disabled={!newComment.trim() || isSubmitting}
                className="gap-1"
              >
                <Send className="size-3" />
                Send
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Comments list */}
      <AnimatePresence>
        {comments.map((comment, index) => {
          const author = getUserById(comment.authorId);
          return (
            <motion.div
              key={comment.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
              className="flex gap-3 rounded-lg border p-3"
            >
              <UserAvatar user={author} size="sm" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-semibold">
                    {author?.name ?? 'Unknown'}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {format(new Date(comment.createdAt), 'MMM d, yyyy h:mm a')}
                  </span>
                </div>
                <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap">
                  {comment.content}
                </p>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
