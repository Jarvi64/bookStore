import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { STATUS_CONFIG } from '@/lib/constants';
import type { ObjectiveStatus } from '@/models';

interface StatusSummaryCardsProps {
  counts: Record<ObjectiveStatus, number>;
  activeFilter: ObjectiveStatus | null;
  onFilterClick: (status: ObjectiveStatus | null) => void;
}

const statusOrder: ObjectiveStatus[] = [
  'no_status',
  'off_track',
  'at_risk',
  'on_track',
  'closed',
];

/**
 * StatusSummaryCards — Horizontal row of clickable status count cards.
 * Matches the Viva Goals reference (0 No status | 0 Off track | 4 At risk | 9 On track | 0 Closed).
 */
export function StatusSummaryCards({
  counts,
  activeFilter,
  onFilterClick,
}: StatusSummaryCardsProps) {
  return (
    <div className="flex items-center gap-2">
      {statusOrder.map((status, index) => {
        const config = STATUS_CONFIG[status];
        const count = counts[status] || 0;
        const isActive = activeFilter === status;

        return (
          <motion.button
            key={status}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05, duration: 0.3 }}
            onClick={() => onFilterClick(isActive ? null : status)}
            className={cn(
              'flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-all',
              'hover:border-primary/30 hover:shadow-sm',
              isActive
                ? 'border-primary/40 bg-primary/5 shadow-sm'
                : 'border-border bg-card',
            )}
          >
            <span className={cn('size-2 rounded-full', config.dotColor)} />
            <span className="font-semibold tabular-nums">{count}</span>
            <span className="text-muted-foreground">{config.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
}
