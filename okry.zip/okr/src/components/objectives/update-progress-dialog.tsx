import { useState } from 'react';
import { motion } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { METRIC_TYPE_CONFIG } from '@/lib/constants';
import type { MetricType } from '@/models';
import { toast } from 'sonner';

interface UpdateProgressDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  metricType: MetricType;
  currentValue: number;
  targetValue: number;
  onSubmit: (newValue: number) => Promise<void>;
}

/**
 * UpdateProgressDialog — Manual check-in dialog for updating an objective's current value.
 */
export function UpdateProgressDialog({
  open,
  onOpenChange,
  title,
  metricType,
  currentValue,
  targetValue,
  onSubmit,
}: UpdateProgressDialogProps) {
  const [newValue, setNewValue] = useState(currentValue);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const config = METRIC_TYPE_CONFIG[metricType];
  const range = targetValue - 0;
  const newProgress =
    range === 0 ? 0 : Math.round((newValue / targetValue) * 1000) / 10;

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      await onSubmit(newValue);
      toast.success('Progress updated');
      onOpenChange(false);
    } catch {
      toast.error('Failed to update progress');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="text-base">Update progress</DialogTitle>
        </DialogHeader>

        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 pt-2"
        >
          <p className="text-sm text-muted-foreground line-clamp-2">{title}</p>

          <div className="space-y-1.5">
            <Label className="text-sm">
              Current value ({config.prefix || config.suffix})
            </Label>
            <Input
              type="number"
              value={newValue}
              onChange={(e) => setNewValue(Number(e.target.value))}
              className="text-sm"
              autoFocus
            />
            <p className="text-xs text-muted-foreground">
              Target: {config.prefix}{targetValue}{config.suffix} · New progress: {newProgress}%
            </p>
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button size="sm" onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? 'Updating...' : 'Update'}
            </Button>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
