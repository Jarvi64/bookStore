import { cn } from '@/lib/utils';
import { STATUS_CONFIG } from '@/lib/constants';
import type { ObjectiveStatus } from '@/models';

interface ObjectiveStatusBadgeProps {
  status: ObjectiveStatus;
  className?: string;
}

/**
 * StatusBadge — Color-coded status indicator matching the Viva Goals reference.
 * Shows a dot + label with appropriate background color.
 */
export function ObjectiveStatusBadge({ status, className }: ObjectiveStatusBadgeProps) {
  const config = STATUS_CONFIG[status];

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap',
        config.bgColor,
        config.color,
        className,
      )}
    >
      <span className={cn('size-1.5 rounded-full', config.dotColor)} />
      {config.label}
    </span>
  );
}
