import { NavLink, useLocation } from 'react-router-dom';
import {
  Target,
  Users,
  Building2,
  Landmark,
  Globe,
  Tags,
  Settings,
  UserCircle,
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  SidebarSeparator,
} from '@/components/ui/sidebar';
import { cn } from '@/lib/utils';

/** Navigation items for the Objectives section */
const objectiveNavItems = [
  { to: '/objectives/my', label: 'My Objectives', icon: Target },
  { to: '/objectives/team', label: 'My Team', icon: Users },
  { to: '/objectives/department', label: 'Department', icon: Building2 },
  { to: '/objectives/company', label: 'Company', icon: Landmark },
  { to: '/objectives/all', label: 'All Objectives', icon: Globe },
];

/** Navigation items for the Settings section */
const settingsNavItems = [
  { to: '/settings/labels', label: 'Labels', icon: Tags },
  { to: '/settings/teams', label: 'Departments & Teams', icon: Users },
];

/**
 * App Sidebar — Main navigation component.
 * Uses shadcn Sidebar with NavLink for active state highlighting.
 */
export function AppSidebar() {
  const location = useLocation();

  return (
    <Sidebar>
      {/* Logo / App Title */}
      <SidebarHeader className="px-4 py-4">
        <NavLink to="/" className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Target className="size-4" />
          </div>
          <div>
            <h1 className="text-sm font-semibold tracking-tight">OKR Tracker</h1>
            <p className="text-[10px] text-muted-foreground">
              Objectives & Key Results
            </p>
          </div>
        </NavLink>
      </SidebarHeader>

      <SidebarSeparator />

      <SidebarContent>
        {/* Objectives Section */}
        <SidebarGroup>
          <SidebarGroupLabel>Objectives</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {objectiveNavItems.map((item) => (
                <SidebarMenuItem key={item.to}>
                  <SidebarMenuButton
                    asChild
                    isActive={location.pathname === item.to}
                  >
                    <NavLink
                      to={item.to}
                      className={cn(
                        'transition-colors',
                        location.pathname === item.to && 'font-medium',
                      )}
                    >
                      <item.icon className="size-4" />
                      <span>{item.label}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        {/* Settings Section */}
        <SidebarGroup>
          <SidebarGroupLabel>
            <Settings className="mr-1.5 size-3" />
            Settings
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {settingsNavItems.map((item) => (
                <SidebarMenuItem key={item.to}>
                  <SidebarMenuButton
                    asChild
                    isActive={location.pathname === item.to}
                  >
                    <NavLink to={item.to}>
                      <item.icon className="size-4" />
                      <span>{item.label}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* Footer — Current User */}
      <SidebarFooter className="px-4 py-3">
        <div className="flex items-center gap-2.5">
          <div className="flex size-8 items-center justify-center rounded-full bg-primary/10 text-primary">
            <UserCircle className="size-4" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-medium">Benny Matteo</p>
            <p className="truncate text-[10px] text-muted-foreground">
              Marketing Manager
            </p>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
