import { Search, Plus, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Separator } from '@/components/ui/separator';
import { useTheme } from '@/components/theme-provider';
import { useUIStore } from '@/store/ui.store';

/**
 * App Header — Top bar with sidebar trigger, search, and actions.
 */
export function AppHeader() {
  const { theme, setTheme } = useTheme();
  const { searchQuery, setSearchQuery, setCreateDialogOpen } = useUIStore();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <header className="flex h-14 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur-sm">
      <SidebarTrigger className="-ml-1" />
      <Separator orientation="vertical" className="h-5" />

      {/* Search */}
      <div className="relative flex-1 max-w-md">
        <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Search by owner or title..."
          className="h-8 pl-8 text-xs"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="ml-auto flex items-center gap-2">
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={toggleTheme}
          aria-label="Toggle theme"
        >
          {theme === 'dark' ? (
            <Sun className="size-3.5" />
          ) : (
            <Moon className="size-3.5" />
          )}
        </Button>

        {/* New Objective Button */}
        <Button
          size="sm"
          onClick={() => setCreateDialogOpen(true)}
          className="gap-1.5"
        >
          <Plus className="size-3.5" />
          New objective
        </Button>
      </div>
    </header>
  );
}
