import { Outlet } from 'react-router-dom';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { AppSidebar } from './app-sidebar';
import { AppHeader } from './app-header';
import { ObjectiveDetailSheet } from '@/components/objectives/objective-detail-sheet';
import { ObjectiveFormDialog } from '@/components/objectives/objective-form-dialog';

/**
 * App Layout — Shell component wrapping sidebar + header + content.
 * Uses React Router's <Outlet> for page rendering.
 * Detail sheet and create dialog are rendered here so they're available globally.
 */
export function AppLayout() {
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <AppHeader />
        <main className="flex-1 overflow-auto p-4 md:p-6">
          <Outlet />
        </main>
      </SidebarInset>

      {/* Global overlays */}
      <ObjectiveDetailSheet />
      <ObjectiveFormDialog />
    </SidebarProvider>
  );
}
