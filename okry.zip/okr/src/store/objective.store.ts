import { create } from 'zustand';
import type { Objective, CreateObjectiveDTO, UpdateObjectiveDTO, ObjectiveStatus } from '@/models';
import { objectiveService } from '@/services/service-registry';
import { calculateMetricProgress } from '@/lib/progress-calculator';

/**
 * ObjectiveState — Shape of the Objective store.
 *
 * Objectives are the primary domain entity in the OKR system.
 * They form a tree via `parentObjectiveId` and cascade from
 * Company → Department → Team → Individual.
 */
interface ObjectiveState {
  /** All objectives loaded from the service */
  objectives: Objective[];
  /** Whether initial fetch is in progress */
  isLoading: boolean;
  /** Last error message from a failed service call */
  error: string | null;

  // ---- Actions ----
  /** Fetch all objectives from the service layer */
  fetchObjectives: () => Promise<void>;
  /** Create a new objective and append to local state */
  createObjective: (data: CreateObjectiveDTO) => Promise<Objective>;
  /** Update an existing objective by ID */
  updateObjective: (id: string, data: UpdateObjectiveDTO) => Promise<void>;
  /** Delete an objective by ID (also orphans children in dummy service) */
  deleteObjective: (id: string) => Promise<void>;
  /** Quick-update just the status badge */
  updateStatus: (id: string, status: ObjectiveStatus) => Promise<void>;
  /**
   * Update the currentValue and recalculate progress percentage.
   * Also auto-sets status to 'on_track' if it was 'no_status',
   * or 'closed' if progress reaches 100%.
   */
  updateProgress: (id: string, currentValue: number) => Promise<void>;
}

/**
 * Zustand store for Objectives.
 *
 * All data operations go through the service layer (see service-registry.ts),
 * making the backend implementation swappable without touching this file.
 *
 * Progress calculation:
 * - For leaf objectives (no KRs/children): progress = (current - initial) / (target - initial) * 100
 * - For parent objectives: progress is the weighted average of children (handled by the service)
 */
export const useObjectiveStore = create<ObjectiveState>((set, get) => ({
  objectives: [],
  isLoading: false,
  error: null,

  fetchObjectives: async () => {
    set({ isLoading: true, error: null });
    try {
      const objectives = await objectiveService.getAll();
      set({ objectives, isLoading: false });
    } catch (e) {
      set({ error: (e as Error).message, isLoading: false });
    }
  },

  createObjective: async (data) => {
    const created = await objectiveService.create(data);
    set({ objectives: [...get().objectives, created] });
    return created;
  },

  updateObjective: async (id, data) => {
    const updated = await objectiveService.update(id, data);
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },

  deleteObjective: async (id) => {
    await objectiveService.delete(id);
    set({
      objectives: get().objectives.filter((o) => o.id !== id),
    });
  },

  updateStatus: async (id, status) => {
    const updated = await objectiveService.update(id, { status });
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },

  updateProgress: async (id, currentValue) => {
    const objective = get().objectives.find((o) => o.id === id);
    if (!objective) return;

    const progress = calculateMetricProgress(
      currentValue,
      objective.initialValue,
      objective.targetValue,
    );
    const nextStatus =
      progress >= 100
        ? 'closed'
        : objective.status === 'no_status'
          ? 'on_track'
          : objective.status;

    const updated = await objectiveService.update(id, {
      currentValue,
      status: nextStatus,
    });
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },
}));
