import { create } from 'zustand';
import type { Label, CreateLabelDTO } from '@/models';
import { labelService } from '@/services/service-registry';

/**
 * LabelState — Shape of the Label store.
 *
 * Labels are colored tags that can be applied to objectives
 * for categorization (e.g., "Revenue", "Growth", "Infrastructure").
 * They are managed via the Settings → Labels page.
 */
interface LabelState {
  /** All available labels */
  labels: Label[];
  /** Whether initial fetch is in progress */
  isLoading: boolean;

  // ---- Actions ----
  /** Fetch all labels from the service layer */
  fetchLabels: () => Promise<void>;
  /** Create a new label and append to local state */
  createLabel: (data: CreateLabelDTO) => Promise<Label>;
  /** Update an existing label's name or color */
  updateLabel: (id: string, data: Partial<CreateLabelDTO>) => Promise<void>;
  /** Delete a label by ID */
  deleteLabel: (id: string) => Promise<void>;
  /** Synchronous lookup by ID */
  getLabelById: (id: string) => Label | undefined;
}

/**
 * Zustand store for Labels.
 *
 * Labels are referenced by ID in the Objective model's `labelIds` array.
 * The label store provides the full Label objects needed for rendering
 * colored badges in the UI.
 */
export const useLabelStore = create<LabelState>((set, get) => ({
  labels: [],
  isLoading: false,

  fetchLabels: async () => {
    set({ isLoading: true });
    const labels = await labelService.getAll();
    set({ labels, isLoading: false });
  },

  createLabel: async (data) => {
    const created = await labelService.create(data);
    set({ labels: [...get().labels, created] });
    return created;
  },

  updateLabel: async (id, data) => {
    const updated = await labelService.update(id, data);
    set({
      labels: get().labels.map((l) => (l.id === id ? updated : l)),
    });
  },

  deleteLabel: async (id) => {
    await labelService.delete(id);
    set({ labels: get().labels.filter((l) => l.id !== id) });
  },

  getLabelById: (id) => get().labels.find((l) => l.id === id),
}));
