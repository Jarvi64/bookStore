import { create } from 'zustand';
import type { User } from '@/models';
import { userService } from '@/services/service-registry';

/**
 * UserState — Shape of the User store.
 *
 * Users are referenced throughout the app as objective owners,
 * key result owners, and comment authors. This store provides
 * a centralized list with a fast lookup helper.
 */
interface UserState {
  /** All users in the organization */
  users: User[];
  /** The currently logged-in user (used for "My Objectives" filtering) */
  currentUser: User | null;
  /** Whether initial fetch is in progress */
  isLoading: boolean;

  // ---- Actions ----
  /** Fetch all users from the service layer */
  fetchUsers: () => Promise<void>;
  /** Fetch the current authenticated user */
  fetchCurrentUser: () => Promise<void>;
  /**
   * Synchronous lookup by ID — used in render loops.
   * Returns undefined if the user is not found.
   */
  getUserById: (id: string) => User | undefined;
}

/**
 * Zustand store for Users.
 *
 * Note: getUserById uses Array.find() which is O(n).
 * For large orgs, consider building a Map<string, User> on fetch.
 */
export const useUserStore = create<UserState>((set, get) => ({
  users: [],
  currentUser: null,
  isLoading: false,

  fetchUsers: async () => {
    set({ isLoading: true });
    const users = await userService.getAll();
    set({ users, isLoading: false });
  },

  fetchCurrentUser: async () => {
    const currentUser = await userService.getCurrentUser();
    set({ currentUser });
  },

  getUserById: (id) => get().users.find((u) => u.id === id),
}));
