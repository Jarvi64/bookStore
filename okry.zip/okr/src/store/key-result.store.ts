import { create } from 'zustand';
import type { KeyResult, CreateKeyResultDTO, UpdateKeyResultDTO } from '@/models';
import { keyResultService } from '@/services/service-registry';

/**
 * KeyResultState — Shape of the Key Result store.
 *
 * Key Results are measurable outcomes tied to a parent Objective.
 * Each KR has a single owner and a weight that determines its
 * contribution to the parent's progress calculation.
 */
interface KeyResultState {
  /** All key results loaded from the service */
  keyResults: KeyResult[];
  /** Whether initial fetch is in progress */
  isLoading: boolean;
  /** Last error message from a failed service call */
  error: string | null;

  // ---- Actions ----
  /** Fetch all key results from the service layer */
  fetchKeyResults: () => Promise<void>;
  /** Synchronous filter — returns KRs belonging to a specific objective */
  getByObjectiveId: (objectiveId: string) => KeyResult[];
  /** Create a new KR and append to local state */
  createKeyResult: (data: CreateKeyResultDTO) => Promise<KeyResult>;
  /** Update an existing KR by ID */
  updateKeyResult: (id: string, data: UpdateKeyResultDTO) => Promise<void>;
  /** Delete a KR by ID */
  deleteKeyResult: (id: string) => Promise<void>;
  /** Batch-update weights for all KRs under one objective (must sum to 100) */
  updateWeights: (objectiveId: string, weights: { id: string; weight: number }[]) => Promise<void>;
}

/**
 * Zustand store for Key Results.
 *
 * All data operations go through the service layer (see service-registry.ts),
 * making the backend implementation swappable without touching this file.
 */
export const useKeyResultStore = create<KeyResultState>((set, get) => ({
  keyResults: [],
  isLoading: false,
  error: null,

  fetchKeyResults: async () => {
    set({ isLoading: true, error: null });
    try {
      const keyResults = await keyResultService.getAll();
      set({ keyResults, isLoading: false });
    } catch (e) {
      set({ error: (e as Error).message, isLoading: false });
    }
  },

  getByObjectiveId: (objectiveId) => {
    return get().keyResults.filter((kr) => kr.objectiveId === objectiveId);
  },

  createKeyResult: async (data) => {
    const created = await keyResultService.create(data);
    set({ keyResults: [...get().keyResults, created] });
    return created;
  },

  updateKeyResult: async (id, data) => {
    const updated = await keyResultService.update(id, data);
    set({
      keyResults: get().keyResults.map((kr) => (kr.id === id ? updated : kr)),
    });
  },

  deleteKeyResult: async (id) => {
    await keyResultService.delete(id);
    set({
      keyResults: get().keyResults.filter((kr) => kr.id !== id),
    });
  },

  updateWeights: async (objectiveId, weights) => {
    await keyResultService.updateWeights(objectiveId, weights);
    // Optimistically update local state with the new weights
    const updatedKRs = get().keyResults.map((kr) => {
      const weightUpdate = weights.find((w) => w.id === kr.id);
      return weightUpdate ? { ...kr, weight: weightUpdate.weight } : kr;
    });
    set({ keyResults: updatedKRs });
  },
}));
