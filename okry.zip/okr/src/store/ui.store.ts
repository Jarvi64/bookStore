import { create } from 'zustand';
import type { ScopeTab, ViewMode, ObjectiveStatus } from '@/models';

/**
 * UI state store — controls view preferences, filters, and selected items.
 * Separate from domain stores to keep concerns clean.
 */
interface UIState {
  /** Currently active scope tab */
  activeTab: ScopeTab;
  /** List vs Board view */
  viewMode: ViewMode;
  /** Selected objective ID (for detail sheet) */
  selectedObjectiveId: string | null;
  /** ID of the objective currently being edited in the form dialog */
  editingObjectiveId: string | null;
  /** Whether the create objective dialog is open */
  isCreateDialogOpen: boolean;
  /** Search query for filtering objectives */
  searchQuery: string;
  /** Status filter (null = show all) */
  statusFilter: ObjectiveStatus | null;
  /** Whether the sidebar is collapsed */
  sidebarCollapsed: boolean;

  // ---- Actions ----
  setActiveTab: (tab: ScopeTab) => void;
  setViewMode: (mode: ViewMode) => void;
  setSelectedObjectiveId: (id: string | null) => void;
  setEditingObjectiveId: (id: string | null) => void;
  setCreateDialogOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  setStatusFilter: (status: ObjectiveStatus | null) => void;
  toggleSidebar: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  activeTab: 'my_objectives',
  viewMode: 'list',
  selectedObjectiveId: null,
  editingObjectiveId: null,
  isCreateDialogOpen: false,
  searchQuery: '',
  statusFilter: null,
  sidebarCollapsed: false,

  setActiveTab: (activeTab) => set({ activeTab }),
  setViewMode: (viewMode) => set({ viewMode }),
  setSelectedObjectiveId: (selectedObjectiveId) => set({ selectedObjectiveId }),
  setEditingObjectiveId: (editingObjectiveId) => set({ editingObjectiveId }),
  setCreateDialogOpen: (isCreateDialogOpen) => set({ isCreateDialogOpen }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),
  setStatusFilter: (statusFilter) => set({ statusFilter }),
  toggleSidebar: () =>
    set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
}));
