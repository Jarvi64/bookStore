import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Pencil, Trash2, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useLabelStore } from '@/store/label.store';
import { toast } from 'sonner';

/** Predefined color palette for label color picker */
const COLOR_PALETTE = [
  '#f87171', '#fb923c', '#facc15', '#4ade80', '#34d399',
  '#22d3ee', '#60a5fa', '#818cf8', '#a78bfa', '#c084fc',
  '#f472b6', '#e879f9', '#7c3aed', '#2563eb', '#059669',
];

/**
 * LabelsSettingsPage — Full CRUD for labels with inline editing and color picker.
 */
export function LabelsSettingsPage() {
  const { labels, fetchLabels, createLabel, updateLabel, deleteLabel } =
    useLabelStore();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editColor, setEditColor] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(COLOR_PALETTE[0]);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    fetchLabels();
  }, [fetchLabels]);

  const handleCreate = async () => {
    if (!newName.trim()) {
      toast.error('Label name is required');
      return;
    }
    await createLabel({ name: newName.trim(), color: newColor });
    setNewName('');
    setNewColor(COLOR_PALETTE[0]);
    setIsAdding(false);
    toast.success('Label created');
  };

  const handleUpdate = async (id: string) => {
    if (!editName.trim()) return;
    await updateLabel(id, { name: editName.trim(), color: editColor });
    setEditingId(null);
    toast.success('Label updated');
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    await deleteLabel(deleteId);
    setDeleteId(null);
    toast.success('Label deleted');
  };

  const startEdit = (id: string, name: string, color: string) => {
    setEditingId(id);
    setEditName(name);
    setEditColor(color);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">Labels</h1>
          <p className="text-sm text-muted-foreground">
            Manage labels used to categorize objectives
          </p>
        </div>
        <Button size="sm" className="gap-1" onClick={() => setIsAdding(true)}>
          <Plus className="size-3.5" />
          Add label
        </Button>
      </div>

      {/* Add new label form */}
      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Input
                    placeholder="Label name"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="text-sm flex-1"
                    autoFocus
                    onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
                  />
                  <Button size="sm" onClick={handleCreate} className="gap-1">
                    <Check className="size-3" />
                    Save
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => setIsAdding(false)}
                  >
                    <X className="size-3.5" />
                  </Button>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground mb-1.5 block">
                    Color
                  </Label>
                  <div className="flex flex-wrap gap-1.5">
                    {COLOR_PALETTE.map((color) => (
                      <button
                        key={color}
                        className="size-6 rounded-full border-2 transition-transform hover:scale-110"
                        style={{
                          backgroundColor: color,
                          borderColor:
                            newColor === color ? 'var(--foreground)' : 'transparent',
                        }}
                        onClick={() => setNewColor(color)}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Labels list */}
      <div className="space-y-1.5">
        <AnimatePresence>
          {labels.map((label, index) => (
            <motion.div
              key={label.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 8 }}
              transition={{ delay: index * 0.03 }}
              className="flex items-center gap-3 rounded-lg border p-3 hover:bg-accent/30 transition-colors group"
            >
              {editingId === label.id ? (
                // Editing mode
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2">
                    <Input
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="text-sm h-8 flex-1"
                      autoFocus
                      onKeyDown={(e) =>
                        e.key === 'Enter' && handleUpdate(label.id)
                      }
                    />
                    <Button
                      size="icon-xs"
                      onClick={() => handleUpdate(label.id)}
                    >
                      <Check className="size-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      onClick={() => setEditingId(null)}
                    >
                      <X className="size-3" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {COLOR_PALETTE.map((color) => (
                      <button
                        key={color}
                        className="size-5 rounded-full border-2 transition-transform hover:scale-110"
                        style={{
                          backgroundColor: color,
                          borderColor:
                            editColor === color
                              ? 'var(--foreground)'
                              : 'transparent',
                        }}
                        onClick={() => setEditColor(color)}
                      />
                    ))}
                  </div>
                </div>
              ) : (
                // Display mode
                <>
                  <span
                    className="size-4 rounded-full shrink-0"
                    style={{ backgroundColor: label.color }}
                  />
                  <Badge
                    variant="secondary"
                    className="text-xs font-medium"
                    style={{
                      backgroundColor: `${label.color}20`,
                      color: label.color,
                    }}
                  >
                    {label.name}
                  </Badge>
                  <span className="flex-1" />
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      onClick={() =>
                        startEdit(label.id, label.name, label.color)
                      }
                    >
                      <Pencil className="size-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      className="text-destructive hover:text-destructive"
                      onClick={() => setDeleteId(label.id)}
                    >
                      <Trash2 className="size-3" />
                    </Button>
                  </div>
                </>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Delete confirmation */}
      <AlertDialog
        open={!!deleteId}
        onOpenChange={(open) => !open && setDeleteId(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete label?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the label from all objectives. This action cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </motion.div>
  );
}
