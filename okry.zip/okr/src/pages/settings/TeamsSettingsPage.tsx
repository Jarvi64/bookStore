import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Building2, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { UserAvatar } from '@/components/shared/user-avatar';
import { useUserStore } from '@/store/user.store';
import { DUMMY_DEPARTMENTS } from '@/services/dummy/data/departments.data';
import { DUMMY_TEAMS } from '@/services/dummy/data/teams.data';

/**
 * TeamsSettingsPage — Displays departments and teams with member lists.
 * Read-only for now — CRUD can be added later.
 */
export function TeamsSettingsPage() {
  const { users, fetchUsers } = useUserStore();

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl space-y-6"
    >
      <div>
        <h1 className="text-lg font-semibold tracking-tight">
          Departments & Teams
        </h1>
        <p className="text-sm text-muted-foreground">
          Organization structure and team membership
        </p>
      </div>

      {DUMMY_DEPARTMENTS.map((dept, deptIndex) => {
        const deptTeams = DUMMY_TEAMS.filter(
          (t) => t.departmentId === dept.id,
        );
        const deptUsers = users.filter((u) => u.departmentId === dept.id);

        return (
          <motion.div
            key={dept.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: deptIndex * 0.08 }}
          >
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Building2 className="size-4 text-primary" />
                  {dept.name}
                  <Badge variant="secondary" className="text-[10px] font-normal">
                    {deptUsers.length} members
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {deptTeams.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    No teams in this department
                  </p>
                ) : (
                  deptTeams.map((team) => {
                    const teamMembers = team.memberIds
                      .map((id) => users.find((u) => u.id === id))
                      .filter(Boolean);

                    return (
                      <div key={team.id}>
                        <div className="flex items-center gap-2 mb-2">
                          <Users className="size-3.5 text-muted-foreground" />
                          <span className="text-sm font-medium">
                            {team.name}
                          </span>
                          <Badge
                            variant="outline"
                            className="text-[10px] font-normal"
                          >
                            {teamMembers.length} members
                          </Badge>
                        </div>
                        <div className="flex flex-wrap gap-2 pl-5">
                          {teamMembers.map(
                            (member) =>
                              member && (
                                <div
                                  key={member.id}
                                  className="flex items-center gap-2 rounded-lg bg-muted/50 px-2.5 py-1.5"
                                >
                                  <UserAvatar
                                    user={member}
                                    size="sm"
                                    showTooltip={false}
                                  />
                                  <div>
                                    <p className="text-xs font-medium">
                                      {member.name}
                                    </p>
                                    <p className="text-[10px] text-muted-foreground capitalize">
                                      {member.role}
                                    </p>
                                  </div>
                                </div>
                              ),
                          )}
                        </div>
                        <Separator className="mt-3" />
                      </div>
                    );
                  })
                )}
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
