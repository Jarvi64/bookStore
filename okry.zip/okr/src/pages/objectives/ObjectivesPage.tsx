import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useObjectiveStore } from '@/store/objective.store';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { ObjectivesList } from '@/components/objectives/objectives-list';
import { Skeleton } from '@/components/ui/skeleton';

/**
 * ObjectivesPage — Main page for viewing and managing objectives.
 * Loads all required data on mount, then renders the ObjectivesList.
 */
export function ObjectivesPage() {
  const { isLoading, fetchObjectives } = useObjectiveStore();
  const { fetchKeyResults } = useKeyResultStore();
  const { fetchUsers, fetchCurrentUser } = useUserStore();
  const { fetchLabels } = useLabelStore();

  // Load all data on mount
  useEffect(() => {
    fetchObjectives();
    fetchKeyResults();
    fetchUsers();
    fetchCurrentUser();
    fetchLabels();
  }, [fetchObjectives, fetchKeyResults, fetchUsers, fetchCurrentUser, fetchLabels]);

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <ObjectivesList />
    </motion.div>
  );
}

/** Skeleton loader for the objectives page — matches the real layout shape */
function LoadingSkeleton() {
  return (
    <div className="space-y-5">
      {/* Header skeleton */}
      <div className="flex items-center gap-5">
        <Skeleton className="size-14 rounded-full" />
        <div className="space-y-2">
          <Skeleton className="h-5 w-36" />
          <Skeleton className="h-3 w-48" />
        </div>
      </div>

      {/* Status cards skeleton */}
      <div className="flex gap-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-8 w-28 rounded-lg" />
        ))}
      </div>

      {/* Table skeleton */}
      <div className="space-y-0 rounded-lg border">
        <Skeleton className="h-9 rounded-t-lg" />
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 border-t px-4 py-3">
            <Skeleton className="size-5 rounded" />
            <Skeleton className="size-7 rounded-md" />
            <Skeleton className="size-6 rounded-full" />
            <Skeleton className="h-4 flex-1" />
            <Skeleton className="h-1.5 w-36 rounded-full" />
            <Skeleton className="h-5 w-20 rounded-full" />
            <Skeleton className="h-3 w-20" />
          </div>
        ))}
      </div>
    </div>
  );
}
