/**
 * App.tsx — Root component with routing configuration.
 *
 * All routes are wrapped in AppLayout which provides:
 * - Collapsible sidebar with navigation links
 * - Top header bar with search, theme toggle, and user avatar
 *
 * Route structure:
 * - /objectives/my     → My Objectives (filtered to current user)
 * - /objectives/team   → My Team's objectives
 * - /objectives/department → Department objectives
 * - /objectives/company → Company-wide objectives
 * - /objectives/all    → All objectives (unfiltered)
 * - /settings/labels   → Label management (CRUD)
 * - /settings/teams    → Organization structure viewer
 *
 * The ObjectivesPage component is shared across all /objectives/* routes
 * and reads the current path to determine which scope filter to apply.
 */
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from '@/components/layout/app-layout';
import { ObjectivesPage } from '@/pages/objectives/ObjectivesPage';
import { LabelsSettingsPage } from '@/pages/settings/LabelsSettingsPage';
import { TeamsSettingsPage } from '@/pages/settings/TeamsSettingsPage';

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          {/* Default redirect to "My Objectives" */}
          <Route path="/" element={<Navigate to="/objectives/my" replace />} />

          {/* Objectives — same page component, scope determined by URL path */}
          <Route path="/objectives/my" element={<ObjectivesPage />} />
          <Route path="/objectives/team" element={<ObjectivesPage />} />
          <Route path="/objectives/department" element={<ObjectivesPage />} />
          <Route path="/objectives/company" element={<ObjectivesPage />} />
          <Route path="/objectives/all" element={<ObjectivesPage />} />

          {/* Settings */}
          <Route path="/settings/labels" element={<LabelsSettingsPage />} />
          <Route path="/settings/teams" element={<TeamsSettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
