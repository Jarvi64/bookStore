/**
 * main.tsx — Application entry point.
 *
 * Sets up the React root and wraps the app with global providers:
 * - ThemeProvider: Dark/light/system theme persistence via localStorage
 * - TooltipProvider: Enables tooltips across all Radix UI components
 * - Toaster: Sonner toast notifications (bottom-right position)
 */
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"

import "./index.css"
import App from "./App.tsx"
import { ThemeProvider } from "@/components/theme-provider.tsx"
import { TooltipProvider } from "@/components/ui/tooltip"
import { Toaster } from "@/components/ui/sonner"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider>
      <TooltipProvider>
        <App />
        <Toaster position="bottom-right" richColors />
      </TooltipProvider>
    </ThemeProvider>
  </StrictMode>
)
