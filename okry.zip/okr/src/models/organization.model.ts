/** Department entity — organizational unit */
export interface Department {
  id: string;
  name: string;
}

/** Team/Group entity — a group of users within a department */
export interface Team {
  id: string;
  name: string;
  departmentId: string; // FK to Department
  memberIds: string[]; // FK(s) to User
}
