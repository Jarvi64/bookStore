/** Label entity — color-coded tags for categorizing objectives */
export interface Label {
  id: string;
  name: string;

  /** CSS color value (hex, hsl, oklch) for the badge background */
  color: string;
}

/** DTO for creating/updating a label */
export interface CreateLabelDTO {
  name: string;
  color: string;
}
