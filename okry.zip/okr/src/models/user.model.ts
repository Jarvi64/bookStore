import type { UserRole } from './enums';

/** User entity — represents a person in the organization */
export interface User {
  id: string;
  name: string;
  email: string;

  /** Avatar URL or fallback initials (e.g. "BM" for Benny Matteo) */
  avatar: string;

  role: UserRole;

  /** FK to Department */
  departmentId: string;

  /** FK to Team (null if not assigned to a team) */
  teamId: string | null;
}
