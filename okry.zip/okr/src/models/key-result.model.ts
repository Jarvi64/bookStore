import type { MetricType, ObjectiveStatus } from './enums';

/**
 * Key Result — a measurable leaf-node outcome under an objective.
 * Key results and sub-objectives share a weight pool that sums to 100.
 */
export interface KeyResult {
  id: string;
  title: string;
  description: string | null;

  /** FK to the parent Objective this KR belongs to */
  objectiveId: string;

  /** FK to User — single owner per key result */
  ownerId: string;

  /**
   * Weight within the parent objective's children pool.
   * All KRs + sub-objectives for one parent must sum to 100.
   */
  weight: number;

  /** Measurement configuration */
  metricType: MetricType;
  initialValue: number;
  targetValue: number;
  currentValue: number;

  /** 0–100, calculated as (currentValue - initialValue) / (targetValue - initialValue) * 100 */
  progress: number;

  startDate: string; // ISO date string
  endDate: string; // ISO date string
  status: ObjectiveStatus;

  createdAt: string; // ISO timestamp
  updatedAt: string; // ISO timestamp
}

/** DTO for creating a new key result */
export interface CreateKeyResultDTO {
  title: string;
  description?: string | null;
  objectiveId: string;
  ownerId: string;
  weight?: number; // auto-distributed if not provided
  metricType: MetricType;
  initialValue: number;
  targetValue: number;
  startDate: string;
  endDate: string;
}

/** DTO for updating an existing key result */
export interface UpdateKeyResultDTO {
  title?: string;
  description?: string | null;
  ownerId?: string;
  weight?: number;
  metricType?: MetricType;
  initialValue?: number;
  targetValue?: number;
  currentValue?: number;
  startDate?: string;
  endDate?: string;
  status?: ObjectiveStatus;
}
