/**
 * Barrel export for all models.
 * Import from '@/models' instead of individual files.
 */

export * from './enums';
export type {
  Objective,
  CreateObjectiveDTO,
  UpdateObjectiveDTO,
} from './objective.model';
export type {
  KeyResult,
  CreateKeyResultDTO,
  UpdateKeyResultDTO,
} from './key-result.model';
export type { User } from './user.model';
export type { Label, CreateLabelDTO } from './label.model';
export type { Department, Team } from './organization.model';
export type { Comment, CreateCommentDTO } from './comment.model';
