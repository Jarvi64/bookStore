/** Comment on an objective */
export interface Comment {
  id: string;
  objectiveId: string; // FK to Objective
  authorId: string; // FK to User
  content: string;
  createdAt: string; // ISO timestamp
}

/** DTO for creating a comment */
export interface CreateCommentDTO {
  objectiveId: string;
  content: string;
}
