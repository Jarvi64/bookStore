// ───────────────────────────────────────────────────────────────
// GanttPage.tsx — Single End-Date Milestone Timeline (Linear/Shadcn inspired)
// ───────────────────────────────────────────────────────────────
import { useCallback, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useAppStore } from "@/lib/store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  CalendarDays,
  Check,
  ChevronDown,
  CircleDollarSign,
  Flag,
  Info,
  Layers,
  Sparkles,
  Target,
} from "lucide-react";
import { format, addMonths, differenceInCalendarMonths } from "date-fns";

/* ================================================================
   LAYOUT & STYLE CONSTANTS
   ================================================================ */
const ROW_H = 44;
const HEADER_H = 50;
const TOTAL_MONTHS = 83; // T0 → T0+82

// Programme tab columns
const PROG_COLS = { name: 260, status: 100, date: 95, payment: 75 };
const PROG_LEFT_W = 530;

// Partner tab columns
const PART_COLS = { name: 335, status: 100, date: 95 };
const PART_LEFT_W = 530;

// ─── Status Palette ────────────────────────────────────────────
const S_DOT: Record<string, string> = {
  "Not Started": "#94a3b8",
  "In Progress": "#3b82f6",
  Completed: "#10b981",
  Delayed: "#f59e0b",
  "At Risk": "#ef4444",
};

const S_GLOW: Record<string, string> = {
  "Not Started": "rgba(148, 163, 184, 0.25)",
  "In Progress": "rgba(59, 130, 246, 0.3)",
  Completed: "rgba(16, 185, 129, 0.3)",
  Delayed: "rgba(245, 158, 11, 0.3)",
  "At Risk": "rgba(239, 68, 68, 0.35)",
};

const S_BADGE: Record<string, string> = {
  "Not Started":
    "bg-slate-100 text-slate-600 border-slate-200/80 dark:bg-slate-800/60 dark:text-slate-400 dark:border-slate-700",
  "In Progress":
    "bg-blue-50 text-blue-700 border-blue-200/80 dark:bg-blue-950/40 dark:text-blue-400 dark:border-blue-800",
  Completed:
    "bg-emerald-50 text-emerald-700 border-emerald-200/80 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800",
  Delayed:
    "bg-amber-50 text-amber-700 border-amber-200/80 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800",
  "At Risk":
    "bg-red-50 text-red-700 border-red-200/80 dark:bg-red-950/40 dark:text-red-400 dark:border-red-800",
};

/* ================================================================
   ROW TYPE
   ================================================================ */
type GanttRow = {
  id: string;
  name: string;
  type: "parent" | "sub" | "partner";
  partner?: string;
  status: string;
  endDate: string;
  endOffset: number;
  payment: number;
  parentId: string | null;
  raw: any;
};

/* ================================================================
   STATUS DOT
   ================================================================ */
function StatusDot({ status, size = 8 }: { status: string; size?: number }) {
  const c = S_DOT[status] || "#94a3b8";
  if (status === "Not Started")
    return (
      <span
        className="rounded-full inline-block shrink-0 border-[1.5px]"
        style={{ width: size, height: size, borderColor: c }}
      />
    );
  if (status === "Completed")
    return (
      <span
        className="rounded-full inline-flex items-center justify-center shrink-0"
        style={{ width: size, height: size, backgroundColor: c }}
      >
        <Check
          className="text-white"
          style={{ width: size * 0.65, height: size * 0.65 }}
          strokeWidth={3}
        />
      </span>
    );
  return (
    <span
      className="rounded-full inline-block shrink-0"
      style={{ width: size, height: size, backgroundColor: c }}
    />
  );
}

/* ================================================================
   MAIN COMPONENT
   ================================================================ */
export function GanttPage() {
  const { programmeConfig, milestones, programmeOrgNodes, partnerMilestones } =
    useAppStore();
  const t0Str = programmeConfig.t0Start || "2026-09-01";
  const t0 = useMemo(() => new Date(t0Str + "T00:00:00"), [t0Str]);

  /* ── State ──────────────────────────────────────────────────── */
  const [tab, setTab] = useState<"programme" | "partners">("programme");
  const [zoom, setZoom] = useState<"Months" | "Quarters" | "Years">(
    "Quarters"
  );
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const [hovered, setHovered] = useState<string | null>(null);
  const [detail, setDetail] = useState<any>(null);

  /* ── Scroll sync ────────────────────────────────────────────── */
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);
  const lock = useRef(false);
  const syncL = (e: React.UIEvent<HTMLDivElement>) => {
    if (lock.current) return;
    lock.current = true;
    if (rightRef.current)
      rightRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    lock.current = false;
  };
  const syncR = (e: React.UIEvent<HTMLDivElement>) => {
    if (lock.current) return;
    lock.current = true;
    if (leftRef.current)
      leftRef.current.scrollTop = (e.target as HTMLElement).scrollTop;
    lock.current = false;
  };

  /* ── Toggle helpers ─────────────────────────────────────────── */
  const toggle = (id: string) =>
    setCollapsed((p) => ({ ...p, [id]: !p[id] }));

  const switchTab = (v: string) => {
    setTab(v as "programme" | "partners");
    setHovered(null);
    if (leftRef.current) leftRef.current.scrollTop = 0;
    if (rightRef.current) {
      rightRef.current.scrollTop = 0;
      rightRef.current.scrollLeft = 0;
    }
  };

  /* ── Programme data ─────────────────────────────────────────── */
  const progItems = useMemo(
    () =>
      milestones
        .filter((m) => m.programmeid === programmeConfig.programmeid)
        .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd),
    [milestones, programmeConfig.programmeid]
  );
  const mains = useMemo(
    () => progItems.filter((m) => m.parentMilestoneId === null),
    [progItems]
  );
  const subs = useCallback(
    (pid: string) => progItems.filter((m) => m.parentMilestoneId === pid),
    [progItems]
  );

  const progRows = useMemo((): GanttRow[] => {
    const rows: GanttRow[] = [];
    mains.forEach((p) => {
      const children = subs(p.milestoneid);

      // Aggregate payment from children + parent
      const payment =
        children.reduce((s, c) => s + c.paymentPercentage, 0) +
        p.paymentPercentage;

      // Derive overall status
      let st = p.status;
      if (children.length > 0) {
        if (children.some((c) => c.status === "At Risk")) st = "At Risk";
        else if (children.some((c) => c.status === "Delayed")) st = "Delayed";
        else if (children.every((c) => c.status === "Completed"))
          st = "Completed";
        else if (
          children.some(
            (c) => c.status === "In Progress" || c.status === "Completed"
          )
        )
          st = "In Progress";
        else st = "Not Started";
      }

      rows.push({
        id: p.milestoneid,
        name: p.name,
        type: "parent",
        status: st,
        endDate: p.targetedcompletiondate,
        endOffset: p.t0OffsetEnd,
        payment,
        parentId: null,
        raw: p,
      });

      if (!collapsed[p.milestoneid]) {
        children.forEach((c) =>
          rows.push({
            id: c.milestoneid,
            name: c.name,
            type: "sub",
            status: c.status,
            endDate: c.targetedcompletiondate,
            endOffset: c.t0OffsetEnd,
            payment: c.paymentPercentage || 0,
            parentId: p.milestoneid,
            raw: c,
          })
        );
      }
    });
    return rows;
  }, [mains, subs, collapsed]);

  /* ── Partner data ───────────────────────────────────────────── */
  const partRows = useMemo((): GanttRow[] => {
    return partnerMilestones
      .filter((m) => m.programmeid === programmeConfig.programmeid)
      .map((m) => {
        const ed = new Date(`${m.targetedcompletiondate}T00:00:00`);
        return {
          id: m.partnermilestoneid,
          name: m.name,
          type: "partner" as const,
          partner: m.partner,
          status: m.status,
          endDate: m.targetedcompletiondate,
          endOffset: Math.min(
            82,
            Math.max(0, differenceInCalendarMonths(ed, t0))
          ),
          payment: 0,
          parentId: null,
          raw: m,
        };
      })
      .sort((a, b) => a.endOffset - b.endOffset);
  }, [partnerMilestones, programmeConfig.programmeid, t0]);

  const rows = tab === "programme" ? progRows : partRows;
  const showPayment = tab === "programme";
  const LEFT_W = showPayment ? PROG_LEFT_W : PART_LEFT_W;
  const COL_W = showPayment ? PROG_COLS : PART_COLS;

  /* ── Timeline calculations ──────────────────────────────────── */
  const mCols = useMemo(
    () =>
      Array.from({ length: TOTAL_MONTHS }, (_, i) => {
        const d = addMonths(t0, i);
        return {
          off: i,
          date: d,
          label: format(d, "MMM yy"),
          yr: format(d, "yyyy"),
          q: `Q${Math.floor(d.getMonth() / 3) + 1}`,
        };
      }),
    [t0]
  );

  const mw = useMemo(
    () => (zoom === "Months" ? 65 : zoom === "Quarters" ? 26 : 9),
    [zoom]
  );
  const TW = mCols.length * mw;
  const totalH = HEADER_H + rows.length * ROW_H + 8;

  const headers = useMemo(() => {
    const r: { label: string; sub: string; x: number; w: number }[] = [];
    if (zoom === "Months")
      mCols.forEach((c) =>
        r.push({
          label: c.label,
          sub: `T0+${c.off}`,
          x: c.off * mw,
          w: mw,
        })
      );
    else if (zoom === "Quarters")
      for (let i = 0; i < mCols.length; i += 3) {
        const c = mCols[i];
        r.push({
          label: `${c.q} '${c.yr.slice(2)}`,
          sub: `T0+${i}M`,
          x: i * mw,
          w: mw * 3,
        });
      }
    else
      for (let i = 0; i < mCols.length; i += 12) {
        const c = mCols[i];
        r.push({
          label: c.yr,
          sub: `Year ${Math.floor(i / 12) + 1}`,
          x: i * mw,
          w: mw * 12,
        });
      }
    return r;
  }, [zoom, mCols, mw]);

  // Gate lines — vertical dashed lines at milestone end dates
  const gates = useMemo(() => {
    if (tab !== "programme") return [];
    return mains.map((m) => ({
      name: m.name.match(/Milestone \d+/)?.[0] || m.name.slice(0, 11),
      off: m.t0OffsetEnd,
      x: (m.t0OffsetEnd + 0.5) * mw,
    }));
  }, [tab, mains, mw]);

  // Today marker
  const todayX = useMemo(() => {
    const now = new Date();
    if (now < t0) return -1;
    const mo = differenceInCalendarMonths(now, t0) + (now.getDate() - 1) / 30;
    return mo > 83 ? -1 : mo * mw;
  }, [t0, mw]);

  /* ── Payment stats ──────────────────────────────────────────── */
  const stats = useMemo(() => {
    const adv = 20;
    const compPay = progItems
      .filter(
        (m) => m.parentMilestoneId === null && m.status === "Completed"
      )
      .reduce((s, m) => s + m.paymentPercentage, 0);
    const released = adv + compPay;
    const gatesDone = mains.filter((m) => {
      const ch = subs(m.milestoneid);
      return ch.length > 0 && ch.every((c) => c.status === "Completed");
    }).length;
    return { released, pending: 100 - released, gatesDone };
  }, [progItems, mains, subs]);

  /* ── Helpers ────────────────────────────────────────────────── */
  const owner = (nid: string) =>
    programmeOrgNodes.find((n) => n.programmeorgnodeid === nid)?.displayname ||
    "—";

  const fmtD = (d: string) => {
    if (!d) return "—";
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "2-digit",
    });
  };

  const pointX = (off: number) => (off + 0.5) * mw;

  const scrollToToday = () => {
    if (todayX > 0 && rightRef.current)
      rightRef.current.scrollLeft = todayX - rightRef.current.clientWidth / 2;
  };

  const openDetail = (row: GanttRow) => {
    setDetail({
      ...row.raw,
      _type: row.type,
      _partner: row.partner,
      _payment: row.payment,
      _ownerName:
        row.type === "partner"
          ? row.partner || "Partner"
          : owner(row.raw.ownerorgnodeid || ""),
      _calEnd: fmtD(row.endDate),
      _deliverable:
        row.type === "partner"
          ? `${row.partner}: ${row.name}`
          : row.raw.deliverable,
    });
  };

  // SVG Diamond Path centered at (0,0)
  const diamondPath = (r: number) => `M 0 ${-r} L ${r} 0 L 0 ${r} L ${-r} 0 Z`;

  /* ================================================================
     RENDER
     ================================================================ */
  return (
    <div className="flex flex-col h-[calc(100vh-80px)] bg-background overflow-hidden">
      {/* ─── TOOLBAR ─── */}
      <div className="px-4 h-12 border-b flex items-center justify-between shrink-0 bg-card">
        {/* Left: Tabs */}
        <Tabs value={tab} onValueChange={switchTab}>
          <TabsList className="h-8 bg-muted/60">
            <TabsTrigger
              value="programme"
              className="text-xs px-3.5 h-7 data-[state=active]:shadow-sm font-medium"
            >
              Programme Milestones
            </TabsTrigger>
            <TabsTrigger
              value="partners"
              className="text-xs px-3.5 h-7 data-[state=active]:shadow-sm font-medium"
            >
              Partner Milestones
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Right: Controls + stats */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            className="h-7 text-xs px-2.5 font-medium"
            onClick={scrollToToday}
          >
            Today
          </Button>

          {/* Zoom */}
          <div className="flex items-center border rounded-md overflow-hidden h-7 bg-muted/30">
            {(
              [
                { k: "Months", l: "Month" },
                { k: "Quarters", l: "Quarter" },
                { k: "Years", l: "Year" },
              ] as const
            ).map((m) => (
              <button
                key={m.k}
                onClick={() => setZoom(m.k)}
                className={`px-2.5 text-[11px] font-medium cursor-pointer h-full transition-colors ${
                  zoom === m.k
                    ? "bg-primary text-primary-foreground font-semibold"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                {m.l}
              </button>
            ))}
          </div>

          {tab === "programme" && (
            <>
              <div className="h-5 w-px bg-border" />
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <CircleDollarSign className="size-3.5 text-blue-500 shrink-0" />
                <span>
                  Cashflow:{" "}
                  <strong className="text-foreground tabular-nums">
                    {stats.released}%
                  </strong>
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Target className="size-3.5 text-emerald-500 shrink-0" />
                <span>
                  Gates Done:{" "}
                  <strong className="text-foreground tabular-nums">
                    {stats.gatesDone}/{mains.length}
                  </strong>
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* ─── GANTT BODY ─── */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* ─── LEFT PANEL ─── */}
        <div
          className="shrink-0 border-r flex flex-col bg-card"
          style={{ width: LEFT_W }}
        >
          {/* Column Headers */}
          <div
            className="flex shrink-0 border-b bg-muted/30"
            style={{ height: HEADER_H }}
          >
            <div
              className="flex items-end pb-2 px-3.5 border-r"
              style={{ width: COL_W.name }}
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Milestone Deliverable
              </span>
            </div>
            <div
              className="flex items-end pb-2 px-2 border-r justify-center"
              style={{ width: COL_W.status }}
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Status
              </span>
            </div>
            <div
              className={`flex items-end pb-2 px-2 justify-center ${showPayment ? "border-r" : ""}`}
              style={{ width: COL_W.date }}
            >
              <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                Target Date
              </span>
            </div>
            {showPayment && (
              <div
                className="flex items-end pb-2 px-2 justify-center"
                style={{ width: (COL_W as typeof PROG_COLS).payment }}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Payment
                </span>
              </div>
            )}
          </div>

          {/* Data Rows */}
          <div
            ref={leftRef}
            onScroll={syncL}
            className="overflow-y-scroll flex-1 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]"
          >
            {rows.length === 0 && (
              <div className="flex flex-col items-center justify-center h-40 text-sm text-muted-foreground gap-1.5">
                <CalendarDays className="size-5 text-muted-foreground/40" />
                No milestones found.
              </div>
            )}
            {rows.map((r) => {
              const isP = r.type === "parent";
              const isPa = r.type === "partner";
              const isH = hovered === r.id;
              const isC = collapsed[r.id] === true;

              return (
                <div
                  key={r.id}
                  className={`flex items-center border-b transition-colors duration-100 cursor-pointer ${
                    isH
                      ? "bg-accent/60 dark:bg-accent/30"
                      : isP
                        ? "bg-muted/15 hover:bg-accent/30 font-semibold"
                        : isPa
                          ? "bg-violet-50/20 dark:bg-violet-950/10 hover:bg-violet-50/40 font-medium"
                          : "hover:bg-accent/20 font-medium"
                  }`}
                  style={{ height: ROW_H }}
                  onMouseEnter={() => setHovered(r.id)}
                  onMouseLeave={() => setHovered(null)}
                  onClick={() => openDetail(r)}
                >
                  {/* Name cell */}
                  <div
                    className="border-r flex items-center gap-1.5 px-3 h-full min-w-0"
                    style={{ width: COL_W.name }}
                  >
                    {isP ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggle(r.id);
                        }}
                        className="shrink-0 p-0.5 hover:bg-muted rounded transition-colors"
                      >
                        <ChevronDown
                          className={`size-3.5 text-muted-foreground transition-transform duration-200 ${isC ? "-rotate-90" : ""}`}
                        />
                      </button>
                    ) : (
                      <span className="shrink-0 w-4" />
                    )}

                    {isPa ? (
                      <Badge
                        variant="outline"
                        className={`shrink-0 text-[8px] px-1.5 py-0 font-bold ${
                          r.partner === "xAI"
                            ? "bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-950/50 dark:text-purple-300"
                            : "bg-pink-100 text-pink-800 border-pink-300 dark:bg-pink-950/50 dark:text-pink-300"
                        }`}
                      >
                        {r.partner}
                      </Badge>
                    ) : (
                      <StatusDot status={r.status} size={isP ? 9 : 7} />
                    )}

                    <span
                      className={`truncate text-xs ${isP ? "font-bold text-foreground" : "text-foreground/80"}`}
                      title={r.name}
                    >
                      {r.name}
                    </span>
                  </div>

                  {/* Status */}
                  <div
                    className="border-r flex items-center justify-center h-full"
                    style={{ width: COL_W.status }}
                  >
                    <Badge
                      variant="outline"
                      className={`${S_BADGE[r.status] || "bg-muted"} text-[9px] px-1.5 py-0 font-medium border`}
                    >
                      {r.status}
                    </Badge>
                  </div>

                  {/* Target Date */}
                  <div
                    className={`flex items-center justify-center h-full text-xs tabular-nums text-foreground/80 ${showPayment ? "border-r" : ""}`}
                    style={{ width: COL_W.date }}
                  >
                    {fmtD(r.endDate)}
                  </div>

                  {/* Payment % */}
                  {showPayment && (
                    <div
                      className="flex items-center justify-center h-full"
                      style={{
                        width: (COL_W as typeof PROG_COLS).payment,
                      }}
                    >
                      {r.payment > 0 ? (
                        <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded">
                          {r.payment}%
                        </span>
                      ) : (
                        <span className="text-muted-foreground/30 text-xs">
                          —
                        </span>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* ─── RIGHT PANEL — POINT-BASED TIMELINE ─── */}
        <div
          ref={rightRef}
          onScroll={syncR}
          className="flex-1 overflow-auto bg-background relative"
        >
          <div style={{ width: TW, minWidth: TW }}>
            <svg
              width={TW}
              height={totalH}
              className="select-none block"
              style={{ fontFamily: "inherit" }}
            >
              <defs>
                <filter
                  id="drop-shadow-node"
                  x="-50%"
                  y="-50%"
                  width="200%"
                  height="200%"
                >
                  <feDropShadow
                    dx="0"
                    dy="1"
                    stdDeviation="1.5"
                    floodOpacity="0.2"
                  />
                </filter>
              </defs>

              {/* ── Column grid lines + header labels ── */}
              {headers.map((h, i) => (
                <g key={i}>
                  <line
                    x1={h.x}
                    y1={0}
                    x2={h.x}
                    y2={totalH}
                    className="stroke-border/25 dark:stroke-border/10"
                    strokeWidth={0.5}
                  />
                  <text
                    x={h.x + h.w / 2}
                    y={20}
                    textAnchor="middle"
                    fontSize="10"
                    fontWeight="600"
                    className="fill-foreground/60"
                  >
                    {h.label}
                  </text>
                  <text
                    x={h.x + h.w / 2}
                    y={36}
                    textAnchor="middle"
                    fontSize="8.5"
                    fontWeight="500"
                    className="fill-muted-foreground/50"
                  >
                    {h.sub}
                  </text>
                </g>
              ))}

              {/* Header bottom border */}
              <line
                x1={0}
                y1={HEADER_H}
                x2={TW}
                y2={HEADER_H}
                className="stroke-border"
                strokeWidth={1}
              />

              {/* ── Row Backgrounds & Guides ── */}
              {rows.map((r, i) => {
                const y = HEADER_H + i * ROW_H;
                const isH = hovered === r.id;
                const cx = pointX(r.endOffset);
                const cy = y + ROW_H / 2;

                return (
                  <g key={`bg-${r.id}`}>
                    {/* Hover row highlight */}
                    {isH && (
                      <rect
                        x={0}
                        y={y}
                        width={TW}
                        height={ROW_H}
                        className="fill-accent/40 dark:fill-accent/20"
                      />
                    )}

                    {/* Horizontal divider */}
                    <line
                      x1={0}
                      y1={y + ROW_H}
                      x2={TW}
                      y2={y + ROW_H}
                      className="stroke-border/15"
                      strokeWidth={0.5}
                    />

                    {/* Dotted horizontal stem line connecting table row to point marker */}
                    <line
                      x1={0}
                      y1={cy}
                      x2={cx}
                      y2={cy}
                      stroke={
                        isH
                          ? S_DOT[r.status] || "#3b82f6"
                          : "var(--color-border)"
                      }
                      strokeWidth={isH ? 1.5 : 1}
                      strokeDasharray={isH ? "none" : "3,4"}
                      strokeOpacity={isH ? 0.8 : 0.4}
                    />
                  </g>
                );
              })}

              {/* ── Vertical Gate Dashed Lines ── */}
              {gates.map((g, idx) => (
                <g
                  key={`gate-${idx}`}
                  className="opacity-40 hover:opacity-90 transition-opacity"
                >
                  <line
                    x1={g.x}
                    y1={45}
                    x2={g.x}
                    y2={totalH}
                    stroke="#6366f1"
                    strokeWidth={1.2}
                    strokeDasharray="3,5"
                  />
                  <g transform={`translate(${g.x - 22}, 6)`}>
                    <rect
                      width="44"
                      height="34"
                      rx="6"
                      fill="#6366f1"
                      fillOpacity={0.9}
                    />
                    <text
                      x="22"
                      y="16"
                      textAnchor="middle"
                      fontSize="8"
                      fontWeight="bold"
                      fill="white"
                    >
                      {g.name}
                    </text>
                    <text
                      x="22"
                      y="26"
                      textAnchor="middle"
                      fontSize="7.5"
                      fontWeight="600"
                      fill="rgba(255, 255, 255, 0.75)"
                    >
                      T0+{g.off}M
                    </text>
                  </g>
                </g>
              ))}

              {/* ── Milestone Single-Point Markers ── */}
              {rows.map((r, i) => {
                const y = HEADER_H + i * ROW_H;
                const cx = pointX(r.endOffset);
                const cy = y + ROW_H / 2;
                const isP = r.type === "parent";
                const isPa = r.type === "partner";
                const isH = hovered === r.id;

                const color = isPa
                  ? r.partner === "xAI"
                    ? "#7c3aed"
                    : "#db2777"
                  : S_DOT[r.status] || "#94a3b8";

                const rSize = isP ? 7 : 5.5;

                return (
                  <g
                    key={`point-${r.id}`}
                    className="cursor-pointer"
                    onMouseEnter={() => setHovered(r.id)}
                    onMouseLeave={() => setHovered(null)}
                    onClick={() => openDetail(r)}
                  >
                    {/* Hover Glow Halo */}
                    {isH && (
                      <circle
                        cx={cx}
                        cy={cy}
                        r={rSize + 8}
                        fill={S_GLOW[r.status] || "rgba(99, 102, 241, 0.2)"}
                      />
                    )}

                    {/* Single Point Marker */}
                    {isP ? (
                      /* Parent Stage-Gate Diamond Pin */
                      <g transform={`translate(${cx}, ${cy})`}>
                        <path
                          d={diamondPath(rSize + 1)}
                          fill={color}
                          stroke="white"
                          strokeWidth={2}
                          filter="url(#drop-shadow-node)"
                          style={{
                            transform: isH ? "scale(1.3)" : "scale(1)",
                            transformOrigin: "center",
                            transition: "transform 0.15s ease",
                          }}
                        />
                        <path
                          d={diamondPath(rSize - 2)}
                          fill="white"
                          fillOpacity={0.3}
                        />
                      </g>
                    ) : isPa ? (
                      /* Partner Circle Pin */
                      <circle
                        cx={cx}
                        cy={cy}
                        r={rSize}
                        fill={color}
                        stroke="white"
                        strokeWidth={1.5}
                        filter="url(#drop-shadow-node)"
                        style={{
                          transform: isH ? "scale(1.3)" : "scale(1)",
                          transformOrigin: `${cx}px ${cy}px`,
                          transition: "transform 0.15s ease",
                        }}
                      />
                    ) : (
                      /* Sub-milestone Point Marker */
                      <g transform={`translate(${cx}, ${cy})`}>
                        <circle
                          r={rSize}
                          fill={color}
                          stroke="white"
                          strokeWidth={1.5}
                          filter="url(#drop-shadow-node)"
                          style={{
                            transform: isH ? "scale(1.3)" : "scale(1)",
                            transformOrigin: "center",
                            transition: "transform 0.15s ease",
                          }}
                        />
                        {r.status === "Completed" && (
                          <path
                            d="M-2,0 L-0.5,1.5 L2.5,-1.5"
                            stroke="white"
                            strokeWidth="1.2"
                            fill="none"
                          />
                        )}
                      </g>
                    )}

                    {/* Payment chip badge beside the marker */}
                    {r.payment > 0 && (
                      <g
                        transform={`translate(${cx + rSize + 6}, ${cy - 7})`}
                      >
                        <rect
                          width="28"
                          height="14"
                          rx="4"
                          fill="white"
                          stroke={color}
                          strokeWidth="1"
                          className="dark:fill-slate-900"
                        />
                        <text
                          x="14"
                          y="10"
                          textAnchor="middle"
                          fontSize="8"
                          fontWeight="bold"
                          fill={color}
                        >
                          {r.payment}%
                        </text>
                      </g>
                    )}

                    {/* Target Date / Name hint inline to the right of marker */}
                    <text
                      x={cx + rSize + (r.payment > 0 ? 38 : 10)}
                      y={cy + 1}
                      dominantBaseline="middle"
                      fontSize="9.5"
                      fontWeight={isP ? "700" : "500"}
                      className="fill-foreground/75"
                    >
                      {zoom === "Months"
                        ? r.name.length > 28
                          ? r.name.substring(0, 26) + "…"
                          : r.name
                        : `T0+${r.endOffset}M`}
                    </text>
                  </g>
                );
              })}

              {/* ── TODAY LINE ── */}
              {todayX > 0 && todayX < TW && (
                <g>
                  <line
                    x1={todayX}
                    y1={0}
                    x2={todayX}
                    y2={totalH}
                    stroke="#ef4444"
                    strokeWidth={5}
                    strokeOpacity={0.06}
                  />
                  <line
                    x1={todayX}
                    y1={0}
                    x2={todayX}
                    y2={totalH}
                    stroke="#ef4444"
                    strokeWidth={1.5}
                    strokeOpacity={0.7}
                  />
                  <rect
                    x={todayX - 18}
                    y={2}
                    width={36}
                    height={15}
                    rx="4"
                    fill="#ef4444"
                  />
                  <text
                    x={todayX}
                    y={12.5}
                    textAnchor="middle"
                    fontSize="8.5"
                    fontWeight="bold"
                    fill="white"
                  >
                    Today
                  </text>
                </g>
              )}
            </svg>
          </div>
        </div>
      </div>

      {/* ─── INTERACTIVE DETAIL DIALOG ─── */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent className="sm:max-w-[420px] p-0 overflow-hidden gap-0 rounded-2xl border-0 shadow-2xl">
          <div className="h-1.5 w-full bg-gradient-to-r from-violet-500 via-indigo-500 to-blue-500" />

          {detail && (
            <div className="p-5 pt-4">
              <DialogHeader className="mb-4 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="size-6 rounded-md bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
                    <Flag className="size-3 text-white" />
                  </div>
                  <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                    {detail._partner
                      ? `${detail._partner} Milestone`
                      : detail.parentMilestoneId
                        ? "Sub-Milestone"
                        : "Milestone Stage Gate"}
                  </span>
                  {detail.t0OffsetEnd != null && (
                    <span className="ml-auto text-[10px] font-mono font-bold text-primary bg-primary/10 px-2.5 py-0.5 rounded-md">
                      T0+{detail.t0OffsetEnd}M
                    </span>
                  )}
                </div>
                <DialogTitle className="text-base font-bold leading-snug tracking-tight">
                  {detail.name}
                </DialogTitle>
                <p className="text-[11px] text-muted-foreground">
                  Owner:{" "}
                  <span className="font-semibold text-foreground">
                    {detail._ownerName}
                  </span>
                </p>
              </DialogHeader>

              <div className="space-y-3">
                {/* Status */}
                <div className="flex items-center justify-between pb-2.5 border-b">
                  <span className="text-xs font-semibold text-muted-foreground">
                    Current Status
                  </span>
                  <Badge
                    variant="outline"
                    className={`${S_BADGE[detail.status]} text-xs px-2.5 py-0.5 border font-medium`}
                  >
                    {detail.status}
                  </Badge>
                </div>

                {/* Target Date */}
                <div className="rounded-xl border bg-muted/20 p-3 flex flex-col">
                  <span className="text-[9px] uppercase font-bold text-muted-foreground mb-1 tracking-wider flex items-center gap-1">
                    <CalendarDays className="size-3 text-primary/60" /> Target
                    Completion Date
                  </span>
                  <div className="flex items-baseline gap-2.5">
                    {detail.t0OffsetEnd != null && (
                      <span className="text-sm font-bold font-mono text-foreground">
                        T0+{detail.t0OffsetEnd}M
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground font-medium">
                      ({detail._calEnd})
                    </span>
                  </div>
                </div>

                {/* Deliverable */}
                {detail._deliverable && (
                  <div className="rounded-xl border bg-muted/20 p-3">
                    <span className="text-[9px] uppercase font-bold text-muted-foreground mb-1 block tracking-wider flex items-center gap-1">
                      <Layers className="size-3 text-primary/60" /> Deliverable
                    </span>
                    <p className="text-xs font-medium text-foreground leading-relaxed">
                      {detail._deliverable}
                    </p>
                  </div>
                )}

                {/* Payment */}
                {detail._payment > 0 && (
                  <div className="rounded-xl border border-blue-200/60 bg-blue-50/40 dark:bg-blue-950/20 dark:border-blue-900/40 p-3 flex items-center justify-between">
                    <span className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                      <CircleDollarSign className="size-3.5 text-blue-500" />{" "}
                      Payment Release
                    </span>
                    <Badge className="bg-blue-600 text-white font-bold border-0 text-xs">
                      {detail._payment}%
                    </Badge>
                  </div>
                )}

                {/* Remarks */}
                {detail.remarks && (
                  <div className="rounded-xl border bg-muted/10 p-3">
                    <span className="text-[9px] uppercase font-bold text-muted-foreground mb-1 block tracking-wider flex items-center gap-1">
                      <Info className="size-3 text-muted-foreground/50" />{" "}
                      Remarks
                    </span>
                    <p className="text-xs italic text-muted-foreground leading-relaxed">
                      "{detail.remarks}"
                    </p>
                  </div>
                )}

                <Button
                  asChild
                  className="w-full mt-1 h-9 text-xs font-semibold rounded-xl"
                  size="sm"
                >
                  <Link to="/milestones">
                    Open Milestones Control{" "}
                    <Sparkles className="size-3.5 ml-1.5 text-amber-300" />
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
