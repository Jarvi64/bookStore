import { useState, useMemo, useCallback, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import {
  useAppStore,
  WORK_AREAS,
  ENTRY_STATUSES,
  OVERALL_STATUSES,
} from "@/lib/store";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import {
  Plus,
  Trash2,
  Save,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  CalendarDays,
  User,
  TrendingUp,
  Eye,
  EyeOff,
  Link2,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Spinner } from "@/components/ui/spinner";
import { Separator } from "@/components/ui/separator";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";

// ── Helpers ─────────────────────────────────────────────────
function getISOWeek(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}

function getCurrentWeekKey(): string {
  const now = new Date();
  const week = getISOWeek(now);
  return `${now.getFullYear()}-W${String(week).padStart(2, "0")}`;
}

function getNextWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number);
  const next = w + 1;
  if (next > 52) return `${year + 1}-W01`;
  return `${year}-W${String(next).padStart(2, "0")}`;
}

function getPrevWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number);
  const prev = w - 1;
  if (prev < 1) return `${year - 1}-W52`;
  return `${year}-W${String(prev).padStart(2, "0")}`;
}

function weekKeyToDateRange(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number);
  const jan1 = new Date(year, 0, 1);
  const dayOfWeek = jan1.getDay() || 7;
  const monday = new Date(jan1);
  monday.setDate(jan1.getDate() + (w - 1) * 7 - dayOfWeek + 1);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const fmt = (d: Date) =>
    d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
  return `${fmt(monday)} – ${fmt(sunday)}, ${year}`;
}

// ── Work area styles ─────────────────────────────────────────
const WORK_AREA_COLORS: Record<string, { border: string; bg: string; text: string }> = {
  Design:        { border: "border-l-violet-500", bg: "bg-violet-500/8", text: "text-violet-700 dark:text-violet-400" },
  Development:   { border: "border-l-blue-500", bg: "bg-blue-500/8", text: "text-blue-700 dark:text-blue-400" },
  Testing:       { border: "border-l-emerald-500", bg: "bg-emerald-500/8", text: "text-emerald-700 dark:text-emerald-400" },
  Review:        { border: "border-l-amber-500", bg: "bg-amber-500/8", text: "text-amber-700 dark:text-amber-400" },
  Documentation: { border: "border-l-cyan-500", bg: "bg-cyan-500/8", text: "text-cyan-700 dark:text-cyan-400" },
  Meetings:      { border: "border-l-pink-500", bg: "bg-pink-500/8", text: "text-pink-700 dark:text-pink-400" },
  Other:         { border: "border-l-gray-500", bg: "bg-gray-500/8", text: "text-gray-700 dark:text-gray-400" },
};

const STATUS_STYLES: Record<string, { icon: React.ReactNode; color: string }> = {
  Completed:     { icon: <CheckCircle2 className="size-3.5" />, color: "text-emerald-600 dark:text-emerald-400" },
  "In Progress": { icon: <Clock className="size-3.5" />, color: "text-blue-600 dark:text-blue-400" },
  Blocked:       { icon: <XCircle className="size-3.5" />, color: "text-red-600 dark:text-red-400" },
};

const OVERALL_STATUS_STYLES: Record<string, { bg: string; text: string; icon: React.ReactNode }> = {
  "On Track":        { bg: "bg-emerald-100 dark:bg-emerald-900/30", text: "text-emerald-700 dark:text-emerald-400", icon: <CheckCircle2 className="size-3.5" /> },
  "Needs Attention": { bg: "bg-amber-100 dark:bg-amber-900/30", text: "text-amber-700 dark:text-amber-400", icon: <AlertTriangle className="size-3.5" /> },
  Blocked:           { bg: "bg-red-100 dark:bg-red-900/30", text: "text-red-700 dark:text-red-400", icon: <XCircle className="size-3.5" /> },
};

// ── Local entry type for editing ────────────────────────────
type LocalEntry = {
  tempId: string;
  workarea: string;
  status: string;
  description: string;
  hoursSpent: number;
  milestoneid: string | null; // linked milestone/deliverable
};

let tempCounter = 0;
const nextTempId = () => `tmp_${++tempCounter}`;

// ═══════════════════════════════════════════════════════════════
// ROOT COMPONENT
// ═══════════════════════════════════════════════════════════════
export function TeamWeeklyStatus() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid);
  const { programmeOrgNodes, teamWeeklyStatuses } = useAppStore();

  // Get deliverables org members
  const deliverableMembers = useMemo(
    () =>
      programmeOrgNodes
        .filter((n) => n.programmeid === programmeId && n.orgtype === "deliverables" && n.active === "Yes")
        .sort((a, b) => a.sortorder - b.sortorder),
    [programmeOrgNodes, programmeId],
  );

  // Person selection via URL param or combobox
  const personParam = searchParams.get("person");
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(
    personParam && deliverableMembers.some((m) => m.programmeorgnodeid === personParam)
      ? personParam
      : deliverableMembers[0]?.programmeorgnodeid ?? null,
  );

  // Sync with URL
  useEffect(() => {
    if (personParam && deliverableMembers.some((m) => m.programmeorgnodeid === personParam)) {
      setSelectedPersonId(personParam);
    }
  }, [personParam, deliverableMembers]);

  const selectedPerson = deliverableMembers.find((m) => m.programmeorgnodeid === selectedPersonId);

  const handlePersonChange = (id: string | null) => {
    if (id) {
      setSelectedPersonId(id);
      setSearchParams({ person: id });
    }
  };

  // Person combobox items
  const personItems = deliverableMembers.map((m) => m.programmeorgnodeid);

  // Initials helper
  const getInitials = (name: string) =>
    name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .substring(0, 2)
      .toUpperCase();

  return (
    <div className="flex flex-col gap-6 pt-4 pb-12">
      {/* ── Page Header ── */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Team Weekly Status</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Track individual weekly work progress for each deliverables team member.
        </p>
      </div>

      {/* ── Person Selector Card ── */}
      <Card className="border-primary/10 bg-gradient-to-r from-primary/[0.03] to-transparent overflow-hidden">
        <CardContent className="pt-5 pb-4 px-5">
          <div className="flex items-center gap-5">
            {/* Avatar */}
            {selectedPerson && (
              <motion.div
                key={selectedPerson.programmeorgnodeid}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className="size-14 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-primary-foreground font-bold text-lg shadow-lg shrink-0"
              >
                {getInitials(selectedPerson.displayname)}
              </motion.div>
            )}

            <div className="flex-1 min-w-0">
              <Label className="text-xs text-muted-foreground uppercase tracking-wider mb-1.5 block">
                Select Team Member
              </Label>
              <Combobox
                value={selectedPersonId}
                onValueChange={handlePersonChange}
                items={personItems}
              >
                <ComboboxInput placeholder="Search by name or role..." className="h-10" />
                <ComboboxContent>
                  <ComboboxEmpty>No team member found.</ComboboxEmpty>
                  <ComboboxList>
                    {(id: string) => {
                      const person = deliverableMembers.find((m) => m.programmeorgnodeid === id);
                      if (!person) return null;
                      return (
                        <ComboboxItem key={id} value={id} keywords={[person.displayname, person.title]}>
                          <div className="flex items-center gap-3 py-0.5">
                            <div className="size-7 rounded-full bg-secondary flex items-center justify-center text-xs font-semibold shrink-0">
                              {getInitials(person.displayname)}
                            </div>
                            <div className="min-w-0">
                              <div className="text-sm font-medium truncate">{person.displayname}</div>
                              <div className="text-xs text-muted-foreground truncate">{person.title}</div>
                            </div>
                          </div>
                        </ComboboxItem>
                      );
                    }}
                  </ComboboxList>
                </ComboboxContent>
              </Combobox>
            </div>

            {/* Quick info */}
            {selectedPerson && (
              <motion.div
                key={selectedPerson.programmeorgnodeid + "-info"}
                initial={{ x: 10, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="hidden sm:flex flex-col items-end text-right"
              >
                <span className="text-sm font-semibold">{selectedPerson.displayname}</span>
                <span className="text-xs text-muted-foreground">{selectedPerson.title}</span>
                <Badge variant="outline" className="mt-1 text-[10px]">
                  {teamWeeklyStatuses.filter((s) => s.orgnodeid === selectedPersonId).length} weeks tracked
                </Badge>
              </motion.div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* ── Main Content ── */}
      {selectedPersonId && selectedPerson ? (
        <WeeklyEditor
          programmeId={programmeId}
          personId={selectedPersonId}
          personName={selectedPerson.displayname}
        />
      ) : (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <User className="size-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Select a team member to view or edit their weekly status.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// WEEKLY EDITOR — week nav + entries + last-week ref + timeline
// ═══════════════════════════════════════════════════════════════
function WeeklyEditor({
  programmeId,
  personId,
  personName,
}: {
  programmeId: string;
  personId: string;
  personName: string;
}) {
  const {
    milestones,
    teamWeeklyStatuses,
    teamWeeklyEntries,
    addTeamWeeklyStatus,
    updateTeamWeeklyStatus,
    bulkSetTeamWeeklyEntries,
  } = useAppStore();

  // All statuses for this person
  const personStatuses = useMemo(
    () =>
      teamWeeklyStatuses
        .filter((s) => s.programmeid === programmeId && s.orgnodeid === personId)
        .sort((a, b) => a.weekkey.localeCompare(b.weekkey)),
    [teamWeeklyStatuses, programmeId, personId],
  );

  // Sub-milestones/deliverables for this programme
  const milestoneItems = useMemo(
    () => milestones.filter((m) => m.programmeid === programmeId && m.parentMilestoneId !== null),
    [milestones, programmeId],
  );

  // Week navigation
  const currentWeek = getCurrentWeekKey();
  const [selectedWeek, setSelectedWeek] = useState(currentWeek);
  const [localEntries, setLocalEntries] = useState<LocalEntry[]>([]);
  const [summary, setSummary] = useState("");
  const [overallStatus, setOverallStatus] = useState("On Track");
  const [isSaving, setIsSaving] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [showLastWeek, setShowLastWeek] = useState(true);

  // Find existing status for selected week
  const selectedStatus = personStatuses.find((s) => s.weekkey === selectedWeek);
  const prevWeekKey = getPrevWeekKey(selectedWeek);
  const prevStatus = personStatuses.find((s) => s.weekkey === prevWeekKey);
  const prevEntries = prevStatus
    ? teamWeeklyEntries.filter((e) => e.teamweeklystatusid === prevStatus.teamweeklystatusid)
    : [];

  // Reset when selectedWeek or personId changes
  useEffect(() => {
    if (selectedStatus) {
      const entries = teamWeeklyEntries.filter(
        (e) => e.teamweeklystatusid === selectedStatus.teamweeklystatusid,
      );
      setLocalEntries(
        entries.map((e) => ({
          tempId: nextTempId(),
          workarea: e.workarea,
          status: e.status,
          description: e.description,
          hoursSpent: e.hoursSpent,
          milestoneid: e.milestoneid || null,
        })),
      );
      setSummary(selectedStatus.summary);
      setOverallStatus(selectedStatus.overallstatus);
    } else {
      // New week — start empty with one entry
      setLocalEntries([
        { tempId: nextTempId(), workarea: "Development", status: "In Progress", description: "", hoursSpent: 0, milestoneid: null },
      ]);
      setSummary("");
      setOverallStatus("On Track");
    }
    setIsDirty(false);
  }, [selectedWeek, personId, selectedStatus?.teamweeklystatusid]);

  const addEntry = useCallback(() => {
    setLocalEntries((prev) => [
      ...prev,
      { tempId: nextTempId(), workarea: "Development", status: "In Progress", description: "", hoursSpent: 0, milestoneid: null },
    ]);
    setIsDirty(true);
  }, []);

  const removeEntry = useCallback((tempId: string) => {
    setLocalEntries((prev) => prev.filter((e) => e.tempId !== tempId));
    setIsDirty(true);
  }, []);

  const updateEntry = useCallback((tempId: string, field: keyof LocalEntry, value: string | number | null) => {
    setLocalEntries((prev) =>
      prev.map((e) => (e.tempId === tempId ? { ...e, [field]: value } : e)),
    );
    setIsDirty(true);
  }, []);

  const totalHours = localEntries.reduce((s, e) => s + (e.hoursSpent || 0), 0);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await new Promise((r) => setTimeout(r, 500));
      const validEntries = localEntries.filter((e) => e.description.trim());

      if (selectedStatus) {
        updateTeamWeeklyStatus(selectedStatus.teamweeklystatusid, {
          summary,
          overallstatus: overallStatus,
          submittedon: new Date().toISOString(),
        });
        bulkSetTeamWeeklyEntries(
          selectedStatus.teamweeklystatusid,
          validEntries.map((e) => ({
            teamweeklystatusid: selectedStatus.teamweeklystatusid,
            workarea: e.workarea,
            status: e.status,
            description: e.description.trim(),
            hoursSpent: e.hoursSpent,
            milestoneid: e.milestoneid || null,
          })),
        );
      } else {
        addTeamWeeklyStatus({
          programmeid: programmeId,
          orgnodeid: personId,
          weekkey: selectedWeek,
          submittedon: new Date().toISOString(),
          overallstatus: overallStatus,
          summary,
        });
        // Get the newly created status and add entries
        setTimeout(() => {
          const latest = useAppStore.getState().teamWeeklyStatuses
            .filter((s) => s.programmeid === programmeId && s.orgnodeid === personId && s.weekkey === selectedWeek)
            .pop();
          if (latest) {
            bulkSetTeamWeeklyEntries(
              latest.teamweeklystatusid,
              validEntries.map((e) => ({
                teamweeklystatusid: latest.teamweeklystatusid,
                workarea: e.workarea,
                status: e.status,
                description: e.description.trim(),
                hoursSpent: e.hoursSpent,
                milestoneid: e.milestoneid || null,
              })),
            );
          }
        }, 50);
      }

      setIsDirty(false);
      toast.success(`Week ${selectedWeek} saved for ${personName}`);
    } catch {
      toast.error("Something went wrong");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-6">
      {/* ── Week Navigator ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            className="size-8 rounded-full"
            onClick={() => setSelectedWeek(getPrevWeekKey(selectedWeek))}
          >
            <ChevronLeft className="size-4" />
          </Button>
          <motion.div
            key={selectedWeek}
            initial={{ y: 6, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
            className="flex flex-col items-center px-4"
          >
            <span className="text-lg font-bold tracking-tight">{selectedWeek}</span>
            <span className="text-xs text-muted-foreground">{weekKeyToDateRange(selectedWeek)}</span>
          </motion.div>
          <Button
            variant="outline"
            size="icon"
            className="size-8 rounded-full"
            onClick={() => setSelectedWeek(getNextWeekKey(selectedWeek))}
          >
            <ChevronRight className="size-4" />
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowLastWeek(!showLastWeek)}
            className="text-xs"
          >
            {showLastWeek ? <EyeOff className="size-3.5 mr-1.5" /> : <Eye className="size-3.5 mr-1.5" />}
            Last Week
          </Button>
          {selectedWeek !== currentWeek && (
            <Button variant="outline" size="sm" onClick={() => setSelectedWeek(currentWeek)}>
              <CalendarDays className="size-3.5 mr-1.5" />
              This Week
            </Button>
          )}
          <Button onClick={handleSave} disabled={isSaving} size="sm">
            {isSaving ? <Spinner data-icon="inline-start" /> : <Save className="size-3.5 mr-1.5" />}
            Save
          </Button>
        </div>
      </div>

      {/* ── Summary & Status Row ── */}
      <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto] gap-4">
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground uppercase tracking-wider">Week Summary</Label>
          <Textarea
            value={summary}
            onChange={(e) => { setSummary(e.target.value); setIsDirty(true); }}
            placeholder="Brief summary of the week's work…"
            className="min-h-[60px] resize-none"
          />
        </div>
        <div className="space-y-1.5 min-w-[180px]">
          <Label className="text-xs text-muted-foreground uppercase tracking-wider">Overall Status</Label>
          <div className="flex flex-col gap-1.5">
            {OVERALL_STATUSES.map((s) => {
              const style = OVERALL_STATUS_STYLES[s];
              const isSelected = overallStatus === s;
              return (
                <button
                  key={s}
                  onClick={() => { setOverallStatus(s); setIsDirty(true); }}
                  className={`
                    flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border
                    ${isSelected
                      ? `${style.bg} ${style.text} border-current/20 shadow-sm`
                      : "bg-card border-transparent hover:bg-muted text-muted-foreground"
                    }
                  `}
                >
                  {style.icon}
                  {s}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ── Entries + Last Week Reference ── */}
      <div className={`grid gap-6 ${showLastWeek && prevEntries.length > 0 ? "grid-cols-1 lg:grid-cols-[1fr_320px]" : "grid-cols-1"}`}>
        {/* Current Week Entries */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-semibold">Work Entries</h4>
              <Badge variant="outline" className="text-[10px] font-mono">
                {totalHours}h total
              </Badge>
            </div>
            <Button variant="outline" size="sm" onClick={addEntry}>
              <Plus className="size-3.5 mr-1.5" />
              Add Entry
            </Button>
          </div>

          <AnimatePresence mode="popLayout">
            {localEntries.map((entry) => {
              const areaStyle = WORK_AREA_COLORS[entry.workarea] || WORK_AREA_COLORS.Other;
              return (
                <motion.div
                  key={entry.tempId}
                  layout
                  initial={{ opacity: 0, y: 12, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95, y: -8 }}
                  transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  className={`rounded-lg border-l-[3px] ${areaStyle.border} bg-card border border-border/60 p-4 shadow-sm hover:shadow-md transition-shadow`}
                >
                  <div className="grid grid-cols-[1fr_1fr_auto] gap-3 mb-3">
                    {/* Work Area */}
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground uppercase">Area</Label>
                      <Combobox
                        value={entry.workarea}
                        onValueChange={(v: string | null) => updateEntry(entry.tempId, "workarea", v ?? "Other")}
                        items={[...WORK_AREAS]}
                      >
                        <ComboboxInput placeholder="Area" className="h-8 text-xs" />
                        <ComboboxContent>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                <span className={`size-2 rounded-full ${WORK_AREA_COLORS[item]?.border.replace("border-l-", "bg-")} mr-2 inline-block`} />
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    </div>

                    {/* Status */}
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground uppercase">Status</Label>
                      <Combobox
                        value={entry.status}
                        onValueChange={(v: string | null) => updateEntry(entry.tempId, "status", v ?? "In Progress")}
                        items={[...ENTRY_STATUSES]}
                      >
                        <ComboboxInput placeholder="Status" className="h-8 text-xs" />
                        <ComboboxContent>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                <span className={`mr-1.5 ${STATUS_STYLES[item]?.color}`}>{STATUS_STYLES[item]?.icon}</span>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    </div>

                    {/* Hours Spent */}
                    <div className="flex items-end gap-1.5">
                      <div className="space-y-1">
                        <Label className="text-[10px] text-muted-foreground uppercase">Hrs</Label>
                        <Input
                          type="number"
                          min={0}
                          max={60}
                          value={entry.hoursSpent || ""}
                          onChange={(e) => updateEntry(entry.tempId, "hoursSpent", Number(e.target.value))}
                          className="h-8 w-16 text-xs text-center"
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 text-destructive hover:bg-destructive/10 shrink-0"
                        onClick={() => removeEntry(entry.tempId)}
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </div>

                  {/* Linked Milestone / Deliverable */}
                  <div className="mb-3">
                    <Label className="text-[10px] text-muted-foreground uppercase mb-1 block">Linked Deliverable / Milestone</Label>
                    <Combobox
                      value={entry.milestoneid}
                      onValueChange={(v: string | null) => updateEntry(entry.tempId, "milestoneid", v)}
                      items={milestoneItems.map((m) => m.milestoneid)}
                    >
                      <ComboboxInput
                        placeholder="Search & link contractual deliverable..."
                        className="h-8 text-xs w-full"
                        value={milestoneItems.find((m) => m.milestoneid === entry.milestoneid)?.name || ""}
                      />
                      <ComboboxContent>
                        <ComboboxEmpty>No deliverables found.</ComboboxEmpty>
                        <ComboboxList>
                          {(id: string) => {
                            const m = milestoneItems.find((item) => item.milestoneid === id);
                            if (!m) return null;
                            const isAssigned = m.assigneeNodeIds?.includes(personId);
                            return (
                              <ComboboxItem key={id} value={id}>
                                <div className="flex items-center justify-between w-full text-xs">
                                  <span className="truncate">{m.name}</span>
                                  {isAssigned && (
                                    <Badge variant="secondary" className="ml-2 text-[9px] shrink-0 bg-amber-500/10 text-amber-600 dark:text-amber-400 py-0">
                                      ⭐ Assigned
                                    </Badge>
                                  )}
                                </div>
                              </ComboboxItem>
                            );
                          }}
                        </ComboboxList>
                      </ComboboxContent>
                    </Combobox>
                  </div>

                  {/* Description */}
                  <Textarea
                    value={entry.description}
                    onChange={(e) => updateEntry(entry.tempId, "description", e.target.value)}
                    placeholder="Describe the work done..."
                    className="min-h-[48px] resize-none text-sm"
                  />
                </motion.div>
              );
            })}
          </AnimatePresence>

          {localEntries.length === 0 && (
            <div className="rounded-lg border border-dashed py-10 text-center text-muted-foreground text-sm">
              No entries yet. Click "Add Entry" to start tracking.
            </div>
          )}
        </div>

        {/* ── Last Week Reference Panel ── */}
        {showLastWeek && prevEntries.length > 0 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="space-y-3"
          >
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-semibold text-muted-foreground">Last Week</h4>
              <Badge variant="outline" className="text-[10px]">{prevWeekKey}</Badge>
            </div>
            {prevStatus && (
              <div className={`rounded-lg px-3 py-2 text-xs ${OVERALL_STATUS_STYLES[prevStatus.overallstatus]?.bg || "bg-muted"} ${OVERALL_STATUS_STYLES[prevStatus.overallstatus]?.text || ""}`}>
                <div className="flex items-center gap-1.5 font-medium mb-1">
                  {OVERALL_STATUS_STYLES[prevStatus.overallstatus]?.icon}
                  {prevStatus.overallstatus}
                </div>
                <p className="text-[11px] opacity-80">{prevStatus.summary}</p>
              </div>
            )}
            <div className="space-y-2">
              {prevEntries.map((entry) => {
                const areaStyle = WORK_AREA_COLORS[entry.workarea] || WORK_AREA_COLORS.Other;
                const statusStyle = STATUS_STYLES[entry.status];
                const linkedMilestone = milestoneItems.find(m => m.milestoneid === entry.milestoneid);
                return (
                  <div
                    key={entry.teamweeklyentryid}
                    className={`rounded-md border-l-2 ${areaStyle.border} bg-muted/50 px-3 py-2 text-xs`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Badge variant="outline" className={`text-[9px] ${areaStyle.text}`}>
                        {entry.workarea}
                      </Badge>
                      <span className={`flex items-center gap-1 text-[10px] font-medium ${statusStyle?.color || ""}`}>
                        {statusStyle?.icon}
                        {entry.status}
                      </span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{entry.description}</p>
                    {linkedMilestone && (
                      <div className="text-[10px] text-primary/85 mt-1 font-semibold flex items-center gap-1">
                        <Link2 className="size-3" />
                        <span className="truncate" title={linkedMilestone.name}>{linkedMilestone.name}</span>
                      </div>
                    )}
                    {entry.hoursSpent > 0 && (
                      <span className="text-[10px] text-muted-foreground/60 mt-1 block">{entry.hoursSpent}h</span>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </div>

      <Separator />

      {/* ── Timeline History ── */}
      <WeeklyTimeline
        personId={personId}
        programmeId={programmeId}
        personStatuses={personStatuses}
        currentSelectedWeek={selectedWeek}
        onSelectWeek={setSelectedWeek}
        milestoneItems={milestoneItems}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// TIMELINE — animated vertical timeline of all past weeks
// ═══════════════════════════════════════════════════════════════
function WeeklyTimeline({
  personId,
  programmeId,
  personStatuses,
  currentSelectedWeek,
  onSelectWeek,
  milestoneItems,
}: {
  personId: string;
  programmeId: string;
  personStatuses: ReturnType<typeof useAppStore.getState>["teamWeeklyStatuses"];
  currentSelectedWeek: string;
  onSelectWeek: (week: string) => void;
  milestoneItems: ReturnType<typeof useAppStore.getState>["milestones"];
}) {
  const { teamWeeklyEntries } = useAppStore();
  const [expandedWeeks, setExpandedWeeks] = useState<Set<string>>(new Set());

  const toggleWeek = (week: string) => {
    setExpandedWeeks((prev) => {
      const next = new Set(prev);
      if (next.has(week)) next.delete(week);
      else next.add(week);
      return next;
    });
  };

  // Group statuses by year-month for sticky headers
  const groupedByMonth = useMemo(() => {
    const groups: { label: string; statuses: typeof personStatuses }[] = [];
    const map = new Map<string, typeof personStatuses>();

    for (const s of [...personStatuses].reverse()) {
      const [yearStr] = s.weekkey.split("-W");
      const weekNum = parseInt(s.weekkey.split("-W")[1]);
      // Approximate month from week number
      const approxMonth = Math.min(11, Math.floor(((weekNum - 1) * 7) / 30));
      const monthLabel = new Date(parseInt(yearStr), approxMonth, 1).toLocaleDateString("en-GB", {
        month: "long",
        year: "numeric",
      });

      if (!map.has(monthLabel)) {
        map.set(monthLabel, []);
      }
      map.get(monthLabel)!.push(s);
    }

    for (const [label, statuses] of map) {
      groups.push({ label, statuses });
    }
    return groups;
  }, [personStatuses]);

  if (personStatuses.length === 0) {
    return (
      <div className="text-center py-10 text-muted-foreground text-sm">
        <TrendingUp className="size-8 mx-auto mb-2 opacity-30" />
        <p>No weekly updates recorded yet. Save this week to start building the timeline.</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <h4 className="text-sm font-semibold flex items-center gap-2">
        <TrendingUp className="size-4" />
        Activity Timeline
      </h4>
      <p className="text-xs text-muted-foreground mb-4">
        Click any week to expand details or navigate to edit.
      </p>

      <div className="relative pl-6">
        {/* Vertical line */}
        <div className="absolute left-[11px] top-0 bottom-0 w-px bg-border" />

        {groupedByMonth.map((group) => (
          <div key={group.label} className="mb-6">
            {/* Month label */}
            <div className="sticky top-0 z-10 -ml-6 mb-3">
              <span className="inline-flex items-center gap-1.5 bg-background px-3 py-1 text-xs font-bold text-muted-foreground uppercase tracking-wider border rounded-full shadow-sm">
                <CalendarDays className="size-3" />
                {group.label}
              </span>
            </div>

            <div className="space-y-3">
              <AnimatePresence>
                {group.statuses.map((status, idx) => {
                  const isExpanded = expandedWeeks.has(status.weekkey);
                  const isCurrentSelection = status.weekkey === currentSelectedWeek;
                  const overallStyle = OVERALL_STATUS_STYLES[status.overallstatus] || OVERALL_STATUS_STYLES["On Track"];
                  const entries = teamWeeklyEntries.filter(
                    (e) => e.teamweeklystatusid === status.teamweeklystatusid,
                  );
                  const totalHours = entries.reduce((s, e) => s + e.hoursSpent, 0);

                  return (
                    <motion.div
                      key={status.teamweeklystatusid}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05, type: "spring", stiffness: 300, damping: 25 }}
                      className="relative"
                    >
                      {/* Timeline dot */}
                      <div
                        className={`
                          absolute -left-6 top-3 size-[10px] rounded-full border-2 z-10
                          ${isCurrentSelection
                            ? "bg-primary border-primary ring-4 ring-primary/20"
                            : `${overallStyle.bg} border-current ${overallStyle.text}`
                          }
                        `}
                      />

                      {/* Week card */}
                      <button
                        onClick={() => toggleWeek(status.weekkey)}
                        className={`
                          w-full text-left rounded-lg border p-3 transition-all hover:shadow-md
                          ${isCurrentSelection
                            ? "border-primary/30 bg-primary/[0.03] shadow-sm"
                            : "bg-card hover:border-border/80"
                          }
                        `}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold">{status.weekkey}</span>
                            <Badge className={`text-[10px] ${overallStyle.bg} ${overallStyle.text} border-0`}>
                              {overallStyle.icon}
                              <span className="ml-1">{status.overallstatus}</span>
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-muted-foreground font-mono">{totalHours}h</span>
                            <Badge variant="outline" className="text-[10px]">
                              {entries.length} {entries.length === 1 ? "entry" : "entries"}
                            </Badge>
                            <motion.div
                              animate={{ rotate: isExpanded ? 90 : 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <ChevronRight className="size-3.5 text-muted-foreground" />
                            </motion.div>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{status.summary}</p>
                      </button>

                      {/* Expanded entries */}
                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ type: "spring", stiffness: 300, damping: 30 }}
                            className="overflow-hidden"
                          >
                            <div className="pt-2 pl-4 space-y-2">
                              {entries.map((entry) => {
                                const areaStyle = WORK_AREA_COLORS[entry.workarea] || WORK_AREA_COLORS.Other;
                                const statusStyle = STATUS_STYLES[entry.status];
                                const linkedMilestone = milestoneItems.find(m => m.milestoneid === entry.milestoneid);
                                return (
                                  <div
                                    key={entry.teamweeklyentryid}
                                    className={`rounded-md border-l-2 ${areaStyle.border} bg-muted/40 px-3 py-2 text-xs`}
                                  >
                                    <div className="flex items-center justify-between mb-1">
                                      <div className="flex items-center gap-2">
                                        <Badge variant="outline" className={`text-[9px] ${areaStyle.text}`}>
                                          {entry.workarea}
                                        </Badge>
                                        <span className={`flex items-center gap-1 text-[10px] font-medium ${statusStyle?.color || ""}`}>
                                          {statusStyle?.icon}
                                          {entry.status}
                                        </span>
                                      </div>
                                      <span className="text-[10px] text-muted-foreground font-mono">{entry.hoursSpent}h</span>
                                    </div>
                                    <p className="text-muted-foreground leading-relaxed">{entry.description}</p>
                                    {linkedMilestone && (
                                      <div className="text-[10px] text-primary/85 mt-1 font-semibold flex items-center gap-1">
                                        <Link2 className="size-3" />
                                        <span className="truncate" title={linkedMilestone.name}>{linkedMilestone.name}</span>
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-xs"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onSelectWeek(status.weekkey);
                                }}
                              >
                                Edit this week →
                              </Button>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
