/**
 * CV Screening Dashboard - Schema Definition
 * Single source of truth for column names and candidate data structure
 * 
 * IMPORTANT: Column names must match exactly with the Excel output from Power Automate
 */

const SCHEMA = (() => {
    /**
     * Standardized column names - EXACTLY as they appear in Excel
     * These are the ONLY valid column names. No flexible matching.
     */
    const COLUMNS = Object.freeze({
        // Identity & Contact
        CANDIDATE_NAME: 'candidate_name',
        EMAIL: 'email',
        PHONE: 'phone',
        RESUME_LINK: 'resume_link',

        // Experience
        YEARS_OF_EXPERIENCE: 'years_of_experience',
        RELEVANT_EXPERIENCE_YEARS: 'relevant_experience_years',

        // Employment Status
        EMPLOYMENT_STATUS: 'employment_status',
        EMPLOYMENT_GAPS: 'employment_gaps',
        OVERQUALIFIED: 'overqualified',

        // Match Indicators
        EDUCATION_MATCH: 'education_match',
        DOMAIN_MATCH: 'domain_match',

        // Current Position
        CURRENT_COMPANY: 'current_company',
        CURRENT_DESIGNATION: 'current_designation',

        // Work History
        PREVIOUS_COMPANIES: 'previous_companies',
        PREVIOUS_ROLES: 'previous_roles',
        CAREER_TIMELINE: 'career_timeline',

        // Education
        HIGHEST_EDUCATION: 'highest_education',
        EDUCATION_TIMELINE: 'education_timeline',
        CERTIFICATIONS: 'certifications',

        // Languages & Skills
        LANGUAGES: 'languages',
        SKILLS: 'skills',
        CRITICAL_SKILLS_MATCH: 'critical_skills_match',
        NICE_TO_HAVE_SKILLS: 'nice_to_have_skills',
        MISSING_CRITICAL_SKILLS: 'missing_critical_skills',

        // Scores (0-10)
        EDUCATION_SCORE: 'education_score',
        DOMAIN_SCORE: 'domain_score',
        EXPERIENCE_SCORE: 'experience_score',
        SKILLS_SCORE: 'skills_score',

        // Analysis
        RED_FLAGS: 'red_flags',
        PROS: 'pros',
        CONS: 'cons',
        NOTES: 'notes',
        SUMMARY: 'summary'
    });

    /**
     * Column metadata for display and sorting
     */
    const COLUMN_META = Object.freeze({
        [COLUMNS.CANDIDATE_NAME]: { label: 'Candidate Name', type: 'string', sortable: true },
        [COLUMNS.EMAIL]: { label: 'Email', type: 'string', sortable: true },
        [COLUMNS.PHONE]: { label: 'Phone', type: 'string', sortable: false },
        [COLUMNS.RESUME_LINK]: { label: 'Resume', type: 'link', sortable: false },
        [COLUMNS.YEARS_OF_EXPERIENCE]: { label: 'Experience (Yrs)', type: 'number', sortable: true },
        [COLUMNS.RELEVANT_EXPERIENCE_YEARS]: { label: 'Relevant Exp', type: 'number', sortable: true },
        [COLUMNS.EMPLOYMENT_STATUS]: { label: 'Employment Status', type: 'string', sortable: true },
        [COLUMNS.EMPLOYMENT_GAPS]: { label: 'Employment Gaps', type: 'string', sortable: false },
        [COLUMNS.OVERQUALIFIED]: { label: 'Overqualified', type: 'boolean', sortable: true },
        [COLUMNS.EDUCATION_MATCH]: { label: 'Education Match', type: 'boolean', sortable: true },
        [COLUMNS.DOMAIN_MATCH]: { label: 'Domain Match', type: 'boolean', sortable: true },
        [COLUMNS.CURRENT_COMPANY]: { label: 'Current Company', type: 'string', sortable: true },
        [COLUMNS.CURRENT_DESIGNATION]: { label: 'Current Role', type: 'string', sortable: true },
        [COLUMNS.PREVIOUS_COMPANIES]: { label: 'Previous Companies', type: 'string', sortable: false },
        [COLUMNS.PREVIOUS_ROLES]: { label: 'Previous Roles', type: 'string', sortable: false },
        [COLUMNS.CAREER_TIMELINE]: { label: 'Career Timeline', type: 'timeline', sortable: false },
        [COLUMNS.HIGHEST_EDUCATION]: { label: 'Highest Education', type: 'string', sortable: true },
        [COLUMNS.EDUCATION_TIMELINE]: { label: 'Education Timeline', type: 'timeline', sortable: false },
        [COLUMNS.CERTIFICATIONS]: { label: 'Certifications', type: 'tags', sortable: false },
        [COLUMNS.LANGUAGES]: { label: 'Languages', type: 'tags', sortable: false },
        [COLUMNS.SKILLS]: { label: 'Skills', type: 'tags', sortable: false },
        [COLUMNS.CRITICAL_SKILLS_MATCH]: { label: 'Critical Skills Match', type: 'tags', sortable: false },
        [COLUMNS.NICE_TO_HAVE_SKILLS]: { label: 'Nice-to-Have Skills', type: 'tags', sortable: false },
        [COLUMNS.MISSING_CRITICAL_SKILLS]: { label: 'Missing Critical Skills', type: 'tags', sortable: false },
        [COLUMNS.EDUCATION_SCORE]: { label: 'Education Score', type: 'score', sortable: true },
        [COLUMNS.DOMAIN_SCORE]: { label: 'Domain Score', type: 'score', sortable: true },
        [COLUMNS.EXPERIENCE_SCORE]: { label: 'Experience Score', type: 'score', sortable: true },
        [COLUMNS.SKILLS_SCORE]: { label: 'Skills Score', type: 'score', sortable: true },
        [COLUMNS.RED_FLAGS]: { label: 'Red Flags', type: 'text', sortable: false },
        [COLUMNS.PROS]: { label: 'Pros', type: 'text', sortable: false },
        [COLUMNS.CONS]: { label: 'Cons', type: 'text', sortable: false },
        [COLUMNS.NOTES]: { label: 'Notes', type: 'text', sortable: false },
        [COLUMNS.SUMMARY]: { label: 'Summary', type: 'text', sortable: false }
    });

    /**
     * Internal computed fields (added during processing)
     */
    const COMPUTED_FIELDS = Object.freeze({
        ID: '_id',
        CALCULATED_SCORE: '_calculatedScore',
        CALCULATED_STATUS: '_calculatedStatus',
        HAS_OVERRIDE: '_hasOverride',
        SUBSCORES: '_subscores',
        AUTO_REJECTION_REASONS: '_autoRejectionReasons',
        IS_AUTO_REJECTED: '_isAutoRejected',
        HAS_CAREER_GAPS: '_hasCareerGaps',
        IS_UNEMPLOYED: '_isUnemployed',
        IS_OVERQUALIFIED: '_isOverqualified',
        HAS_EDU_MISMATCH: '_hasEduMismatch',
        HAS_DOMAIN_MISMATCH: '_hasDomainMismatch'
    });

    /**
     * Scoring parameters configuration
     */
    const SCORING_PARAMS = Object.freeze([
        { id: 'education', label: 'Education', abbr: 'Edu', column: COLUMNS.EDUCATION_SCORE },
        { id: 'domain', label: 'Domain', abbr: 'Dom', column: COLUMNS.DOMAIN_SCORE },
        { id: 'experience', label: 'Experience', abbr: 'Exp', column: COLUMNS.EXPERIENCE_SCORE },
        { id: 'skills', label: 'Skills', abbr: 'Ski', column: COLUMNS.SKILLS_SCORE }
    ]);

    /**
     * Normalize column name to snake_case for comparison
     */
    const normalizeColumnName = (name) => {
        if (!name) return '';
        return name
            .toLowerCase()
            .replace(/\s+/g, '_')
            .replace(/-+/g, '_')
            .replace(/[()]/g, '')
            .trim();
    };

    /**
     * Get value from row - tries exact match first, then normalized match
     * @param {object} row - Data row
     * @param {string} column - Exact column name from COLUMNS
     * @param {*} defaultVal - Default value if not found
     * @returns {*} Value or default
     */
    const get = (row, column, defaultVal = null) => {
        if (!row) return defaultVal;
        
        // Try exact match first (preferred)
        if (row[column] !== undefined && row[column] !== null && row[column] !== '') {
            return row[column];
        }
        
        // Fallback: try to find a matching key with different casing/formatting
        // This handles cases where Excel has 'Candidate Name' instead of 'candidate_name'
        const normalizedTarget = normalizeColumnName(column);
        const matchingKey = Object.keys(row).find(key => {
            const normalizedKey = normalizeColumnName(key);
            return normalizedKey === normalizedTarget;
        });
        
        if (matchingKey && row[matchingKey] !== undefined && row[matchingKey] !== null && row[matchingKey] !== '') {
            return row[matchingKey];
        }
        
        return defaultVal;
    };

    /**
     * Get string value safely
     * @param {object} row - Data row
     * @param {string} column - Column name
     * @param {string} defaultVal - Default value
     * @returns {string} String value
     */
    const getString = (row, column, defaultVal = '-') => {
        const val = get(row, column, defaultVal);
        return val === null ? defaultVal : String(val);
    };

    /**
     * Get number value safely
     * @param {object} row - Data row
     * @param {string} column - Column name
     * @param {number} defaultVal - Default value
     * @returns {number} Number value
     */
    const getNumber = (row, column, defaultVal = 0) => {
        const val = get(row, column, defaultVal);
        const num = parseFloat(val);
        return isNaN(num) ? defaultVal : num;
    };

    /**
     * Get boolean value safely
     * @param {object} row - Data row
     * @param {string} column - Column name
     * @returns {boolean} Boolean value
     */
    const getBoolean = (row, column) => {
        const val = get(row, column, false);
        if (typeof val === 'boolean') return val;
        if (typeof val === 'number') return val === 1;
        const str = String(val).toLowerCase().trim();
        return str === 'true' || str === 'yes' || str === '1';
    };

    /**
     * Validate that a row has all required columns
     * @param {object} row - Data row
     * @returns {string[]} Array of missing column names
     */
    const validateRow = (row) => {
        const required = [
            COLUMNS.CANDIDATE_NAME,
            COLUMNS.EDUCATION_SCORE,
            COLUMNS.DOMAIN_SCORE,
            COLUMNS.EXPERIENCE_SCORE,
            COLUMNS.SKILLS_SCORE
        ];
        return required.filter(col => get(row, col) === null);
    };

    /**
     * Get all column names as array
     * @returns {string[]} Array of column names
     */
    const getAllColumns = () => Object.values(COLUMNS);

    return {
        COLUMNS,
        COLUMN_META,
        COMPUTED_FIELDS,
        SCORING_PARAMS,
        get,
        getString,
        getNumber,
        getBoolean,
        validateRow,
        getAllColumns
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SCHEMA;
} else {
    window.SCHEMA = SCHEMA;
}
