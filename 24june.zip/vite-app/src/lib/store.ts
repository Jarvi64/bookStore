import { create } from 'zustand';

// ── Programme Config (single programme) ──────────────────────
export type ProgrammeConfig = {
  programmeid: string;
  name: string;
  businessUnit: string;
  capability: string;
  poc1: string;
  poc2: string;
  lastreportingweek: string;
  notes: string;
  t0Start: string; // ISO date string (default: "2026-09-01")
};

// ── Programme-level Types ─────────────────────────────────────
export type ProgrammeOrgNode = {
  programmeorgnodeid: string;
  programmeid: string;
  displayname: string;
  title: string;
  sortorder: number;
  active: string;
  parentnodeid: string | null;
};

export type Milestone = {
  milestoneid: string;
  programmeid: string;
  name: string;
  startdate: string;
  originaltargetedcompletiondate: string;
  targetedcompletiondate: string;
  ownerorgnodeid: string;
  status: string;
  remarks: string;
  changecount: number;
  lastchangereason: string;

  // T0 & Payment Extensions
  t0OffsetStart: number;          // relative month offset from T0 (e.g. 0)
  t0OffsetEnd: number;            // relative month offset from T0 (e.g. 5)
  deliverable: string;            // details of the deliverable item
  paymentPercentage: number;      // payment percentage associated (e.g. 10%)
  parentMilestoneId: string | null; // links sub-milestone to parent (null for main milestones)
};

export type SupportRequired = {
  supportrequiredid: string;
  programmeid: string;
  supporttext: string;
  category: string;
  criticality: string;
  ownerorgnodeid: string;
  deadline: string;
  status: string;
};

export type DateChangeLog = {
  datechangelogid: string;
  programmeid: string;
  module: 
    | "milestone"
    | "support_required"
    | "partner_deliverable"
    | "capex"
    | "opex"
    | "certification"
    | "supply_chain";
  recordid: string;
  recordname: string;
  fieldname: string;
  olddate: string;
  newdate: string;
  reason: string;
  changedon: string;
};

export type ManpowerGapHiringPlan = {
  manpowergaphiringplansid: string;
  programmeid: string;
  role: string;
  requiredqty: number;
  filledqty: number;
  sourcingchannel: string;
  targetjoindate: string;
  priority: string;
  remarks: string;
};

export type ManpowerDeliverable = {
  manpowerdeliverableid: string;
  programmeid: string;
  role: string;
  qualification: string;
  experience: string;
  requiredqty: number;
  remarks: string;
};

export type WeeklyUpdate = {
  weeklyupdateid: string;
  programmeid: string;
  weekkey: string; // e.g. "2026-W14"
  submittedon: string; // ISO datetime
  status: string; // Draft / Submitted
};

export type WeeklyUpdateItem = {
  weeklyupdateitemid: string;
  weeklyupdateid: string;
  category: string;
  entrytype: string; // "positive" | "negative"
  description: string;
};

export type PartnerDeliverable = {
  partnerdeliverableid: string;
  programmeid: string;
  partnername: string;
  deliverable: string;
  targetedc: string; // ISO string
  currentedc: string; // ISO string
  status: string;
  riskremarks: string;
  ownerorgnodeid: string;
};

export type CapexBudget = {
  capexbudgetid: string;
  programmeid: string;
  item: string;
  budgetcr: number;
  actualcr: number;
  commisiongdate: string;
  ownerorgnodeid: string;
};

export type OpexBudget = {
  programmebudgetid: string;
  programmeid: string;
  item: string;
  supplier: string;
  unitcostcr: number;
  targetcostcr: number;
  deadline: string;
  ownerorgnodeid: string;
};

export type Certification = {
  certificationid: string;
  programmeid: string;
  name: string;
  ownerorgnodeid: string;
  status: string;
  validitydate: string;
  currentedc: string;
  riskremarks: string;
};

export type SupplyChainReadiness = {
  supplychainreadinessid: string;
  programmeid: string;
  item: string;
  supplier: string;
  actualcostcr: number;
  targetcostcr: number;
  variancecr: number;
  status: string;
  riskremarks: string;
  dateoforder: string;
  dateofdelivery: string;
  leadtime: string;
  ownerorgnodeid: string;
};

// ── Constants ─────────────────────────────────────────────────
export const MILESTONE_STATUSES = ['Not Started', 'In Progress', 'Completed', 'Delayed', 'At Risk'] as const;
export const SUPPORT_CATEGORIES = ['Program', 'Engineering', 'SCM', 'Partner', 'Manpower', 'Certifications', 'Infra/Project', 'Supply Chain', 'Finance'] as const;
export const SUPPORT_CRITICALITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export const SUPPORT_STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'] as const;
export const SOURCING_CHANNELS = ['IJP', 'External'] as const;
export const HIRING_PRIORITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export const WEEKLY_CATEGORIES = ['Program', 'Engineering', 'SCM', 'Partner', 'Manpower', 'Certifications', 'Infra/Project', 'Supply Chain', 'Finance'] as const;

// ── Store Interface ───────────────────────────────────────────
interface AppState {
  programmeConfig: ProgrammeConfig;
  programmeOrgNodes: ProgrammeOrgNode[];
  milestones: Milestone[];
  supportRequired: SupportRequired[];
  dateChangeLogs: DateChangeLog[];
  manpowerPlans: ManpowerGapHiringPlan[];
  manpowerDeliverables: ManpowerDeliverable[];
  weeklyUpdates: WeeklyUpdate[];
  weeklyUpdateItems: WeeklyUpdateItem[];
  partnerDeliverables: PartnerDeliverable[];
  capexBudgets: CapexBudget[];
  opexBudgets: OpexBudget[];
  certifications: Certification[];
  supplyChains: SupplyChainReadiness[];

  // Programme Config
  updateProgrammeConfig: (config: Partial<ProgrammeConfig>) => void;

  // Programme-level CRUD
  addMilestone: (m: Omit<Milestone, 'milestoneid' | 'changecount' | 'lastchangereason'>) => void;
  updateMilestone: (id: string, m: Partial<Milestone>) => void;
  deleteMilestone: (id: string) => void;

  addSupportRequired: (s: Omit<SupportRequired, 'supportrequiredid'>) => void;
  updateSupportRequired: (id: string, s: Partial<SupportRequired>) => void;
  deleteSupportRequired: (id: string) => void;

  addManpowerPlan: (p: Omit<ManpowerGapHiringPlan, 'manpowergaphiringplansid'>) => void;
  updateManpowerPlan: (id: string, p: Partial<ManpowerGapHiringPlan>) => void;
  deleteManpowerPlan: (id: string) => void;

  addManpowerDeliverable: (d: Omit<ManpowerDeliverable, 'manpowerdeliverableid'>) => void;
  updateManpowerDeliverable: (id: string, d: Partial<ManpowerDeliverable>) => void;
  deleteManpowerDeliverable: (id: string) => void;

  // Org nodes CRUD
  addOrgNode: (n: Omit<ProgrammeOrgNode, 'programmeorgnodeid'>) => void;
  updateOrgNode: (id: string, n: Partial<ProgrammeOrgNode>) => void;
  deleteOrgNode: (id: string) => void;

  // Weekly Updates
  addWeeklyUpdate: (u: Omit<WeeklyUpdate, 'weeklyupdateid'>) => void;
  updateWeeklyUpdate: (id: string, u: Partial<WeeklyUpdate>) => void;
  deleteWeeklyUpdate: (id: string) => void;

  // Weekly Update Items
  addWeeklyUpdateItem: (item: Omit<WeeklyUpdateItem, 'weeklyupdateitemid'>) => void;
  updateWeeklyUpdateItem: (id: string, item: Partial<WeeklyUpdateItem>) => void;
  deleteWeeklyUpdateItem: (id: string) => void;
  bulkSetWeeklyUpdateItems: (weeklyupdateid: string, items: Omit<WeeklyUpdateItem, 'weeklyupdateitemid'>[]) => void;

  // Partner Deliverables
  addPartnerDeliverable: (d: Omit<PartnerDeliverable, 'partnerdeliverableid'>) => void;
  updatePartnerDeliverable: (id: string, d: Partial<PartnerDeliverable>) => void;
  deletePartnerDeliverable: (id: string) => void;

  // Budgets
  addCapexBudget: (c: Omit<CapexBudget, 'capexbudgetid'>) => void;
  updateCapexBudget: (id: string, c: Partial<CapexBudget>) => void;
  deleteCapexBudget: (id: string) => void;

  addOpexBudget: (o: Omit<OpexBudget, 'programmebudgetid'>) => void;
  updateOpexBudget: (id: string, o: Partial<OpexBudget>) => void;
  deleteOpexBudget: (id: string) => void;

  // Certifications
  addCertification: (c: Omit<Certification, 'certificationid'>) => void;
  updateCertification: (id: string, c: Partial<Certification>) => void;
  deleteCertification: (id: string) => void;

  // Supply Chain Readiness
  addSupplyChain: (s: Omit<SupplyChainReadiness, 'supplychainreadinessid'>) => void;
  updateSupplyChain: (id: string, s: Partial<SupplyChainReadiness>) => void;
  deleteSupplyChain: (id: string) => void;

  // Date change log (append-only)
  addDateChangeLog: (log: Omit<DateChangeLog, 'datechangelogid' | 'changedon'>) => void;
}

// ── Seed Data ─────────────────────────────────────────────────
const PROGRAMME_CONFIG: ProgrammeConfig = {
  programmeid: 'prog_1',
  name: 'Third Eye',
  businessUnit: 'Defence & Aerospace',
  capability: 'Surveillance & Reconnaissance',
  poc1: 'Alice Smith',
  poc2: 'Bob Johnson',
  lastreportingweek: '2026-W14',
  notes: 'Advanced surveillance and reconnaissance programme',
  t0Start: '2026-06-01',
};

const SEED_ORG_NODES: ProgrammeOrgNode[] = [
  { programmeorgnodeid: 'org_1', programmeid: 'prog_1', displayname: 'Alice Smith', title: 'Programme Director', sortorder: 1, active: 'Yes', parentnodeid: null },
  { programmeorgnodeid: 'org_2', programmeid: 'prog_1', displayname: 'Bob Johnson', title: 'Tech Lead', sortorder: 2, active: 'Yes', parentnodeid: 'org_1' },
  { programmeorgnodeid: 'org_3', programmeid: 'prog_1', displayname: 'Charlie Davis', title: 'Delivery Manager', sortorder: 3, active: 'Yes', parentnodeid: 'org_1' },
];

const SEED_MILESTONES: Milestone[] = [
  // M1
  { milestoneid: 'ms_1', programmeid: 'prog_1', name: 'Milestone 1: Preliminary Design Review (PDR)', startdate: '2026-06-01', originaltargetedcompletiondate: '2026-11-30', targetedcompletiondate: '2026-11-30', ownerorgnodeid: 'org_1', status: 'At Risk', remarks: 'Requirements review delayed', changecount: 0, lastchangereason: '', t0OffsetStart: 0, t0OffsetEnd: 5, deliverable: 'PDR Design Package & System Requirements Document', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_1_1', programmeid: 'prog_1', name: 'System Requirements Sign-off', startdate: '2026-06-01', originaltargetedcompletiondate: '2026-07-15', targetedcompletiondate: '2026-07-15', ownerorgnodeid: 'org_1', status: 'At Risk', remarks: 'Awaiting stakeholder signature', changecount: 0, lastchangereason: '', t0OffsetStart: 0, t0OffsetEnd: 3, deliverable: 'System Requirements Specification (SRS)', paymentPercentage: 10, parentMilestoneId: 'ms_1' },
  { milestoneid: 'ms_1_2', programmeid: 'prog_1', name: 'PDR Clearance Certificate', startdate: '2026-07-16', originaltargetedcompletiondate: '2026-11-30', targetedcompletiondate: '2026-11-30', ownerorgnodeid: 'org_2', status: 'In Progress', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 3, t0OffsetEnd: 5, deliverable: 'PDR Certificate signed by Authority', paymentPercentage: 10, parentMilestoneId: 'ms_1' },

  // M2
  { milestoneid: 'ms_2', programmeid: 'prog_1', name: 'Milestone 2: Critical Design Review (CDR)', startdate: '2026-12-01', originaltargetedcompletiondate: '2027-06-30', targetedcompletiondate: '2027-06-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 5, t0OffsetEnd: 12, deliverable: 'System Design Freeze & Prototype Specifications', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_2_1', programmeid: 'prog_1', name: 'Sub-system Schematics Review', startdate: '2026-12-01', originaltargetedcompletiondate: '2027-04-30', targetedcompletiondate: '2027-04-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 5, t0OffsetEnd: 10, deliverable: 'Engineering Drawings Package', paymentPercentage: 5, parentMilestoneId: 'ms_2' },
  { milestoneid: 'ms_2_2', programmeid: 'prog_1', name: 'CDR Gate Clearance', startdate: '2027-05-01', originaltargetedcompletiondate: '2027-06-30', targetedcompletiondate: '2027-06-30', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 10, t0OffsetEnd: 12, deliverable: 'CDR Approval Sign-off', paymentPercentage: 5, parentMilestoneId: 'ms_2' },

  // M3
  { milestoneid: 'ms_3', programmeid: 'prog_1', name: 'Milestone 3: Prototype Manufacturing & Testing', startdate: '2027-10-01', originaltargetedcompletiondate: '2028-09-30', targetedcompletiondate: '2028-09-30', ownerorgnodeid: 'org_2', status: 'In Progress', remarks: 'Assembly & unit level checks in execution', changecount: 0, lastchangereason: '', t0OffsetStart: 12, t0OffsetEnd: 24, deliverable: 'First Prototype Unit & Test Bench Report', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_3_1', programmeid: 'prog_1', name: 'Material Sourcing & Fabrication', startdate: '2027-10-01', originaltargetedcompletiondate: '2028-05-31', targetedcompletiondate: '2028-05-31', ownerorgnodeid: 'org_3', status: 'Completed', remarks: 'Fabrication complete', changecount: 0, lastchangereason: '', t0OffsetStart: 12, t0OffsetEnd: 20, deliverable: 'BOM Sourced Certificate', paymentPercentage: 5, parentMilestoneId: 'ms_3' },
  { milestoneid: 'ms_3_2', programmeid: 'prog_1', name: 'Prototype Fabrication & Assembly', startdate: '2028-06-01', originaltargetedcompletiondate: '2028-07-31', targetedcompletiondate: '2028-07-31', ownerorgnodeid: 'org_2', status: 'In Progress', remarks: 'Cabling & packaging work active', changecount: 0, lastchangereason: '', t0OffsetStart: 20, t0OffsetEnd: 22, deliverable: 'Prototype Unit Assembly', paymentPercentage: 5, parentMilestoneId: 'ms_3' },
  { milestoneid: 'ms_3_3', programmeid: 'prog_1', name: 'Unit Level Verification', startdate: '2028-08-01', originaltargetedcompletiondate: '2028-09-30', targetedcompletiondate: '2028-09-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 22, t0OffsetEnd: 24, deliverable: 'Test Bench Evaluation Report', paymentPercentage: 5, parentMilestoneId: 'ms_3' },

  // M4
  { milestoneid: 'ms_4', programmeid: 'prog_1', name: 'Milestone 4: Software Integration & Platform Release', startdate: '2028-10-01', originaltargetedcompletiondate: '2029-09-30', targetedcompletiondate: '2029-09-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 24, t0OffsetEnd: 36, deliverable: 'Integrated Software Suite v1.0', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_4_1', programmeid: 'prog_1', name: 'Sensor Driver SDKs Integration', startdate: '2028-10-01', originaltargetedcompletiondate: '2029-03-31', targetedcompletiondate: '2029-03-31', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 24, t0OffsetEnd: 30, deliverable: 'Sensor Communication Layer', paymentPercentage: 5, parentMilestoneId: 'ms_4' },
  { milestoneid: 'ms_4_2', programmeid: 'prog_1', name: 'Software GUI Release v1.0', startdate: '2029-04-01', originaltargetedcompletiondate: '2029-09-30', targetedcompletiondate: '2029-09-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 30, t0OffsetEnd: 36, deliverable: 'GUI Command Interface v1.0', paymentPercentage: 5, parentMilestoneId: 'ms_4' },

  // M5
  { milestoneid: 'ms_5', programmeid: 'prog_1', name: 'Milestone 5: Subsystem Acceptance Testing (SAT)', startdate: '2029-10-01', originaltargetedcompletiondate: '2030-09-30', targetedcompletiondate: '2030-09-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 36, t0OffsetEnd: 48, deliverable: 'SAT Clearance Certificate', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_5_1', programmeid: 'prog_1', name: 'Lab Validation Testing', startdate: '2029-10-01', originaltargetedcompletiondate: '2030-05-31', targetedcompletiondate: '2030-05-31', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 36, t0OffsetEnd: 44, deliverable: 'Lab Acceptance Test Report', paymentPercentage: 5, parentMilestoneId: 'ms_5' },
  { milestoneid: 'ms_5_2', programmeid: 'prog_1', name: 'Environmental Stress Screenings', startdate: '2030-06-01', originaltargetedcompletiondate: '2030-09-30', targetedcompletiondate: '2030-09-30', ownerorgnodeid: 'org_3', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 44, t0OffsetEnd: 48, deliverable: 'Environmental Qualification Certificate', paymentPercentage: 5, parentMilestoneId: 'ms_5' },

  // M6
  { milestoneid: 'ms_6', programmeid: 'prog_1', name: 'Milestone 6: Pilot Production (2 Sets of XY)', startdate: '2030-10-01', originaltargetedcompletiondate: '2031-05-31', targetedcompletiondate: '2031-05-31', ownerorgnodeid: 'org_3', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 48, t0OffsetEnd: 56, deliverable: '2 Sets of XY Radar Units', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_6_1', programmeid: 'prog_1', name: 'Manufacturing Setup & Assembly', startdate: '2030-10-01', originaltargetedcompletiondate: '2031-01-31', targetedcompletiondate: '2031-01-31', ownerorgnodeid: 'org_3', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 48, t0OffsetEnd: 52, deliverable: 'Assembly Readiness Clearance', paymentPercentage: 5, parentMilestoneId: 'ms_6' },
  { milestoneid: 'ms_6_2', programmeid: 'prog_1', name: 'Acceptable Delivery of 2 XY Sets', startdate: '2031-02-01', originaltargetedcompletiondate: '2031-05-31', targetedcompletiondate: '2031-05-31', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 52, t0OffsetEnd: 56, deliverable: 'Delivery Handover Receipt', paymentPercentage: 5, parentMilestoneId: 'ms_6' },

  // M7
  { milestoneid: 'ms_7', programmeid: 'prog_1', name: 'Milestone 7: Operational Field Trials', startdate: '2031-06-01', originaltargetedcompletiondate: '2032-01-31', targetedcompletiondate: '2032-01-31', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 56, t0OffsetEnd: 64, deliverable: 'Operational Evaluation Report', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_7_1', programmeid: 'prog_1', name: 'Field Site Deployment', startdate: '2031-06-01', originaltargetedcompletiondate: '2031-09-30', targetedcompletiondate: '2031-09-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 56, t0OffsetEnd: 60, deliverable: 'Installation Readiness Report', paymentPercentage: 5, parentMilestoneId: 'ms_7' },
  { milestoneid: 'ms_7_2', programmeid: 'prog_1', name: 'Joint Tactical Trials Evaluation', startdate: '2031-10-01', originaltargetedcompletiondate: '2032-01-31', targetedcompletiondate: '2032-01-31', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 60, t0OffsetEnd: 64, deliverable: 'Joint Acceptance Sign-off Certificate', paymentPercentage: 5, parentMilestoneId: 'ms_7' },

  // M8
  { milestoneid: 'ms_8', programmeid: 'prog_1', name: 'Milestone 8: Full Scale Production Setup', startdate: '2032-02-01', originaltargetedcompletiondate: '2032-09-30', targetedcompletiondate: '2032-09-30', ownerorgnodeid: 'org_3', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 64, t0OffsetEnd: 72, deliverable: 'Commissioned Assembly Line', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_8_1', programmeid: 'prog_1', name: 'Supply Chain Procurement Check', startdate: '2032-02-01', originaltargetedcompletiondate: '2032-05-31', targetedcompletiondate: '2032-05-31', ownerorgnodeid: 'org_3', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 64, t0OffsetEnd: 68, deliverable: 'SCM Clearance Report', paymentPercentage: 5, parentMilestoneId: 'ms_8' },
  { milestoneid: 'ms_8_2', programmeid: 'prog_1', name: 'Production Line Commissioning', startdate: '2032-06-01', originaltargetedcompletiondate: '2032-09-30', targetedcompletiondate: '2032-09-30', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 68, t0OffsetEnd: 72, deliverable: 'Manufacturing Audit Certificate', paymentPercentage: 5, parentMilestoneId: 'ms_8' },

  // M9
  { milestoneid: 'ms_9', programmeid: 'prog_1', name: 'Milestone 9: Final Product Handover', startdate: '2032-10-01', originaltargetedcompletiondate: '2033-01-31', targetedcompletiondate: '2033-01-31', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 72, t0OffsetEnd: 76, deliverable: 'Confidential Handover Certificate Package', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_9_1', programmeid: 'prog_1', name: 'Final Handover Sign-off', startdate: '2032-10-01', originaltargetedcompletiondate: '2033-01-31', targetedcompletiondate: '2033-01-31', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 72, t0OffsetEnd: 76, deliverable: 'Handover Certificate signed by Client', paymentPercentage: 5, parentMilestoneId: 'ms_9' },

  // M10
  { milestoneid: 'ms_10', programmeid: 'prog_1', name: 'Milestone 10: Project Close-out', startdate: '2033-02-01', originaltargetedcompletiondate: '2033-04-30', targetedcompletiondate: '2033-04-30', ownerorgnodeid: 'org_1', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 76, t0OffsetEnd: 79, deliverable: 'Acceptance & Project Close-out Certificate', paymentPercentage: 0, parentMilestoneId: null },
  { milestoneid: 'ms_10_1', programmeid: 'prog_1', name: 'Audit Clearance & Closure', startdate: '2033-02-01', originaltargetedcompletiondate: '2033-04-30', targetedcompletiondate: '2033-04-30', ownerorgnodeid: 'org_2', status: 'Not Started', remarks: '', changecount: 0, lastchangereason: '', t0OffsetStart: 76, t0OffsetEnd: 79, deliverable: 'Final Closure Certificate', paymentPercentage: 5, parentMilestoneId: 'ms_10' }
];

const SEED_SUPPORT: SupportRequired[] = [
  { supportrequiredid: 'sup_1', programmeid: 'prog_1', supporttext: 'Need dedicated DevOps engineer for CI/CD pipeline setup', category: 'Engineering', criticality: 'High', ownerorgnodeid: 'org_2', deadline: '2026-04-15', status: 'Open' },
  { supportrequiredid: 'sup_2', programmeid: 'prog_1', supporttext: 'Partner API documentation access required', category: 'Partner', criticality: 'Critical', ownerorgnodeid: 'org_3', deadline: '2026-04-10', status: 'In Progress' },
];

const SEED_MANPOWER: ManpowerGapHiringPlan[] = [
  { manpowergaphiringplansid: 'mp_1', programmeid: 'prog_1', role: 'Senior Backend Engineer', requiredqty: 3, filledqty: 2, sourcingchannel: 'IJP', targetjoindate: '2026-05-01', priority: 'High', remarks: 'Need Java/Spring expertise' },
  { manpowergaphiringplansid: 'mp_2', programmeid: 'prog_1', role: 'DevOps Engineer', requiredqty: 2, filledqty: 0, sourcingchannel: 'External', targetjoindate: '2026-04-15', priority: 'Critical', remarks: 'CI/CD pipeline setup' },
  { manpowergaphiringplansid: 'mp_3', programmeid: 'prog_1', role: 'QA Automation Lead', requiredqty: 1, filledqty: 1, sourcingchannel: 'IJP', targetjoindate: '2026-03-15', priority: 'Medium', remarks: '' },
];

const SEED_MANPOWER_DELIVERABLES: ManpowerDeliverable[] = [
  { manpowerdeliverableid: 'mpd_1', programmeid: 'prog_1', role: 'Radar Signal Processing Architect', qualification: 'M.Tech / PhD in Electronics & Comm', experience: '6-10 Years', requiredqty: 2, remarks: 'Key algorithms design' },
  { manpowerdeliverableid: 'mpd_2', programmeid: 'prog_1', role: 'Embedded Systems Firmware Engineer', qualification: 'B.Tech / M.Tech CSE/ECE', experience: '3-6 Years', requiredqty: 4, remarks: 'Sub-system firmware fabrication' },
  { manpowerdeliverableid: 'mpd_3', programmeid: 'prog_1', role: 'Systems Integration & Validation Lead', qualification: 'B.Tech ECE/EEE', experience: '5-9 Years', requiredqty: 1, remarks: 'Field deployment testing coordination' }
];

const now = new Date();
const twoDaysAgo = new Date(now.getTime() - 2 * 86400000).toISOString();

const SEED_DATE_LOGS: DateChangeLog[] = [
  { datechangelogid: 'dcl_1', programmeid: 'prog_1', module: 'milestone', recordid: 'ms_1', recordname: 'Preliminary Design Review (PDR)', fieldname: 'targetedcompletiondate', olddate: '2026-02-28', newdate: '2026-03-10', reason: 'Stakeholder review delayed', changedon: twoDaysAgo },
];

const SEED_WEEKLY_UPDATES: WeeklyUpdate[] = [
  { weeklyupdateid: 'wu_1', programmeid: 'prog_1', weekkey: '2026-W13', submittedon: '2026-03-28T10:30:00Z', status: 'Submitted' },
  { weeklyupdateid: 'wu_2', programmeid: 'prog_1', weekkey: '2026-W14', submittedon: '2026-04-04T14:15:00Z', status: 'Submitted' },
];

const SEED_WEEKLY_ITEMS: WeeklyUpdateItem[] = [
  { weeklyupdateitemid: 'wui_1', weeklyupdateid: 'wu_1', category: 'Program', entrytype: 'positive', description: 'Requirements sign-off achieved ahead of schedule' },
  { weeklyupdateitemid: 'wui_2', weeklyupdateid: 'wu_1', category: 'Program', entrytype: 'negative', description: 'Stakeholder availability remains a bottleneck' },
  { weeklyupdateitemid: 'wui_3', weeklyupdateid: 'wu_1', category: 'Engineering', entrytype: 'positive', description: 'CI/CD pipeline setup completed' },
  { weeklyupdateitemid: 'wui_8', weeklyupdateid: 'wu_2', category: 'Program', entrytype: 'positive', description: 'Requirements sign-off achieved ahead of schedule' },
  { weeklyupdateitemid: 'wui_9', weeklyupdateid: 'wu_2', category: 'Program', entrytype: 'positive', description: 'Architecture review meeting scheduled for next week' },
  { weeklyupdateitemid: 'wui_13', weeklyupdateid: 'wu_2', category: 'Engineering', entrytype: 'negative', description: 'Beta release delayed due to partner API integration' },
];

const SEED_PARTNER_DELIVERABLES: PartnerDeliverable[] = [
  { partnerdeliverableid: 'pd_1', programmeid: 'prog_1', partnername: 'AWS', deliverable: 'Cloud Infrastructure Setup & Security Audit', targetedc: '2026-05-01', currentedc: '2026-05-15', status: 'In Progress', riskremarks: 'Waiting on compliance team', ownerorgnodeid: 'org_2' }
];

const SEED_CAPEX: CapexBudget[] = [
  { capexbudgetid: 'capx_1', programmeid: 'prog_1', item: 'Assembly Line Conveyors', budgetcr: 4.5, actualcr: 4.65, commisiongdate: '2026-07-01', ownerorgnodeid: 'org_1' }
];

const SEED_OPEX: OpexBudget[] = [
  { programmebudgetid: 'opx_1', programmeid: 'prog_1', item: 'Software Licensing', supplier: 'Microsoft', unitcostcr: 0.1, targetcostcr: 5.0, deadline: '2026-12-31', ownerorgnodeid: 'org_1' }
];

const SEED_CERTIFICATIONS: Certification[] = [
  { certificationid: 'cert_1', programmeid: 'prog_1', name: 'ISO 9001 Compliance Audit', status: 'In Review', validitydate: '2027-01-01', currentedc: '2026-11-01', riskremarks: '', ownerorgnodeid: 'org_3' }
];

const SEED_SUPPLY_CHAIN: SupplyChainReadiness[] = [
  { supplychainreadinessid: 'scr_1', programmeid: 'prog_1', item: 'Raw Steel Sheets', supplier: 'Tata Steel', actualcostcr: 12.5, targetcostcr: 12.0, variancecr: -0.5, status: 'In Transit', riskremarks: 'Delay in shipping port', dateoforder: '2026-02-15', dateofdelivery: '2026-04-30', leadtime: '10 Weeks', ownerorgnodeid: 'org_1' }
];

// ── Helpers ───────────────────────────────────────────────────
const generateId = (prefix: string) => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID()}`;
  }

  return `${prefix}_${Date.now().toString(36)}`;
};

export const useAppStore = create<AppState>((set) => ({
  programmeConfig: PROGRAMME_CONFIG,
  programmeOrgNodes: SEED_ORG_NODES,
  milestones: SEED_MILESTONES,
  supportRequired: SEED_SUPPORT,
  dateChangeLogs: SEED_DATE_LOGS,
  manpowerPlans: SEED_MANPOWER,
  manpowerDeliverables: SEED_MANPOWER_DELIVERABLES,
  weeklyUpdates: SEED_WEEKLY_UPDATES,
  weeklyUpdateItems: SEED_WEEKLY_ITEMS,
  partnerDeliverables: SEED_PARTNER_DELIVERABLES,
  capexBudgets: SEED_CAPEX,
  opexBudgets: SEED_OPEX,
  certifications: SEED_CERTIFICATIONS,
  supplyChains: SEED_SUPPLY_CHAIN,

  // ── Programme Config ──
  updateProgrammeConfig: (config) => set((state) => ({
    programmeConfig: { ...state.programmeConfig, ...config },
  })),

  // ── Milestones ──
  addMilestone: (m) => set((state) => ({
    milestones: [...state.milestones, { ...m, milestoneid: generateId('ms'), changecount: 0, lastchangereason: '' }],
  })),
  updateMilestone: (id, m) => set((state) => ({
    milestones: state.milestones.map((ms) => (ms.milestoneid === id ? { ...ms, ...m } : ms)),
  })),
  deleteMilestone: (id) => set((state) => ({
    milestones: state.milestones.filter((ms) => ms.milestoneid !== id && ms.parentMilestoneId !== id),
  })),

  // ── Support Required ──
  addSupportRequired: (s) => set((state) => ({
    supportRequired: [...state.supportRequired, { ...s, supportrequiredid: generateId('sup') }],
  })),
  updateSupportRequired: (id, s) => set((state) => ({
    supportRequired: state.supportRequired.map((sr) => (sr.supportrequiredid === id ? { ...sr, ...s } : sr)),
  })),
  deleteSupportRequired: (id) => set((state) => ({
    supportRequired: state.supportRequired.filter((sr) => sr.supportrequiredid !== id),
  })),

  // ── Manpower Plans ──
  addManpowerPlan: (p) => set((state) => ({
    manpowerPlans: [...state.manpowerPlans, { ...p, manpowergaphiringplansid: generateId('mp') }],
  })),
  updateManpowerPlan: (id, p) => set((state) => ({
    manpowerPlans: state.manpowerPlans.map((mp) => (mp.manpowergaphiringplansid === id ? { ...mp, ...p } : mp)),
  })),
  deleteManpowerPlan: (id) => set((state) => ({
    manpowerPlans: state.manpowerPlans.filter((mp) => mp.manpowergaphiringplansid !== id),
  })),

  // ── Manpower Deliverables ──
  addManpowerDeliverable: (d) => set((state) => ({
    manpowerDeliverables: [...state.manpowerDeliverables, { ...d, manpowerdeliverableid: generateId('mpd') }],
  })),
  updateManpowerDeliverable: (id, d) => set((state) => ({
    manpowerDeliverables: state.manpowerDeliverables.map((mpd) => (mpd.manpowerdeliverableid === id ? { ...mpd, ...d } : mpd)),
  })),
  deleteManpowerDeliverable: (id) => set((state) => ({
    manpowerDeliverables: state.manpowerDeliverables.filter((mpd) => mpd.manpowerdeliverableid !== id),
  })),

  // ── Org Nodes ──
  addOrgNode: (n) => set((state) => ({
    programmeOrgNodes: [...state.programmeOrgNodes, { ...n, programmeorgnodeid: generateId('org') }],
  })),
  updateOrgNode: (id, n) => set((state) => ({
    programmeOrgNodes: state.programmeOrgNodes.map((node) => (node.programmeorgnodeid === id ? { ...node, ...n } : node)),
  })),
  deleteOrgNode: (id) => set((state) => ({
    programmeOrgNodes: state.programmeOrgNodes.filter((node) => node.programmeorgnodeid !== id),
  })),

  // ── Weekly Updates ──
  addWeeklyUpdate: (u) => set((state) => ({
    weeklyUpdates: [...state.weeklyUpdates, { ...u, weeklyupdateid: generateId('wu') }],
  })),
  updateWeeklyUpdate: (id, u) => set((state) => ({
    weeklyUpdates: state.weeklyUpdates.map((wu) => (wu.weeklyupdateid === id ? { ...wu, ...u } : wu)),
  })),
  deleteWeeklyUpdate: (id) => set((state) => ({
    weeklyUpdates: state.weeklyUpdates.filter((wu) => wu.weeklyupdateid !== id),
    weeklyUpdateItems: state.weeklyUpdateItems.filter((i) => i.weeklyupdateid !== id),
  })),

  // ── Weekly Update Items ──
  addWeeklyUpdateItem: (item) => set((state) => ({
    weeklyUpdateItems: [...state.weeklyUpdateItems, { ...item, weeklyupdateitemid: generateId('wui') }],
  })),
  updateWeeklyUpdateItem: (id, item) => set((state) => ({
    weeklyUpdateItems: state.weeklyUpdateItems.map((i) => (i.weeklyupdateitemid === id ? { ...i, ...item } : i)),
  })),
  deleteWeeklyUpdateItem: (id) => set((state) => ({
    weeklyUpdateItems: state.weeklyUpdateItems.filter((i) => i.weeklyupdateitemid !== id),
  })),
  bulkSetWeeklyUpdateItems: (weeklyupdateid, newItems) =>
    set((state) => {
      const filtered = state.weeklyUpdateItems.filter((i) => i.weeklyupdateid !== weeklyupdateid);
      const toAdd = newItems.map((n) => ({ ...n, weeklyupdateitemid: generateId('wui') }));
      return { weeklyUpdateItems: [...filtered, ...toAdd] };
    }),

  // Extended Tabs
  addPartnerDeliverable: (d) => set((s) => ({ partnerDeliverables: [...s.partnerDeliverables, { ...d, partnerdeliverableid: generateId('pd') }] })),
  updatePartnerDeliverable: (id, updates) => set((s) => ({
    partnerDeliverables: s.partnerDeliverables.map((x) => x.partnerdeliverableid === id ? { ...x, ...updates } : x)
  })),
  deletePartnerDeliverable: (id) => set((s) => ({ partnerDeliverables: s.partnerDeliverables.filter((x) => x.partnerdeliverableid !== id) })),

  addCapexBudget: (c) => set((s) => ({ capexBudgets: [...s.capexBudgets, { ...c, capexbudgetid: generateId('capx') }] })),
  updateCapexBudget: (id, updates) => set((s) => ({
    capexBudgets: s.capexBudgets.map((x) => x.capexbudgetid === id ? { ...x, ...updates } : x)
  })),
  deleteCapexBudget: (id) => set((s) => ({ capexBudgets: s.capexBudgets.filter((x) => x.capexbudgetid !== id) })),

  addOpexBudget: (o) => set((s) => ({ opexBudgets: [...s.opexBudgets, { ...o, programmebudgetid: generateId('opx') }] })),
  updateOpexBudget: (id, updates) => set((s) => ({
    opexBudgets: s.opexBudgets.map((x) => x.programmebudgetid === id ? { ...x, ...updates } : x)
  })),
  deleteOpexBudget: (id) => set((s) => ({ opexBudgets: s.opexBudgets.filter((x) => x.programmebudgetid !== id) })),

  addCertification: (c) => set((s) => ({ certifications: [...s.certifications, { ...c, certificationid: generateId('cert') }] })),
  updateCertification: (id, updates) => set((s) => ({
    certifications: s.certifications.map((x) => x.certificationid === id ? { ...x, ...updates } : x)
  })),
  deleteCertification: (id) => set((s) => ({ certifications: s.certifications.filter((x) => x.certificationid !== id) })),

  addSupplyChain: (sc) => set((s) => ({ supplyChains: [...s.supplyChains, { ...sc, supplychainreadinessid: generateId('scr') }] })),
  updateSupplyChain: (id, updates) => set((s) => ({
    supplyChains: s.supplyChains.map((x) => x.supplychainreadinessid === id ? { ...x, ...updates } : x)
  })),
  deleteSupplyChain: (id) => set((s) => ({ supplyChains: s.supplyChains.filter((x) => x.supplychainreadinessid !== id) })),

  // Date logs
  addDateChangeLog: (log) =>
    set((state) => ({
      dateChangeLogs: [
        ...state.dateChangeLogs,
        { ...log, datechangelogid: generateId('dcl'), changedon: new Date().toISOString() },
      ],
    })),
}));
