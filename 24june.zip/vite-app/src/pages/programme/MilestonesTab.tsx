import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAppStore, MILESTONE_STATUSES } from "@/lib/store";
import { toast } from "sonner";
import { 
  Plus, Pencil, Trash2, AlertTriangle, ArrowRight, Clock,
  ChevronRight, Award, CircleDollarSign,
  Settings, CheckCircle, BadgePercent
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Field, FieldGroup, FieldError } from "@/components/ui/field";
import { Spinner } from "@/components/ui/spinner";
import { DatePicker } from "@/components/ui/date-picker";
import { Card, CardContent } from "@/components/ui/card";
import {
  Combobox,
  ComboboxContent,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { addMonths, format, startOfMonth, endOfMonth } from "date-fns";

const schema = z.object({
  name: z.string().min(2, "Name is required"),
  t0OffsetStart: z.coerce.number().min(0, "Offset must be positive"),
  t0OffsetEnd: z.coerce.number().min(0, "Offset must be positive"),
  deliverable: z.string().min(2, "Deliverable details are required"),
  paymentPercentage: z.coerce.number().min(0, "Payment percentage must be positive"),
  parentMilestoneId: z.string().nullable(),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
  status: z.string().min(1, "Status is required"),
  remarks: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

const STATUS_COLORS: Record<string, string> = {
  "Not Started": "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress": "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Completed: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  Delayed: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "At Risk": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

export function MilestonesTab() {
  const { programmeConfig, updateProgrammeConfig } = useAppStore();
  const programmeId = programmeConfig.programmeid;
  const t0StartStr = programmeConfig.t0Start || "2026-09-01";
  
  const {
    milestones,
    programmeOrgNodes,
    dateChangeLogs,
    addMilestone,
    updateMilestone,
    deleteMilestone,
    addDateChangeLog,
  } = useAppStore();

  const items = milestones.filter((m) => m.programmeid === programmeId);
  const orgNodes = programmeOrgNodes.filter((n) => n.programmeid === programmeId && n.active === "Yes");
  const orgNodeNames = orgNodes.map((n) => n.displayname);
  const statusItems = [...MILESTONE_STATUSES];

  // Component UI States
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Date shift audit states
  const [dateChangeReason, setDateChangeReason] = useState("");
  const [pendingDateChanges, setPendingDateChanges] = useState<Array<{ field: string; oldDate: string; newDate: string }>>([]);
  const [showReasonDialog, setShowReasonDialog] = useState(false);
  const [pendingFormData, setPendingFormData] = useState<FormData | null>(null);
  
  // Collapsed main milestones map
  const [collapsedGates, setCollapsedGates] = useState<Record<string, boolean>>({});
  
  // T0 Editor modal state
  const [isT0ModalOpen, setIsT0ModalOpen] = useState(false);
  const [tempT0, setTempT0] = useState(t0StartStr);
  const [isT0Saving, setIsT0Saving] = useState(false);

  // Date History modal states
  const [historyMilestoneId, setHistoryMilestoneId] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  // Calculate dates from offset helper
  const calculateDates = (offsetStart: number, offsetEnd: number) => {
    const t0 = new Date(t0StartStr + "T00:00:00");
    const resolvedStart = startOfMonth(addMonths(t0, offsetStart));
    const resolvedEnd = endOfMonth(addMonths(t0, offsetEnd));
    return {
      startdate: format(resolvedStart, "yyyy-MM-dd"),
      targetedcompletiondate: format(resolvedEnd, "yyyy-MM-dd"),
    };
  };

  // Build Hierarchical Structure
  const mainMilestones = useMemo(() => {
    return items.filter((m) => m.parentMilestoneId === null)
                .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd);
  }, [items]);

  const getSubMilestones = (parentId: string) => {
    return items.filter((m) => m.parentMilestoneId === parentId)
                .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd);
  };

  // Collapsed management
  const toggleCollapse = (id: string) => {
    setCollapsedGates((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Payment Calculations
  const paymentSummary = useMemo(() => {
    const advance = 20; // 20% flat advance
    const completedSubPercent = items
      .filter((m) => m.parentMilestoneId !== null && m.status === "Completed")
      .reduce((sum, m) => sum + m.paymentPercentage, 0);

    const totalInvoiced = advance + completedSubPercent;
    const totalPotential = 100;
    
    // Find next upcoming payment milestone
    const upcoming = items
      .filter((m) => m.parentMilestoneId !== null && m.status !== "Completed" && m.paymentPercentage > 0)
      .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd)[0];

    return {
      totalInvoiced,
      totalPotential,
      upcoming,
    };
  }, [items]);

  const openAddDialog = () => {
    reset({
      name: "",
      t0OffsetStart: 0,
      t0OffsetEnd: 1,
      deliverable: "",
      paymentPercentage: 0,
      parentMilestoneId: null,
      ownerorgnodeid: orgNodes[0]?.programmeorgnodeid || "",
      status: "Not Started",
      remarks: "",
    });
    setEditingId(null);
    setIsDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    const item = items.find((m) => m.milestoneid === id);
    if (item) {
      reset({
        name: item.name,
        t0OffsetStart: item.t0OffsetStart,
        t0OffsetEnd: item.t0OffsetEnd,
        deliverable: item.deliverable,
        paymentPercentage: item.paymentPercentage,
        parentMilestoneId: item.parentMilestoneId,
        ownerorgnodeid: item.ownerorgnodeid,
        status: item.status,
        remarks: item.remarks,
      });
      setEditingId(id);
      setIsDialogOpen(true);
    }
  };

  const onSubmit = async (data: FormData) => {
    const dates = calculateDates(data.t0OffsetStart, data.t0OffsetEnd);
    const finalData = {
      ...data,
      startdate: dates.startdate,
      originaltargetedcompletiondate: dates.targetedcompletiondate,
      targetedcompletiondate: dates.targetedcompletiondate,
    };

    if (editingId) {
      const existing = items.find((m) => m.milestoneid === editingId);
      if (existing && existing.targetedcompletiondate !== finalData.targetedcompletiondate) {
        setPendingDateChanges([
          {
            field: "targetedcompletiondate",
            oldDate: existing.targetedcompletiondate,
            newDate: finalData.targetedcompletiondate,
          }
        ]);
        setPendingFormData(data);
        setDateChangeReason("");
        setShowReasonDialog(true);
        return;
      }
    }
    await saveData(data, "");
  };

  const saveData = async (formData: FormData, reason: string) => {
    setIsSaving(true);
    try {
      const computedDates = calculateDates(formData.t0OffsetStart, formData.t0OffsetEnd);
      
      const payload = {
        ...formData,
        startdate: computedDates.startdate,
        targetedcompletiondate: computedDates.targetedcompletiondate,
        originaltargetedcompletiondate: computedDates.targetedcompletiondate,
        remarks: formData.remarks || "",
      };

      await new Promise((r) => setTimeout(r, 400));
      
      if (editingId) {
        const existing = items.find((m) => m.milestoneid === editingId)!;
        if (reason && pendingDateChanges.length > 0) {
          addDateChangeLog({
            programmeid: programmeId,
            module: "milestone",
            recordid: editingId,
            recordname: existing.name,
            fieldname: "targetedcompletiondate",
            olddate: pendingDateChanges[0].oldDate,
            newdate: pendingDateChanges[0].newDate,
            reason,
          });
        }
        updateMilestone(editingId, {
          ...payload,
          changecount: existing.changecount + (pendingDateChanges.length > 0 ? 1 : 0),
          lastchangereason: reason || existing.lastchangereason,
        });
        toast.success("Milestone updated successfully");
      } else {
        addMilestone({
          ...payload,
          programmeid: programmeId,
        });
        toast.success("Milestone added successfully");
      }
      setIsDialogOpen(false);
      setPendingDateChanges([]);
      setPendingFormData(null);
    } catch {
      toast.error("Failed to save milestone");
    } finally {
      setIsSaving(false);
    }
  };

  const handleReasonConfirm = async () => {
    if (!dateChangeReason.trim()) return;
    setShowReasonDialog(false);
    if (pendingFormData) {
      await saveData(pendingFormData, dateChangeReason.trim());
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      await new Promise((r) => setTimeout(r, 400));
      deleteMilestone(deleteTarget);
      toast.success("Milestone deleted successfully");
      setDeleteTarget(null);
    } catch {
      toast.error("Failed to delete milestone");
    } finally {
      setIsDeleting(false);
    }
  };

  // Base date shifter trigger
  const handleT0Shift = async () => {
    setIsT0Saving(true);
    try {
      // 1. Update t0Start in config
      updateProgrammeConfig({ t0Start: tempT0 });
      
      // 2. Loop over and recalculate actual target dates for all milestones in the store
      // Since recalculating depends on the offsets stored in milestones, we trigger updates
      for (const m of items) {
        const t0 = new Date(tempT0 + "T00:00:00");
        const newStart = startOfMonth(addMonths(t0, m.t0OffsetStart));
        const newEnd = endOfMonth(addMonths(t0, m.t0OffsetEnd));
        updateMilestone(m.milestoneid, {
          startdate: format(newStart, "yyyy-MM-dd"),
          targetedcompletiondate: format(newEnd, "yyyy-MM-dd"),
          originaltargetedcompletiondate: format(newEnd, "yyyy-MM-dd"),
        });
      }
      
      toast.success("T0 timeline baseline adjusted. Dates shifted successfully.");
      setIsT0ModalOpen(false);
    } catch {
      toast.error("Failed to shift T0 timeline");
    } finally {
      setIsT0Saving(false);
    }
  };

  const getOwnerName = (nodeId: string) =>
    orgNodes.find((n) => n.programmeorgnodeid === nodeId)?.displayname || "—";

  const formatDate = (d: string) => {
    if (!d) return "—";
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <div className="flex flex-col gap-5 pt-4">
      {/* ── TOP ACTION HEADER ── */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/5 dark:bg-slate-900/40 p-4.5 rounded-xl border">
        <div>
          <h3 className="text-lg font-bold tracking-tight">Relative Milestones (T0 Roadmap)</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            Timeline offsets mapped to baseline T0 start. Calendar dates shift dynamically based on T0.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={() => { setTempT0(t0StartStr); setIsT0ModalOpen(true); }} className="gap-2">
            <Settings className="size-3.5 text-indigo-500" />
            Set T0: {formatDate(t0StartStr)}
          </Button>
          <Button onClick={openAddDialog} className="gap-2">
            <Plus className="size-4" /> Add Deliverable
          </Button>
        </div>
      </div>

      {/* ── PAYMENT & COMPLETION SUMMARY ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-indigo-500/20 bg-indigo-500/5">
          <CardContent className="pt-4 pb-4 px-4 flex items-center gap-3.5">
            <div className="p-3 bg-indigo-500/10 rounded-xl">
              <BadgePercent className="size-6 text-indigo-500" />
            </div>
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Payments Released</span>
              <h4 className="text-2xl font-extrabold tabular-nums text-indigo-600 dark:text-indigo-400">
                {paymentSummary.totalInvoiced}% <span className="text-xs text-muted-foreground font-normal">released</span>
              </h4>
              <p className="text-[10px] text-muted-foreground mt-0.5">Includes 20% advance payment</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-500/20 bg-emerald-500/5">
          <CardContent className="pt-4 pb-4 px-4 flex items-center gap-3.5">
            <div className="p-3 bg-emerald-500/10 rounded-xl">
              <CheckCircle className="size-6 text-emerald-500" />
            </div>
            <div>
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Sub-milestones Completed</span>
              <h4 className="text-2xl font-extrabold tabular-nums text-emerald-600 dark:text-emerald-400">
                {items.filter(m => m.parentMilestoneId !== null && m.status === "Completed").length} <span className="text-xs text-muted-foreground font-normal">of {items.filter(m => m.parentMilestoneId !== null).length} done</span>
              </h4>
              <p className="text-[10px] text-muted-foreground mt-0.5">10 main phases overall</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber-500/20 bg-amber-500/5">
          <CardContent className="pt-4 pb-4 px-4 flex items-center gap-3.5">
            <div className="p-3 bg-amber-500/10 rounded-xl">
              <CircleDollarSign className="size-6 text-amber-500" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Next Payment Event</span>
              {paymentSummary.upcoming ? (
                <div className="truncate">
                  <h4 className="text-sm font-bold text-amber-600 dark:text-amber-400 truncate leading-snug">
                    {paymentSummary.upcoming.name}
                  </h4>
                  <p className="text-[10px] text-muted-foreground">
                    Val: <strong className="text-foreground">{paymentSummary.upcoming.paymentPercentage}%</strong> · Offset: <strong className="text-foreground">T0+{paymentSummary.upcoming.t0OffsetEnd}M</strong>
                  </p>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground py-1">No pending payments.</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── HIERARCHICAL GATES & SUB-MILESTONES TABLE ── */}
      <div className="rounded-md border bg-card overflow-hidden">
        <Table>
          <TableHeader className="bg-slate-500/5">
            <TableRow>
              <TableHead className="w-[32px]"></TableHead>
              <TableHead className="min-w-[200px]">Milestone / Deliverable</TableHead>
              <TableHead className="w-[100px] text-center">Offset</TableHead>
              <TableHead className="w-[180px] text-center">Dates (Baseline)</TableHead>
              <TableHead className="min-w-[200px]">Contractual Deliverables</TableHead>
              <TableHead className="w-[100px] text-center">Payment %</TableHead>
              <TableHead className="w-[110px] text-center">Status</TableHead>
              <TableHead className="w-[130px]">Owner</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mainMilestones.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="h-28 text-center text-muted-foreground">
                  No main milestones seeded. Press "Add Deliverable" to build the T0 timeline.
                </TableCell>
              </TableRow>
            ) : (
              mainMilestones.map((gate) => {
                const subMilestones = getSubMilestones(gate.milestoneid);
                const isCollapsed = collapsedGates[gate.milestoneid] === true;
                
                // Determine Main Gate overall status based on sub-milestones
                let gateStatus = "Not Started";
                const subStatuses = subMilestones.map(s => s.status);
                if (subStatuses.length > 0) {
                  if (subStatuses.includes("At Risk")) gateStatus = "At Risk";
                  else if (subStatuses.includes("Delayed")) gateStatus = "Delayed";
                  else if (subStatuses.every(s => s === "Completed")) gateStatus = "Completed";
                  else if (subStatuses.includes("In Progress") || subStatuses.includes("Completed")) gateStatus = "In Progress";
                } else {
                  gateStatus = gate.status;
                }

                return (
                  <>
                    {/* Main Gate Row */}
                    <TableRow key={gate.milestoneid} className="bg-slate-500/5 hover:bg-slate-500/10 font-medium">
                      <TableCell className="p-0 text-center">
                        {subMilestones.length > 0 && (
                          <button onClick={() => toggleCollapse(gate.milestoneid)} className="p-2 cursor-pointer">
                            <ChevronRight 
                              className={`size-4 text-slate-500 transition-transform duration-200 ${
                                !isCollapsed ? "rotate-90" : ""
                              }`} 
                            />
                          </button>
                        )}
                      </TableCell>
                      <TableCell className="font-semibold text-slate-900 dark:text-slate-100 py-3">
                        <div className="flex items-center gap-2">
                          <Award className="size-4 text-indigo-500 shrink-0" />
                          <span>{gate.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center font-mono text-xs text-indigo-600 dark:text-indigo-400">
                        T0 + {gate.t0OffsetStart}M to T0 + {gate.t0OffsetEnd}M
                      </TableCell>
                      <TableCell className="text-center text-xs whitespace-nowrap tabular-nums">
                        {formatDate(gate.startdate)} <span className="text-slate-400">→</span> {formatDate(gate.targetedcompletiondate)}
                      </TableCell>
                      <TableCell className="text-xs text-slate-600 dark:text-slate-400 italic">
                        {gate.deliverable || "—"}
                      </TableCell>
                      <TableCell className="text-center font-semibold text-xs text-slate-400">
                        —
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={`${STATUS_COLORS[gateStatus] || "bg-muted"} text-[10px] px-2 py-0.5`}>
                          {gateStatus}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs">
                        {getOwnerName(gate.ownerorgnodeid)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" onClick={() => openEditDialog(gate.milestoneid)}>
                            <Pencil className="size-3.5" />
                          </Button>
                          <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => setDeleteTarget(gate.milestoneid)}>
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Sub-milestone Rows */}
                    <TableRow className="border-0 hover:bg-transparent data-[state=selected]:bg-transparent">
                      <TableCell colSpan={9} className="p-0 border-0">
                        <AnimatePresence initial={false}>
                          {!isCollapsed && subMilestones.length > 0 && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.22, ease: [0.4, 0, 0.2, 1] }}
                              className="overflow-hidden bg-slate-500/[0.02] dark:bg-slate-900/10 border-b"
                            >
                              <Table className="table-fixed w-full">
                                <colgroup>
                                  <col style={{ width: "32px" }} />
                                  <col style={{ minWidth: "200px" }} />
                                  <col style={{ width: "100px" }} />
                                  <col style={{ width: "180px" }} />
                                  <col style={{ minWidth: "200px" }} />
                                  <col style={{ width: "100px" }} />
                                  <col style={{ width: "110px" }} />
                                  <col style={{ width: "130px" }} />
                                  <col style={{ width: "100px" }} />
                                </colgroup>
                                <TableBody>
                                  {subMilestones.map((sub) => {
                                    const isDateShifted = sub.targetedcompletiondate !== sub.originaltargetedcompletiondate;
                                    return (
                                      <TableRow key={sub.milestoneid} className="hover:bg-muted/40 transition-colors border-b last:border-b-0">
                                        <TableCell className="py-2.5"></TableCell>
                                        <TableCell className="pl-6 text-xs font-medium text-foreground py-2.5">
                                          <div className="flex items-center gap-2">
                                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                                            <span>{sub.name}</span>
                                          </div>
                                        </TableCell>
                                        <TableCell className="text-center font-mono text-[10px] text-muted-foreground py-2.5">
                                          T0 + {sub.t0OffsetEnd}M
                                        </TableCell>
                                        <TableCell className="text-center text-xs whitespace-nowrap tabular-nums font-semibold py-2.5">
                                          {isDateShifted ? (
                                            <button onClick={() => setHistoryMilestoneId(sub.milestoneid)} className="flex items-center gap-1.5 mx-auto hover:underline cursor-pointer group transition-colors">
                                              <span className="text-amber-600">{formatDate(sub.targetedcompletiondate)}</span>
                                              <AlertTriangle className="size-3 text-amber-500" />
                                            </button>
                                          ) : (
                                            formatDate(sub.targetedcompletiondate)
                                          )}
                                        </TableCell>
                                        <TableCell className="text-xs text-muted-foreground truncate max-w-[220px] py-2.5" title={sub.deliverable}>
                                          {sub.deliverable}
                                        </TableCell>
                                        <TableCell className="text-center text-xs font-mono font-bold text-indigo-500 py-2.5">
                                          {sub.paymentPercentage > 0 ? `${sub.paymentPercentage}%` : "—"}
                                        </TableCell>
                                        <TableCell className="text-center py-2.5">
                                          <Badge className={`${STATUS_COLORS[sub.status] || "bg-muted"} text-[9px] px-1.5 py-0`}>
                                            {sub.status}
                                          </Badge>
                                        </TableCell>
                                        <TableCell className="text-xs text-muted-foreground py-2.5">
                                          {getOwnerName(sub.ownerorgnodeid)}
                                        </TableCell>
                                        <TableCell className="text-right py-2.5">
                                          <div className="flex items-center justify-end gap-1">
                                            <Button variant="ghost" size="icon" onClick={() => openEditDialog(sub.milestoneid)}>
                                              <Pencil className="size-3.5" />
                                            </Button>
                                            <Button variant="ghost" size="icon" className="text-destructive hover:bg-destructive/10" onClick={() => setDeleteTarget(sub.milestoneid)}>
                                              <Trash2 className="size-3.5" />
                                            </Button>
                                          </div>
                                        </TableCell>
                                      </TableRow>
                                    );
                                  })}
                                </TableBody>
                              </Table>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </TableCell>
                    </TableRow>
                  </>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* ── T0 TIMELINE CONFIGURATION MODAL ── */}
      <Dialog modal={false} open={isT0ModalOpen} onOpenChange={setIsT0ModalOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Set T0 Base Date</DialogTitle>
            <DialogDescription>
              Changing T0 shifts the calendar timelines for all relative milestones.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Field>
              <Label>T0 Start Date</Label>
              <DatePicker value={tempT0} onChange={(val) => setTempT0(val || "2026-09-01")} placeholder="Select baseline date" />
            </Field>
          </div>
          <DialogFooter>
            <DialogClose asChild><Button variant="outline" disabled={isT0Saving}>Cancel</Button></DialogClose>
            <Button onClick={handleT0Shift} disabled={isT0Saving}>
              {isT0Saving && <Spinner data-icon="inline-start" />} Apply Shift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── ADD/EDIT DIALOG ── */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>{editingId ? "Edit Milestone Item" : "Add Milestone Item"}</DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh] pr-4">
            <form onSubmit={handleSubmit(onSubmit)}>
              <FieldGroup>
                <Field data-invalid={!!errors.name || undefined}>
                  <Label htmlFor="ms-name">Milestone / Deliverable Name</Label>
                  <Input id="ms-name" {...register("name")} placeholder="e.g., Preliminary Design Freeze" />
                  {errors.name && <FieldError>{errors.name.message}</FieldError>}
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.t0OffsetStart || undefined}>
                    <Label htmlFor="ms-offset-start">T0 Offset Start (Months)</Label>
                    <Input id="ms-offset-start" type="number" {...register("t0OffsetStart")} />
                    {errors.t0OffsetStart && <FieldError>{errors.t0OffsetStart.message}</FieldError>}
                  </Field>
                  <Field data-invalid={!!errors.t0OffsetEnd || undefined}>
                    <Label htmlFor="ms-offset-end">T0 Offset End (Months)</Label>
                    <Input id="ms-offset-end" type="number" {...register("t0OffsetEnd")} />
                    {errors.t0OffsetEnd && <FieldError>{errors.t0OffsetEnd.message}</FieldError>}
                  </Field>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.parentMilestoneId || undefined}>
                    <Label>Parent Milestone (Main Gate)</Label>
                    <Controller
                      control={control}
                      name="parentMilestoneId"
                      render={({ field }) => {
                        const itemsList = mainMilestones.filter(m => m.milestoneid !== editingId);
                        const selectedVal = field.value || null;
                        const selectedLabel = itemsList.find(i => i.milestoneid === selectedVal)?.name || "Main Milestone (None)";
                        return (
                          <Combobox
                            value={selectedVal ? selectedLabel : "Main Milestone (None)"}
                            onValueChange={(label) => {
                              const found = itemsList.find(i => i.name === label);
                              field.onChange(found ? found.milestoneid : null);
                            }}
                            items={["Main Milestone (None)", ...itemsList.map(i => i.name)]}
                          >
                            <ComboboxInput placeholder="Select parent" />
                            <ComboboxContent>
                              <ComboboxList>
                                {(item) => <ComboboxItem key={item} value={item}>{item}</ComboboxItem>}
                              </ComboboxList>
                            </ComboboxContent>
                          </Combobox>
                        );
                      }}
                    />
                  </Field>
                  <Field data-invalid={!!errors.paymentPercentage || undefined}>
                    <Label htmlFor="ms-payment">Payment Percentage (%)</Label>
                    <Input id="ms-payment" type="number" {...register("paymentPercentage")} placeholder="0" />
                    {errors.paymentPercentage && <FieldError>{errors.paymentPercentage.message}</FieldError>}
                  </Field>
                </div>

                <Field data-invalid={!!errors.deliverable || undefined}>
                  <Label htmlFor="ms-deliv">Contractual Deliverable Details</Label>
                  <Input id="ms-deliv" {...register("deliverable")} placeholder="e.g. 2 sets of XY Unit, Acceptance Certificate" />
                  {errors.deliverable && <FieldError>{errors.deliverable.message}</FieldError>}
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.status || undefined}>
                    <Label>Status</Label>
                    <Controller
                      control={control}
                      name="status"
                      render={({ field }) => (
                        <Combobox
                          value={field.value || null}
                          onValueChange={(v: string | null) => field.onChange(v ?? "")}
                          items={statusItems}
                        >
                          <ComboboxInput placeholder="Select status" />
                          <ComboboxContent>
                            <ComboboxList>
                              {(item: string) => <ComboboxItem key={item} value={item}>{item}</ComboboxItem>}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      )}
                    />
                    {errors.status && <FieldError>{errors.status.message}</FieldError>}
                  </Field>
                  
                  <Field data-invalid={!!errors.ownerorgnodeid || undefined}>
                    <Label>Owner</Label>
                    <Controller
                      control={control}
                      name="ownerorgnodeid"
                      render={({ field }) => {
                        const selectedName = orgNodes.find((n) => n.programmeorgnodeid === field.value)?.displayname ?? null;
                        return (
                          <Combobox
                            value={selectedName}
                            onValueChange={(name: string | null) => {
                              const node = orgNodes.find((n) => n.displayname === name);
                              field.onChange(node?.programmeorgnodeid ?? "");
                            }}
                            items={orgNodeNames}
                          >
                            <ComboboxInput placeholder="Select owner" />
                            <ComboboxContent>
                              <ComboboxList>
                                {(name: string) => <ComboboxItem key={name} value={name}>{name}</ComboboxItem>}
                              </ComboboxList>
                            </ComboboxContent>
                          </Combobox>
                        );
                      }}
                    />
                    {errors.ownerorgnodeid && <FieldError>{errors.ownerorgnodeid.message}</FieldError>}
                  </Field>
                </div>

                <Field>
                  <Label htmlFor="ms-remarks">Remarks</Label>
                  <Textarea id="ms-remarks" {...register("remarks")} placeholder="Additional notes..." />
                </Field>
              </FieldGroup>

              <DialogFooter className="mt-6">
                <DialogClose asChild><Button type="button" variant="outline" disabled={isSaving}>Cancel</Button></DialogClose>
                <Button type="submit" disabled={isSaving}>
                  {isSaving && <Spinner data-icon="inline-start" />} Save
                </Button>
              </DialogFooter>
            </form>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* ── DATE AUDIT REASON DIALOG ── */}
      <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Date Shift Reason Required</DialogTitle>
            <DialogDescription>
              Modifying T0 offsets changes baseline schedules. Please log a reason for this audit event.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            {pendingDateChanges.map((c) => (
              <div key={c.field} className="flex items-center gap-2 text-xs rounded-lg bg-muted px-3 py-2">
                <span className="text-muted-foreground font-semibold">Target:</span>
                <span className="line-through text-red-500">{formatDate(c.oldDate)}</span>
                <ArrowRight className="size-3 text-muted-foreground" />
                <span className="font-bold">{formatDate(c.newDate)}</span>
              </div>
            ))}
          </div>
          <FieldGroup>
            <Field>
              <Label htmlFor="change-reason">Reason</Label>
              <Textarea id="change-reason" value={dateChangeReason} onChange={(e) => setDateChangeReason(e.target.value)} placeholder="e.g., Fabrication assembly delayed..." />
            </Field>
          </FieldGroup>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowReasonDialog(false); setPendingDateChanges([]); setPendingFormData(null); }}>Cancel</Button>
            <Button onClick={handleReasonConfirm} disabled={!dateChangeReason.trim()}>Confirm & Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DATE HISTORY MODAL ── */}
      <Dialog open={!!historyMilestoneId} onOpenChange={(open) => !open && setHistoryMilestoneId(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Shift History Log</DialogTitle>
            <DialogDescription>
              Chronological schedule changes audited for this sub-milestone.
            </DialogDescription>
          </DialogHeader>

          {historyMilestoneId && dateChangeLogs.filter((l) => l.recordid === historyMilestoneId && l.module === "milestone").length === 0 ? (
            <div className="py-8 text-center text-muted-foreground text-xs">
              No date changes logged yet for this milestone.
            </div>
          ) : (
            <ScrollArea className="max-h-[50vh] pr-2">
              <div className="flex flex-col gap-3">
                {historyMilestoneId && dateChangeLogs
                  .filter((l) => l.recordid === historyMilestoneId && l.module === "milestone")
                  .sort((a, b) => new Date(b.changedon).getTime() - new Date(a.changedon).getTime())
                  .map((log) => (
                    <div key={log.datechangelogid} className="rounded-lg border px-4 py-3 bg-muted/20">
                      <div className="flex items-center justify-between mb-1.5">
                        <Badge variant="secondary" className="text-[10px] font-normal">Target Date Shifted</Badge>
                        <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                          <Clock className="size-3" /> {new Date(log.changedon).toLocaleString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="line-through text-red-500">{formatDate(log.olddate)}</span>
                        <ArrowRight className="size-3 text-muted-foreground" />
                        <span className="font-semibold text-emerald-600">{formatDate(log.newdate)}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1.5 italic">"{log.reason}"</p>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setHistoryMilestoneId(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DELETE ALERT ── */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && !isDeleting && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete this milestone. If you delete a parent milestone, all nested sub-milestones will also be removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button variant="destructive" disabled={isDeleting} onClick={handleDelete}>
              {isDeleting && <Spinner data-icon="inline-start" />} Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
