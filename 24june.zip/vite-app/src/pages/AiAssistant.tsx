import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertTriangle,
  ArrowDown,
  BarChart3,
  CalendarClock,
  Check,
  Copy,
  Database,
  Flag,
  Loader2,
  MessageSquare,
  Plus,
  Send,
  Sparkles,
  Trash2,
  User,
  Users,
  WalletCards,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SUGGESTED_PROMPTS, SPIN_VERBS } from "@/features/ai-assistant/constants";
import { buildSystemContext } from "@/features/ai-assistant/context";
import { hasGeminiApiKey, requestAssistantReply } from "@/features/ai-assistant/gemini";
import { renderMarkdown, toPlainText } from "@/features/ai-assistant/markdown";
import type { ChatMessage, Conversation, SuggestedPrompt } from "@/features/ai-assistant/types";
import { useAppStore } from "@/lib/store";

const promptIcons = {
  flag: Flag,
  wallet: WalletCards,
  chart: BarChart3,
  alert: AlertTriangle,
  calendar: CalendarClock,
  users: Users,
} satisfies Record<SuggestedPrompt["icon"], React.ComponentType<{ className?: string }>>;

function createId(prefix: string) {
  if (crypto.randomUUID) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  return `${prefix}-${Date.now().toString(36)}`;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    await navigator.clipboard.writeText(toPlainText(text));
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      type="button"
      onClick={copy}
      className="rounded-md p-1 text-muted-foreground/40 transition-all hover:bg-muted/80 hover:text-muted-foreground"
      title="Copy"
    >
      {copied ? <Check className="size-3 text-emerald-500" /> : <Copy className="size-3" />}
    </button>
  );
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const isUser = message.role === "user";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 380, damping: 30 }}
      className={`group flex items-start gap-2.5 ${isUser ? "flex-row-reverse" : ""}`}
    >
      <div
        className={`mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg ${
          isUser
            ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground"
            : "bg-gradient-to-br from-violet-500/20 to-blue-500/20 ring-1 ring-violet-500/20 dark:from-violet-500/30 dark:to-blue-500/30 dark:ring-violet-400/30"
        }`}
      >
        {isUser ? <User className="size-3" /> : <Sparkles className="size-3 text-violet-600 dark:text-violet-300" />}
      </div>

      <div className={`min-w-0 ${isUser ? "max-w-[70%]" : "max-w-[90%]"}`}>
        <div
          className={`relative rounded-2xl px-4 py-2.5 ${
            isUser
              ? "rounded-tr-sm bg-primary text-primary-foreground"
              : "rounded-tl-sm border border-border/50 bg-card shadow-sm dark:border-border dark:bg-card/80 dark:shadow-md"
          }`}
        >
          <p className={`mb-1 text-[9px] font-medium ${isUser ? "text-primary-foreground/60" : "text-violet-600/70 dark:text-violet-400/70"}`}>
            {isUser ? "You" : "AI Assistant"} - {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>

          {isUser ? (
            <p className="text-[13px] leading-relaxed">{message.content}</p>
          ) : (
            <div className="text-foreground/80 dark:text-foreground/85">{renderMarkdown(message.content)}</div>
          )}

          {!isUser && (
            <div className="absolute -bottom-3 right-2 flex gap-0.5 rounded-lg border bg-background p-0.5 opacity-0 shadow-sm transition-opacity group-hover:opacity-100">
              <CopyButton text={message.content} />
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function TypingIndicator() {
  const [verbIndex, setVerbIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setVerbIndex((current) => (current + 1) % SPIN_VERBS.length);
    }, 2000);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="flex items-start gap-2.5"
    >
      <div className="relative mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/20 to-blue-500/20 ring-1 ring-violet-500/20 dark:from-violet-500/30 dark:to-blue-500/30 dark:ring-violet-400/30">
        <motion.div
          className="absolute inset-0 rounded-lg bg-violet-500/20"
          animate={{ scale: [1, 1.4, 1], opacity: [0.3, 0, 0.3] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        />
        <Sparkles className="relative z-10 size-3 text-violet-600 dark:text-violet-300" />
      </div>

      <div className="rounded-2xl rounded-tl-sm border border-border/50 bg-card px-4 py-2.5 shadow-sm dark:border-border dark:bg-card/80 dark:shadow-md">
        <div className="flex items-center gap-2.5">
          <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
            <Loader2 className="size-4 text-violet-500" />
          </motion.div>
          <AnimatePresence mode="wait">
            <motion.span
              key={verbIndex}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="text-xs font-medium text-muted-foreground"
            >
              {SPIN_VERBS[verbIndex]}
            </motion.span>
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

export function AiAssistant() {
  const store = useAppStore();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [greetingHour] = useState(() => new Date().getHours());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const activeConversation = conversations.find((conversation) => conversation.id === activeConversationId) ?? null;
  const systemContext = useMemo(() => buildSystemContext(store), [store]);
  const greeting = greetingHour < 12 ? "morning" : greetingHour < 17 ? "afternoon" : "evening";

  const dataStats = useMemo(
    () => ({
      milestones: store.milestones.length,
      support: store.supportRequired.length,
      certs: store.certifications.length,
    }),
    [store.certifications.length, store.milestones.length, store.supportRequired.length],
  );

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [activeConversation?.messages.length, scrollToBottom]);

  const handleScroll = useCallback(() => {
    const element = chatContainerRef.current;
    if (!element) return;

    setShowScrollButton(element.scrollHeight - element.scrollTop - element.clientHeight > 80);
  }, []);

  const newConversation = useCallback(() => {
    const conversation: Conversation = {
      id: createId("conv"),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
    };

    setConversations((current) => [conversation, ...current]);
    setActiveConversationId(conversation.id);
    setInput("");
    window.setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const deleteConversation = useCallback((id: string) => {
    setConversations((current) => current.filter((conversation) => conversation.id !== id));
    setActiveConversationId((currentId) => (currentId === id ? null : currentId));
  }, []);

  const sendMessage = useCallback(
    async (text?: string) => {
      const messageText = (text ?? input).trim();
      if (!messageText || isLoading) return;

      let conversationId = activeConversationId;
      const createdConversation = !conversationId
        ? {
            id: createId("conv"),
            title: messageText.slice(0, 50),
            messages: [],
            createdAt: new Date(),
          }
        : null;

      if (createdConversation) {
        conversationId = createdConversation.id;
        setConversations((current) => [createdConversation, ...current]);
        setActiveConversationId(conversationId);
      }

      const userMessage: ChatMessage = {
        id: createId("msg"),
        role: "user",
        content: messageText,
        timestamp: new Date(),
      };

      setConversations((current) =>
        current.map((conversation) =>
          conversation.id === conversationId
            ? {
                ...conversation,
                messages: [...conversation.messages, userMessage],
                title: conversation.messages.length === 0 ? messageText.slice(0, 50) : conversation.title,
              }
            : conversation,
        ),
      );
      setInput("");
      setIsLoading(true);

      try {
        const currentConversation = conversations.find((conversation) => conversation.id === conversationId);
        const history = currentConversation?.messages ?? [];
        const minimumSpinnerTime = new Promise((resolve) => window.setTimeout(resolve, 1200));

        const [assistantText] = await Promise.all([
          requestAssistantReply({ history, systemContext, userText: messageText }),
          minimumSpinnerTime,
        ]);

        const assistantMessage: ChatMessage = {
          id: createId("msg"),
          role: "assistant",
          content: assistantText,
          timestamp: new Date(),
        };

        setConversations((current) =>
          current.map((conversation) =>
            conversation.id === conversationId
              ? { ...conversation, messages: [...conversation.messages, assistantMessage] }
              : conversation,
          ),
        );
      } catch (error) {
        const errorMessage: ChatMessage = {
          id: createId("msg"),
          role: "assistant",
          content: `**Error:** ${error instanceof Error ? error.message : "Failed to get response"}\n\nPlease check the AI configuration and try again.`,
          timestamp: new Date(),
        };

        setConversations((current) =>
          current.map((conversation) =>
            conversation.id === conversationId
              ? { ...conversation, messages: [...conversation.messages, errorMessage] }
              : conversation,
          ),
        );
      } finally {
        setIsLoading(false);
      }
    },
    [activeConversationId, conversations, input, isLoading, systemContext],
  );

  const handleKeyDown = (event: React.KeyboardEvent) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  };

  return (
    <div className="-m-6 flex h-[calc(100vh-3rem)] min-h-0 overflow-hidden">
      <div className="flex min-h-0 w-56 max-w-[30%] shrink-0 flex-col border-r bg-muted/15">
        <div className="shrink-0 border-b p-2">
          <Button onClick={newConversation} className="h-8 w-full gap-1.5 rounded-lg text-[11px]" variant="outline">
            <Plus className="size-3" />
            New Chat
          </Button>
        </div>

        <ScrollArea className="min-h-0 flex-1">
          <div className="space-y-0.5 p-1.5">
            {conversations.length === 0 ? (
              <div className="px-3 py-8 text-center">
                <div className="mx-auto mb-2 flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500/10 to-blue-500/10">
                  <MessageSquare className="size-4 text-muted-foreground/30" />
                </div>
                <p className="text-[11px] font-medium text-muted-foreground">No conversations yet</p>
                <p className="mt-0.5 text-[10px] text-muted-foreground/60">Start a new chat</p>
              </div>
            ) : (
              conversations.map((conversation) => (
                <motion.button
                  key={conversation.id}
                  type="button"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  onClick={() => setActiveConversationId(conversation.id)}
                  className={`group flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left transition-all ${
                    activeConversationId === conversation.id
                      ? "border border-primary/10 bg-primary/8 text-foreground"
                      : "text-muted-foreground hover:bg-muted/40 hover:text-foreground"
                  }`}
                >
                  <MessageSquare className="size-3 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <span className="block truncate text-[11px] font-medium">{conversation.title}</span>
                    <span className="text-[9px] text-muted-foreground/60">{conversation.messages.length} messages</span>
                  </div>
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      deleteConversation(conversation.id);
                    }}
                    className="shrink-0 rounded p-0.5 text-destructive/60 opacity-0 transition-all hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                    title="Delete conversation"
                  >
                    <Trash2 className="size-2.5" />
                  </button>
                </motion.button>
              ))
            )}
          </div>
        </ScrollArea>

        <div className="shrink-0 border-t p-2">
          <div className="rounded-lg border border-violet-500/10 bg-gradient-to-br from-violet-500/[0.06] to-blue-500/[0.04] px-2.5 py-2">
            <div className="mb-1.5 flex items-center gap-1">
              <Database className="size-2.5 text-violet-500" />
              <span className="text-[9px] font-bold uppercase tracking-wider text-violet-600/80 dark:text-violet-400/80">Connected Data</span>
            </div>
            <div className="grid grid-cols-3 gap-x-2 gap-y-0.5">
              {[
                { label: "Miles", count: dataStats.milestones },
                { label: "Supp", count: dataStats.support },
                { label: "Certs", count: dataStats.certs },
              ].map((stat) => (
                <div key={stat.label} className="flex items-center justify-between">
                  <span className="text-[9px] text-muted-foreground">{stat.label}</span>
                  <span className="text-[9px] font-bold tabular-nums">{stat.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="relative flex min-h-0 min-w-0 flex-1 flex-col bg-background">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.015]"
          style={{
            backgroundImage: "radial-gradient(circle, currentColor 1px, transparent 1px)",
            backgroundSize: "24px 24px",
          }}
        />

        <div className="relative z-10 flex h-11 shrink-0 items-center gap-2.5 border-b bg-background/80 px-4 backdrop-blur-sm">
          <div className="relative">
            <div className="flex size-7 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/15 to-blue-500/15 ring-1 ring-violet-500/10">
              <Sparkles className="size-3.5 text-violet-600 dark:text-violet-300" />
            </div>
            <span className={`absolute -bottom-0.5 -right-0.5 size-2 rounded-full ring-2 ring-background ${hasGeminiApiKey ? "bg-emerald-500" : "bg-amber-500"}`} />
          </div>
          <div className="min-w-0">
            <h2 className="text-xs font-bold tracking-tight">Programme AI</h2>
            <p className="text-[9px] text-muted-foreground/70">
              {hasGeminiApiKey ? "Gemini - Full database access" : "Add VITE_GEMINI_API_KEY to enable AI replies"}
            </p>
          </div>
          <div className="ml-auto shrink-0">
            <div
              className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-semibold ${
                hasGeminiApiKey
                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                  : "bg-amber-500/10 text-amber-600 dark:text-amber-400"
              }`}
            >
              <span className={`size-1.5 rounded-full ${hasGeminiApiKey ? "animate-pulse bg-emerald-500" : "bg-amber-500"}`} />
              {hasGeminiApiKey ? "Online" : "Config needed"}
            </div>
          </div>
        </div>

        <div ref={chatContainerRef} onScroll={handleScroll} className="relative z-0 min-h-0 flex-1 overflow-y-auto">
          {!activeConversation || activeConversation.messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center px-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 25 }}
                className="w-full max-w-md text-center"
              >
                <div className="relative mx-auto mb-5 size-16">
                  <motion.div
                    className="absolute inset-0 rounded-2xl bg-gradient-to-br from-violet-500/20 to-blue-500/20 blur-xl"
                    animate={{ scale: [1, 1.15, 1], opacity: [0.4, 0.7, 0.4] }}
                    transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
                  />
                  <div className="relative flex size-16 items-center justify-center rounded-2xl border border-violet-500/15 bg-gradient-to-br from-violet-500/10 to-blue-500/10">
                    <Sparkles className="size-7 text-violet-500/80" />
                  </div>
                </div>

                <h2 className="mb-1 text-lg font-bold tracking-tight">Good {greeting}</h2>
                <p className="mx-auto mb-6 max-w-xs text-xs text-muted-foreground">
                  Ask me about milestones, budgets, risks, or anything in your programme data.
                </p>

                <div className="mx-auto grid max-w-md grid-cols-2 gap-2">
                  {SUGGESTED_PROMPTS.map((prompt, index) => {
                    const Icon = promptIcons[prompt.icon];

                    return (
                      <motion.button
                        key={prompt.title}
                        type="button"
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1 + index * 0.04, type: "spring", stiffness: 300, damping: 25 }}
                        onClick={() => sendMessage(prompt.text)}
                        className="group rounded-lg border border-border/50 bg-card/50 px-3 py-2.5 text-left transition-all duration-200 hover:border-primary/20 hover:bg-card hover:shadow-sm"
                      >
                        <div className="mb-1 flex items-center gap-1.5">
                          <Icon className="size-3 text-violet-500" />
                          <span className="text-[11px] font-semibold text-foreground transition-colors group-hover:text-primary">{prompt.title}</span>
                        </div>
                        <span className="line-clamp-2 text-[10px] leading-snug text-muted-foreground/70 transition-colors group-hover:text-muted-foreground">
                          {prompt.text}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>
              </motion.div>
            </div>
          ) : (
            <div className="mx-auto max-w-4xl space-y-4 px-5 py-4">
              {activeConversation.messages.map((message) => (
                <MessageBubble key={message.id} message={message} />
              ))}
              <AnimatePresence>{isLoading && <TypingIndicator />}</AnimatePresence>
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <AnimatePresence>
          {showScrollButton && (
            <motion.button
              type="button"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={scrollToBottom}
              className="absolute bottom-20 left-1/2 z-20 flex size-8 -translate-x-1/2 items-center justify-center rounded-full border bg-card shadow-lg transition-colors hover:bg-muted"
              title="Scroll to bottom"
            >
              <ArrowDown className="size-3.5 text-muted-foreground" />
            </motion.button>
          )}
        </AnimatePresence>

        <div className="relative z-10 shrink-0 border-t bg-background/80 px-4 py-2 backdrop-blur-sm">
          <div className="mx-auto max-w-4xl">
            <div className="flex items-center gap-2 rounded-xl border border-border/50 bg-card px-3 py-1.5 shadow-sm transition-all focus-within:border-primary/30 focus-within:shadow-md">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(event) => {
                  setInput(event.target.value);
                  event.target.style.height = "0";
                  event.target.style.height = `${Math.min(event.target.scrollHeight, 112)}px`;
                }}
                onKeyDown={handleKeyDown}
                placeholder={hasGeminiApiKey ? "Ask about your programmes..." : "Configure VITE_GEMINI_API_KEY to enable AI replies"}
                rows={1}
                className="flex-1 resize-none bg-transparent py-1 text-sm leading-snug outline-none placeholder:text-muted-foreground/40"
                style={{ height: "28px", maxHeight: "112px" }}
              />
              <Button
                size="icon-sm"
                onClick={() => sendMessage()}
                disabled={!input.trim() || isLoading}
                className="size-7 shrink-0 rounded-lg bg-gradient-to-r from-violet-600 to-blue-600 text-white shadow-sm transition-all hover:from-violet-500 hover:to-blue-500 disabled:from-muted disabled:to-muted disabled:opacity-30"
              >
                {isLoading ? <Loader2 className="size-3.5 animate-spin" /> : <Send className="size-3" />}
              </Button>
            </div>
            <p className="mt-1 text-center text-[9px] text-muted-foreground/40">Enter to send - Shift+Enter for new line</p>
          </div>
        </div>
      </div>
    </div>
  );
}
