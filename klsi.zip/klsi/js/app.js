/**
 * CV Screening Dashboard - Application Entry Point
 * Initializes the app and sets up event delegation
 */

const App = (() => {
    /**
     * Initializes the application.
     */
    const init = () => {
        lucide.createIcons();
        initTheme();
        initWeightsUI();
        initEventDelegation();
        initDropdownBehavior();
        initModalBehavior();
        initDragAndDrop();

        // Sync UI on filter reset
        AppState.on('filtersReset', () => {
            updateStatusCardHighlight('all');
        });
    };

    /**
     * Initializes theme from storage/preference.
     */
    const initTheme = () => {
        const saved = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const isDark = saved === 'dark' || (!saved && prefersDark);
        
        document.documentElement.classList.toggle('dark', isDark);
        updateThemeIcons(isDark);
    };

    /**
     * Toggles dark mode.
     */
    const toggleTheme = () => {
        const isDark = document.documentElement.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        updateThemeIcons(isDark);
        Utils.Toast.info(`Theme switched to ${isDark ? 'dark' : 'light'} mode`);
    };

    /**
     * Updates theme toggle icons.
     */
    const updateThemeIcons = (isDark) => {
        const sun = document.getElementById('sun-icon');
        const moon = document.getElementById('moon-icon');
        if (sun) sun.style.display = isDark ? 'none' : 'block';
        if (moon) moon.style.display = isDark ? 'block' : 'none';
    };

    /**
     * Updates status card highlight based on current filter.
     */
    const updateStatusCardHighlight = (activeStatus) => {
        document.querySelectorAll('.clickable-status').forEach(card => {
            const isSelected = card.dataset.status === activeStatus;
            card.classList.toggle('active', isSelected);
        });
    };

    /**
     * Initializes scoring weights UI.
     */
    const initWeightsUI = () => {
        const container = document.querySelector('.slider-group');
        if (!container) return;

        container.innerHTML = '';

        AppState.SCORING_PARAMS.forEach(param => {
            const weight = AppState.weights[param.id];
            const div = document.createElement('div');
            div.className = 'slider-item';
            div.innerHTML = `
                <div class="slider-header">
                    <span>${param.label}</span>
                    <span>
                        <span id="val-${param.id}" class="slider-value">${weight}</span>
                        <span id="pct-${param.id}" class="weight-percent">(25%)</span>
                    </span>
                </div>
                <input type="range" id="weight-${param.id}" min="0" max="10" value="${weight}" step="1" data-param="${param.id}">
            `;
            container.appendChild(div);

            const input = div.querySelector('input');
            Utils.updateSliderFill(input);
        });

        updateWeightPercentages();
    };

    /**
     * Updates weight percentage displays.
     */
    const updateWeightPercentages = () => {
        const total = AppState.getTotalWeight();

        AppState.SCORING_PARAMS.forEach(param => {
            const pct = total === 0 ? 0 : Math.round((AppState.weights[param.id] / total) * 100);
            const el = document.getElementById(`pct-${param.id}`);
            if (el) el.textContent = `(${pct}%)`;
        });
    };

    /**
     * Sets up event delegation for the entire app.
     */
    const initEventDelegation = () => {
        // File uploads
        document.addEventListener('change', (e) => {
            if (e.target.matches('#fileInput, #fileInputOverlay, #fileInputToolbar')) {
                DataProcessor.handleFileUpload(e);
            }
            if (e.target.matches('.col-visibility-checkbox')) {
                const idx = parseInt(e.target.dataset.idx);
                AppState.setColumnVisibility(idx, e.target.checked);
                UIRenderer.renderHeaders();
                UIRenderer.renderTable();
            }
        });

        // Slider input - real-time updates for visual feedback
        document.addEventListener('input', (e) => {
            // Slider fill updates (immediate, no debounce)
            if (e.target.matches('[data-param]')) {
                const paramId = e.target.dataset.param;
                const value = parseInt(e.target.value);
                
                // Update visual immediately
                Utils.updateSliderFill(e.target);
                document.getElementById(`val-${paramId}`).textContent = value;
                
                // Update weight in state
                AppState.setWeight(paramId, value);
                updateWeightPercentages();
            }
            
            // Search with debounce and clear button visibility
            if (e.target.matches('#search-text')) {
                const clearBtn = document.getElementById('search-clear-btn');
                if (clearBtn) {
                    clearBtn.style.display = e.target.value ? 'flex' : 'none';
                }
                handleSearchDebounced(e.target.value);
            }
        });

        // Slider change - recalculate only on release
        document.addEventListener('change', (e) => {
            if (e.target.matches('[data-param]')) {
                DataProcessor.recalculateAndRender();
            }
        });

        // Debounced search handler
        const handleSearchDebounced = Utils.debounce((value) => {
            AppState.setFilter('search', value.toLowerCase());
            DataProcessor.updateFilteredData();
            if (AppState.viewMode === 'table') {
                UIRenderer.renderTable();
            } else {
                UIRenderer.renderKanban();
            }
        }, 200);

        // Search clear button - use mousedown to prevent blur issues
        document.addEventListener('mousedown', (e) => {
            if (e.target.closest('#search-clear-btn')) {
                e.preventDefault(); // Prevent input from losing focus
                const searchInput = document.getElementById('search-text');
                const clearBtn = document.getElementById('search-clear-btn');
                if (searchInput) {
                    searchInput.value = '';
                    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                    searchInput.focus();
                }
                if (clearBtn) {
                    clearBtn.style.display = 'none';
                }
            }
        });

        // Click events
        document.addEventListener('click', (e) => {
            // Theme toggle
            if (e.target.closest('#theme-toggle')) {
                toggleTheme();
                return;
            }

            // Copy to Clipboard
            const copyBtn = e.target.closest('.btn-copy');
            if (copyBtn) {
                const text = copyBtn.dataset.copy;
                if (text) Utils.copyToClipboard(text, copyBtn);
                return;
            }

            // Status Card Filter
            const statusCard = e.target.closest('.clickable-status');
            if (statusCard) {
                const status = statusCard.dataset.status;
                const currentStatus = AppState.filters.status;
                const newStatus = currentStatus === status ? 'all' : status;

                // Sync with dropdown
                const statusDropdown = document.getElementById('filter-status');
                if (statusDropdown) statusDropdown.value = newStatus;

                AppState.setFilter('status', newStatus);
                DataProcessor.updateFilteredData();
                
                if (AppState.viewMode === 'table') {
                    UIRenderer.renderTable();
                } else {
                    UIRenderer.renderKanban();
                }
                
                updateStatusCardHighlight(newStatus);
                return;
            }

            // View tabs
            const viewTab = e.target.closest('.view-tab');
            if (viewTab) {
                const mode = viewTab.dataset.view.toLowerCase();
                setViewMode(mode);
                return;
            }

            // Export button
            if (e.target.closest('#export-btn')) {
                DataProcessor.exportToExcel();
                return;
            }

            // Export PDF button
            if (e.target.closest('#export-pdf-btn')) {
                DataProcessor.exportToPDF();
                return;
            }

            // Clear filters
            if (e.target.closest('#clear-filters-btn')) {
                DataProcessor.clearFilters();
                return;
            }

            // Pagination
            const pageBtn = e.target.closest('#pagination-controls [data-page]');
            if (pageBtn && !pageBtn.disabled) {
                AppState.setCurrentPage(parseInt(pageBtn.dataset.page));
                UIRenderer.renderTable();
                return;
            }

            // Page size selection
            const pageSizeItem = e.target.closest('#page-size-menu .dropdown-item');
            if (pageSizeItem) {
                AppState.setRowsPerPage(parseInt(pageSizeItem.dataset.value));
                UIRenderer.renderTable();
                document.getElementById('page-size-menu')?.classList.remove('show');
                return;
            }

            // Table row click (open modal)
            const tableRow = e.target.closest('#table-body tr');
            if (tableRow) {
                const id = tableRow.dataset.id;
                if (id) UIRenderer.showCandidateModal(id);
                return;
            }

            // Kanban card click
            const kanbanCard = e.target.closest('.k-card');
            if (kanbanCard) {
                const id = kanbanCard.dataset.id;
                if (id) UIRenderer.showCandidateModal(id);
                return;
            }

            // Header click to open dropdown (entire header area)
            const headerClickable = e.target.closest('.header-clickable');
            if (headerClickable) {
                e.stopPropagation();
                const colId = headerClickable.dataset.colId;
                closeAllDropdowns();
                const menu = document.getElementById(`dropdown-${colId}`);
                if (menu) menu.classList.toggle('show');
                return;
            }

            // Sort actions
            const sortAction = e.target.closest('.sort-action');
            if (sortAction) {
                e.stopPropagation();
                const colId = sortAction.dataset.id;
                const dir = parseInt(sortAction.dataset.dir);
                DataProcessor.sortTable(colId, dir);
                closeAllDropdowns();
                return;
            }

            // Hide column action
            const hideAction = e.target.closest('.hide-col-action');
            if (hideAction) {
                e.stopPropagation();
                const idx = parseInt(hideAction.dataset.idx);
                AppState.setColumnVisibility(idx, false);
                UIRenderer.renderHeaders();
                UIRenderer.renderTable();
                
                // Sync checkbox
                const cb = document.querySelector(`.col-visibility-checkbox[data-idx="${idx}"]`);
                if (cb) cb.checked = false;
                
                closeAllDropdowns();
                return;
            }

            // Column toggle dropdown
            if (e.target.closest('#col-toggle-btn')) {
                e.stopPropagation();
                document.getElementById('col-dropdown')?.classList.toggle('show');
                return;
            }

            // Page size trigger
            if (e.target.closest('#page-size-trigger')) {
                e.stopPropagation();
                document.getElementById('page-size-menu')?.classList.toggle('show');
                return;
            }
        });

        // Keyboard events
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                UIRenderer.closeCandidateModal();
                closeAllDropdowns();
            }
        });
    };

    /**
     * Closes all dropdown menus.
     */
    const closeAllDropdowns = () => {
        document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
            menu.classList.remove('show');
        });
    };

    /**
     * Initializes dropdown close-on-outside-click behavior.
     */
    const initDropdownBehavior = () => {
        document.addEventListener('click', (e) => {
            // Don't close if clicking on dropdown-related elements
            if (!e.target.closest('.dropdown') && 
                !e.target.closest('.dropdown-trigger') &&
                !e.target.closest('.header-clickable') &&
                !e.target.closest('#page-size-trigger') &&
                !e.target.closest('.dropdown-menu')) {
                closeAllDropdowns();
            }
        });
    };

    /**
     * Initializes modal behavior.
     */
    const initModalBehavior = () => {
        document.getElementById('modal-close-btn')?.addEventListener('click', UIRenderer.closeCandidateModal);
        document.getElementById('candidate-modal')?.addEventListener('click', (e) => {
            if (e.target.id === 'candidate-modal') {
                UIRenderer.closeCandidateModal();
            }
        });
    };

    /**
     * Sets view mode (table/board).
     */
    const setViewMode = (mode) => {
        if (AppState.viewMode === mode) return;
        AppState.setViewMode(mode);

        // Update tabs
        document.querySelectorAll('.view-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.view.toLowerCase() === mode);
        });

        // Sliders remain enabled in both views now

        // Toggle column dropdown
        const colWrapper = document.getElementById('col-toggle-wrapper');
        if (colWrapper) colWrapper.style.display = mode === 'board' ? 'none' : 'block';
        DataProcessor.recalculateAndRender();
        Utils.Toast.info(`Switched to ${mode} view`);
    };

    /**
     * Initializes drag and drop for Kanban.
     */
    const initDragAndDrop = () => {
        // Delegate drag events on kanban columns
        document.querySelectorAll('.kanban-col').forEach(col => {
            col.addEventListener('dragover', (e) => {
                e.preventDefault();
                col.classList.add('drag-over');
            });

            col.addEventListener('dragleave', () => {
                col.classList.remove('drag-over');
            });

            col.addEventListener('drop', (e) => {
                e.preventDefault();
                col.classList.remove('drag-over');
                
                const id = e.dataTransfer.getData('text');
                if (!id) return;

                // Extract status from column ID
                const statusMap = {
                    'col-shortlisted': 'Shortlisted',
                    'col-borderline': 'Borderline',
                    'col-rejected': 'Rejected'
                };
                const newStatus = statusMap[col.id];
                
                if (newStatus) {
                    AppState.setStatusOverride(id, newStatus);
                    DataProcessor.recalculateAndRender();
                }
            });
        });

        // Delegate dragstart on cards
        document.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('k-card')) {
                const card = e.target;
                // Capture the ID immediately
                e.dataTransfer.setData('text', card.dataset.id);
                
                // Delay adding the class until visual capture is done
                requestAnimationFrame(() => {
                    card.classList.add('dragging');
                });
            }
        });

        document.addEventListener('dragend', (e) => {
            if (e.target.classList.contains('k-card')) {
                e.target.classList.remove('dragging');
            }
        });
    };


    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    return {
        init,
        setViewMode,
        toggleTheme
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
} else {
    window.App = App;
}
