/**
 * CV Screening Dashboard - State Management Module
 * Centralized state with getters/setters for better encapsulation
 */

const AppState = (() => {
    // Private state
    const state = {
        // Core Data
        rawData: [],
        processedData: [],
        filteredData: [],
        columns: [],
        statusOverrides: new Map(),
        fieldMapping: {},

        // UI State
        currentPage: 1,
        rowsPerPage: 10,
        viewMode: 'table',
        currentSort: { colId: null, dir: 1 },
        isLoading: false,

        // Filters
        filters: {
            search: '',
            minExp: null,
            domainMatch: 'all',
            status: 'all',
            // Flag Rules: 0 = Any, 1 = Show Only, -1 = Hide
            flagRules: {
                overqualified: 0,
                careerGap: 0,
                unemployed: 0,
                eduMismatch: 0,
                domainMismatch: 0
            }
        }
    };

    // Configuration Constants
    const CONFIG = Object.freeze({
        SCORE_THRESHOLDS: {
            HIGH: 70,
            LOW: 40
        },
        DEFAULT_WEIGHT: 5,
        MAX_WEIGHT: 10,
        DEFAULT_ROWS_PER_PAGE: 10,
        PAGE_SIZE_OPTIONS: [10, 20, 50, 100]
    });

    // Rejection Criteria State
    const rejectionCriteria = {
        rejectOnEduMismatch: false,
        rejectOnDomainMismatch: false,
        hideRejected: false
    };

    // Scoring Parameters Configuration
    const SCORING_PARAMS = Object.freeze([
        { id: 'edu', keywords: ['education'], label: 'Education', abbr: 'Ed' },
        { id: 'dom', keywords: ['domain'], label: 'Domain Fit', abbr: 'Do' },
        { id: 'exp', keywords: ['experien'], label: 'Experience', abbr: 'Ex' },
        { id: 'req', keywords: ['skill', 'tool', 'Skills'], label: 'Skills/Reqs', abbr: 'Sk' }
    ]);

    // Initialize weights from scoring params
    const weights = {};
    SCORING_PARAMS.forEach(p => weights[p.id] = CONFIG.DEFAULT_WEIGHT);
    // Column Definitions - using exact SCHEMA column names as dataKey
    const CORE_COLUMNS = [
        { id: 'Candidate', label: 'Candidate', show: true, type: 'contact', width: '250px' },
        { id: 'Exp', label: 'Exp (Yrs)', show: true, type: 'number', dataKey: 'years_of_experience', sortable: true, width: '100px' },
        { id: 'RelExp', label: 'Rel. Exp', show: false, type: 'number', dataKey: 'relevant_experience_years', sortable: true, width: '100px' },
        { id: 'Domain', label: 'Domain Match', show: false, type: 'boolean', dataKey: 'domain_match', width: '100px' },
        { id: 'EduMatch', label: 'Edu Match', show: false, type: 'boolean', dataKey: 'education_match', width: '100px' },
        { id: 'CurrentCompany', label: 'Current Company', show: true, type: 'text', dataKey: 'current_company', width: '180px' },
        { id: 'CurrentRole', label: 'Current Role', show: true, type: 'text', dataKey: 'current_designation', width: '180px' },
        { id: 'PrevCompanies', label: 'Previous Companies', show: false, type: 'tags', dataKey: 'previous_companies', width: '250px' },
        { id: 'PrevRoles', label: 'Previous Roles', show: false, type: 'tags', dataKey: 'previous_roles', width: '250px' },
        { id: 'Education', label: 'Education', show: false, type: 'text', dataKey: 'highest_education', width: '250px' },
        { id: 'Certifications', label: 'Certifications', show: false, type: 'tags', dataKey: 'certifications', width: '250px' },
        { id: 'Languages', label: 'Languages', show: true, type: 'tags', dataKey: 'languages', width: '200px' },
        { id: 'Skills', label: 'Skills', show: false, type: 'tags', dataKey: 'skills', width: '300px' },
        { id: 'Critical', label: 'Critical Match', show: false, type: 'tags', dataKey: 'critical_skills_match', width: '200px' },
        { id: 'NonCritical', label: 'Nice-to-Have', show: false, type: 'tags', dataKey: 'nice_to_have_skills', width: '200px' },
        { id: 'MissingSkills', label: 'Missing Skills', show: false, type: 'tags', dataKey: 'missing_critical_skills', width: '200px' },
        { id: 'Pros', label: 'Why Consider', show: false, type: 'text', dataKey: 'pros', width: '300px' },
        { id: 'Cons', label: 'Why Not', show: false, type: 'text', dataKey: 'cons', width: '300px' },
        { id: 'Notes', label: 'Notes', show: false, type: 'text', dataKey: 'notes', width: '250px' },
        { id: 'Summary', label: 'AI Summary', show: false, type: 'text', dataKey: 'summary', width: '300px' },
        { id: 'Redflag', label: 'Red Flags', show: false, type: 'tags', dataKey: 'red_flags', width: '200px' },
        { id: 'ResumeLink', label: 'Resume', show: true, type: 'link', dataKey: 'resume_link', width: '120px' },
        { id: 'Subcards', label: 'Subscores', show: true, type: 'subcards', width: '200px' },
        { id: 'Score', label: 'Final Score', show: true, type: 'score', sortable: true, width: '120px' },
        { id: 'Status', label: 'Status', show: true, type: 'status', width: '120px' }
    ];

    // Event subscribers
    const subscribers = new Map();

    // Event system for state changes
    const emit = (event, data) => {
        const handlers = subscribers.get(event) || [];
        handlers.forEach(handler => handler(data));
    };

    return {
        // Configuration getters
        get CONFIG() { return CONFIG; },
        get SCORING_PARAMS() { return SCORING_PARAMS; },
        get CORE_COLUMNS() { return CORE_COLUMNS; },

        // State getters
        get rawData() { return state.rawData; },
        get processedData() { return state.processedData; },
        get filteredData() { return state.filteredData; },
        get columns() { return state.columns; },
        get statusOverrides() { return state.statusOverrides; },
        get fieldMapping() { return state.fieldMapping; },
        get weights() { return weights; },
        get currentPage() { return state.currentPage; },
        get rowsPerPage() { return state.rowsPerPage; },
        get viewMode() { return state.viewMode; },
        get currentSort() { return state.currentSort; },
        get filters() { return state.filters; },
        get isLoading() { return state.isLoading; },
        get rejectionCriteria() { return rejectionCriteria; },

        // State setters with event emission
        setRawData(data) {
            state.rawData = data;
            emit('dataChanged', data);
        },

        setProcessedData(data) {
            state.processedData = data;
            emit('processedDataChanged', data);
        },

        setFilteredData(data) {
            state.filteredData = data;
            emit('filteredDataChanged', data);
        },

        setColumns(cols) {
            state.columns = cols;
            emit('columnsChanged', cols);
        },

        setColumnVisibility(idx, visible) {
            if (state.columns[idx]) {
                state.columns[idx].show = visible;
                emit('columnsChanged', state.columns);
            }
        },

        setColumnWidth(idx, width) {
            if (state.columns[idx]) {
                state.columns[idx].width = width;
            }
        },

        setFieldMapping(mapping) {
            state.fieldMapping = { ...state.fieldMapping, ...mapping };
        },

        setStatusOverride(id, status) {
            // Find current state of the item
            const item = state.processedData.find(d => d._id === id);
            if (item) {
                // Get the score-based natural status
                const scoreBasedStatus = this.getStatusFromScore(item._calculatedScore);
                
                // Determine what status the item would be WITHOUT any override
                // This considers auto-rejection: if item has mismatches AND criteria is enabled, it would be Rejected
                const criteria = rejectionCriteria;
                const hasMismatch = (item._autoRejectionReasons || []).length > 0;
                const wouldBeAutoRejected = hasMismatch && 
                    ((item._autoRejectionReasons.includes('education') && criteria.rejectOnEduMismatch) ||
                     (item._autoRejectionReasons.includes('domain') && criteria.rejectOnDomainMismatch));
                
                const effectiveNaturalStatus = wouldBeAutoRejected ? 'Rejected' : scoreBasedStatus;
                
                if (status === effectiveNaturalStatus) {
                    // Item is back to where it would naturally be, so remove manual override
                    state.statusOverrides.delete(id);
                } else {
                    // This is a true override - user wants a different status than natural
                    state.statusOverrides.set(id, status);
                }
            } else {
                state.statusOverrides.set(id, status);
            }
            emit('statusOverrideChanged', { id, status });
        },

        clearStatusOverrides() {
            state.statusOverrides.clear();
        },

        setWeight(paramId, value) {
            if (weights.hasOwnProperty(paramId)) {
                weights[paramId] = Math.max(0, Math.min(CONFIG.MAX_WEIGHT, value));
                emit('weightsChanged', weights);
            }
        },

        setCurrentPage(page) {
            state.currentPage = Math.max(1, page);
            emit('pageChanged', state.currentPage);
        },

        setRowsPerPage(rows) {
            state.rowsPerPage = rows;
            state.currentPage = 1;
            emit('rowsPerPageChanged', rows);
        },

        setViewMode(mode) {
            state.viewMode = mode;
            emit('viewModeChanged', mode);
        },

        setSort(colId, dir) {
            state.currentSort = { colId, dir };
            emit('sortChanged', state.currentSort);
        },

        setFilter(key, value) {
            if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                state.filters[key] = { ...state.filters[key], ...value };
            } else {
                state.filters[key] = value;
            }
            state.currentPage = 1;
            emit('filtersChanged', state.filters);
        },

        setFlagRule(flag, rule) {
            if (state.filters.flagRules.hasOwnProperty(flag)) {
                state.filters.flagRules[flag] = rule;
                state.currentPage = 1;
                emit('filtersChanged', state.filters);
            }
        },

        resetFilters() {
            state.filters = {
                search: '',
                minExp: null,
                domainMatch: 'all',
                status: 'all',
                flagRules: {
                    overqualified: 0,
                    careerGap: 0,
                    unemployed: 0,
                    eduMismatch: 0,
                    domainMismatch: 0
                }
            };
            state.currentPage = 1;
            emit('filtersReset', state.filters);
        },

        setLoading(loading, message = 'Loading...') {
            state.isLoading = loading;
            if (loading) {
                Utils.Loading.show(message);
            } else {
                Utils.Loading.hide();
            }
            emit('loadingChanged', loading);
        },

        // Rejection Criteria setters
        setRejectionCriteria(key, value) {
            if (rejectionCriteria.hasOwnProperty(key)) {
                rejectionCriteria[key] = value;
                emit('rejectionCriteriaChanged', rejectionCriteria);
            }
        },

        toggleHideRejected(value) {
            rejectionCriteria.hideRejected = value;
            emit('hideRejectedChanged', value);
        },

        // Event subscription
        on(event, handler) {
            if (!subscribers.has(event)) {
                subscribers.set(event, []);
            }
            subscribers.get(event).push(handler);
            return () => {
                const handlers = subscribers.get(event);
                const idx = handlers.indexOf(handler);
                if (idx > -1) handlers.splice(idx, 1);
            };
        },

        // Utility methods
        getScoreClass(score) {
            if (score >= CONFIG.SCORE_THRESHOLDS.HIGH) return 'score-high';
            if (score < CONFIG.SCORE_THRESHOLDS.LOW) return 'score-low';
            return 'score-mid';
        },

        getStatusFromScore(score) {
            if (score >= CONFIG.SCORE_THRESHOLDS.HIGH) return 'Shortlisted';
            if (score < CONFIG.SCORE_THRESHOLDS.LOW) return 'Rejected';
            return 'Borderline';
        },

        getTotalWeight() {
            return Object.values(weights).reduce((sum, w) => sum + w, 0);
        }
    };
})();

// Export for module systems or attach to window for global access
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AppState;
} else {
    window.AppState = AppState;
}
