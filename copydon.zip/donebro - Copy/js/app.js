/**
 * CV Screening Dashboard - Application Entry Point
 * Initializes the app and sets up event delegation
 */

const App = (() => {
    /**
     * Initializes the application.
     */
    const init = () => {
        lucide.createIcons();
        initTheme();
        initWeightsUI();
        initRejectionCriteria();
        initEventDelegation();
        initDropdownBehavior();
        initModalBehavior();
        initReviewRejectedModal();
        initDragAndDrop();

        // Sync UI on filter reset
        AppState.on('filtersReset', () => {
            updateStatusCardHighlight('all');
        });
    };

    /**
     * Initializes theme from storage/preference.
     */
    const initTheme = () => {
        const saved = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const isDark = saved === 'dark' || (!saved && prefersDark);
        
        document.documentElement.classList.toggle('dark', isDark);
        updateThemeIcons(isDark);
    };

    /**
     * Toggles dark mode.
     */
    const toggleTheme = () => {
        const isDark = document.documentElement.classList.toggle('dark');
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        updateThemeIcons(isDark);
        Utils.Toast.info(`Theme switched to ${isDark ? 'dark' : 'light'} mode`);
    };

    /**
     * Updates theme toggle icons.
     */
    const updateThemeIcons = (isDark) => {
        const sun = document.getElementById('sun-icon');
        const moon = document.getElementById('moon-icon');
        if (sun) sun.style.display = isDark ? 'none' : 'block';
        if (moon) moon.style.display = isDark ? 'block' : 'none';
    };

    /**
     * Updates status card highlight based on current filter.
     */
    const updateStatusCardHighlight = (activeStatus) => {
        document.querySelectorAll('.clickable-status').forEach(card => {
            const isSelected = card.dataset.status === activeStatus;
            card.classList.toggle('active', isSelected);
        });
    };

    /**
     * Initializes scoring weights UI.
     */
    const initWeightsUI = () => {
        const container = document.querySelector('.slider-group');
        if (!container) return;

        container.innerHTML = '';

        AppState.SCORING_PARAMS.forEach(param => {
            const weight = AppState.weights[param.id];
            const div = document.createElement('div');
            div.className = 'slider-item';
            div.innerHTML = `
                <div class="slider-header">
                    <span>${param.label}</span>
                    <span>
                        <span id="val-${param.id}" class="slider-value">${weight}</span>
                        <span id="pct-${param.id}" class="weight-percent">(25%)</span>
                    </span>
                </div>
                <input type="range" id="weight-${param.id}" min="0" max="10" value="${weight}" step="1" data-param="${param.id}">
            `;
            container.appendChild(div);

            const input = div.querySelector('input');
            Utils.updateSliderFill(input);
        });

        updateWeightPercentages();
    };

    /**
     * Updates weight percentage displays.
     */
    const updateWeightPercentages = () => {
        const total = AppState.getTotalWeight();

        AppState.SCORING_PARAMS.forEach(param => {
            const pct = total === 0 ? 0 : Math.round((AppState.weights[param.id] / total) * 100);
            const el = document.getElementById(`pct-${param.id}`);
            if (el) el.textContent = `(${pct}%)`;
        });
    };

    /**
     * Initializes rejection criteria UI and restores saved preferences.
     */
    const initRejectionCriteria = () => {
        // Restore saved preferences from localStorage
        const savedCriteria = localStorage.getItem('rejectionCriteria');
        if (savedCriteria) {
            try {
                const parsed = JSON.parse(savedCriteria);
                if (parsed.rejectOnEduMismatch !== undefined) {
                    AppState.setRejectionCriteria('rejectOnEduMismatch', parsed.rejectOnEduMismatch);
                }
                if (parsed.rejectOnDomainMismatch !== undefined) {
                    AppState.setRejectionCriteria('rejectOnDomainMismatch', parsed.rejectOnDomainMismatch);
                }
                if (parsed.hideRejected !== undefined) {
                    AppState.toggleHideRejected(parsed.hideRejected);
                }
            } catch (e) {
                console.warn('Failed to parse saved rejection criteria', e);
            }
        }

        // Update UI to match state
        const eduCheckbox = document.getElementById('reject-edu-mismatch');
        const domainCheckbox = document.getElementById('reject-domain-mismatch');
        const hideRejectedCheckbox = document.getElementById('hide-rejected-toggle');

        const updateTogglesState = () => {
            if (!hideRejectedCheckbox) return;
            const anyCriteria = AppState.rejectionCriteria.rejectOnEduMismatch || AppState.rejectionCriteria.rejectOnDomainMismatch;
            hideRejectedCheckbox.disabled = !anyCriteria;
            
            // If disabled, also ensure it's unchecked in state if it was checked
            if (!anyCriteria && AppState.rejectionCriteria.hideRejected) {
                hideRejectedCheckbox.checked = false;
                AppState.toggleHideRejected(false);
                saveRejectionCriteria();
            }
            
            const parent = hideRejectedCheckbox.closest('.toggle-option');
            if (parent) {
                parent.style.opacity = anyCriteria ? '1' : '0.5';
                parent.style.pointerEvents = anyCriteria ? 'auto' : 'none';
                parent.title = anyCriteria ? '' : 'Enable at least one auto-rejection criteria first';
            }
        };

        if (eduCheckbox) {
            eduCheckbox.checked = AppState.rejectionCriteria.rejectOnEduMismatch;
            eduCheckbox.addEventListener('change', (e) => {
                AppState.setRejectionCriteria('rejectOnEduMismatch', e.target.checked);
                updateTogglesState();
                saveRejectionCriteria();
                DataProcessor.recalculateAndRender();
            });
        }

        if (domainCheckbox) {
            domainCheckbox.checked = AppState.rejectionCriteria.rejectOnDomainMismatch;
            domainCheckbox.addEventListener('change', (e) => {
                AppState.setRejectionCriteria('rejectOnDomainMismatch', e.target.checked);
                updateTogglesState();
                saveRejectionCriteria();
                DataProcessor.recalculateAndRender();
            });
        }

        if (hideRejectedCheckbox) {
            hideRejectedCheckbox.checked = AppState.rejectionCriteria.hideRejected;
            hideRejectedCheckbox.addEventListener('change', (e) => {
                AppState.toggleHideRejected(e.target.checked);
                saveRejectionCriteria();
                DataProcessor.updateFilteredData();
                if (AppState.viewMode === 'table') {
                    UIRenderer.renderTable();
                } else {
                    UIRenderer.renderKanban();
                }
            });
        }
        
        // Hide Overqualified Toggle (Legacy - removed)
        /*
        const hideOverqualifiedCheckbox = document.getElementById('hide-overqualified-toggle');
        if (hideOverqualifiedCheckbox) {
            hideOverqualifiedCheckbox.checked = AppState.filters.hideOverqualified;
            hideOverqualifiedCheckbox.addEventListener('change', (e) => {
                AppState.setFilter('hideOverqualified', e.target.checked);
                DataProcessor.updateFilteredData();
                if (AppState.viewMode === 'table') {
                    UIRenderer.renderTable();
                } else {
                    UIRenderer.renderKanban();
                }
            });
        }
        */
        
        // Advanced Flag Filters (Tri-state)
        document.addEventListener('change', (e) => {
            const segmentedControl = e.target.closest('.segmented-control');
            if (segmentedControl) {
                const flagKey = segmentedControl.dataset.flag;
                const ruleValue = parseInt(e.target.value);
                
                AppState.setFlagRule(flagKey, ruleValue);
                DataProcessor.updateFilteredData();
                
                if (AppState.viewMode === 'table') {
                    UIRenderer.renderTable();
                } else {
                    UIRenderer.renderKanban();
                }
            }
        });

        // Initial run
        updateTogglesState();
    };

    /**
     * Saves rejection criteria to localStorage.
     */
    const saveRejectionCriteria = () => {
        localStorage.setItem('rejectionCriteria', JSON.stringify(AppState.rejectionCriteria));
    };

    /**
     * Initializes the review rejected modal functionality.
     */
    const initReviewRejectedModal = () => {
        const modal = document.getElementById('review-rejected-modal');
        const closeBtn = document.getElementById('review-modal-close');
        const doneBtn = document.getElementById('review-done-btn');
        const reviewBtn = document.getElementById('review-rejected-btn');
        const body = document.getElementById('review-modal-body');

        if (reviewBtn) {
            reviewBtn.addEventListener('click', () => {
                openReviewRejectedModal();
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                closeReviewRejectedModal();
            });
        }

        if (doneBtn) {
            doneBtn.addEventListener('click', () => {
                closeReviewRejectedModal();
            });
        }

        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeReviewRejectedModal();
                }
            });
        }

        // Set up event delegation once for button actions within modal body
        if (body) {
            body.addEventListener('click', (e) => {
                const btn = e.target.closest('[data-action]');
                if (!btn) return;

                const action = btn.dataset.action;
                const id = btn.dataset.id;
                const card = btn.closest('.review-candidate-card');

                if (action === 'override') {
                    // Set override to Borderline
                    AppState.setStatusOverride(id, 'Borderline');
                    Utils.Toast.success('Candidate moved to Borderline');
                } else if (action === 'keep-rejected') {
                    Utils.Toast.info('Candidate kept as rejected');
                }

                // Remove card from modal with animation
                if (card) {
                    card.style.opacity = '0';
                    card.style.transform = 'translateX(20px)';
                    setTimeout(() => {
                        card.remove();
                        
                        // Update count
                        const remaining = document.querySelectorAll('#review-modal-body .review-candidate-card').length;
                        const countEl = document.getElementById('review-remaining-count');
                        if (countEl) {
                            countEl.textContent = `${remaining} remaining`;
                        }

                        // Show empty state if no more candidates
                        if (remaining === 0) {
                            const modalBody = document.getElementById('review-modal-body');
                            if (modalBody) {
                                modalBody.innerHTML = `
                                    <div class="review-empty">
                                        <i data-lucide="check-circle"></i>
                                        <p>All candidates reviewed!</p>
                                    </div>
                                `;
                                requestAnimationFrame(() => {
                                    if (typeof lucide !== 'undefined') {
                                        lucide.createIcons({ icons: lucide.icons });
                                    }
                                });
                            }
                        }
                    }, 200);
                }
            });
        }
    };

    /**
     * Opens the review rejected candidates modal.
     */
    const openReviewRejectedModal = () => {
        const modal = document.getElementById('review-rejected-modal');
        const body = document.getElementById('review-modal-body');

        if (!modal || !body) return;

        // Get auto-rejected candidates
        const autoRejected = AppState.processedData.filter(item => 
            item._isAutoRejected && !item._hasOverride
        );

        if (autoRejected.length === 0) {
            body.innerHTML = `
                <div class="review-empty">
                    <i data-lucide="check-circle"></i>
                    <p>No auto-rejected candidates to review</p>
                </div>
            `;
        } else {
            body.innerHTML = autoRejected.map(item => {
                const name = item[AppState.fieldMapping.candidate] || 'Unknown';
                const reasons = item._autoRejectionReasons || [];
                const reasonText = reasons.map(r => {
                    if (r === 'education') return 'Education mismatch';
                    if (r === 'domain') return 'Domain mismatch';
                    return r;
                }).join(', ');

                return `
                    <div class="review-candidate-card" data-id="${item._id}">
                        <div class="review-candidate-info">
                            <div class="avatar" style="background: ${Utils.getAvatarGradient(name)}">
                                ${Utils.getInitials(name)}
                            </div>
                            <div class="review-candidate-details">
                                <span class="review-candidate-name">${Utils.sanitizeHTML(name)}</span>
                                <span class="review-candidate-reason">
                                    <i data-lucide="alert-circle"></i>
                                    ${Utils.sanitizeHTML(reasonText)}
                                </span>
                            </div>
                        </div>
                        <div class="review-candidate-actions">
                            <button class="btn btn-outline btn-sm" data-action="keep-rejected" data-id="${item._id}" title="Keep as rejected">
                                <i data-lucide="x" width="12"></i> Keep
                            </button>
                            <button class="btn btn-primary btn-sm" data-action="override" data-id="${item._id}" title="Override to Borderline">
                                <i data-lucide="check" width="12"></i> Override
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        // Update count
        const countEl = document.getElementById('review-remaining-count');
        if (countEl) {
            countEl.textContent = `${autoRejected.length} remaining`;
        }

        modal.classList.add('show');
        requestAnimationFrame(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons({ icons: lucide.icons });
            }
        });
    };

    /**
     * Closes the review rejected modal.
     */
    const closeReviewRejectedModal = () => {
        const modal = document.getElementById('review-rejected-modal');

        if (modal) {
            modal.classList.remove('show');
        }

        // Recalculate to apply any overrides
        DataProcessor.recalculateAndRender();
    };

    /**
     * Sets up event delegation for the entire app.
     */
    const initEventDelegation = () => {
        // File uploads
        document.addEventListener('change', (e) => {
            if (e.target.matches('#fileInput, #fileInputOverlay, #fileInputToolbar')) {
                DataProcessor.handleFileUpload(e);
            }
            if (e.target.matches('.col-visibility-checkbox')) {
                const idx = parseInt(e.target.dataset.idx);
                AppState.setColumnVisibility(idx, e.target.checked);
                UIRenderer.renderHeaders();
                UIRenderer.renderTable();
            }
        });

        // Slider input - real-time updates for visual feedback
        document.addEventListener('input', (e) => {
            // Slider fill updates (immediate, no debounce)
            if (e.target.matches('[data-param]')) {
                const paramId = e.target.dataset.param;
                const value = parseInt(e.target.value);
                
                // Update visual immediately
                Utils.updateSliderFill(e.target);
                document.getElementById(`val-${paramId}`).textContent = value;
                
                // Update weight in state
                AppState.setWeight(paramId, value);
                updateWeightPercentages();
            }
            
            // Search with debounce and clear button visibility
            if (e.target.matches('#search-text')) {
                const clearBtn = document.getElementById('search-clear-btn');
                if (clearBtn) {
                    clearBtn.style.display = e.target.value ? 'flex' : 'none';
                }
                handleSearchDebounced(e.target.value);
            }
        });

        // Slider change - recalculate only on release
        document.addEventListener('change', (e) => {
            if (e.target.matches('[data-param]')) {
                DataProcessor.recalculateAndRender();
            }
        });

        // Debounced search handler
        const handleSearchDebounced = Utils.debounce((value) => {
            AppState.setFilter('search', value.toLowerCase());
            DataProcessor.updateFilteredData();
            if (AppState.viewMode === 'table') {
                UIRenderer.renderTable();
            } else {
                UIRenderer.renderKanban();
            }
        }, 200);

        // Search clear button - use mousedown to prevent blur issues
        document.addEventListener('mousedown', (e) => {
            if (e.target.closest('#search-clear-btn')) {
                e.preventDefault(); // Prevent input from losing focus
                const searchInput = document.getElementById('search-text');
                const clearBtn = document.getElementById('search-clear-btn');
                if (searchInput) {
                    searchInput.value = '';
                    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                    searchInput.focus();
                }
                if (clearBtn) {
                    clearBtn.style.display = 'none';
                }
            }
        });

        // Click events
        document.addEventListener('click', (e) => {
            // Theme toggle
            if (e.target.closest('#theme-toggle')) {
                toggleTheme();
                return;
            }

            // Copy to Clipboard
            const copyBtn = e.target.closest('.btn-copy');
            if (copyBtn) {
                const text = copyBtn.dataset.copy;
                if (text) Utils.copyToClipboard(text, copyBtn);
                return;
            }

            // Status Card Filter
            const statusCard = e.target.closest('.clickable-status');
            if (statusCard) {
                const status = statusCard.dataset.status;
                const currentStatus = AppState.filters.status;
                const newStatus = currentStatus === status ? 'all' : status;

                // Sync with dropdown
                const statusDropdown = document.getElementById('filter-status');
                if (statusDropdown) statusDropdown.value = newStatus;

                AppState.setFilter('status', newStatus);
                DataProcessor.updateFilteredData();
                
                if (AppState.viewMode === 'table') {
                    UIRenderer.renderTable();
                } else {
                    UIRenderer.renderKanban();
                }
                
                updateStatusCardHighlight(newStatus);
                return;
            }

            // View tabs
            const viewTab = e.target.closest('.view-tab');
            if (viewTab) {
                const mode = viewTab.dataset.view.toLowerCase();
                setViewMode(mode);
                return;
            }

            // Export button
            if (e.target.closest('#export-btn')) {
                DataProcessor.exportToExcel();
                return;
            }

            // Export PDF button
            if (e.target.closest('#export-pdf-btn')) {
                DataProcessor.exportToPDF();
                return;
            }

            // Clear filters
            if (e.target.closest('#clear-filters-btn')) {
                DataProcessor.clearFilters();
                return;
            }

            // Pagination
            const pageBtn = e.target.closest('#pagination-controls [data-page]');
            if (pageBtn && !pageBtn.disabled) {
                AppState.setCurrentPage(parseInt(pageBtn.dataset.page));
                UIRenderer.renderTable();
                return;
            }

            // Page size selection
            const pageSizeItem = e.target.closest('#page-size-menu .dropdown-item');
            if (pageSizeItem) {
                AppState.setRowsPerPage(parseInt(pageSizeItem.dataset.value));
                UIRenderer.renderTable();
                document.getElementById('page-size-menu')?.classList.remove('show');
                return;
            }

            // Table row click (open modal)
            const tableRow = e.target.closest('#table-body tr');
            if (tableRow) {
                const id = tableRow.dataset.id;
                if (id) UIRenderer.showCandidateModal(id);
                return;
            }

            // Kanban card click
            const kanbanCard = e.target.closest('.k-card');
            if (kanbanCard) {
                const id = kanbanCard.dataset.id;
                if (id) UIRenderer.showCandidateModal(id);
                return;
            }

            // Header click to open dropdown (entire header area)
            const headerClickable = e.target.closest('.header-clickable');
            if (headerClickable) {
                e.stopPropagation();
                const colId = headerClickable.dataset.colId;
                closeAllDropdowns();
                const menu = document.getElementById(`dropdown-${colId}`);
                if (menu) menu.classList.toggle('show');
                return;
            }

            // Sort actions
            const sortAction = e.target.closest('.sort-action');
            if (sortAction) {
                e.stopPropagation();
                const colId = sortAction.dataset.id;
                const dir = parseInt(sortAction.dataset.dir);
                DataProcessor.sortTable(colId, dir);
                closeAllDropdowns();
                return;
            }

            // Hide column action
            const hideAction = e.target.closest('.hide-col-action');
            if (hideAction) {
                e.stopPropagation();
                const idx = parseInt(hideAction.dataset.idx);
                AppState.setColumnVisibility(idx, false);
                UIRenderer.renderHeaders();
                UIRenderer.renderTable();
                
                // Sync checkbox
                const cb = document.querySelector(`.col-visibility-checkbox[data-idx="${idx}"]`);
                if (cb) cb.checked = false;
                
                closeAllDropdowns();
                return;
            }

            // Column toggle dropdown
            if (e.target.closest('#col-toggle-btn')) {
                e.stopPropagation();
                document.getElementById('col-dropdown')?.classList.toggle('show');
                return;
            }

            // Page size trigger
            if (e.target.closest('#page-size-trigger')) {
                e.stopPropagation();
                document.getElementById('page-size-menu')?.classList.toggle('show');
                return;
            }
        });

        // Keyboard events
        // Keyboard events
        document.addEventListener('keydown', (e) => {
            // Context-aware shortcuts (ignore if typing in input)
            if (e.target.matches('input, textarea')) {
                if (e.key === 'Escape') {
                    e.target.blur();
                    closeAllDropdowns();
                }
                return;
            }

            if (e.key === 'Escape') {
                UIRenderer.closeCandidateModal();
                closeAllDropdowns();
                
                // Close Shortcuts Modal
                const shortcutsModal = document.getElementById('shortcuts-modal');
                if (shortcutsModal && shortcutsModal.classList.contains('show')) {
                    shortcutsModal.classList.remove('show');
                }
            }

            // D: Toggle Dark Mode
            if (e.key.toLowerCase() === 'd') {
                toggleTheme();
            }

            // K or /: Focus Search
            if (e.key.toLowerCase() === 'k' || e.key === '/') {
                e.preventDefault();
                const searchInput = document.getElementById('search-text');
                if (searchInput) {
                    searchInput.focus();
                    searchInput.select();
                }
            }

            // P: Export PDF
            if (e.key.toLowerCase() === 'p') {
                e.preventDefault();
                DataProcessor.showPdfModal();
            }

            // Shift+C: Clear Filters
            if (e.shiftKey && e.key.toLowerCase() === 'c') {
                e.preventDefault();
                DataProcessor.clearFilters();
            }

            // V: Toggle View Mode
            if (e.key.toLowerCase() === 'v') {
                const newMode = AppState.viewMode === 'table' ? 'board' : 'table';
                setViewMode(newMode);
            }

            // Left/Right Arrows: Navigate Candidate Modal
            if (document.getElementById('candidate-modal')?.classList.contains('show')) {
                const modal = document.getElementById('candidate-modal');
                const currentId = modal.dataset.currentId;
                
                // O: Open Resume
                if (e.key.toLowerCase() === 'o') {
                    if (!currentId) return;
                    const candidate = AppState.processedData.find(c => c._id === currentId);
                    if (!candidate) return;

                    // Robust resume link finding
                    const resumeKey = Object.keys(candidate).find(k => 
                        ['resume_link', 'resume link', 'resume_url', 'resume url', 'resume'].includes(k.toLowerCase())
                    );
                    const resumeLink = resumeKey ? candidate[resumeKey] : null;

                    if (resumeLink && typeof resumeLink === 'string' && (resumeLink.startsWith('http') || resumeLink.startsWith('www'))) {
                        const url = resumeLink.startsWith('www') ? 'https://' + resumeLink : resumeLink;
                        window.open(url, '_blank');
                        Utils.Toast.info('Opening Resume...');
                    } else {
                        Utils.Toast.info('No valid resume link found.');
                    }
                    return;
                }

                // S, R, B Shortcuts for Status (Only if modal is open)
                if (['s', 'r', 'b'].includes(e.key.toLowerCase())) {
                    if (!currentId) return;
                    
                    // Requirement: Use Shift + Key to prevent accidental touches
                    if (!e.shiftKey) return; 

                    let newStatus = '';
                    if (e.key.toLowerCase() === 's') newStatus = 'Shortlisted';
                    if (e.key.toLowerCase() === 'r') newStatus = 'Rejected';
                    if (e.key.toLowerCase() === 'b') newStatus = 'Borderline';

                    if (newStatus) {
                        AppState.setStatusOverride(currentId, newStatus);
                        DataProcessor.recalculateAndRender();
                        
                        // Update visual status in modal immediately
                        const statusBadgeEl = document.getElementById('modal-status-badge');
                        if (statusBadgeEl) {
                            const statusLower = newStatus.toLowerCase();
                            let icon = '';
                            if (newStatus === 'Shortlisted') icon = '<i data-lucide="check-circle" width="12"></i>';
                            else if (newStatus === 'Rejected') icon = '<i data-lucide="x-circle" width="12"></i>';
                            else if (newStatus === 'Borderline') icon = '<i data-lucide="alert-circle" width="12"></i>';
                            
                            statusBadgeEl.innerHTML = `${icon} ${newStatus}`;
                            statusBadgeEl.className = `modal-status-badge status-${statusLower}`;
                            lucide.createIcons();
                        }
                        
                        Utils.Toast.info(`Marked as ${newStatus}`);
                    }
                    return;
                }
                
                // F: Toggle Fullscreen Modal
                if (e.key.toLowerCase() === 'f') {
                   const content = modal.querySelector('.modal-content');
                   content.classList.toggle('fullscreen');
                   const isFull = content.classList.contains('fullscreen');
                   const maxBtn = document.getElementById('modal-maximize-btn');
                   if (maxBtn) {
                       maxBtn.innerHTML = isFull ? '<i data-lucide="minimize-2" width="18"></i>' : '<i data-lucide="maximize-2" width="18"></i>';
                       lucide.createIcons();
                   }
                }

                if (!currentId) return;

                const allItems = AppState.filteredData; // Use filtered list for navigation
                const currentIndex = allItems.findIndex(i => i._id === currentId);

                if (currentIndex === -1) return;

                if (e.key === 'ArrowRight' && currentIndex < allItems.length - 1) {
                    UIRenderer.showCandidateModal(allItems[currentIndex + 1]._id);
                } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
                    UIRenderer.showCandidateModal(allItems[currentIndex - 1]._id);
                }
            }

            // ?: Show Shortcuts Modal
            if (e.key === '?' || (e.shiftKey && e.key === '/')) {
                const modal = document.getElementById('shortcuts-modal');
                if (modal) {
                    modal.classList.add('show');
                    // Add close handler specifically for this modal
                    const closeBtn = document.getElementById('shortcuts-close-btn');
                    if (closeBtn) {
                        closeBtn.onclick = () => modal.classList.remove('show');
                    }
                    // Also close on background click
                    modal.onclick = (ev) => {
                        if (ev.target === modal) modal.classList.remove('show');
                    }
                }
            }

            // Z: Zen Mode
            if (e.key.toLowerCase() === 'z') {
                document.body.classList.toggle('zen-mode');
                const isZen = document.body.classList.contains('zen-mode');
                
                if (isZen) {
                   Utils.Toast.info('Zen Mode On (Press Z to exit)');
                } else {
                   Utils.Toast.info('Zen Mode Off');
                }
            }
        });
    };

    /**
     * Closes all dropdown menus.
     */
    const closeAllDropdowns = () => {
        document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
            menu.classList.remove('show');
        });
    };

    /**
     * Initializes dropdown close-on-outside-click behavior.
     */
    const initDropdownBehavior = () => {
        document.addEventListener('click', (e) => {
            // Don't close if clicking on dropdown-related elements
            if (!e.target.closest('.dropdown') && 
                !e.target.closest('.dropdown-trigger') &&
                !e.target.closest('.header-clickable') &&
                !e.target.closest('#page-size-trigger') &&
                !e.target.closest('.dropdown-menu')) {
                closeAllDropdowns();
            }
        });
    };

    /**
     * Initializes modal behavior.
     */
    const initModalBehavior = () => {
        const modal = document.getElementById('candidate-modal');
        if (!modal) return;

        // Close handlers
        document.getElementById('modal-close-btn')?.addEventListener('click', UIRenderer.closeCandidateModal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                UIRenderer.closeCandidateModal();
            }
        });

        // Helper for status updates
        const updateStatus = (status) => {
            const currentId = modal.dataset.currentId;
            if (!currentId) return;
            
            AppState.setStatusOverride(currentId, status);
            DataProcessor.recalculateAndRender();
            
            // Update modal badge immediately without closing
            const statusBadgeEl = document.getElementById('modal-status-badge');
            if (statusBadgeEl) {
                const statusLower = status.toLowerCase();
                let icon = '';
                if (status === 'Shortlisted') icon = '<i data-lucide="check-circle" width="12"></i>';
                else if (status === 'Rejected') icon = '<i data-lucide="x-circle" width="12"></i>';
                else if (status === 'Borderline') icon = '<i data-lucide="alert-circle" width="12"></i>';
                
                statusBadgeEl.innerHTML = `${icon} ${status}`;
                statusBadgeEl.className = `modal-status-badge status-${statusLower}`;
                if (typeof lucide !== 'undefined') lucide.createIcons();
            }
            
            Utils.Toast.success(`Marked as ${status}`);
        };

        // Helper for navigation
        const navigate = (direction) => {
            const currentId = modal.dataset.currentId;
            if (!currentId) return;

            const allItems = AppState.filteredData;
            const currentIndex = allItems.findIndex(i => i._id === currentId);

            if (currentIndex === -1) return;

            if (direction === 'next' && currentIndex < allItems.length - 1) {
                UIRenderer.showCandidateModal(allItems[currentIndex + 1]._id);
            } else if (direction === 'prev' && currentIndex > 0) {
                UIRenderer.showCandidateModal(allItems[currentIndex - 1]._id);
            }
        };

        // Attach listeners
        document.getElementById('modal-action-reject')?.addEventListener('click', () => updateStatus('Rejected'));
        document.getElementById('modal-action-borderline')?.addEventListener('click', () => updateStatus('Borderline'));
        document.getElementById('modal-action-shortlist')?.addEventListener('click', () => updateStatus('Shortlisted'));
        
        document.getElementById('modal-prev-btn')?.addEventListener('click', () => navigate('prev'));
        document.getElementById('modal-next-btn')?.addEventListener('click', () => navigate('next'));
    };

    /**
     * Sets view mode (table/board).
     */
    const setViewMode = (mode) => {
        if (AppState.viewMode === mode) return;
        AppState.setViewMode(mode);

        // Update tabs
        document.querySelectorAll('.view-tab').forEach(tab => {
            tab.classList.toggle('active', tab.dataset.view.toLowerCase() === mode);
        });

        // Sliders remain enabled in both views now

        // Toggle column dropdown
        const colWrapper = document.getElementById('col-toggle-wrapper');
        if (colWrapper) colWrapper.style.display = mode === 'board' ? 'none' : 'block';
        DataProcessor.recalculateAndRender();
        Utils.Toast.info(`Switched to ${mode} view`);
    };

    /**
     * Initializes drag and drop for Kanban.
     */
    const initDragAndDrop = () => {
        // Delegate drag events on kanban columns
        document.querySelectorAll('.kanban-col').forEach(col => {
            col.addEventListener('dragover', (e) => {
                e.preventDefault();
                col.classList.add('drag-over');
            });

            col.addEventListener('dragleave', () => {
                col.classList.remove('drag-over');
            });

            col.addEventListener('drop', (e) => {
                e.preventDefault();
                col.classList.remove('drag-over');
                
                const id = e.dataTransfer.getData('text');
                if (!id) return;

                // Extract status from column ID
                const statusMap = {
                    'col-shortlisted': 'Shortlisted',
                    'col-borderline': 'Borderline',
                    'col-rejected': 'Rejected'
                };
                const newStatus = statusMap[col.id];
                
                if (newStatus) {
                    AppState.setStatusOverride(id, newStatus);
                    DataProcessor.recalculateAndRender();
                }
            });
        });

        // Delegate dragstart on cards
        document.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('k-card')) {
                const card = e.target;
                // Capture the ID immediately
                e.dataTransfer.setData('text', card.dataset.id);
                
                // Delay adding the class until visual capture is done
                requestAnimationFrame(() => {
                    card.classList.add('dragging');
                });
            }
        });

        document.addEventListener('dragend', (e) => {
            if (e.target.classList.contains('k-card')) {
                e.target.classList.remove('dragging');
            }
        });
    };


    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    return {
        init,
        setViewMode,
        toggleTheme
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
} else {
    window.App = App;
}
