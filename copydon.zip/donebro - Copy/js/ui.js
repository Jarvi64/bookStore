/**
 * CV Screening Dashboard - UI Rendering Module
 * Handles all DOM rendering and UI updates
 */

const UIRenderer = (() => {
    /**
     * Renders table headers with dropdown menus.
     */
    const renderHeaders = () => {
        const tableHead = document.getElementById('table-head');
        if (!tableHead) return;

        const columns = AppState.columns;
        let html = '<tr>';

        columns.forEach((col, idx) => {
            if (!col.show) return;

            const widthStyle = col.width ? `style="width:${col.width}"` : '';
            const label = Utils.sanitizeHTML(col.label);
            const isSortable = col.id === 'Exp' || col.id === 'Score';
            const isCandidate = col.id === 'Candidate';
            const { colId, dir } = AppState.currentSort;
            const sortIndicator = colId === col.id ? (dir === 1 ? '↑' : '↓') : '';

            html += `
                <th ${widthStyle} data-col-id="${col.id}" data-col-idx="${idx}">
                    <div class="header-container ${!isCandidate ? 'header-clickable' : ''}" data-col-id="${col.id}">
                        <div class="header-btn">
                            <span>${label}</span>
                            ${sortIndicator ? `<span class="sort-indicator">${sortIndicator}</span>` : ''}
                        </div>
                        ${!isCandidate ? `<i data-lucide="chevron-down" width="12" class="header-chevron"></i>` : ''}
                    </div>
                    
                    ${!isCandidate ? `
                    <div class="dropdown-menu header-dropdown-menu" id="dropdown-${col.id}">
                        ${isSortable ? `
                        <div class="dropdown-item sort-action" data-id="${col.id}" data-dir="1">
                            <i data-lucide="arrow-up" width="14"></i> Sort Ascending
                        </div>
                        <div class="dropdown-item sort-action" data-id="${col.id}" data-dir="-1">
                            <i data-lucide="arrow-down" width="14"></i> Sort Descending
                        </div>
                        ` : ''}
                        <div class="dropdown-item hide-col-action" data-idx="${idx}">
                            <i data-lucide="eye-off" width="14"></i> Hide Column
                        </div>
                    </div>
                    ` : ''}
                </th>
            `;
        });

        html += '</tr>';
        tableHead.innerHTML = html;
        if (typeof lucide !== 'undefined') {
            lucide.createIcons({ icons: lucide.icons });
        }
    };

    /**
     * Renders column toggle checkboxes in the dropdown.
     */
    const renderColumnToggles = () => {
        const dropdown = document.getElementById('col-dropdown');
        if (!dropdown) return;

        dropdown.innerHTML = '';
        
        AppState.columns.forEach((col, idx) => {
            if (['Score', 'Status', 'Candidate'].includes(col.id)) return;

            const label = document.createElement('label');
            label.className = 'column-toggle-item';
            label.innerHTML = `
                <input type="checkbox" ${col.show ? 'checked' : ''} data-idx="${idx}" class="col-visibility-checkbox">
                <span>${Utils.sanitizeHTML(col.label)}</span>
            `;
            dropdown.appendChild(label);
        });
    };

    /**
     * Renders a single table row.
     * @param {object} item - Data item
     * @returns {string} HTML string
     */
    const renderTableRow = (item) => {
        const { columns } = AppState;
        let html = '';

        columns.forEach(col => {
            if (!col.show) return;
            html += renderTableCell(col, item);
        });

        return html;
    };

    /**
     * Renders a single table cell.
     * @param {object} col - Column definition
     * @param {object} item - Data item
     * @returns {string} HTML string
     */
    const renderTableCell = (col, item) => {
        switch (col.type) {
            case 'contact':
                return renderContactCell(item);
            case 'status':
                return renderStatusCell(item);
            case 'score':
                return renderScoreCell(item);
            case 'subcards':
                return renderSubscoresCell(item._subscores);
            case 'tags':
                return `<td>${Utils.renderTags(item[col.dataKey])}</td>`;
            case 'boolean':
                return renderBooleanCell(item[col.dataKey]);
            case 'link':
                const url = item[col.dataKey];
                if (url && url !== '-') {
                    return `<td><a href="${Utils.sanitizeHTML(url)}" target="_blank" rel="noopener noreferrer" class="resume-link" title="Open Resume">
                        <i data-lucide="external-link" width="14"></i> View
                    </a></td>`;
                }
                return `<td>-</td>`;
            default:
                return `<td>${Utils.sanitizeHTML(item[col.dataKey]) || '-'}</td>`;
        }
    };

    /**
     * Renders contact cell with avatar.
     */
    const renderContactCell = (item) => {
        // Use SCHEMA for type-safe access to contact fields
        const name = SCHEMA.getString(item, SCHEMA.COLUMNS.CANDIDATE_NAME, 'Unknown');
        const email = SCHEMA.getString(item, SCHEMA.COLUMNS.EMAIL, '');
        const phone = SCHEMA.getString(item, SCHEMA.COLUMNS.PHONE, '');

        // Build status badges for career indicators and rejection reasons
        let statusBadgesHtml = '';
        const badges = [];
        const isOverridden = item._hasOverride;
        const criteria = AppState.rejectionCriteria;
        
        // Career gap badge - NEVER strikethrough (informational only)
        if (item._hasCareerGaps) {
            badges.push(`<span class="status-badge status-badge-gap" title="Career gap detected (more than 1 month between jobs)"><i data-lucide="clock" width="10"></i> Gap</span>`);
        }
        
        // Unemployed badge - NEVER strikethrough (informational only)
        if (item._isUnemployed) {
            badges.push(`<span class="status-badge status-badge-unemployed" title="Candidate is currently unemployed or not in a current role"><i data-lucide="user-x" width="10"></i> Unemployed</span>`);
        }
        
        // Overqualified badge
        if (item._isOverqualified) {
            badges.push(`<span class="status-badge status-badge-overqualified" title="Candidate experience exceeds requirements significantly"><i data-lucide="chevrons-up" width="10"></i> Overqualified</span>`);
        }

        
        // Mismatch badges - only strikethrough if that specific criteria is enabled AND overridden
        if (item._autoRejectionReasons && item._autoRejectionReasons.length > 0) {
            item._autoRejectionReasons.forEach(reason => {
                if (reason === 'education') {
                    // Only strikethrough if education criteria is active and candidate is overridden
                    const shouldStrike = isOverridden && criteria.rejectOnEduMismatch;
                    const strikeClass = shouldStrike ? ' overridden' : '';
                    const tooltip = shouldStrike ? 'Does not meet education requirements (overridden)' : 'Does not meet education requirements';
                    badges.push(`<span class="status-badge status-badge-edu${strikeClass}" title="${tooltip}"><i data-lucide="graduation-cap" width="10"></i> Edu Mismatch</span>`);
                } else if (reason === 'domain') {
                    // Only strikethrough if domain criteria is active and candidate is overridden
                    const shouldStrike = isOverridden && criteria.rejectOnDomainMismatch;
                    const strikeClass = shouldStrike ? ' overridden' : '';
                    const tooltip = shouldStrike ? 'Does not match required domain experience (overridden)' : 'Does not match required domain experience';
                    badges.push(`<span class="status-badge status-badge-domain${strikeClass}" title="${tooltip}"><i data-lucide="briefcase" width="10"></i> Domain Mismatch</span>`);
                }
            });
        }
        
        // Add override indicator if overridden
        if (isOverridden) {
            badges.push(`<span class="status-badge status-badge-override" title="Manually overridden by recruiter"><i data-lucide="shield-check" width="10"></i> Overridden</span>`);
        }
        
        if (badges.length > 0) {
            statusBadgesHtml = `<div class="candidate-status-badges table-badges">${badges.join('')}</div>`;
        }

        return `
            <td>
                <div class="name-cell-inner">
                    <div class="avatar candidate-avatar" style="background: ${Utils.getAvatarGradient(name)}">
                        ${Utils.getInitials(name)}
                    </div>
                    <div class="contact-info">
                        <b>${Utils.sanitizeHTML(name)}</b>
                        <div class="contact-details">
                            ${email ? `
                                <span class="contact-item">
                                    <i data-lucide="mail" width="12"></i>
                                    ${Utils.sanitizeHTML(email)}
                                    <button class="btn-copy" data-copy="${Utils.sanitizeHTML(email)}" title="Copy email"><i data-lucide="copy"></i></button>
                                </span>` : ''}
                            ${phone ? `
                                <span class="contact-item">
                                    <i data-lucide="phone" width="12"></i>
                                    ${Utils.sanitizeHTML(phone)}
                                    <button class="btn-copy" data-copy="${Utils.sanitizeHTML(phone)}" title="Copy phone"><i data-lucide="copy"></i></button>
                                </span>` : ''}
                        </div>
                        ${statusBadgesHtml}
                    </div>
                </div>
            </td>
        `;
    };

    /**
     * Renders status cell with badge.
     */
    const renderStatusCell = (item) => {
        const status = item._calculatedStatus;
        const badgeClass = status === 'Shortlisted' ? 'badge-success' : 
                          (status === 'Rejected' ? 'badge-danger' : 'badge-warning');
        
        return `
            <td>
                <div class="status-cell-wrap">
                    <span class="badge ${badgeClass}">${status}</span>
                    ${item._hasOverride ? `<i data-lucide="user-cog" class="override-indicator" title="Manually Adjusted"></i>` : ''}
                </div>
            </td>
        `;
    };

    /**
     * Renders boolean cell.
     */
    const renderBooleanCell = (value) => {
        const isTrue = Utils.isTruthy(value);
        const icon = isTrue ? 'check-circle' : 'x-circle';
        const colorClass = isTrue ? 'text-success' : 'text-muted';
        return `<td><i data-lucide="${icon}" width="18" class="${colorClass}"></i></td>`;
    };

    /**
     * Renders score cell - simple score display.
     */
    const renderScoreCell = (item) => {
        const score = item._calculatedScore;
        const scoreClass = AppState.getScoreClass(score);

        return `
            <td>
                <span class="final-score ${scoreClass}">${score}</span>
            </td>
        `;
    };

    /**
     * Renders subscores cell with circular indicators.
     */
    const renderSubscoresCell = (subscores) => {
        if (!subscores || subscores.length === 0) return '<td>-</td>';

        const circles = subscores.map(s => `
            <div class="subscore-item" title="${s.label}: ${s.value}">
                ${Utils.createCircularProgress({ value: s.value, size: 32, strokeWidth: 2 })}
                <span class="subscore-label">${s.abbr}</span>
            </div>
        `).join('');

        return `<td><div class="subscores-container">${circles}</div></td>`;
    };

    /**
     * Renders the main table.
     */
    const renderTable = () => {
        const tableBody = document.getElementById('table-body');
        if (!tableBody) return;

        const { filteredData, rowsPerPage, currentPage } = AppState;
        const totalPages = Math.ceil(filteredData.length / rowsPerPage) || 1;

        // Adjust current page if out of bounds
        if (currentPage > totalPages) AppState.setCurrentPage(totalPages);
        if (currentPage < 1) AppState.setCurrentPage(1);

        renderPaginationControls(totalPages);

        const startIdx = (AppState.currentPage - 1) * rowsPerPage;
        const pageData = filteredData.slice(startIdx, startIdx + rowsPerPage);

        tableBody.innerHTML = '';

        pageData.forEach((item, idx) => {
            const tr = document.createElement('tr');
            tr.dataset.id = item._id;
            tr.style.setProperty('--row-index', idx);
            tr.innerHTML = renderTableRow(item);
            tableBody.appendChild(tr);
        });

        // Only process icons within the table body for performance
        requestAnimationFrame(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons({ icons: lucide.icons });
            }
        });
    };

    /**
     * Renders pagination controls.
     */
    const renderPaginationControls = (totalPages) => {
        const controls = document.getElementById('pagination-controls');
        const infoEl = document.getElementById('page-info-text');
        const sizeDisplay = document.getElementById('current-page-size');

        if (infoEl) infoEl.textContent = `Page ${AppState.currentPage} of ${totalPages}`;
        if (sizeDisplay) sizeDisplay.textContent = AppState.rowsPerPage;

        if (!controls) return;

        const cp = AppState.currentPage;
        controls.innerHTML = `
            <button class="btn btn-outline btn-icon" ${cp === 1 ? 'disabled' : ''} data-page="1">
                <i data-lucide="chevrons-left" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === 1 ? 'disabled' : ''} data-page="${cp - 1}">
                <i data-lucide="chevron-left" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === totalPages ? 'disabled' : ''} data-page="${cp + 1}">
                <i data-lucide="chevron-right" width="16"></i>
            </button>
            <button class="btn btn-outline btn-icon" ${cp === totalPages ? 'disabled' : ''} data-page="${totalPages}">
                <i data-lucide="chevrons-right" width="16"></i>
            </button>
        `;
        requestAnimationFrame(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons({ icons: lucide.icons });
            }
        });
    };

    /**
     * Renders Kanban board view.
     */
    const renderKanban = () => {
        const lists = {
            shortlisted: document.getElementById('list-shortlisted'),
            borderline: document.getElementById('list-borderline'),
            rejected: document.getElementById('list-rejected')
        };

        Object.values(lists).forEach(list => { if (list) list.innerHTML = ''; });

        const counts = { Shortlisted: 0, Borderline: 0, Rejected: 0 };
        const { filteredData, fieldMapping } = AppState;

        // Sort by score descending
        const sortedData = [...filteredData].sort((a, b) => b._calculatedScore - a._calculatedScore);

        sortedData.forEach(item => {
            const status = item._calculatedStatus;
            counts[status]++;

            const card = createKanbanCard(item, fieldMapping);
            const listId = `list-${status.toLowerCase()}`;
            const container = document.getElementById(listId);
            if (container) container.appendChild(card);
        });

        // Update counts
        const countEls = {
            'count-k-short': counts.Shortlisted,
            'count-k-border': counts.Borderline,
            'count-k-reject': counts.Rejected
        };

        Object.entries(countEls).forEach(([id, count]) => {
            const el = document.getElementById(id);
            if (el) el.textContent = count;
        });

        // Add empty states to empty columns
        Object.entries(lists).forEach(([key, list]) => {
            if (list && list.children.length === 0) {
                list.innerHTML = `
                    <div class="kanban-empty">
                        <i data-lucide="inbox" width="32" height="32"></i>
                        <p>No candidates in this category</p>
                    </div>
                `;
            }
        });

        requestAnimationFrame(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons({ icons: lucide.icons });
            }
        });
    };

    /**
     * Creates a Kanban card element.
     * @param {object} item - Data item
     * @param {object} fieldMapping - Field mapping
     * @returns {HTMLElement}
     */
    const createKanbanCard = (item, fieldMapping) => {
        const card = document.createElement('div');
        card.className = 'k-card';
        card.dataset.id = item._id;
        card.draggable = true;

        const name = item[fieldMapping.candidate] || 'Unknown';
        const score = item._calculatedScore;
        const scoreClass = AppState.getScoreClass(score);
        const subscores = item._subscores || [];

        // Get company, role, and experience using standardized SCHEMA
        const currentRole = SCHEMA.getString(item, SCHEMA.COLUMNS.CURRENT_DESIGNATION, null);
        const currentCompany = SCHEMA.getString(item, SCHEMA.COLUMNS.CURRENT_COMPANY, null);
        const experience = SCHEMA.getNumber(item, SCHEMA.COLUMNS.YEARS_OF_EXPERIENCE, 0);

        const subscoreCircles = subscores.map(s => `
            <div class="subscore-item-sm" title="${s.label}: ${s.value}">
                ${Utils.createCircularProgress({ value: s.value, size: 28, strokeWidth: 2 })}
                <span class="subscore-label-sm">${s.abbr}</span>
            </div>
        `).join('');

        // Build job info with separate lines for role and company
        const roleHtml = currentRole ? `<div class="k-card-role" title="${Utils.sanitizeHTML(currentRole)}">${Utils.sanitizeHTML(currentRole)}</div>` : '';
        const companyHtml = currentCompany ? `<div class="k-card-company" title="${Utils.sanitizeHTML(currentCompany)}">${Utils.sanitizeHTML(currentCompany)}</div>` : '';
        const jobInfoHtml = `<div class="k-card-job-wrap">${roleHtml}${companyHtml}</div>`;

        // Build metrics row (exp + badges) to be displayed below company/role
        let expBadge = experience ? `<span class="k-metric exp-metric"><i data-lucide="briefcase" width="10"></i>${experience}y</span>` : '';
        let compactBadges = [];
        
        // Get rejection criteria to determine which mismatches would cause rejection
        const criteria = AppState.rejectionCriteria;
        const isOverridden = item._hasOverride;
        
        // Gap and unemployed are informational - NEVER strikethrough
        if (item._hasCareerGaps) {
            compactBadges.push(`<span class="k-metric gap-metric" title="Career gap detected"><i data-lucide="clock" width="10"></i>Gap</span>`);
        }
        if (item._isUnemployed) {
            compactBadges.push(`<span class="k-metric unemployed-metric" title="Currently unemployed"><i data-lucide="user-x" width="10"></i>Unemp</span>`);
        }
        if (item._isOverqualified) {
            compactBadges.push(`<span class="k-metric overqualified-metric" title="Significantly exceeds experience requirements"><i data-lucide="chevrons-up" width="10"></i>Overqual</span>`);
        }
        
        // Mismatch badges - only strikethrough if that specific criteria is enabled AND overridden
        if (item._autoRejectionReasons && item._autoRejectionReasons.length > 0) {
            item._autoRejectionReasons.forEach(reason => {
                if (reason === 'education') {
                    // Only strikethrough if education criteria is active and candidate is overridden
                    const shouldStrike = isOverridden && criteria.rejectOnEduMismatch;
                    const badgeClass = shouldStrike ? 'k-metric overridden' : 'k-metric';
                    const tooltip = shouldStrike ? 'Education mismatch (overridden)' : 'Education mismatch';
                    compactBadges.push(`<span class="${badgeClass} edu-metric" title="${tooltip}"><i data-lucide="graduation-cap" width="10"></i>Edu Mismatch</span>`);
                } else if (reason === 'domain') {
                    // Only strikethrough if domain criteria is active and candidate is overridden
                    const shouldStrike = isOverridden && criteria.rejectOnDomainMismatch;
                    const badgeClass = shouldStrike ? 'k-metric overridden' : 'k-metric';
                    const tooltip = shouldStrike ? 'Domain mismatch (overridden)' : 'Domain mismatch';
                    compactBadges.push(`<span class="${badgeClass} domain-metric" title="${tooltip}"><i data-lucide="briefcase" width="10"></i>Domain Mismatch</span>`);
                }
            });
        }
        
        // Show override indicator if candidate was overridden
        const overrideIndicator = isOverridden 
            ? `<span class="k-metric override-metric" title="Manually overridden by recruiter"><i data-lucide="shield-check" width="10"></i></span>` 
            : '';
        
        const metricsHtml = `
            <div class="k-card-metrics-row">
                ${expBadge}
                ${compactBadges.join('')}
                ${overrideIndicator}
            </div>
        `;

        card.innerHTML = `
            <div class="k-card-header">
                <div class="name-cell-inner">
                    <div class="avatar candidate-avatar k-card-avatar" style="background: ${Utils.getAvatarGradient(name)}">
                        ${Utils.getInitials(name)}
                    </div>
                    <div class="k-card-name-info">
                        <span class="k-card-name">${Utils.sanitizeHTML(name)}</span>
                        ${jobInfoHtml}
                        ${metricsHtml}
                    </div>
                </div>
                <div class="k-card-top-scores">
                    <div class="k-card-subscores">
                        ${subscoreCircles}
                    </div>
                    <span class="final-score ${scoreClass}">${score}</span>
                </div>
            </div>
            <div class="k-card-skills">
                ${Utils.renderTags(item[fieldMapping.skills], 4).replace('tag-container', 'tag-container tag-container-sm')}
            </div>
        `;

        return card;
    };

    /**
     * Shows candidate detail modal.
     * @param {string} id - Candidate ID
     */
    const showCandidateModal = (id) => {
        const item = AppState.processedData.find(d => d._id === id);
        if (!item) return;
        
        const modal = document.getElementById('candidate-modal');
        if (!modal) return;
        
        // Store ID for navigation
        modal.dataset.currentId = id;

        const { fieldMapping } = AppState;
        const name = item[fieldMapping.candidate] || 'Unknown';
        const email = item[fieldMapping.email] || '';
        const phone = item[fieldMapping.phone] || '';

        if (modal) {
            const modalContent = modal.querySelector('.modal-content');
            if (modalContent) modalContent.classList.add('glass');
        }

        // Populate hero section
        const nameEl = document.getElementById('modal-name');
        const avatarEl = document.getElementById('modal-avatar');
        const contactEl = document.getElementById('modal-contact');

        if (nameEl) nameEl.textContent = name;
        if (avatarEl) {
            avatarEl.textContent = Utils.getInitials(name);
            avatarEl.style.background = Utils.getAvatarGradient(name);
        }
        if (contactEl) {
            contactEl.innerHTML = `
                ${email ? `
                    <div class="contact-item">
                        <i data-lucide="mail" width="14"></i> 
                        ${Utils.sanitizeHTML(email)}
                        <button class="btn-copy" data-copy="${Utils.sanitizeHTML(email)}" title="Copy email"><i data-lucide="copy"></i></button>
                    </div>` : ''}
                ${phone ? `
                    <div class="contact-item">
                        <i data-lucide="phone" width="14"></i> 
                        ${Utils.sanitizeHTML(phone)}
                        <button class="btn-copy" data-copy="${Utils.sanitizeHTML(phone)}" title="Copy phone"><i data-lucide="copy"></i></button>
                    </div>` : ''}
            `;
        }

        // Populate total score in header
        const totalScoreEl = document.getElementById('modal-total-score');
        if (totalScoreEl) {
            const score = item._calculatedScore;
            totalScoreEl.textContent = score;
            totalScoreEl.className = `final-score modal-header-score ${AppState.getScoreClass(score)}`;
        }

        // Populate Status Badge
        const statusBadgeEl = document.getElementById('modal-status-badge');
        if (statusBadgeEl) {
            const status = item._calculatedStatus || 'Pending';
            const statusLower = status.toLowerCase();
            let icon = '';
            
            if (status === 'Shortlisted') icon = '<i data-lucide="check-circle" width="12"></i>';
            else if (status === 'Rejected') icon = '<i data-lucide="x-circle" width="12"></i>';
            else if (status === 'Borderline') icon = '<i data-lucide="alert-circle" width="12"></i>';

            statusBadgeEl.innerHTML = `${icon} ${status}`;
            statusBadgeEl.className = `modal-status-badge status-${statusLower}`;
        }

        // Add Maximize Listener (if not added yet - simplified check)
        const maxBtn = document.getElementById('modal-maximize-btn');
        if (maxBtn) {
            // Remove old listeners by cloning
            const newBtn = maxBtn.cloneNode(true);
            maxBtn.parentNode.replaceChild(newBtn, maxBtn);
            
            newBtn.addEventListener('click', () => {
                const content = document.querySelector('#candidate-modal .modal-content');
                content.classList.toggle('fullscreen');
                const isFull = content.classList.contains('fullscreen');
                
                // Update icon
                const icon = newBtn.querySelector('i'); // Lucide icon might be an svg now
                // We're re-running createIcons so we can just reset innerHTML
                newBtn.innerHTML = isFull ? '<i data-lucide="minimize-2" width="18"></i>' : '<i data-lucide="maximize-2" width="18"></i>';
                lucide.createIcons();
            });
        }

        // Populate scores
        const scoresEl = document.getElementById('modal-scores');
        if (scoresEl) {
            const subscores = item._subscores || [];
            scoresEl.innerHTML = subscores.map(s => `
                <div class="modal-score-item">
                    ${Utils.createCircularProgress({ value: s.value, size: 52, strokeWidth: 3, label: s.label })}
                </div>
            `).join('');
        }

        // Define fields to exclude (shown in header or internal)
        const excludeFields = new Set([
            fieldMapping.candidate, fieldMapping.email, fieldMapping.phone,
            '_id', '_calculatedScore', '_calculatedStatus', '_subscores', '_hasOverride',
            '_autoRejectionReasons', '_isAutoRejected', '_hasCareerGaps', '_isUnemployed', '_isOverqualified'
        ]);

        // Define field sections for organized display
        const sections = [
            {
                title: 'Career & Education Journey',
                icon: 'route',
                type: 'timelines',
                fields: [] // Special handling for timelines
            },
            {
                title: 'Quick Overview',
                icon: 'briefcase',
                fields: [
                    { key: SCHEMA.COLUMNS.CURRENT_COMPANY, label: 'Current Company' },
                    { key: SCHEMA.COLUMNS.CURRENT_DESIGNATION, label: 'Current Role' },
                    { key: SCHEMA.COLUMNS.YEARS_OF_EXPERIENCE, label: 'Total Experience' },
                    { key: SCHEMA.COLUMNS.RELEVANT_EXPERIENCE_YEARS, label: 'Relevant Experience' },
                    { key: SCHEMA.COLUMNS.HIGHEST_EDUCATION, label: 'Education' },
                    { key: SCHEMA.COLUMNS.CERTIFICATIONS, label: 'Certifications' },
                    { key: SCHEMA.COLUMNS.LANGUAGES, label: 'Languages' }
                ]
            },
            {
                title: 'Skills Analysis',
                icon: 'code',
                fields: [
                    { key: SCHEMA.COLUMNS.SKILLS, label: 'All Skills', type: 'tags' },
                    { key: SCHEMA.COLUMNS.CRITICAL_SKILLS_MATCH, label: 'Critical Skills Match', type: 'tags-success' },
                    { key: SCHEMA.COLUMNS.NICE_TO_HAVE_SKILLS, label: 'Nice-to-Have Skills', type: 'tags' },
                    { key: SCHEMA.COLUMNS.MISSING_CRITICAL_SKILLS, label: 'Missing Skills', type: 'tags-danger' }
                ]
            },
            {
                title: 'AI Evaluation',
                icon: 'brain',
                fields: [
                    { key: SCHEMA.COLUMNS.EMPLOYMENT_STATUS, label: 'Employment Status', type: 'text' },
                    { key: SCHEMA.COLUMNS.EMPLOYMENT_GAPS, label: 'Employment Gaps', type: 'alert-warning' },
                    { key: SCHEMA.COLUMNS.DOMAIN_MATCH, label: 'Domain Match', type: 'boolean' },
                    { key: SCHEMA.COLUMNS.RED_FLAGS, label: 'Red Flags', type: 'alert-danger' },
                    { key: SCHEMA.COLUMNS.NOTES, label: 'Screening Notes', type: 'text' },
                    { key: SCHEMA.COLUMNS.SUMMARY, label: 'AI Summary', type: 'text' }
                ]
            },
            {
                title: 'Quick Decision Support',
                icon: 'zap',
                fields: [
                    { key: SCHEMA.COLUMNS.PROS, label: 'Why Hire?', type: 'alert-success' },
                    { key: SCHEMA.COLUMNS.CONS, label: 'Valid Risks', type: 'alert-warning' }
                ]
            }
        ];

        // Populate details grid with sections
        const gridEl = document.getElementById('modal-details-grid');
        if (gridEl) {
            gridEl.innerHTML = '';

            sections.forEach(section => {
                // Special handling for timelines section
                if (section.type === 'timelines') {
                    // Use standardized SCHEMA column names
                    const careerTimeline = SCHEMA.getString(item, SCHEMA.COLUMNS.CAREER_TIMELINE, null);
                    const educationTimeline = SCHEMA.getString(item, SCHEMA.COLUMNS.EDUCATION_TIMELINE, null);
                    
                    // Parse career data (pipe-delimited format only now)
                    let parsedCareer = [];
                    if (careerTimeline && careerTimeline !== '-') {
                        parsedCareer = parsePipeDelimitedCareer(careerTimeline);
                    }
                    
                    // Parse education data (pipe-delimited format only now)
                    let parsedEducation = [];
                    if (educationTimeline && educationTimeline !== '-') {
                        parsedEducation = parsePipeDelimitedEducation(educationTimeline);
                    }
                    
                    // Only render if we have timeline data
                    if (parsedCareer.length > 0 || parsedEducation.length > 0) {
                        const sectionEl = document.createElement('div');
                        sectionEl.className = 'modal-detail-section';
                        
                        // Get employment status for display using SCHEMA
                        const employmentStatus = SCHEMA.getString(item, SCHEMA.COLUMNS.EMPLOYMENT_STATUS, null);
                        const employmentGaps = SCHEMA.getString(item, SCHEMA.COLUMNS.EMPLOYMENT_GAPS, null);
                        
                        // Overqualified logic for modal
                        let overqualifiedBadge = '';
                        if (item._isOverqualified) {
                            overqualifiedBadge = `<span class="timeline-badge timeline-badge-overqualified" style="margin-left: 0.5rem;"><i data-lucide="chevrons-up" width="12"></i> Overqualified</span>`;
                        }
                        
                        // Handle multiple employment gaps as individual badges
                        let gapsHTML = '';
                        if (employmentGaps) {
                            const gaps = employmentGaps.split(',').map(g => g.trim()).filter(Boolean);
                            gapsHTML = `<div class="gap-badges-container" style="display: flex; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1.5rem;">
                                ${gaps.map(gap => `<div class="timeline-gap-badge modal-alert modal-alert-warning"><i data-lucide="alert-circle" width="14"></i> <span class="gap-label">GAP:</span> ${Utils.sanitizeHTML(gap)}</div>`).join('')}
                            </div>`;
                        }
                        
                        sectionEl.innerHTML = `
                            <h4 class="modal-detail-section-title">
                                <i data-lucide="${section.icon}" width="16"></i>
                                ${section.title}
                                ${employmentStatus ? `<span class="timeline-badge ${employmentStatus === 'Employed' ? 'timeline-badge-current' : 'timeline-badge-highest'}" style="margin-left: auto;">${Utils.sanitizeHTML(employmentStatus)}</span>` : ''}
                                ${overqualifiedBadge}
                            </h4>
                            ${gapsHTML}
                            <div class="timeline-grid">
                                ${parsedCareer.length > 0 ? `
                                    <div class="timeline-section">
                                        <h5 class="timeline-section-title">
                                            <i data-lucide="briefcase" width="14"></i>
                                            Career Timeline
                                        </h5>
                                        <div class="timeline-container">
                                            ${renderCareerTimeline(parsedCareer)}
                                        </div>
                                    </div>
                                ` : ''}
                                ${parsedEducation.length > 0 ? `
                                    <div class="timeline-section">
                                        <h5 class="timeline-section-title">
                                            <i data-lucide="graduation-cap" width="14"></i>
                                            Education Timeline
                                        </h5>
                                        <div class="timeline-container">
                                            ${renderEducationTimeline(parsedEducation, parsedCareer.length)}
                                        </div>
                                    </div>
                                ` : ''}
                            </div>
                        `;
                        
                        gridEl.appendChild(sectionEl);
                    }
                    return;
                }
                
                // Check if section has any data
                const hasData = section.fields.some(f => {
                    const val = findFieldValue(item, f.key);
                    return val !== null && val !== undefined && val !== '';
                });

                if (!hasData) return;

                // Create section
                const sectionEl = document.createElement('div');
                sectionEl.className = 'modal-detail-section';
                sectionEl.innerHTML = `
                    <h4 class="modal-detail-section-title">
                        <i data-lucide="${section.icon}" width="16"></i>
                        ${section.title}
                    </h4>
                    <div class="modal-detail-section-content"></div>
                `;

                const contentEl = sectionEl.querySelector('.modal-detail-section-content');

                section.fields.forEach(field => {
                    const value = findFieldValue(item, field.key);
                    if (value === null || value === undefined || value === '') return;

                    const itemEl = document.createElement('div');
                    itemEl.className = 'detail-item';

                    let displayValue = '';
                    switch (field.type) {
                        case 'tags':
                            displayValue = Utils.renderTags(value);
                            break;
                        case 'tags-success':
                            displayValue = renderColoredTags(value, 'success');
                            break;
                        case 'tags-danger':
                            displayValue = renderColoredTags(value, 'danger');
                            break;
                        case 'boolean':
                            const isTrue = Utils.isTruthy(value);
                            displayValue = `<span class="badge ${isTrue ? 'badge-success' : 'badge-danger'}">${isTrue ? 'Yes' : 'No'}</span>`;
                            break;
                        case 'alert-danger':
                            displayValue = `<div class="modal-alert modal-alert-danger"><i data-lucide="alert-triangle" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'alert-success':
                            displayValue = `<div class="modal-alert modal-alert-success"><i data-lucide="check-circle" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'alert-warning':
                            displayValue = `<div class="modal-alert modal-alert-warning"><i data-lucide="info" width="14"></i> ${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'archetype':
                            displayValue = `<span class="badge badge-neutral" style="background:#e0e7ff; color:#3730a3; padding:0.4rem 0.8rem; border:none; font-weight:700;">${Utils.sanitizeHTML(value)}</span>`;
                            break;
                        case 'text-highlight':
                            displayValue = `<div class="modal-text" style="background:var(--secondary); padding:1rem; border-left:4px solid var(--primary); border-radius:4px; font-style:italic;">${Utils.sanitizeHTML(value)}</div>`;
                            break;
                        case 'text':
                            displayValue = `<p class="modal-text">${Utils.sanitizeHTML(value)}</p>`;
                            break;
                        default:
                            displayValue = Utils.sanitizeHTML(value);
                    }

                    itemEl.innerHTML = `
                        <label>${field.label}</label>
                        <div>${displayValue}</div>
                    `;
                    contentEl.appendChild(itemEl);
                });

                gridEl.appendChild(sectionEl);
            });
        }

        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        // Defer icon creation to next frame for smoother modal opening
        requestAnimationFrame(() => {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons({ icons: lucide.icons });
            }
        });
    };

    /**
     * Gets field value using standardized SCHEMA column names.
     * @param {object} item - Data item
     * @param {string} columnName - Exact column name from SCHEMA.COLUMNS
     * @returns {*} Field value or null
     */
    const findFieldValue = (item, columnName) => {
        // Use SCHEMA for type-safe access
        return SCHEMA.get(item, columnName);
    };

    /**
     * Renders colored tags.
     * @param {string} value - Comma-separated values
     * @param {string} color - Color type (success, danger, warning)
     * @returns {string} HTML string
     */
    const renderColoredTags = (value, color) => {
        if (!value) return '-';
        const tags = String(value).split(',').map(s => s.trim()).filter(Boolean);
        if (tags.length === 0) return '-';
        return `<div class="tag-container">${tags.map(t => 
            `<span class="badge badge-${color}">${Utils.sanitizeHTML(t)}</span>`
        ).join('')}</div>`;
    };

    /**
     * Parses pipe-delimited career timeline string into structured array.
     * Format: "Role @ Company (StartDate - EndDate) | Role @ Company (StartDate - EndDate)"
     * @param {string} timeline - Pipe-delimited career timeline string
     * @returns {object[]} Array of career entries
     */
    const parsePipeDelimitedCareer = (timeline) => {
        if (!timeline || typeof timeline !== 'string') return [];
        
        const entries = timeline.split('|').map(s => s.trim()).filter(Boolean);
        
        return entries.map((entry, index) => {
            // Parse format: "Role @ Company (StartDate - EndDate)"
            // Regex to match: Role @ Company (StartDate - EndDate)
            const match = entry.match(/^(.+?)\s*@\s*(.+?)\s*\(([^)]+)\)\s*$/);
            
            if (match) {
                const role = match[1].trim();
                const company = match[2].trim();
                const dateRange = match[3].trim();
                
                // Parse date range: "StartDate - EndDate"
                const dateParts = dateRange.split('-').map(d => d.trim());
                const startDate = dateParts[0] || '';
                const endDate = dateParts.length > 1 ? dateParts.slice(1).join('-').trim() : '';
                
                // First entry (index 0) with "Present" is current
                const isCurrent = index === 0 && endDate.toLowerCase().includes('present');
                
                return {
                    role,
                    company,
                    start_date: startDate,
                    end_date: endDate,
                    is_current: isCurrent
                };
            }
            
            // Fallback: just use the raw entry as role
            return {
                role: entry,
                company: '',
                start_date: '',
                end_date: '',
                is_current: index === 0
            };
        });
    };

    /**
     * Parses pipe-delimited education timeline string into structured array.
     * Format: "Degree in Field @ Institution (Year) [Grade] | Degree @ Institution (Year)"
     * @param {string} timeline - Pipe-delimited education timeline string
     * @returns {object[]} Array of education entries
     */
    const parsePipeDelimitedEducation = (timeline) => {
        if (!timeline || typeof timeline !== 'string') return [];
        
        const entries = timeline.split('|').map(s => s.trim()).filter(Boolean);
        
        return entries.map((entry, index) => {
            // Parse format: "Degree in Field @ Institution (Year) [Grade]" or "Degree @ Institution (Year) [Grade]"
            // Grade in square brackets is optional
            
            // First, extract optional grade from square brackets at the end
            let grade = null;
            let entryWithoutGrade = entry;
            const gradeMatch = entry.match(/\[([^\]]+)\]\s*$/);
            if (gradeMatch) {
                grade = gradeMatch[1].trim();
                entryWithoutGrade = entry.replace(/\[([^\]]+)\]\s*$/, '').trim();
            }
            
            // Match with optional "in Field" part
            const matchWithField = entryWithoutGrade.match(/^(.+?)\s+in\s+(.+?)\s*@\s*(.+?)\s*\((\d{4})\)\s*$/i);
            const matchWithoutField = entryWithoutGrade.match(/^(.+?)\s*@\s*(.+?)\s*\((\d{4})\)\s*$/);
            
            if (matchWithField) {
                return {
                    degree: matchWithField[1].trim(),
                    field: matchWithField[2].trim(),
                    institution: matchWithField[3].trim(),
                    year: matchWithField[4].trim(),
                    grade: grade,
                    is_highest: index === 0
                };
            } else if (matchWithoutField) {
                return {
                    degree: matchWithoutField[1].trim(),
                    field: null,
                    institution: matchWithoutField[2].trim(),
                    year: matchWithoutField[3].trim(),
                    grade: grade,
                    is_highest: index === 0
                };
            }
            
            // Fallback: just use the raw entry as degree
            return {
                degree: entry,
                field: null,
                institution: '',
                year: '',
                grade: grade,
                is_highest: index === 0
            };
        });
    };

    /**
     * Renders career timeline HTML.
     * @param {object[]} careers - Array of career history entries
     * @returns {string} HTML string
     */
    const renderCareerTimeline = (careers) => {
        if (!Array.isArray(careers) || careers.length === 0) {
            return '<div class="timeline-empty">No career history available</div>';
        }
        
        // Helper to parse date strings
        const parseDate = (dateStr) => {
            if (!dateStr || typeof dateStr !== 'string') return null;
            const str = dateStr.trim().toLowerCase();
            if (str === 'present' || str === 'current') return new Date();
            
            const monthYearMatch = str.match(/(\w+)\s+(\d{4})/);
            if (monthYearMatch) {
                const date = new Date(`${monthYearMatch[1]} 1, ${monthYearMatch[2]}`);
                if (!isNaN(date.getTime())) return date;
            }
            
            const yearMatch = str.match(/(\d{4})/);
            if (yearMatch) {
                return new Date(`Jan 1, ${yearMatch[1]}`);
            }
            return null;
        };

        // Calculate gap between two dates in months
        const getGapMonths = (endDate, startDate) => {
            if (!endDate || !startDate) return 0;
            const endParsed = parseDate(endDate);
            const startParsed = parseDate(startDate);
            if (!endParsed || !startParsed) return 0;
            return (startParsed.getTime() - endParsed.getTime()) / (1000 * 60 * 60 * 24 * 30);
        };

        // Format gap duration
        const formatGap = (months) => {
            const roundedMonths = Math.round(months);
            if (roundedMonths >= 12) {
                const years = Math.floor(roundedMonths / 12);
                const remainingMonths = roundedMonths % 12;
                if (remainingMonths === 0) return `${years} year${years > 1 ? 's' : ''}`;
                return `${years}y ${remainingMonths}m`;
            }
            return `${roundedMonths} month${roundedMonths !== 1 ? 's' : ''}`;
        };

        // Data is already in most recent first order (from pipe-delimited format)
        let html = '';
        careers.forEach((job, index) => {
            const isCurrent = job.is_current || job.isCurrent;
            const company = Utils.sanitizeHTML(job.company || '');
            const role = Utils.sanitizeHTML(job.role || '');
            const startDate = Utils.sanitizeHTML(job.start_date || job.startDate || '');
            const endDate = isCurrent ? 'Present' : Utils.sanitizeHTML(job.end_date || job.endDate || '');
            const delay = index * 0.1;
            
            // Check for gap before this job (comparing to previous job's end date)
            if (index > 0) {
                const prevJob = careers[index - 1];
                const prevEndDate = prevJob.is_current || prevJob.isCurrent ? 'Present' : (prevJob.end_date || prevJob.endDate || '');
                const gapMonths = getGapMonths(endDate, prevJob.start_date || prevJob.startDate);
                
                // If gap is more than 1 month, show it
                if (gapMonths > 1 && prevEndDate !== 'Present') {
                    const actualGap = getGapMonths(prevJob.end_date || prevJob.endDate, startDate);
                    if (actualGap > 1) {
                        html += `
                            <div class="timeline-gap" style="animation-delay: ${delay - 0.05}s">
                                <div class="timeline-gap-line"></div>
                                <span class="timeline-gap-label">
                                    <i data-lucide="clock" width="10"></i>
                                    ${formatGap(actualGap)} gap
                                </span>
                                <div class="timeline-gap-line"></div>
                            </div>
                        `;
                    }
                }
            }
            
            html += `
                <div class="timeline-item ${isCurrent ? 'timeline-current' : ''}" style="animation-delay: ${delay}s">
                    <div class="timeline-header">
                        <span class="timeline-title">${role}</span>
                        ${isCurrent ? '<span class="timeline-badge timeline-badge-current"><i data-lucide="zap" width="10"></i> Current</span>' : ''}
                    </div>
                    <div class="timeline-subtitle">${company}</div>
                    <div class="timeline-meta">
                        <span class="timeline-meta-item">
                            <i data-lucide="calendar" width="12"></i>
                            ${startDate} — ${endDate}
                        </span>
                    </div>
                </div>
            `;
        });
        
        return html;
    };

    /**
     * Renders education timeline HTML.
     * @param {object[]} education - Array of education history entries
     * @returns {string} HTML string
     */
    const renderEducationTimeline = (education, careerCount = 0) => {
        if (!Array.isArray(education) || education.length === 0) {
            return '<div class="timeline-empty">No education history available</div>';
        }
        
        // Data is already in highest/most recent first order (from pipe-delimited format)
        return education.map((edu, index) => {
            const isHighest = edu.is_highest || edu.isHighest;
            const institution = Utils.sanitizeHTML(edu.institution || '');
            const degree = Utils.sanitizeHTML(edu.degree || '');
            const field = Utils.sanitizeHTML(edu.field || '');
            const year = Utils.sanitizeHTML(edu.year || '');
            const delay = (careerCount + index) * 0.1;
            
            return `
                <div class="timeline-item ${isHighest ? 'timeline-highest' : ''}" style="animation-delay: ${delay}s">
                    <div class="timeline-header">
                        <span class="timeline-title">${degree}${field ? ` in ${field}` : ''}</span>
                        ${isHighest ? '<span class="timeline-badge timeline-badge-highest"><i data-lucide="award" width="10"></i> Highest</span>' : ''}
                    </div>
                    <div class="timeline-subtitle">${institution}</div>
                    <div class="timeline-meta">
                        <span class="timeline-meta-item">
                            <i data-lucide="calendar" width="12"></i>
                            ${year}
                        </span>
                        ${edu.grade ? `
                        <span class="timeline-meta-item">
                            <i data-lucide="star" width="12"></i>
                            ${Utils.sanitizeHTML(edu.grade)}
                        </span>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join('');
    };

    /**
     * Closes the candidate modal.
     */
    const closeCandidateModal = () => {
        const modal = document.getElementById('candidate-modal');
        if (modal) modal.classList.remove('show');
        document.body.style.overflow = '';
    };

    return {
        renderHeaders,
        renderColumnToggles,
        renderTable,
        renderPaginationControls,
        renderKanban,
        showCandidateModal,
        closeCandidateModal,
        renderSubscoresCell
    };
})();

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = UIRenderer;
} else {
    window.UIRenderer = UIRenderer;
}
