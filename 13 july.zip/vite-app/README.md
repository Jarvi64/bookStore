# Programme Tracker wireframe

React, TypeScript, Vite and Zustand wireframe for programme delivery tracking. It currently uses in-memory seed data and has a typed boundary ready for a Dataverse-backed Power Apps Code Apps host.

## Development

```bash
npm install
npm run dev
npm run typecheck
npm run lint
npm run build
```

Copy `.env.example` to `.env` only when using the optional AI-assistant wireframe. Do not add production credentials to a `VITE_*` variable.

## Handoff references

- [Dataverse table schema](docs/DATAVERSE_SCHEMA.md)
- [Dataverse migration guide](docs/DATAVERSE_MIGRATION_GUIDE.md)

Put Dataverse logical names and bindings in table-specific mappers/services. Pages should consume only the stable application models.
