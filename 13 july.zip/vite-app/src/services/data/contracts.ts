/**
 * Persistence boundary. UI code works with domain objects, never Dataverse
 * response shapes. Authentication is supplied by the production host.
 */
export type EntityId = string

export type QueryOptions<T> = {
  filter?: Partial<T>
  orderBy?: keyof T
  descending?: boolean
  top?: number
}

export interface RecordRepository<T extends Record<string, unknown>> {
  list(options?: QueryOptions<T>): Promise<T[]>
  get(id: EntityId): Promise<T | null>
  create(record: Omit<T, "id">): Promise<T>
  update(id: EntityId, changes: Partial<T>): Promise<T>
  delete(id: EntityId): Promise<void>
}

export class DataServiceError extends Error {
  public readonly cause?: unknown

  constructor(message: string, cause?: unknown) {
    super(message)
    this.name = "DataServiceError"
    this.cause = cause
  }
}
