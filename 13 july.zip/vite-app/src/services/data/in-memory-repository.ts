import {
  type EntityId,
  type QueryOptions,
  type RecordRepository,
} from "./contracts"

/** Development-only asynchronous repository for code written for production I/O. */
export class InMemoryRepository<
  T extends { id: EntityId },
> implements RecordRepository<T> {
  private records: T[]

  constructor(seed: T[] = []) {
    this.records = seed.map((record) => ({ ...record }))
  }

  async list(options: QueryOptions<T> = {}): Promise<T[]> {
    const { filter, orderBy, descending = false, top } = options
    let result = this.records.filter((record) =>
      Object.entries(filter ?? {}).every(
        ([key, value]) => record[key as keyof T] === value
      )
    )
    if (orderBy) {
      result = [...result].sort((left, right) => {
        const comparison = String(left[orderBy] ?? "").localeCompare(
          String(right[orderBy] ?? "")
        )
        return descending ? -comparison : comparison
      })
    }
    return result.slice(0, top).map((record) => ({ ...record }))
  }

  async get(id: EntityId): Promise<T | null> {
    const record = this.records.find((candidate) => candidate.id === id)
    return record ? { ...record } : null
  }

  async create(record: Omit<T, "id">): Promise<T> {
    const entity = { ...record, id: crypto.randomUUID() } as T
    this.records.push(entity)
    return { ...entity }
  }

  async update(id: EntityId, changes: Partial<T>): Promise<T> {
    const index = this.records.findIndex((record) => record.id === id)
    if (index < 0) throw new Error(`Record '${id}' was not found.`)
    const updated = { ...this.records[index], ...changes, id }
    this.records[index] = updated
    return { ...updated }
  }

  async delete(id: EntityId): Promise<void> {
    this.records = this.records.filter((record) => record.id !== id)
  }
}
