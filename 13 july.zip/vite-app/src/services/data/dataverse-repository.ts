import {
  DataServiceError,
  type EntityId,
  type QueryOptions,
  type RecordRepository,
} from "./contracts"

export type DataverseClient = {
  retrieveMultipleRecords: <T>(
    table: string,
    query?: string
  ) => Promise<{ entities: T[] }>
  retrieveRecord: <T>(table: string, id: string, query?: string) => Promise<T>
  createRecord: <T>(
    table: string,
    data: Omit<T, "id">
  ) => Promise<{ id: string }>
  updateRecord: <T>(
    table: string,
    id: string,
    data: Partial<T>
  ) => Promise<void>
  deleteRecord: (table: string, id: string) => Promise<void>
}

/** Adapter for an authenticated Power Apps Code Apps/PCF host client. */
export class DataverseRepository<
  T extends { id: EntityId },
> implements RecordRepository<T> {
  private readonly client: DataverseClient
  private readonly tableLogicalName: string

  constructor(client: DataverseClient, tableLogicalName: string) {
    this.client = client
    this.tableLogicalName = tableLogicalName
  }

  async list(options: QueryOptions<T> = {}): Promise<T[]> {
    try {
      const response = await this.client.retrieveMultipleRecords<T>(
        this.tableLogicalName,
        buildODataQuery(options)
      )
      return response.entities
    } catch (error) {
      throw new DataServiceError(
        `Could not load ${this.tableLogicalName}.`,
        error
      )
    }
  }

  async get(id: EntityId): Promise<T | null> {
    try {
      return await this.client.retrieveRecord<T>(this.tableLogicalName, id)
    } catch (error) {
      if (isNotFoundError(error)) return null
      throw new DataServiceError(
        `Could not load ${this.tableLogicalName} record '${id}'.`,
        error
      )
    }
  }

  async create(record: Omit<T, "id">): Promise<T> {
    try {
      const { id } = await this.client.createRecord<T>(
        this.tableLogicalName,
        record
      )
      const created = await this.get(id)
      if (!created) throw new Error("Created record could not be reloaded.")
      return created
    } catch (error) {
      throw new DataServiceError(
        `Could not create ${this.tableLogicalName}.`,
        error
      )
    }
  }

  async update(id: EntityId, changes: Partial<T>): Promise<T> {
    try {
      await this.client.updateRecord<T>(this.tableLogicalName, id, changes)
      const updated = await this.get(id)
      if (!updated) throw new Error("Updated record could not be reloaded.")
      return updated
    } catch (error) {
      throw new DataServiceError(
        `Could not update ${this.tableLogicalName} record '${id}'.`,
        error
      )
    }
  }

  async delete(id: EntityId): Promise<void> {
    try {
      await this.client.deleteRecord(this.tableLogicalName, id)
    } catch (error) {
      throw new DataServiceError(
        `Could not delete ${this.tableLogicalName} record '${id}'.`,
        error
      )
    }
  }
}

function buildODataQuery<T extends Record<string, unknown>>(
  options: QueryOptions<T>
): string | undefined {
  const clauses: string[] = []
  if (options.top) clauses.push(`$top=${Math.max(1, Math.floor(options.top))}`)
  if (options.orderBy)
    clauses.push(
      `$orderby=${String(options.orderBy)} ${options.descending ? "desc" : "asc"}`
    )
  // Table-specific mappers must encode filters: lookups, choices and strings differ in OData.
  return clauses.length ? `?${clauses.join("&")}` : undefined
}

function isNotFoundError(error: unknown): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "status" in error &&
    (error as { status?: number }).status === 404
  )
}
