import { create } from "zustand"

// ── Programme Config (single programme) ──────────────────────
export type ProgrammeConfig = {
  programmeid: string
  name: string
  businessUnit: string
  capability: string
  poc1: string
  poc2: string
  lastreportingweek: string
  notes: string
  t0Start: string // ISO date string (default: "2026-09-01")
}

// ── Programme-level Types ─────────────────────────────────────
export type ProgrammeOrgNode = {
  programmeorgnodeid: string
  programmeid: string
  displayname: string
  title: string
  sortorder: number
  active: string
  parentnodeid: string | null
  orgtype: "admin" | "deliverables" // "admin" = Administrative Org, "deliverables" = Programme Deliverables Org
}

export type Milestone = {
  milestoneid: string
  programmeid: string
  name: string
  startdate: string
  originaltargetedcompletiondate: string
  targetedcompletiondate: string
  ownerorgnodeid: string
  status: string
  remarks: string
  changecount: number
  lastchangereason: string

  // T0 & Payment Extensions
  t0OffsetStart: number // relative month offset from T0 (e.g. 0)
  t0OffsetEnd: number // relative month offset from T0 (e.g. 5)
  deliverable: string // details of the deliverable item
  paymentPercentage: number // payment percentage associated (e.g. 10%)
  parentMilestoneId: string | null // links sub-milestone to parent (null for main milestones)
  assigneeNodeIds?: string[] // assigned team members from deliverables org chart
}

export type SupportRequired = {
  supportrequiredid: string
  programmeid: string
  supporttext: string
  category: string
  criticality: string
  ownerorgnodeid: string
  deadline: string
  status: string
}

export type DateChangeLog = {
  datechangelogid: string
  programmeid: string
  module:
    | "milestone"
    | "support_required"
    | "partner_deliverable"
    | "capex"
    | "opex"
    | "certification"
    | "supply_chain"
  recordid: string
  recordname: string
  fieldname: string
  olddate: string
  newdate: string
  reason: string
  changedon: string
}

export type ManpowerGapHiringPlan = {
  manpowergaphiringplansid: string
  programmeid: string
  role: string
  requiredqty: number
  filledqty: number
  sourcingchannel: string
  targetjoindate: string
  priority: string
  remarks: string
}

export type ManpowerDeliverable = {
  manpowerdeliverableid: string
  programmeid: string
  role: string
  qualification: string
  experience: string
  requiredqty: number
  remarks: string
}

export type WeeklyUpdate = {
  weeklyupdateid: string
  programmeid: string
  weekkey: string // e.g. "2026-W14"
  submittedon: string // ISO datetime
  status: string // Draft / Submitted
}

export type WeeklyUpdateItem = {
  weeklyupdateitemid: string
  weeklyupdateid: string
  category: string
  entrytype: string // "positive" | "negative"
  description: string
}

export type PartnerDeliverable = {
  partnerdeliverableid: string
  programmeid: string
  partnername: string
  deliverable: string
  targetedc: string // ISO string
  currentedc: string // ISO string
  status: string
  riskremarks: string
  ownerorgnodeid: string
}

export type CapexBudget = {
  capexbudgetid: string
  programmeid: string
  item: string
  budgetcr: number
  actualcr: number
  commisiongdate: string
  ownerorgnodeid: string
}

export type OpexBudget = {
  programmebudgetid: string
  programmeid: string
  item: string
  supplier: string
  unitcostcr: number
  targetcostcr: number
  deadline: string
  ownerorgnodeid: string
}

export type Certification = {
  certificationid: string
  programmeid: string
  name: string
  ownerorgnodeid: string
  status: string
  validitydate: string
  currentedc: string
  riskremarks: string
}

export type SupplyChainReadiness = {
  supplychainreadinessid: string
  programmeid: string
  item: string
  supplier: string
  actualcostcr: number
  targetcostcr: number
  variancecr: number
  status: string
  riskremarks: string
  dateoforder: string
  dateofdelivery: string
  leadtime: string
  ownerorgnodeid: string
  milestoneid?: string | null
  quantity?: number
  prDate?: string
  prNumber?: string
  poDate?: string
  poNumber?: string
  poValueCr?: number
  paymentReleasedCr?: number
}

// ── Team Group Weekly Status Types ───────────────────────────
export type TeamGroupWeeklyStatus = {
  teamgroupstatusid: string
  programmeid: string
  teamleadnodeid: string // The org node whose direct reports form this team
  weekkey: string // e.g. "2026-W28"
  submittedon: string // ISO datetime
  overallstatus: string // "On Track" | "Needs Attention" | "Blocked"
  summary: string // Free-text week summary
  memberNodeIds: string[] // Snapshot of member IDs at time of submission
}

export type TeamGroupWeeklyItem = {
  teamgroupitemid: string
  teamgroupstatusid: string
  category: string // Categories from TEAM_UPDATE_CATEGORIES
  entrytype: "positive" | "negative"
  description: string
}

// ── Constants ─────────────────────────────────────────────────
export const MILESTONE_STATUSES = [
  "Not Started",
  "In Progress",
  "Completed",
  "Delayed",
  "At Risk",
] as const
export const SUPPORT_CATEGORIES = [
  "Program",
  "Engineering",
  "SCM",
  "Partner",
  "Manpower",
  "Certifications",
  "Infra/Project",
  "Supply Chain",
  "Finance",
] as const
export const SUPPORT_CRITICALITIES = [
  "Low",
  "Medium",
  "High",
  "Critical",
] as const
export const SUPPORT_STATUSES = [
  "Open",
  "In Progress",
  "Resolved",
  "Closed",
] as const
export const SOURCING_CHANNELS = ["IJP", "External"] as const
export const HIRING_PRIORITIES = ["Low", "Medium", "High", "Critical"] as const
export const WEEKLY_CATEGORIES = [
  "Program",
  "Engineering",
  "SCM",
  "Partner",
  "Manpower",
  "Certifications",
  "Infra/Project",
  "Supply Chain",
  "Finance",
] as const
export const TEAM_UPDATE_CATEGORIES = [
  "Progress",
  "Blockers",
  "Risks",
  "Decisions",
  "Next Week",
] as const
export const WORK_AREAS = [
  "Design",
  "Development",
  "Testing",
  "Review",
  "Documentation",
  "Meetings",
  "Other",
] as const
export const ENTRY_STATUSES = ["Completed", "In Progress", "Blocked"] as const
export const OVERALL_STATUSES = [
  "On Track",
  "Needs Attention",
  "Blocked",
] as const

// ── Store Interface ───────────────────────────────────────────
interface AppState {
  programmeConfig: ProgrammeConfig
  programmeOrgNodes: ProgrammeOrgNode[]
  milestones: Milestone[]
  supportRequired: SupportRequired[]
  dateChangeLogs: DateChangeLog[]
  manpowerPlans: ManpowerGapHiringPlan[]
  manpowerDeliverables: ManpowerDeliverable[]
  weeklyUpdates: WeeklyUpdate[]
  weeklyUpdateItems: WeeklyUpdateItem[]
  partnerDeliverables: PartnerDeliverable[]
  capexBudgets: CapexBudget[]
  opexBudgets: OpexBudget[]
  certifications: Certification[]
  supplyChains: SupplyChainReadiness[]
  teamGroupStatuses: TeamGroupWeeklyStatus[]
  teamGroupItems: TeamGroupWeeklyItem[]

  // Programme Config
  updateProgrammeConfig: (config: Partial<ProgrammeConfig>) => void

  // Programme-level CRUD
  addMilestone: (
    m: Omit<Milestone, "milestoneid" | "changecount" | "lastchangereason">
  ) => void
  updateMilestone: (id: string, m: Partial<Milestone>) => void
  deleteMilestone: (id: string) => void

  addSupportRequired: (s: Omit<SupportRequired, "supportrequiredid">) => void
  updateSupportRequired: (id: string, s: Partial<SupportRequired>) => void
  deleteSupportRequired: (id: string) => void

  addManpowerPlan: (
    p: Omit<ManpowerGapHiringPlan, "manpowergaphiringplansid">
  ) => void
  updateManpowerPlan: (id: string, p: Partial<ManpowerGapHiringPlan>) => void
  deleteManpowerPlan: (id: string) => void

  addManpowerDeliverable: (
    d: Omit<ManpowerDeliverable, "manpowerdeliverableid">
  ) => void
  updateManpowerDeliverable: (
    id: string,
    d: Partial<ManpowerDeliverable>
  ) => void
  deleteManpowerDeliverable: (id: string) => void

  // Org nodes CRUD
  addOrgNode: (
    n: Omit<ProgrammeOrgNode, "programmeorgnodeid">
  ) => ProgrammeOrgNode
  updateOrgNode: (id: string, n: Partial<ProgrammeOrgNode>) => void
  deleteOrgNode: (id: string) => void

  // Weekly Updates
  addWeeklyUpdate: (u: Omit<WeeklyUpdate, "weeklyupdateid">) => WeeklyUpdate
  updateWeeklyUpdate: (id: string, u: Partial<WeeklyUpdate>) => void
  deleteWeeklyUpdate: (id: string) => void

  // Weekly Update Items
  addWeeklyUpdateItem: (
    item: Omit<WeeklyUpdateItem, "weeklyupdateitemid">
  ) => void
  updateWeeklyUpdateItem: (id: string, item: Partial<WeeklyUpdateItem>) => void
  deleteWeeklyUpdateItem: (id: string) => void
  bulkSetWeeklyUpdateItems: (
    weeklyupdateid: string,
    items: Omit<WeeklyUpdateItem, "weeklyupdateitemid">[]
  ) => void

  // Partner Deliverables
  addPartnerDeliverable: (
    d: Omit<PartnerDeliverable, "partnerdeliverableid">
  ) => void
  updatePartnerDeliverable: (id: string, d: Partial<PartnerDeliverable>) => void
  deletePartnerDeliverable: (id: string) => void

  // Budgets
  addCapexBudget: (c: Omit<CapexBudget, "capexbudgetid">) => void
  updateCapexBudget: (id: string, c: Partial<CapexBudget>) => void
  deleteCapexBudget: (id: string) => void

  addOpexBudget: (o: Omit<OpexBudget, "programmebudgetid">) => void
  updateOpexBudget: (id: string, o: Partial<OpexBudget>) => void
  deleteOpexBudget: (id: string) => void

  // Certifications
  addCertification: (c: Omit<Certification, "certificationid">) => void
  updateCertification: (id: string, c: Partial<Certification>) => void
  deleteCertification: (id: string) => void

  // Supply Chain Readiness
  addSupplyChain: (
    s: Omit<SupplyChainReadiness, "supplychainreadinessid">
  ) => void
  updateSupplyChain: (id: string, s: Partial<SupplyChainReadiness>) => void
  deleteSupplyChain: (id: string) => void

  // Team Group Weekly Status
  addTeamGroupStatus: (
    s: Omit<TeamGroupWeeklyStatus, "teamgroupstatusid">
  ) => TeamGroupWeeklyStatus
  updateTeamGroupStatus: (id: string, s: Partial<TeamGroupWeeklyStatus>) => void
  deleteTeamGroupStatus: (id: string) => void

  addTeamGroupItem: (e: Omit<TeamGroupWeeklyItem, "teamgroupitemid">) => void
  updateTeamGroupItem: (id: string, e: Partial<TeamGroupWeeklyItem>) => void
  deleteTeamGroupItem: (id: string) => void
  bulkSetTeamGroupItems: (
    teamgroupstatusid: string,
    items: Omit<TeamGroupWeeklyItem, "teamgroupitemid">[]
  ) => void

  // Date change log (append-only)
  addDateChangeLog: (
    log: Omit<DateChangeLog, "datechangelogid" | "changedon">
  ) => void
}

// ── Seed Data ─────────────────────────────────────────────────
const PROGRAMME_CONFIG: ProgrammeConfig = {
  programmeid: "prog_1",
  name: "Third Eye",
  businessUnit: "Defence & Aerospace",
  capability: "Surveillance & Reconnaissance",
  poc1: "Alice Smith",
  poc2: "Bob Johnson",
  lastreportingweek: "2026-W14",
  notes: "Advanced surveillance and reconnaissance programme",
  t0Start: "2026-06-01",
}

const SEED_ORG_NODES: ProgrammeOrgNode[] = [
  // ── Administrative Org (Tab 1) ───────────────────────────────
  {
    programmeorgnodeid: "org_1",
    programmeid: "prog_1",
    displayname: "Alice Smith",
    title: "Programme Director",
    sortorder: 1,
    active: "Yes",
    parentnodeid: null,
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_2",
    programmeid: "prog_1",
    displayname: "Bob Johnson",
    title: "Tech Lead",
    sortorder: 2,
    active: "Yes",
    parentnodeid: "org_1",
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_3",
    programmeid: "prog_1",
    displayname: "Charlie Davis",
    title: "Delivery Manager",
    sortorder: 3,
    active: "Yes",
    parentnodeid: "org_1",
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_4",
    programmeid: "prog_1",
    displayname: "Priya Nair",
    title: "Finance Controller",
    sortorder: 4,
    active: "Yes",
    parentnodeid: "org_1",
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_5",
    programmeid: "prog_1",
    displayname: "Rajan Mehta",
    title: "Senior Systems Engineer",
    sortorder: 5,
    active: "Yes",
    parentnodeid: "org_2",
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_6",
    programmeid: "prog_1",
    displayname: "Sunita Rao",
    title: "Firmware Engineer",
    sortorder: 6,
    active: "Yes",
    parentnodeid: "org_2",
    orgtype: "admin",
  },
  {
    programmeorgnodeid: "org_7",
    programmeid: "prog_1",
    displayname: "Kevin D'Souza",
    title: "SCM Lead",
    sortorder: 7,
    active: "Yes",
    parentnodeid: "org_3",
    orgtype: "admin",
  },

  // ── Programme Deliverables Org (Tab 2) ───────────────────────
  {
    programmeorgnodeid: "dorg_1",
    programmeid: "prog_1",
    displayname: "Alice Smith",
    title: "Programme Lead (Deliverables)",
    sortorder: 1,
    active: "Yes",
    parentnodeid: null,
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_2",
    programmeid: "prog_1",
    displayname: "Vikram Anand",
    title: "Systems Engineering Lead",
    sortorder: 2,
    active: "Yes",
    parentnodeid: "dorg_1",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_3",
    programmeid: "prog_1",
    displayname: "Aisha Kapoor",
    title: "Software Lead",
    sortorder: 3,
    active: "Yes",
    parentnodeid: "dorg_1",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_4",
    programmeid: "prog_1",
    displayname: "James Mathew",
    title: "Testing & Validation Lead",
    sortorder: 4,
    active: "Yes",
    parentnodeid: "dorg_1",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_5",
    programmeid: "prog_1",
    displayname: "Kevin D'Souza",
    title: "SCM / Logistics Lead",
    sortorder: 5,
    active: "Yes",
    parentnodeid: "dorg_1",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_6",
    programmeid: "prog_1",
    displayname: "Rajan Mehta",
    title: "Radar Signal Processing Architect",
    sortorder: 6,
    active: "Yes",
    parentnodeid: "dorg_2",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_7",
    programmeid: "prog_1",
    displayname: "Sunita Rao",
    title: "Embedded Firmware Engineer",
    sortorder: 7,
    active: "Yes",
    parentnodeid: "dorg_2",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_8",
    programmeid: "prog_1",
    displayname: "Priya Nair",
    title: "GUI Developer",
    sortorder: 8,
    active: "Yes",
    parentnodeid: "dorg_3",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_9",
    programmeid: "prog_1",
    displayname: "Arjun Pillai",
    title: "Sensor SDK Engineer",
    sortorder: 9,
    active: "Yes",
    parentnodeid: "dorg_3",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_10",
    programmeid: "prog_1",
    displayname: "Meera Thomas",
    title: "Lab Test Engineer",
    sortorder: 10,
    active: "Yes",
    parentnodeid: "dorg_4",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_11",
    programmeid: "prog_1",
    displayname: "Dev Sharma",
    title: "Environmental Qual. Engineer",
    sortorder: 11,
    active: "Yes",
    parentnodeid: "dorg_4",
    orgtype: "deliverables",
  },
  {
    programmeorgnodeid: "dorg_12",
    programmeid: "prog_1",
    displayname: "Fatima Sheikh",
    title: "Supply Chain Coordinator",
    sortorder: 12,
    active: "Yes",
    parentnodeid: "dorg_5",
    orgtype: "deliverables",
  },
]

const SEED_MILESTONES: Milestone[] = [
  // M1
  {
    milestoneid: "ms_1",
    programmeid: "prog_1",
    name: "Milestone 1: Preliminary Design Review (PDR)",
    startdate: "2026-06-01",
    originaltargetedcompletiondate: "2026-11-30",
    targetedcompletiondate: "2026-11-30",
    ownerorgnodeid: "org_1",
    status: "At Risk",
    remarks: "Requirements review delayed",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 0,
    t0OffsetEnd: 5,
    deliverable: "PDR Design Package & System Requirements Document",
    paymentPercentage: 0,
    parentMilestoneId: null,
    assigneeNodeIds: [],
  },
  {
    milestoneid: "ms_1_1",
    programmeid: "prog_1",
    name: "System Requirements Sign-off",
    startdate: "2026-06-01",
    originaltargetedcompletiondate: "2026-07-15",
    targetedcompletiondate: "2026-07-15",
    ownerorgnodeid: "org_1",
    status: "At Risk",
    remarks: "Awaiting stakeholder signature",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 0,
    t0OffsetEnd: 3,
    deliverable: "System Requirements Specification (SRS)",
    paymentPercentage: 10,
    parentMilestoneId: "ms_1",
    assigneeNodeIds: ["dorg_2", "dorg_3"],
  },
  {
    milestoneid: "ms_1_2",
    programmeid: "prog_1",
    name: "PDR Clearance Certificate",
    startdate: "2026-07-16",
    originaltargetedcompletiondate: "2026-11-30",
    targetedcompletiondate: "2026-11-30",
    ownerorgnodeid: "org_2",
    status: "In Progress",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 3,
    t0OffsetEnd: 5,
    deliverable: "PDR Certificate signed by Authority",
    paymentPercentage: 10,
    parentMilestoneId: "ms_1",
    assigneeNodeIds: ["dorg_2", "dorg_6", "dorg_7"],
  },

  // M2
  {
    milestoneid: "ms_2",
    programmeid: "prog_1",
    name: "Milestone 2: Critical Design Review (CDR)",
    startdate: "2026-12-01",
    originaltargetedcompletiondate: "2027-06-30",
    targetedcompletiondate: "2027-06-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 5,
    t0OffsetEnd: 12,
    deliverable: "System Design Freeze & Prototype Specifications",
    paymentPercentage: 0,
    parentMilestoneId: null,
    assigneeNodeIds: [],
  },
  {
    milestoneid: "ms_2_1",
    programmeid: "prog_1",
    name: "Sub-system Schematics Review",
    startdate: "2026-12-01",
    originaltargetedcompletiondate: "2027-04-30",
    targetedcompletiondate: "2027-04-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 5,
    t0OffsetEnd: 10,
    deliverable: "Engineering Drawings Package",
    paymentPercentage: 5,
    parentMilestoneId: "ms_2",
    assigneeNodeIds: ["dorg_2", "dorg_7"],
  },
  {
    milestoneid: "ms_2_2",
    programmeid: "prog_1",
    name: "CDR Gate Clearance",
    startdate: "2027-05-01",
    originaltargetedcompletiondate: "2027-06-30",
    targetedcompletiondate: "2027-06-30",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 10,
    t0OffsetEnd: 12,
    deliverable: "CDR Approval Sign-off",
    paymentPercentage: 5,
    parentMilestoneId: "ms_2",
    assigneeNodeIds: ["dorg_2", "dorg_3"],
  },

  // M3
  {
    milestoneid: "ms_3",
    programmeid: "prog_1",
    name: "Milestone 3: Prototype Manufacturing & Testing",
    startdate: "2027-10-01",
    originaltargetedcompletiondate: "2028-09-30",
    targetedcompletiondate: "2028-09-30",
    ownerorgnodeid: "org_2",
    status: "In Progress",
    remarks: "Assembly & unit level checks in execution",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 12,
    t0OffsetEnd: 24,
    deliverable: "First Prototype Unit & Test Bench Report",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_3_1",
    programmeid: "prog_1",
    name: "Material Sourcing & Fabrication",
    startdate: "2027-10-01",
    originaltargetedcompletiondate: "2028-05-31",
    targetedcompletiondate: "2028-05-31",
    ownerorgnodeid: "org_3",
    status: "Completed",
    remarks: "Fabrication complete",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 12,
    t0OffsetEnd: 20,
    deliverable: "BOM Sourced Certificate",
    paymentPercentage: 5,
    parentMilestoneId: "ms_3",
  },
  {
    milestoneid: "ms_3_2",
    programmeid: "prog_1",
    name: "Prototype Fabrication & Assembly",
    startdate: "2028-06-01",
    originaltargetedcompletiondate: "2028-07-31",
    targetedcompletiondate: "2028-07-31",
    ownerorgnodeid: "org_2",
    status: "In Progress",
    remarks: "Cabling & packaging work active",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 20,
    t0OffsetEnd: 22,
    deliverable: "Prototype Unit Assembly",
    paymentPercentage: 5,
    parentMilestoneId: "ms_3",
  },
  {
    milestoneid: "ms_3_3",
    programmeid: "prog_1",
    name: "Unit Level Verification",
    startdate: "2028-08-01",
    originaltargetedcompletiondate: "2028-09-30",
    targetedcompletiondate: "2028-09-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 22,
    t0OffsetEnd: 24,
    deliverable: "Test Bench Evaluation Report",
    paymentPercentage: 5,
    parentMilestoneId: "ms_3",
  },

  // M4
  {
    milestoneid: "ms_4",
    programmeid: "prog_1",
    name: "Milestone 4: Software Integration & Platform Release",
    startdate: "2028-10-01",
    originaltargetedcompletiondate: "2029-09-30",
    targetedcompletiondate: "2029-09-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 24,
    t0OffsetEnd: 36,
    deliverable: "Integrated Software Suite v1.0",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_4_1",
    programmeid: "prog_1",
    name: "Sensor Driver SDKs Integration",
    startdate: "2028-10-01",
    originaltargetedcompletiondate: "2029-03-31",
    targetedcompletiondate: "2029-03-31",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 24,
    t0OffsetEnd: 30,
    deliverable: "Sensor Communication Layer",
    paymentPercentage: 5,
    parentMilestoneId: "ms_4",
  },
  {
    milestoneid: "ms_4_2",
    programmeid: "prog_1",
    name: "Software GUI Release v1.0",
    startdate: "2029-04-01",
    originaltargetedcompletiondate: "2029-09-30",
    targetedcompletiondate: "2029-09-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 30,
    t0OffsetEnd: 36,
    deliverable: "GUI Command Interface v1.0",
    paymentPercentage: 5,
    parentMilestoneId: "ms_4",
  },

  // M5
  {
    milestoneid: "ms_5",
    programmeid: "prog_1",
    name: "Milestone 5: Subsystem Acceptance Testing (SAT)",
    startdate: "2029-10-01",
    originaltargetedcompletiondate: "2030-09-30",
    targetedcompletiondate: "2030-09-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 36,
    t0OffsetEnd: 48,
    deliverable: "SAT Clearance Certificate",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_5_1",
    programmeid: "prog_1",
    name: "Lab Validation Testing",
    startdate: "2029-10-01",
    originaltargetedcompletiondate: "2030-05-31",
    targetedcompletiondate: "2030-05-31",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 36,
    t0OffsetEnd: 44,
    deliverable: "Lab Acceptance Test Report",
    paymentPercentage: 5,
    parentMilestoneId: "ms_5",
  },
  {
    milestoneid: "ms_5_2",
    programmeid: "prog_1",
    name: "Environmental Stress Screenings",
    startdate: "2030-06-01",
    originaltargetedcompletiondate: "2030-09-30",
    targetedcompletiondate: "2030-09-30",
    ownerorgnodeid: "org_3",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 44,
    t0OffsetEnd: 48,
    deliverable: "Environmental Qualification Certificate",
    paymentPercentage: 5,
    parentMilestoneId: "ms_5",
  },

  // M6
  {
    milestoneid: "ms_6",
    programmeid: "prog_1",
    name: "Milestone 6: Pilot Production (2 Sets of XY)",
    startdate: "2030-10-01",
    originaltargetedcompletiondate: "2031-05-31",
    targetedcompletiondate: "2031-05-31",
    ownerorgnodeid: "org_3",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 48,
    t0OffsetEnd: 56,
    deliverable: "2 Sets of XY Radar Units",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_6_1",
    programmeid: "prog_1",
    name: "Manufacturing Setup & Assembly",
    startdate: "2030-10-01",
    originaltargetedcompletiondate: "2031-01-31",
    targetedcompletiondate: "2031-01-31",
    ownerorgnodeid: "org_3",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 48,
    t0OffsetEnd: 52,
    deliverable: "Assembly Readiness Clearance",
    paymentPercentage: 5,
    parentMilestoneId: "ms_6",
  },
  {
    milestoneid: "ms_6_2",
    programmeid: "prog_1",
    name: "Acceptable Delivery of 2 XY Sets",
    startdate: "2031-02-01",
    originaltargetedcompletiondate: "2031-05-31",
    targetedcompletiondate: "2031-05-31",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 52,
    t0OffsetEnd: 56,
    deliverable: "Delivery Handover Receipt",
    paymentPercentage: 5,
    parentMilestoneId: "ms_6",
  },

  // M7
  {
    milestoneid: "ms_7",
    programmeid: "prog_1",
    name: "Milestone 7: Operational Field Trials",
    startdate: "2031-06-01",
    originaltargetedcompletiondate: "2032-01-31",
    targetedcompletiondate: "2032-01-31",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 56,
    t0OffsetEnd: 64,
    deliverable: "Operational Evaluation Report",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_7_1",
    programmeid: "prog_1",
    name: "Field Site Deployment",
    startdate: "2031-06-01",
    originaltargetedcompletiondate: "2031-09-30",
    targetedcompletiondate: "2031-09-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 56,
    t0OffsetEnd: 60,
    deliverable: "Installation Readiness Report",
    paymentPercentage: 5,
    parentMilestoneId: "ms_7",
  },
  {
    milestoneid: "ms_7_2",
    programmeid: "prog_1",
    name: "Joint Tactical Trials Evaluation",
    startdate: "2031-10-01",
    originaltargetedcompletiondate: "2032-01-31",
    targetedcompletiondate: "2032-01-31",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 60,
    t0OffsetEnd: 64,
    deliverable: "Joint Acceptance Sign-off Certificate",
    paymentPercentage: 5,
    parentMilestoneId: "ms_7",
  },

  // M8
  {
    milestoneid: "ms_8",
    programmeid: "prog_1",
    name: "Milestone 8: Full Scale Production Setup",
    startdate: "2032-02-01",
    originaltargetedcompletiondate: "2032-09-30",
    targetedcompletiondate: "2032-09-30",
    ownerorgnodeid: "org_3",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 64,
    t0OffsetEnd: 72,
    deliverable: "Commissioned Assembly Line",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_8_1",
    programmeid: "prog_1",
    name: "Supply Chain Procurement Check",
    startdate: "2032-02-01",
    originaltargetedcompletiondate: "2032-05-31",
    targetedcompletiondate: "2032-05-31",
    ownerorgnodeid: "org_3",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 64,
    t0OffsetEnd: 68,
    deliverable: "SCM Clearance Report",
    paymentPercentage: 5,
    parentMilestoneId: "ms_8",
  },
  {
    milestoneid: "ms_8_2",
    programmeid: "prog_1",
    name: "Production Line Commissioning",
    startdate: "2032-06-01",
    originaltargetedcompletiondate: "2032-09-30",
    targetedcompletiondate: "2032-09-30",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 68,
    t0OffsetEnd: 72,
    deliverable: "Manufacturing Audit Certificate",
    paymentPercentage: 5,
    parentMilestoneId: "ms_8",
  },

  // M9
  {
    milestoneid: "ms_9",
    programmeid: "prog_1",
    name: "Milestone 9: Final Product Handover",
    startdate: "2032-10-01",
    originaltargetedcompletiondate: "2033-01-31",
    targetedcompletiondate: "2033-01-31",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 72,
    t0OffsetEnd: 76,
    deliverable: "Confidential Handover Certificate Package",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_9_1",
    programmeid: "prog_1",
    name: "Final Handover Sign-off",
    startdate: "2032-10-01",
    originaltargetedcompletiondate: "2033-01-31",
    targetedcompletiondate: "2033-01-31",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 72,
    t0OffsetEnd: 76,
    deliverable: "Handover Certificate signed by Client",
    paymentPercentage: 5,
    parentMilestoneId: "ms_9",
  },

  // M10
  {
    milestoneid: "ms_10",
    programmeid: "prog_1",
    name: "Milestone 10: Project Close-out",
    startdate: "2033-02-01",
    originaltargetedcompletiondate: "2033-04-30",
    targetedcompletiondate: "2033-04-30",
    ownerorgnodeid: "org_1",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 76,
    t0OffsetEnd: 79,
    deliverable: "Acceptance & Project Close-out Certificate",
    paymentPercentage: 0,
    parentMilestoneId: null,
  },
  {
    milestoneid: "ms_10_1",
    programmeid: "prog_1",
    name: "Audit Clearance & Closure",
    startdate: "2033-02-01",
    originaltargetedcompletiondate: "2033-04-30",
    targetedcompletiondate: "2033-04-30",
    ownerorgnodeid: "org_2",
    status: "Not Started",
    remarks: "",
    changecount: 0,
    lastchangereason: "",
    t0OffsetStart: 76,
    t0OffsetEnd: 79,
    deliverable: "Final Closure Certificate",
    paymentPercentage: 5,
    parentMilestoneId: "ms_10",
  },
]

const SEED_SUPPORT: SupportRequired[] = [
  {
    supportrequiredid: "sup_1",
    programmeid: "prog_1",
    supporttext: "Need dedicated DevOps engineer for CI/CD pipeline setup",
    category: "Engineering",
    criticality: "High",
    ownerorgnodeid: "org_2",
    deadline: "2026-04-15",
    status: "Open",
  },
  {
    supportrequiredid: "sup_2",
    programmeid: "prog_1",
    supporttext: "Partner API documentation access required",
    category: "Partner",
    criticality: "Critical",
    ownerorgnodeid: "org_3",
    deadline: "2026-04-10",
    status: "In Progress",
  },
]

const SEED_MANPOWER: ManpowerGapHiringPlan[] = [
  {
    manpowergaphiringplansid: "mp_1",
    programmeid: "prog_1",
    role: "Senior Backend Engineer",
    requiredqty: 3,
    filledqty: 2,
    sourcingchannel: "IJP",
    targetjoindate: "2026-05-01",
    priority: "High",
    remarks: "Need Java/Spring expertise",
  },
  {
    manpowergaphiringplansid: "mp_2",
    programmeid: "prog_1",
    role: "DevOps Engineer",
    requiredqty: 2,
    filledqty: 0,
    sourcingchannel: "External",
    targetjoindate: "2026-04-15",
    priority: "Critical",
    remarks: "CI/CD pipeline setup",
  },
  {
    manpowergaphiringplansid: "mp_3",
    programmeid: "prog_1",
    role: "QA Automation Lead",
    requiredqty: 1,
    filledqty: 1,
    sourcingchannel: "IJP",
    targetjoindate: "2026-03-15",
    priority: "Medium",
    remarks: "",
  },
]

const SEED_MANPOWER_DELIVERABLES: ManpowerDeliverable[] = [
  {
    manpowerdeliverableid: "mpd_1",
    programmeid: "prog_1",
    role: "Radar Signal Processing Architect",
    qualification: "M.Tech / PhD in Electronics & Comm",
    experience: "6-10 Years",
    requiredqty: 2,
    remarks: "Key algorithms design",
  },
  {
    manpowerdeliverableid: "mpd_2",
    programmeid: "prog_1",
    role: "Embedded Systems Firmware Engineer",
    qualification: "B.Tech / M.Tech CSE/ECE",
    experience: "3-6 Years",
    requiredqty: 4,
    remarks: "Sub-system firmware fabrication",
  },
  {
    manpowerdeliverableid: "mpd_3",
    programmeid: "prog_1",
    role: "Systems Integration & Validation Lead",
    qualification: "B.Tech ECE/EEE",
    experience: "5-9 Years",
    requiredqty: 1,
    remarks: "Field deployment testing coordination",
  },
]

const now = new Date()
const twoDaysAgo = new Date(now.getTime() - 2 * 86400000).toISOString()

const SEED_DATE_LOGS: DateChangeLog[] = [
  {
    datechangelogid: "dcl_1",
    programmeid: "prog_1",
    module: "milestone",
    recordid: "ms_1",
    recordname: "Preliminary Design Review (PDR)",
    fieldname: "targetedcompletiondate",
    olddate: "2026-02-28",
    newdate: "2026-03-10",
    reason: "Stakeholder review delayed",
    changedon: twoDaysAgo,
  },
]

const SEED_WEEKLY_UPDATES: WeeklyUpdate[] = [
  {
    weeklyupdateid: "wu_1",
    programmeid: "prog_1",
    weekkey: "2026-W13",
    submittedon: "2026-03-28T10:30:00Z",
    status: "Submitted",
  },
  {
    weeklyupdateid: "wu_2",
    programmeid: "prog_1",
    weekkey: "2026-W14",
    submittedon: "2026-04-04T14:15:00Z",
    status: "Submitted",
  },
]

const SEED_WEEKLY_ITEMS: WeeklyUpdateItem[] = [
  {
    weeklyupdateitemid: "wui_1",
    weeklyupdateid: "wu_1",
    category: "Program",
    entrytype: "positive",
    description: "Requirements sign-off achieved ahead of schedule",
  },
  {
    weeklyupdateitemid: "wui_2",
    weeklyupdateid: "wu_1",
    category: "Program",
    entrytype: "negative",
    description: "Stakeholder availability remains a bottleneck",
  },
  {
    weeklyupdateitemid: "wui_3",
    weeklyupdateid: "wu_1",
    category: "Engineering",
    entrytype: "positive",
    description: "CI/CD pipeline setup completed",
  },
  {
    weeklyupdateitemid: "wui_8",
    weeklyupdateid: "wu_2",
    category: "Program",
    entrytype: "positive",
    description: "Requirements sign-off achieved ahead of schedule",
  },
  {
    weeklyupdateitemid: "wui_9",
    weeklyupdateid: "wu_2",
    category: "Program",
    entrytype: "positive",
    description: "Architecture review meeting scheduled for next week",
  },
  {
    weeklyupdateitemid: "wui_13",
    weeklyupdateid: "wu_2",
    category: "Engineering",
    entrytype: "negative",
    description: "Beta release delayed due to partner API integration",
  },
]

const SEED_PARTNER_DELIVERABLES: PartnerDeliverable[] = [
  {
    partnerdeliverableid: "pd_1",
    programmeid: "prog_1",
    partnername: "AWS",
    deliverable: "Cloud Infrastructure Setup & Security Audit",
    targetedc: "2026-05-01",
    currentedc: "2026-05-15",
    status: "In Progress",
    riskremarks: "Waiting on compliance team",
    ownerorgnodeid: "org_2",
  },
]

const SEED_CAPEX: CapexBudget[] = [
  {
    capexbudgetid: "capx_1",
    programmeid: "prog_1",
    item: "Assembly Line Conveyors",
    budgetcr: 4.5,
    actualcr: 4.65,
    commisiongdate: "2026-07-01",
    ownerorgnodeid: "org_1",
  },
]

const SEED_OPEX: OpexBudget[] = [
  {
    programmebudgetid: "opx_1",
    programmeid: "prog_1",
    item: "Software Licensing",
    supplier: "Microsoft",
    unitcostcr: 0.1,
    targetcostcr: 5.0,
    deadline: "2026-12-31",
    ownerorgnodeid: "org_1",
  },
]

const SEED_CERTIFICATIONS: Certification[] = [
  {
    certificationid: "cert_1",
    programmeid: "prog_1",
    name: "ISO 9001 Compliance Audit",
    status: "In Review",
    validitydate: "2027-01-01",
    currentedc: "2026-11-01",
    riskremarks: "",
    ownerorgnodeid: "org_3",
  },
]

const SEED_SUPPLY_CHAIN: SupplyChainReadiness[] = [
  {
    supplychainreadinessid: "scr_1",
    programmeid: "prog_1",
    item: "Raw Steel Sheets",
    supplier: "Tata Steel",
    actualcostcr: 12.5,
    targetcostcr: 12.0,
    variancecr: -0.5,
    status: "In Transit",
    riskremarks: "Delay in shipping port",
    dateoforder: "2026-02-15",
    dateofdelivery: "2026-04-30",
    leadtime: "10 Weeks",
    ownerorgnodeid: "org_1",
    milestoneid: "ms_1_1",
    quantity: 500,
    prDate: "2026-01-10",
    prNumber: "PR-2026-001",
    poDate: "2026-02-15",
    poNumber: "PO-2026-042",
    poValueCr: 12.2,
    paymentReleasedCr: 6.1,
  },
  {
    supplychainreadinessid: "scr_2",
    programmeid: "prog_1",
    item: "Copper Wiring Alloys",
    supplier: "Hindalco",
    actualcostcr: 3.8,
    targetcostcr: 4.0,
    variancecr: 0.2,
    status: "Ordered",
    riskremarks: "",
    dateoforder: "2026-03-01",
    dateofdelivery: "2026-06-15",
    leadtime: "14 Weeks",
    ownerorgnodeid: "org_2",
    milestoneid: "ms_1_2",
    quantity: 1500,
    prDate: "2026-02-05",
    prNumber: "PR-2026-003",
    poDate: "2026-03-01",
    poNumber: "PO-2026-068",
    poValueCr: 3.8,
    paymentReleasedCr: 0.95,
  },
  {
    supplychainreadinessid: "scr_3",
    programmeid: "prog_1",
    item: "Signal Processor Modules",
    supplier: "Texas Instruments",
    actualcostcr: 0,
    targetcostcr: 8.5,
    variancecr: 8.5,
    status: "Sourcing",
    riskremarks:
      "Awaiting export clearance licence approvals from overseas regulator",
    dateoforder: "",
    dateofdelivery: "2026-10-31",
    leadtime: "24 Weeks",
    ownerorgnodeid: "org_2",
    milestoneid: "ms_1_2",
    quantity: 200,
    prDate: "2026-05-10",
    prNumber: "PR-2026-018",
    poDate: "",
    poNumber: "",
    poValueCr: 0,
    paymentReleasedCr: 0,
  },
  {
    supplychainreadinessid: "scr_4",
    programmeid: "prog_1",
    item: "Aluminum Alloy Casings (7075-T6)",
    supplier: "Vedanta Aluminium",
    actualcostcr: 5.2,
    targetcostcr: 5.0,
    variancecr: -0.2,
    status: "Delivered",
    riskremarks: "",
    dateoforder: "2025-11-01",
    dateofdelivery: "2026-02-15",
    leadtime: "14 Weeks",
    ownerorgnodeid: "org_3",
    milestoneid: "ms_3_1",
    quantity: 120,
    prDate: "2025-09-20",
    prNumber: "PR-2025-088",
    poDate: "2025-11-01",
    poNumber: "PO-2025-214",
    poValueCr: 5.0,
    paymentReleasedCr: 5.0,
  },
  {
    supplychainreadinessid: "scr_5",
    programmeid: "prog_1",
    item: "High-Freq PCBs (Rogers 4003C)",
    supplier: "AT&S India",
    actualcostcr: 2.1,
    targetcostcr: 2.5,
    variancecr: 0.4,
    status: "Ordered",
    riskremarks: "Supplier confirmed delivery window",
    dateoforder: "2026-05-15",
    dateofdelivery: "2026-08-30",
    leadtime: "12 Weeks",
    ownerorgnodeid: "org_2",
    milestoneid: "ms_2_1",
    quantity: 300,
    prDate: "2026-04-01",
    prNumber: "PR-2026-025",
    poDate: "2026-05-15",
    poNumber: "PO-2026-103",
    poValueCr: 2.5,
    paymentReleasedCr: 0.75,
  },
  {
    supplychainreadinessid: "scr_6",
    programmeid: "prog_1",
    item: "FPGA Dev Kit (Xilinx Kintex UltraScale)",
    supplier: "AMD / Xilinx",
    actualcostcr: 0,
    targetcostcr: 15.0,
    variancecr: 15.0,
    status: "Delayed",
    riskremarks:
      "Export control clearance pending from US Commerce Dept. Expected 6-week delay.",
    dateoforder: "2026-03-10",
    dateofdelivery: "2026-09-15",
    leadtime: "26 Weeks",
    ownerorgnodeid: "org_2",
    milestoneid: "ms_1_2",
    quantity: 8,
    prDate: "2026-01-15",
    prNumber: "PR-2026-005",
    poDate: "2026-03-10",
    poNumber: "PO-2026-051",
    poValueCr: 14.8,
    paymentReleasedCr: 0,
  },
  {
    supplychainreadinessid: "scr_7",
    programmeid: "prog_1",
    item: "Waveguide Assemblies",
    supplier: "Bharat Electronics Ltd (BEL)",
    actualcostcr: 7.5,
    targetcostcr: 7.0,
    variancecr: -0.5,
    status: "In Transit",
    riskremarks: "Shipment cleared customs — in domestic transit",
    dateoforder: "2026-01-20",
    dateofdelivery: "2026-07-10",
    leadtime: "20 Weeks",
    ownerorgnodeid: "org_1",
    milestoneid: "ms_1_2",
    quantity: 50,
    prDate: "2025-12-01",
    prNumber: "PR-2025-102",
    poDate: "2026-01-20",
    poNumber: "PO-2026-022",
    poValueCr: 7.2,
    paymentReleasedCr: 3.6,
  },
  {
    supplychainreadinessid: "scr_8",
    programmeid: "prog_1",
    item: "Power Supply Units (MIL-STD-810)",
    supplier: "Emerson Network Power",
    actualcostcr: 3.0,
    targetcostcr: 3.2,
    variancecr: 0.2,
    status: "Delivered",
    riskremarks: "",
    dateoforder: "2025-10-15",
    dateofdelivery: "2026-01-30",
    leadtime: "14 Weeks",
    ownerorgnodeid: "org_3",
    milestoneid: "ms_3_1",
    quantity: 25,
    prDate: "2025-09-01",
    prNumber: "PR-2025-075",
    poDate: "2025-10-15",
    poNumber: "PO-2025-198",
    poValueCr: 3.15,
    paymentReleasedCr: 3.15,
  },
  {
    supplychainreadinessid: "scr_9",
    programmeid: "prog_1",
    item: "Thermal Interface Material (TIM)",
    supplier: "Henkel Loctite",
    actualcostcr: 0,
    targetcostcr: 1.2,
    variancecr: 1.2,
    status: "Sourcing",
    riskremarks: "Evaluating 3 alternative suppliers for MIL-spec compliance",
    dateoforder: "",
    dateofdelivery: "2026-11-30",
    leadtime: "8 Weeks",
    ownerorgnodeid: "org_7",
    milestoneid: "ms_2_1",
    quantity: 1000,
    prDate: "",
    prNumber: "",
    poDate: "",
    poNumber: "",
    poValueCr: 0,
    paymentReleasedCr: 0,
  },
  {
    supplychainreadinessid: "scr_10",
    programmeid: "prog_1",
    item: "Ruggedized Connector Assemblies",
    supplier: "Amphenol India",
    actualcostcr: 1.8,
    targetcostcr: 2.0,
    variancecr: 0.2,
    status: "Ordered",
    riskremarks: "",
    dateoforder: "2026-06-01",
    dateofdelivery: "2026-09-30",
    leadtime: "16 Weeks",
    ownerorgnodeid: "org_3",
    milestoneid: "ms_3_2",
    quantity: 400,
    prDate: "2026-04-20",
    prNumber: "PR-2026-031",
    poDate: "2026-06-01",
    poNumber: "PO-2026-119",
    poValueCr: 2.0,
    paymentReleasedCr: 0.5,
  },
]

// ── Team Group Weekly Status Seed Data ──────────────────────────
const SEED_TEAM_GROUP_STATUSES: TeamGroupWeeklyStatus[] = [
  // Systems Engineering Lead team (Vikram Anand - dorg_2)
  {
    teamgroupstatusid: "tgs_1",
    programmeid: "prog_1",
    teamleadnodeid: "dorg_2",
    weekkey: "2026-W26",
    submittedon: "2026-06-27T16:30:00Z",
    overallstatus: "Needs Attention",
    summary:
      "Systems engineering updates for W26. Interface design is progressing well but updating requirements matrix is currently delayed due to pending inputs from software partners.",
    memberNodeIds: ["dorg_6", "dorg_7"],
  },
  {
    teamgroupstatusid: "tgs_2",
    programmeid: "prog_1",
    teamleadnodeid: "dorg_2",
    weekkey: "2026-W27",
    submittedon: "2026-07-04T11:00:00Z",
    overallstatus: "On Track",
    summary:
      "PDR preparation is on track. Missing partner inputs for requirements matrix have been received. RTOS integration is ongoing.",
    memberNodeIds: ["dorg_6", "dorg_7"],
  },
  // Software Lead team (Aisha Kapoor - dorg_3)
  {
    teamgroupstatusid: "tgs_3",
    programmeid: "prog_1",
    teamleadnodeid: "dorg_3",
    weekkey: "2026-W27",
    submittedon: "2026-07-04T12:00:00Z",
    overallstatus: "Needs Attention",
    summary:
      "Software GUI prototyping is on track, but SDK integration is delayed due to missing driver documentation from external sensor partner.",
    memberNodeIds: ["dorg_8", "dorg_9"],
  },
]

const SEED_TEAM_GROUP_ITEMS: TeamGroupWeeklyItem[] = [
  // tgs_1
  {
    teamgroupitemid: "tgi_1",
    teamgroupstatusid: "tgs_1",
    category: "Progress",
    entrytype: "positive",
    description: "Waveform analysis mathematical models for X-band completed",
  },
  {
    teamgroupitemid: "tgi_2",
    teamgroupstatusid: "tgs_1",
    category: "Progress",
    entrytype: "positive",
    description: "Firmware boot sequence architecture document signed off",
  },
  {
    teamgroupitemid: "tgi_3",
    teamgroupstatusid: "tgs_1",
    category: "Blockers",
    entrytype: "negative",
    description:
      "Requirements matrix updates blocked by partner interface specs",
  },

  // tgs_2
  {
    teamgroupitemid: "tgi_4",
    teamgroupstatusid: "tgs_2",
    category: "Progress",
    entrytype: "positive",
    description: "Requirements matrix update resumed and now 80% complete",
  },
  {
    teamgroupitemid: "tgi_5",
    teamgroupstatusid: "tgs_2",
    category: "Progress",
    entrytype: "positive",
    description: "MATLAB signal chain simulation scripts validated",
  },
  {
    teamgroupitemid: "tgi_6",
    teamgroupstatusid: "tgs_2",
    category: "Risks",
    entrytype: "negative",
    description:
      "Flash memory budget limits are tight; optimization may be required",
  },

  // tgs_3
  {
    teamgroupitemid: "tgi_7",
    teamgroupstatusid: "tgs_3",
    category: "Progress",
    entrytype: "positive",
    description: "GUI prototype layout, navigation, and radar view completed",
  },
  {
    teamgroupitemid: "tgi_8",
    teamgroupstatusid: "tgs_3",
    category: "Blockers",
    entrytype: "negative",
    description: "SDK communication layer blocked on partner driver specs",
  },
]

// ── Helpers ───────────────────────────────────────────────────
const generateId = (prefix: string) => {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID()}`
  }

  return `${prefix}_${Date.now().toString(36)}`
}

export const useAppStore = create<AppState>((set) => ({
  programmeConfig: PROGRAMME_CONFIG,
  programmeOrgNodes: SEED_ORG_NODES,
  milestones: SEED_MILESTONES,
  supportRequired: SEED_SUPPORT,
  dateChangeLogs: SEED_DATE_LOGS,
  manpowerPlans: SEED_MANPOWER,
  manpowerDeliverables: SEED_MANPOWER_DELIVERABLES,
  weeklyUpdates: SEED_WEEKLY_UPDATES,
  weeklyUpdateItems: SEED_WEEKLY_ITEMS,
  partnerDeliverables: SEED_PARTNER_DELIVERABLES,
  capexBudgets: SEED_CAPEX,
  opexBudgets: SEED_OPEX,
  certifications: SEED_CERTIFICATIONS,
  supplyChains: SEED_SUPPLY_CHAIN,
  teamGroupStatuses: SEED_TEAM_GROUP_STATUSES,
  teamGroupItems: SEED_TEAM_GROUP_ITEMS,

  // ── Programme Config ──
  updateProgrammeConfig: (config) =>
    set((state) => ({
      programmeConfig: { ...state.programmeConfig, ...config },
    })),

  // ── Milestones ──
  addMilestone: (m) =>
    set((state) => ({
      milestones: [
        ...state.milestones,
        {
          ...m,
          milestoneid: generateId("ms"),
          changecount: 0,
          lastchangereason: "",
        },
      ],
    })),
  updateMilestone: (id, m) =>
    set((state) => ({
      milestones: state.milestones.map((ms) =>
        ms.milestoneid === id ? { ...ms, ...m } : ms
      ),
    })),
  deleteMilestone: (id) =>
    set((state) => ({
      milestones: state.milestones.filter(
        (ms) => ms.milestoneid !== id && ms.parentMilestoneId !== id
      ),
    })),

  // ── Support Required ──
  addSupportRequired: (s) =>
    set((state) => ({
      supportRequired: [
        ...state.supportRequired,
        { ...s, supportrequiredid: generateId("sup") },
      ],
    })),
  updateSupportRequired: (id, s) =>
    set((state) => ({
      supportRequired: state.supportRequired.map((sr) =>
        sr.supportrequiredid === id ? { ...sr, ...s } : sr
      ),
    })),
  deleteSupportRequired: (id) =>
    set((state) => ({
      supportRequired: state.supportRequired.filter(
        (sr) => sr.supportrequiredid !== id
      ),
    })),

  // ── Manpower Plans ──
  addManpowerPlan: (p) =>
    set((state) => ({
      manpowerPlans: [
        ...state.manpowerPlans,
        { ...p, manpowergaphiringplansid: generateId("mp") },
      ],
    })),
  updateManpowerPlan: (id, p) =>
    set((state) => ({
      manpowerPlans: state.manpowerPlans.map((mp) =>
        mp.manpowergaphiringplansid === id ? { ...mp, ...p } : mp
      ),
    })),
  deleteManpowerPlan: (id) =>
    set((state) => ({
      manpowerPlans: state.manpowerPlans.filter(
        (mp) => mp.manpowergaphiringplansid !== id
      ),
    })),

  // ── Manpower Deliverables ──
  addManpowerDeliverable: (d) =>
    set((state) => ({
      manpowerDeliverables: [
        ...state.manpowerDeliverables,
        { ...d, manpowerdeliverableid: generateId("mpd") },
      ],
    })),
  updateManpowerDeliverable: (id, d) =>
    set((state) => ({
      manpowerDeliverables: state.manpowerDeliverables.map((mpd) =>
        mpd.manpowerdeliverableid === id ? { ...mpd, ...d } : mpd
      ),
    })),
  deleteManpowerDeliverable: (id) =>
    set((state) => ({
      manpowerDeliverables: state.manpowerDeliverables.filter(
        (mpd) => mpd.manpowerdeliverableid !== id
      ),
    })),

  // ── Org Nodes ──
  addOrgNode: (n) => {
    const node = { ...n, programmeorgnodeid: generateId("org") }
    set((state) => ({ programmeOrgNodes: [...state.programmeOrgNodes, node] }))
    return node
  },
  updateOrgNode: (id, n) =>
    set((state) => ({
      programmeOrgNodes: state.programmeOrgNodes.map((node) =>
        node.programmeorgnodeid === id ? { ...node, ...n } : node
      ),
    })),
  deleteOrgNode: (id) =>
    set((state) => {
      const deletedNode = state.programmeOrgNodes.find(
        (node) => node.programmeorgnodeid === id
      )
      // Preserve descendants instead of silently orphaning/hiding a whole branch.
      return {
        programmeOrgNodes: state.programmeOrgNodes
          .filter((node) => node.programmeorgnodeid !== id)
          .map((node) =>
            node.parentnodeid === id
              ? { ...node, parentnodeid: deletedNode?.parentnodeid ?? null }
              : node
          ),
      }
    }),

  // ── Weekly Updates ──
  addWeeklyUpdate: (u) => {
    const weeklyUpdate = { ...u, weeklyupdateid: generateId("wu") }
    set((state) => ({ weeklyUpdates: [...state.weeklyUpdates, weeklyUpdate] }))
    return weeklyUpdate
  },
  updateWeeklyUpdate: (id, u) =>
    set((state) => ({
      weeklyUpdates: state.weeklyUpdates.map((wu) =>
        wu.weeklyupdateid === id ? { ...wu, ...u } : wu
      ),
    })),
  deleteWeeklyUpdate: (id) =>
    set((state) => ({
      weeklyUpdates: state.weeklyUpdates.filter(
        (wu) => wu.weeklyupdateid !== id
      ),
      weeklyUpdateItems: state.weeklyUpdateItems.filter(
        (i) => i.weeklyupdateid !== id
      ),
    })),

  // ── Weekly Update Items ──
  addWeeklyUpdateItem: (item) =>
    set((state) => ({
      weeklyUpdateItems: [
        ...state.weeklyUpdateItems,
        { ...item, weeklyupdateitemid: generateId("wui") },
      ],
    })),
  updateWeeklyUpdateItem: (id, item) =>
    set((state) => ({
      weeklyUpdateItems: state.weeklyUpdateItems.map((i) =>
        i.weeklyupdateitemid === id ? { ...i, ...item } : i
      ),
    })),
  deleteWeeklyUpdateItem: (id) =>
    set((state) => ({
      weeklyUpdateItems: state.weeklyUpdateItems.filter(
        (i) => i.weeklyupdateitemid !== id
      ),
    })),
  bulkSetWeeklyUpdateItems: (weeklyupdateid, newItems) =>
    set((state) => {
      const filtered = state.weeklyUpdateItems.filter(
        (i) => i.weeklyupdateid !== weeklyupdateid
      )
      const toAdd = newItems.map((n) => ({
        ...n,
        weeklyupdateitemid: generateId("wui"),
      }))
      return { weeklyUpdateItems: [...filtered, ...toAdd] }
    }),

  // Extended Tabs
  addPartnerDeliverable: (d) =>
    set((s) => ({
      partnerDeliverables: [
        ...s.partnerDeliverables,
        { ...d, partnerdeliverableid: generateId("pd") },
      ],
    })),
  updatePartnerDeliverable: (id, updates) =>
    set((s) => ({
      partnerDeliverables: s.partnerDeliverables.map((x) =>
        x.partnerdeliverableid === id ? { ...x, ...updates } : x
      ),
    })),
  deletePartnerDeliverable: (id) =>
    set((s) => ({
      partnerDeliverables: s.partnerDeliverables.filter(
        (x) => x.partnerdeliverableid !== id
      ),
    })),

  addCapexBudget: (c) =>
    set((s) => ({
      capexBudgets: [
        ...s.capexBudgets,
        { ...c, capexbudgetid: generateId("capx") },
      ],
    })),
  updateCapexBudget: (id, updates) =>
    set((s) => ({
      capexBudgets: s.capexBudgets.map((x) =>
        x.capexbudgetid === id ? { ...x, ...updates } : x
      ),
    })),
  deleteCapexBudget: (id) =>
    set((s) => ({
      capexBudgets: s.capexBudgets.filter((x) => x.capexbudgetid !== id),
    })),

  addOpexBudget: (o) =>
    set((s) => ({
      opexBudgets: [
        ...s.opexBudgets,
        { ...o, programmebudgetid: generateId("opx") },
      ],
    })),
  updateOpexBudget: (id, updates) =>
    set((s) => ({
      opexBudgets: s.opexBudgets.map((x) =>
        x.programmebudgetid === id ? { ...x, ...updates } : x
      ),
    })),
  deleteOpexBudget: (id) =>
    set((s) => ({
      opexBudgets: s.opexBudgets.filter((x) => x.programmebudgetid !== id),
    })),

  addCertification: (c) =>
    set((s) => ({
      certifications: [
        ...s.certifications,
        { ...c, certificationid: generateId("cert") },
      ],
    })),
  updateCertification: (id, updates) =>
    set((s) => ({
      certifications: s.certifications.map((x) =>
        x.certificationid === id ? { ...x, ...updates } : x
      ),
    })),
  deleteCertification: (id) =>
    set((s) => ({
      certifications: s.certifications.filter((x) => x.certificationid !== id),
    })),

  addSupplyChain: (sc) =>
    set((s) => ({
      supplyChains: [
        ...s.supplyChains,
        { ...sc, supplychainreadinessid: generateId("scr") },
      ],
    })),
  updateSupplyChain: (id, updates) =>
    set((s) => ({
      supplyChains: s.supplyChains.map((x) =>
        x.supplychainreadinessid === id ? { ...x, ...updates } : x
      ),
    })),
  deleteSupplyChain: (id) =>
    set((s) => ({
      supplyChains: s.supplyChains.filter(
        (x) => x.supplychainreadinessid !== id
      ),
    })),

  // ── Team Group Weekly Status ──
  addTeamGroupStatus: (s) => {
    const status = { ...s, teamgroupstatusid: generateId("tgs") }
    set((state) => ({
      teamGroupStatuses: [...state.teamGroupStatuses, status],
    }))
    return status
  },
  updateTeamGroupStatus: (id, s) =>
    set((state) => ({
      teamGroupStatuses: state.teamGroupStatuses.map((x) =>
        x.teamgroupstatusid === id ? { ...x, ...s } : x
      ),
    })),
  deleteTeamGroupStatus: (id) =>
    set((state) => ({
      teamGroupStatuses: state.teamGroupStatuses.filter(
        (x) => x.teamgroupstatusid !== id
      ),
      teamGroupItems: state.teamGroupItems.filter(
        (item) => item.teamgroupstatusid !== id
      ),
    })),

  addTeamGroupItem: (item) =>
    set((state) => ({
      teamGroupItems: [
        ...state.teamGroupItems,
        { ...item, teamgroupitemid: generateId("tgi") },
      ],
    })),
  updateTeamGroupItem: (id, item) =>
    set((state) => ({
      teamGroupItems: state.teamGroupItems.map((x) =>
        x.teamgroupitemid === id ? { ...x, ...item } : x
      ),
    })),
  deleteTeamGroupItem: (id) =>
    set((state) => ({
      teamGroupItems: state.teamGroupItems.filter(
        (x) => x.teamgroupitemid !== id
      ),
    })),
  bulkSetTeamGroupItems: (teamgroupstatusid, newItems) =>
    set((state) => {
      const filtered = state.teamGroupItems.filter(
        (i) => i.teamgroupstatusid !== teamgroupstatusid
      )
      const toAdd = newItems.map((n) => ({
        ...n,
        teamgroupitemid: generateId("tgi"),
      }))
      return { teamGroupItems: [...filtered, ...toAdd] }
    }),

  // Date logs
  addDateChangeLog: (log) =>
    set((state) => ({
      dateChangeLogs: [
        ...state.dateChangeLogs,
        {
          ...log,
          datechangelogid: generateId("dcl"),
          changedon: new Date().toISOString(),
        },
      ],
    })),
}))
