import { z } from "zod"

/** Strict YYYY-MM-DD input used for Dataverse Date Only columns. */
export const dateOnlySchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date.")
  .refine(
    (value) => !Number.isNaN(new Date(`${value}T00:00:00`).getTime()),
    "Enter a valid date."
  )

export const requiredTextSchema = (label: string, min = 1) =>
  z.string().trim().min(min, `${label} is required`)
export const nonNegativeNumberSchema = (label: string) =>
  z.coerce
    .number()
    .finite(`${label} must be a valid number.`)
    .min(0, `${label} cannot be negative.`)
export const trimOptionalText = (value: string | undefined): string =>
  value?.trim() ?? ""
