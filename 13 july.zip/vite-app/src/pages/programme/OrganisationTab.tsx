import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useForm, Controller } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import {
  useAppStore,
  SOURCING_CHANNELS,
  HIRING_PRIORITIES,
  type ProgrammeOrgNode,
} from "@/lib/store"
import { toast } from "sonner"
import {
  Plus,
  Pencil,
  Trash2,
  UserPlus,
  ChevronDown,
  ChevronRight,
  Users,
  Building2,
  PackageCheck,
  ClipboardCheck,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Field, FieldGroup, FieldError } from "@/components/ui/field"
import { Spinner } from "@/components/ui/spinner"
import { DatePicker } from "@/components/ui/date-picker"
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// ── Hiring Plan Form Schema ─────────────────────────────────
const hiringSchema = z
  .object({
    role: z.string().min(2, "Role is required"),
    requiredqty: z.coerce.number().min(1, "Required qty must be ≥ 1"),
    filledqty: z.coerce.number().min(0, "Filled qty must be ≥ 0"),
    sourcingchannel: z.string().min(1, "Sourcing channel is required"),
    targetjoindate: z.string().min(1, "Target join date is required"),
    priority: z.string().min(1, "Priority is required"),
    remarks: z.string().optional(),
  })
  .refine((data) => data.filledqty <= data.requiredqty, {
    message: "Filled quantity cannot exceed required quantity",
    path: ["filledqty"],
  })
type HiringFormData = z.infer<typeof hiringSchema>
type HiringFormInput = z.input<typeof hiringSchema>

// ── Org Node Form Schema ────────────────────────────────────
const orgNodeSchema = z.object({
  displayname: z.string().min(2, "Name is required"),
  title: z.string().min(2, "Title is required"),
  sortorder: z.coerce.number().min(1),
  active: z.string(),
  parentnodeid: z.string().nullable(),
})
type OrgNodeFormData = z.infer<typeof orgNodeSchema>
type OrgNodeFormInput = z.input<typeof orgNodeSchema>

// ── Manpower Deliverable Form Schema ─────────────────────────
const deliverableSchema = z.object({
  role: z.string().min(2, "Role is required"),
  qualification: z.string().min(2, "Qualification degree is required"),
  experience: z.string().min(2, "Experience range is required"),
  requiredqty: z.coerce.number().min(1, "Required qty must be ≥ 1"),
  remarks: z.string().optional(),
})
type DeliverableFormData = z.infer<typeof deliverableSchema>
type DeliverableFormInput = z.input<typeof deliverableSchema>

const PRIORITY_COLORS: Record<string, string> = {
  Low: "bg-muted text-muted-foreground",
  Medium: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  High: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  Critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
}

// ═══════════════════════════════════════════════════════════════
// ROOT COMPONENT
// ═══════════════════════════════════════════════════════════════
export function OrganisationTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid)
  return (
    <div className="flex flex-col gap-6 pt-4">
      <Tabs defaultValue="admin">
        <TabsList className="w-full justify-start gap-1">
          <TabsTrigger value="admin" className="flex items-center gap-2">
            <Building2 className="size-4" />
            Administrative Organisation
          </TabsTrigger>
          <TabsTrigger value="deliverables" className="flex items-center gap-2">
            <PackageCheck className="size-4" />
            Programme Deliverables Organisation
          </TabsTrigger>
        </TabsList>

        {/* ── TAB 1: Administrative Org ── */}
        <TabsContent value="admin" className="mt-6">
          <div className="flex flex-col gap-8">
            <OrgChartSection
              programmeId={programmeId}
              orgtype="admin"
              title="Administrative Organisation Chart"
              description="Internal team hierarchy. Hover nodes to add, edit, or remove members."
            />
            <Separator />
            <HiringPlanSection programmeId={programmeId} />
          </div>
        </TabsContent>

        {/* ── TAB 2: Programme Deliverables Org ── */}
        <TabsContent value="deliverables" className="mt-6">
          <div className="flex flex-col gap-8">
            <OrgChartSection
              programmeId={programmeId}
              orgtype="deliverables"
              title="Programme Deliverables Organisation Chart"
              description="Team structure responsible for delivering the 60 programme deliverables. Hover nodes to add, edit, or remove members."
            />
            <Separator />
            <ManpowerDeliverablesSection programmeId={programmeId} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// MANPOWER DELIVERABLES SECTION
// ═══════════════════════════════════════════════════════════════
function ManpowerDeliverablesSection({ programmeId }: { programmeId: string }) {
  const {
    manpowerDeliverables,
    addManpowerDeliverable,
    updateManpowerDeliverable,
    deleteManpowerDeliverable,
  } = useAppStore()

  const items = manpowerDeliverables.filter(
    (p) => p.programmeid === programmeId
  )

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<DeliverableFormInput, unknown, DeliverableFormData>({
    resolver: zodResolver(deliverableSchema),
  })

  const openAdd = () => {
    reset({
      role: "",
      qualification: "",
      experience: "",
      requiredqty: 1,
      remarks: "",
    })
    setEditingId(null)
    setIsDialogOpen(true)
  }

  const openEdit = (id: string) => {
    const item = items.find((p) => p.manpowerdeliverableid === id)
    if (item) {
      reset({ ...item, remarks: item.remarks || "" })
      setEditingId(id)
      setIsDialogOpen(true)
    }
  }

  const onSubmit = async (data: DeliverableFormData) => {
    setIsSaving(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      if (editingId) {
        updateManpowerDeliverable(editingId, {
          ...data,
          programmeid: programmeId,
          remarks: data.remarks || "",
        })
        toast.success("Manpower deliverable updated")
      } else {
        addManpowerDeliverable({
          ...data,
          programmeid: programmeId,
          remarks: data.remarks || "",
        })
        toast.success("Manpower deliverable added")
      }
      setIsDialogOpen(false)
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setIsDeleting(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      deleteManpowerDeliverable(deleteTarget)
      toast.success("Manpower deliverable deleted")
      setDeleteTarget(null)
    } catch {
      toast.error("Failed to delete")
    } finally {
      setIsDeleting(false)
    }
  }

  // Summary totals
  const totalRequired = items.reduce((s, i) => s + i.requiredqty, 0)

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">
            Manpower Requirements for Deliverables
          </h3>
          <p className="text-sm text-muted-foreground">
            Contractual headcount qualifications and experience bands required
            to deliver the 60 programme deliverables.
          </p>
        </div>
        <Button onClick={openAdd}>
          <Plus data-icon="inline-start" />
          Add Requirement
        </Button>
      </div>

      {/* Summary Card */}
      {items.length > 0 && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Card>
            <CardContent className="flex flex-col px-4 pt-4 pb-3">
              <span className="text-xs tracking-wide text-muted-foreground uppercase">
                Total Roles
              </span>
              <span className="text-2xl font-bold">{items.length}</span>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex flex-col px-4 pt-4 pb-3">
              <span className="text-xs tracking-wide text-muted-foreground uppercase">
                Total Headcount
              </span>
              <span className="text-2xl font-bold text-primary">
                {totalRequired}
              </span>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="overflow-x-auto rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Role / Title</TableHead>
              <TableHead>Qualification Degree</TableHead>
              <TableHead>Experience Range</TableHead>
              <TableHead className="text-center">Required Qty</TableHead>
              <TableHead>Remarks</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={6}
                  className="h-24 text-center text-muted-foreground"
                >
                  No manpower requirements configured yet.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => (
                <TableRow key={item.manpowerdeliverableid}>
                  <TableCell className="font-semibold text-foreground">
                    {item.role}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className="bg-indigo-50/50 text-indigo-600 dark:bg-indigo-950/10 dark:text-indigo-400"
                    >
                      {item.qualification}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-sm font-medium">
                    {item.experience}
                  </TableCell>
                  <TableCell className="text-center font-mono font-bold">
                    {item.requiredqty}
                  </TableCell>
                  <TableCell
                    className="max-w-[250px] truncate text-xs text-muted-foreground"
                    title={item.remarks}
                  >
                    {item.remarks || "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(item.manpowerdeliverableid)}
                      >
                        <Pencil className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:bg-destructive/10"
                        onClick={() =>
                          setDeleteTarget(item.manpowerdeliverableid)
                        }
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingId
                ? "Edit Manpower Requirement"
                : "Add Manpower Requirement"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Manpower deliverable form.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FieldGroup>
              <Field data-invalid={!!errors.role || undefined}>
                <Label htmlFor="mpd-role">Role / Area</Label>
                <Input
                  id="mpd-role"
                  {...register("role")}
                  placeholder="e.g., Radar Signal Processing Architect"
                />
                {errors.role && <FieldError>{errors.role.message}</FieldError>}
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.qualification || undefined}>
                  <Label htmlFor="mpd-qual">Qualification Degree</Label>
                  <Input
                    id="mpd-qual"
                    {...register("qualification")}
                    placeholder="e.g. B.Tech CSE"
                  />
                  {errors.qualification && (
                    <FieldError>{errors.qualification.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.experience || undefined}>
                  <Label htmlFor="mpd-exp">Experience Range</Label>
                  <Input
                    id="mpd-exp"
                    {...register("experience")}
                    placeholder="e.g. 3-9 years"
                  />
                  {errors.experience && (
                    <FieldError>{errors.experience.message}</FieldError>
                  )}
                </Field>
              </div>

              <Field data-invalid={!!errors.requiredqty || undefined}>
                <Label htmlFor="mpd-req">Quantity Required</Label>
                <Input
                  id="mpd-req"
                  type="number"
                  min={1}
                  {...register("requiredqty")}
                />
                {errors.requiredqty && (
                  <FieldError>{errors.requiredqty.message}</FieldError>
                )}
              </Field>

              <Field>
                <Label htmlFor="mpd-remarks">Remarks</Label>
                <Textarea
                  id="mpd-remarks"
                  {...register("remarks")}
                  placeholder="Additional notes..."
                />
              </Field>
            </FieldGroup>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSaving}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <Spinner data-icon="inline-start" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete manpower requirement?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// HIRING PLAN SECTION
// ═══════════════════════════════════════════════════════════════
function HiringPlanSection({ programmeId }: { programmeId: string }) {
  const {
    manpowerPlans,
    addManpowerPlan,
    updateManpowerPlan,
    deleteManpowerPlan,
  } = useAppStore()

  const items = manpowerPlans.filter((p) => p.programmeid === programmeId)
  const channelItems = [...SOURCING_CHANNELS]
  const priorityItems = [...HIRING_PRIORITIES]

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<HiringFormInput, unknown, HiringFormData>({
    resolver: zodResolver(hiringSchema),
  })

  const openAdd = () => {
    reset({
      role: "",
      requiredqty: 1,
      filledqty: 0,
      sourcingchannel: "",
      targetjoindate: "",
      priority: "",
      remarks: "",
    })
    setEditingId(null)
    setIsDialogOpen(true)
  }

  const openEdit = (id: string) => {
    const item = items.find((p) => p.manpowergaphiringplansid === id)
    if (item) {
      reset({ ...item, remarks: item.remarks || "" })
      setEditingId(id)
      setIsDialogOpen(true)
    }
  }

  const onSubmit = async (data: HiringFormData) => {
    setIsSaving(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      if (editingId) {
        updateManpowerPlan(editingId, {
          ...data,
          programmeid: programmeId,
          remarks: data.remarks || "",
        })
        toast.success("Hiring plan updated")
      } else {
        addManpowerPlan({
          ...data,
          programmeid: programmeId,
          remarks: data.remarks || "",
        })
        toast.success("Hiring plan added")
      }
      setIsDialogOpen(false)
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setIsDeleting(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      deleteManpowerPlan(deleteTarget)
      toast.success("Hiring plan deleted")
      setDeleteTarget(null)
    } catch {
      toast.error("Failed to delete")
    } finally {
      setIsDeleting(false)
    }
  }

  const formatDate = (d: string) => {
    if (!d) return "—"
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    })
  }

  // Summary stats
  const totalRequired = items.reduce((s, i) => s + i.requiredqty, 0)
  const totalFilled = items.reduce((s, i) => s + i.filledqty, 0)
  const totalVacant = totalRequired - totalFilled

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Manpower Gap / Hiring Plan</h3>
          <p className="text-sm text-muted-foreground">
            Track internal role demand and hiring pipeline.
          </p>
        </div>
        <Button onClick={openAdd}>
          <UserPlus data-icon="inline-start" />
          Add Role
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="flex flex-col px-4 pt-4 pb-3">
            <span className="text-xs tracking-wide text-muted-foreground uppercase">
              Required
            </span>
            <span className="text-2xl font-bold">{totalRequired}</span>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col px-4 pt-4 pb-3">
            <span className="text-xs tracking-wide text-muted-foreground uppercase">
              Filled
            </span>
            <span className="text-2xl font-bold text-emerald-600">
              {totalFilled}
            </span>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex flex-col px-4 pt-4 pb-3">
            <span className="text-xs tracking-wide text-muted-foreground uppercase">
              Vacant
            </span>
            <span className="text-2xl font-bold text-destructive">
              {totalVacant}
            </span>
          </CardContent>
        </Card>
      </div>

      <div className="overflow-x-auto rounded-md border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Role</TableHead>
              <TableHead className="text-center">Required</TableHead>
              <TableHead className="text-center">Filled</TableHead>
              <TableHead className="text-center">Vacant</TableHead>
              <TableHead>Channel</TableHead>
              <TableHead>Target Join</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {items.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={8}
                  className="h-24 text-center text-muted-foreground"
                >
                  No hiring plans yet.
                </TableCell>
              </TableRow>
            ) : (
              items.map((item) => {
                const vacant = item.requiredqty - item.filledqty
                return (
                  <TableRow key={item.manpowergaphiringplansid}>
                    <TableCell className="font-medium text-foreground">
                      {item.role}
                      {item.remarks && (
                        <p className="mt-0.5 max-w-[200px] truncate text-xs text-muted-foreground">
                          {item.remarks}
                        </p>
                      )}
                    </TableCell>
                    <TableCell className="text-center font-mono">
                      {item.requiredqty}
                    </TableCell>
                    <TableCell className="text-center font-mono text-emerald-600">
                      {item.filledqty}
                    </TableCell>
                    <TableCell className="text-center">
                      {vacant > 0 ? (
                        <Badge variant="destructive" className="font-mono">
                          {vacant}
                        </Badge>
                      ) : (
                        <Badge className="bg-emerald-100 font-mono text-emerald-800">
                          0
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.sourcingchannel}</Badge>
                    </TableCell>
                    <TableCell className="text-sm whitespace-nowrap">
                      {formatDate(item.targetjoindate)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          PRIORITY_COLORS[item.priority] ||
                          PRIORITY_COLORS["Low"]
                        }
                      >
                        {item.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            openEdit(item.manpowergaphiringplansid)
                          }
                        >
                          <Pencil />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                          onClick={() =>
                            setDeleteTarget(item.manpowergaphiringplansid)
                          }
                        >
                          <Trash2 />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Hiring Plan" : "Add Hiring Plan"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Hiring plan form.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FieldGroup>
              <Field data-invalid={!!errors.role || undefined}>
                <Label htmlFor="hp-role">Role</Label>
                <Input
                  id="hp-role"
                  {...register("role")}
                  placeholder="e.g., Senior Backend Engineer"
                />
                {errors.role && <FieldError>{errors.role.message}</FieldError>}
              </Field>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.requiredqty || undefined}>
                  <Label htmlFor="hp-req">Required Qty</Label>
                  <Input
                    id="hp-req"
                    type="number"
                    min={1}
                    {...register("requiredqty")}
                  />
                  {errors.requiredqty && (
                    <FieldError>{errors.requiredqty.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.filledqty || undefined}>
                  <Label htmlFor="hp-fill">Filled Qty</Label>
                  <Input
                    id="hp-fill"
                    type="number"
                    min={0}
                    {...register("filledqty")}
                  />
                  {errors.filledqty && (
                    <FieldError>{errors.filledqty.message}</FieldError>
                  )}
                </Field>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Field data-invalid={!!errors.sourcingchannel || undefined}>
                  <Label>Sourcing Channel</Label>
                  <Controller
                    control={control}
                    name="sourcingchannel"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={channelItems}
                      >
                        <ComboboxInput placeholder="Select" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.sourcingchannel && (
                    <FieldError>{errors.sourcingchannel.message}</FieldError>
                  )}
                </Field>
                <Field data-invalid={!!errors.priority || undefined}>
                  <Label>Priority</Label>
                  <Controller
                    control={control}
                    name="priority"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "")
                        }
                        items={priorityItems}
                      >
                        <ComboboxInput placeholder="Select" />
                        <ComboboxContent>
                          <ComboboxEmpty>No match.</ComboboxEmpty>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {errors.priority && (
                    <FieldError>{errors.priority.message}</FieldError>
                  )}
                </Field>
              </div>

              <Field data-invalid={!!errors.targetjoindate || undefined}>
                <Label>Target Join Date</Label>
                <Controller
                  control={control}
                  name="targetjoindate"
                  render={({ field }) => (
                    <DatePicker
                      value={field.value}
                      onChange={field.onChange}
                      placeholder="Pick a date"
                    />
                  )}
                />
                {errors.targetjoindate && (
                  <FieldError>{errors.targetjoindate.message}</FieldError>
                )}
              </Field>

              <Field>
                <Label htmlFor="hp-remarks">Remarks</Label>
                <Textarea
                  id="hp-remarks"
                  {...register("remarks")}
                  placeholder="Additional notes..."
                />
              </Field>
            </FieldGroup>

            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSaving}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <Spinner data-icon="inline-start" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete hiring plan?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════
// ORG CHART SECTION — accepts orgtype to isolate the two charts
// ═══════════════════════════════════════════════════════════════
function OrgChartSection({
  programmeId,
  orgtype,
  title,
  description,
}: {
  programmeId: string
  orgtype: "admin" | "deliverables"
  title: string
  description: string
}) {
  const navigate = useNavigate()
  const { programmeOrgNodes, addOrgNode, updateOrgNode, deleteOrgNode } =
    useAppStore()

  // Filter by both programme AND orgtype so charts are fully independent
  const nodes = programmeOrgNodes
    .filter((n) => n.programmeid === programmeId && n.orgtype === orgtype)
    .sort((a, b) => a.sortorder - b.sortorder)

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [parentForAdd, setParentForAdd] = useState<string | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(
    new Set(nodes.map((n) => n.programmeorgnodeid))
  )

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<OrgNodeFormInput, unknown, OrgNodeFormData>({
    resolver: zodResolver(orgNodeSchema),
  })

  const rootNodes = nodes.filter((n) => n.parentnodeid === null)

  const toggleExpand = (id: string) => {
    setExpandedNodes((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const openAddDialog = (parentId: string | null) => {
    reset({
      displayname: "",
      title: "",
      sortorder: nodes.length + 1,
      active: "Yes",
      parentnodeid: parentId,
    })
    setParentForAdd(parentId)
    setEditingId(null)
    setIsDialogOpen(true)
  }

  const openEditDialog = (id: string) => {
    const node = nodes.find((n) => n.programmeorgnodeid === id)
    if (node) {
      reset({
        displayname: node.displayname,
        title: node.title,
        sortorder: node.sortorder,
        active: node.active,
        parentnodeid: node.parentnodeid,
      })
      setEditingId(id)
      setIsDialogOpen(true)
    }
  }

  const onSubmit = async (data: OrgNodeFormData) => {
    setIsSaving(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      if (editingId) {
        updateOrgNode(editingId, { ...data, programmeid: programmeId, orgtype })
        toast.success("Node updated")
      } else {
        addOrgNode({
          ...data,
          parentnodeid: parentForAdd,
          programmeid: programmeId,
          orgtype,
        })
        toast.success("Node added")
      }
      setIsDialogOpen(false)
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    const hasChildren = nodes.some((n) => n.parentnodeid === deleteTarget)
    if (hasChildren) {
      toast.error(
        "Cannot delete a node that has children. Remove children first."
      )
      setDeleteTarget(null)
      return
    }
    setIsDeleting(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      deleteOrgNode(deleteTarget)
      toast.success("Node deleted")
      setDeleteTarget(null)
    } catch {
      toast.error("Failed to delete")
    } finally {
      setIsDeleting(false)
    }
  }

  const getChildren = (parentId: string) =>
    nodes.filter((n) => n.parentnodeid === parentId)

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="flex items-center gap-2 text-lg font-semibold">
            <Users className="size-5" />
            {title}
          </h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>

      {/* Org Chart */}
      <div className="overflow-x-auto rounded-lg border bg-muted/30 p-6">
        <div className="flex min-w-fit flex-col items-center">
          {rootNodes.map((root) => (
            <OrgTreeNode
              key={root.programmeorgnodeid}
              node={root}
              getChildren={getChildren}
              expandedNodes={expandedNodes}
              toggleExpand={toggleExpand}
              onEdit={openEditDialog}
              onDelete={setDeleteTarget}
              onAddChild={(parentId) => openAddDialog(parentId)}
              onViewStatus={
                orgtype === "deliverables"
                  ? (id) => {
                      const isParent = programmeOrgNodes.some(
                        (n) =>
                          n.parentnodeid === id &&
                          n.active === "Yes" &&
                          n.programmeid === programmeId
                      )
                      if (isParent) {
                        navigate(`/team-status?team=${id}`)
                      } else {
                        const node = programmeOrgNodes.find(
                          (n) => n.programmeorgnodeid === id
                        )
                        if (node?.parentnodeid) {
                          navigate(`/team-status?team=${node.parentnodeid}`)
                        } else {
                          navigate(`/team-status?team=${id}`)
                        }
                      }
                    }
                  : undefined
              }
              depth={0}
            />
          ))}
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Node" : "Add Team Member"}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Organisation node form.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FieldGroup>
              <Field data-invalid={!!errors.displayname || undefined}>
                <Label htmlFor="org-name">Name</Label>
                <Input
                  id="org-name"
                  {...register("displayname")}
                  placeholder="e.g., John Doe"
                />
                {errors.displayname && (
                  <FieldError>{errors.displayname.message}</FieldError>
                )}
              </Field>
              <Field data-invalid={!!errors.title || undefined}>
                <Label htmlFor="org-title">Title / Role</Label>
                <Input
                  id="org-title"
                  {...register("title")}
                  placeholder="e.g., Programme Director"
                />
                {errors.title && (
                  <FieldError>{errors.title.message}</FieldError>
                )}
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label htmlFor="org-sort">Sort Order</Label>
                  <Input
                    id="org-sort"
                    type="number"
                    min={1}
                    {...register("sortorder")}
                  />
                </Field>
                <Field>
                  <Label>Status</Label>
                  <Controller
                    control={control}
                    name="active"
                    render={({ field }) => (
                      <Combobox
                        value={field.value || null}
                        onValueChange={(v: string | null) =>
                          field.onChange(v ?? "Yes")
                        }
                        items={["Yes", "No"]}
                      >
                        <ComboboxInput placeholder="Active?" />
                        <ComboboxContent>
                          <ComboboxList>
                            {(item: string) => (
                              <ComboboxItem key={item} value={item}>
                                {item}
                              </ComboboxItem>
                            )}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                </Field>
              </div>
            </FieldGroup>
            <DialogFooter className="mt-6">
              <DialogClose asChild>
                <Button type="button" variant="outline" disabled={isSaving}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSaving}>
                {isSaving && <Spinner data-icon="inline-start" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open && !isDeleting) setDeleteTarget(null)
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove team member?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the node from the org chart.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />}
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// ── Org Tree Node Component — Vertical/Column Layout ────────
function OrgTreeNode({
  node,
  getChildren,
  expandedNodes,
  toggleExpand,
  onEdit,
  onDelete,
  onAddChild,
  onViewStatus,
  depth,
  isFirstChild = true,
  isLastChild = true,
  siblingsCount = 1,
}: {
  node: ProgrammeOrgNode
  getChildren: (id: string) => ProgrammeOrgNode[]
  expandedNodes: Set<string>
  toggleExpand: (id: string) => void
  onEdit: (id: string) => void
  onDelete: (id: string) => void
  onAddChild: (parentId: string) => void
  onViewStatus?: (id: string) => void
  depth: number
  isFirstChild?: boolean
  isLastChild?: boolean
  siblingsCount?: number
}) {
  const children = getChildren(node.programmeorgnodeid)
  const isExpanded = expandedNodes.has(node.programmeorgnodeid)
  const hasChildren = children.length > 0
  const isInactive = node.active === "No"

  const initials = node.displayname
    .split(" ")
    .map((w) => w[0])
    .join("")
    .substring(0, 2)
    .toUpperCase()

  return (
    <div className="relative flex flex-col items-center px-2">
      {/* Horizontal connector line linking siblings */}
      {depth > 0 && siblingsCount > 1 && (
        <div
          className={`pointer-events-none absolute top-0 h-px bg-border ${isFirstChild ? "right-0 left-1/2" : ""} ${isLastChild ? "right-1/2 left-0" : ""} ${!isFirstChild && !isLastChild ? "right-0 left-0" : ""} `}
        />
      )}

      {/* Vertical connector from the horizontal line down to THIS node */}
      {depth > 0 && <div className="pointer-events-none h-5 w-px bg-border" />}

      {/* Node Card */}
      <div
        className={`group relative flex max-w-[140px] min-w-[120px] flex-col items-center rounded-xl border bg-card p-3 shadow-sm transition-all hover:border-primary/30 hover:shadow-md ${isInactive ? "opacity-50" : ""} ${depth === 0 ? "border-primary/20 bg-primary/[0.02]" : ""} `}
      >
        {/* Expand/Collapse Toggle */}
        {hasChildren && (
          <button
            onClick={() => toggleExpand(node.programmeorgnodeid)}
            className="absolute -bottom-3 left-1/2 z-10 flex size-6 -translate-x-1/2 items-center justify-center rounded-full border bg-card shadow-sm transition-colors hover:bg-muted"
          >
            {isExpanded ? (
              <ChevronDown className="size-3" />
            ) : (
              <ChevronRight className="size-3" />
            )}
          </button>
        )}

        {/* Avatar */}
        <div
          className={`mb-1.5 flex size-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold ${
            depth === 0
              ? "bg-primary text-primary-foreground"
              : "bg-secondary text-secondary-foreground"
          }`}
        >
          {initials}
        </div>

        {/* Name & Role */}
        <span className="w-full truncate text-center text-xs leading-tight font-medium text-foreground">
          {node.displayname}
        </span>
        <span className="mt-0.5 w-full truncate text-center text-[10px] leading-tight text-muted-foreground">
          {node.title}
        </span>

        {/* Actions — show on hover */}
        <div className="absolute -top-2 -right-2 flex items-center gap-0 rounded-lg border bg-card p-0.5 opacity-0 shadow-sm transition-opacity group-hover:opacity-100">
          {onViewStatus && (
            <Button
              variant="ghost"
              size="icon"
              className="size-5 text-primary hover:bg-primary/10"
              title="View Weekly Status"
              onClick={() => onViewStatus(node.programmeorgnodeid)}
            >
              <ClipboardCheck className="size-2.5" />
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="size-5"
            onClick={() => onAddChild(node.programmeorgnodeid)}
          >
            <Plus className="size-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-5"
            onClick={() => onEdit(node.programmeorgnodeid)}
          >
            <Pencil className="size-2.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-5 text-destructive hover:bg-destructive/10"
            onClick={() => onDelete(node.programmeorgnodeid)}
          >
            <Trash2 className="size-2.5" />
          </Button>
        </div>
      </div>

      {/* Children */}
      {hasChildren && isExpanded && (
        <>
          {/* Vertical line down from parent node */}
          <div className="pointer-events-none h-5 w-px bg-border" />

          {/* Child nodes in a row */}
          <div className="flex items-start justify-center">
            {children.map((child, index) => (
              <OrgTreeNode
                key={child.programmeorgnodeid}
                node={child}
                getChildren={getChildren}
                expandedNodes={expandedNodes}
                toggleExpand={toggleExpand}
                onEdit={onEdit}
                onDelete={onDelete}
                onAddChild={onAddChild}
                onViewStatus={onViewStatus}
                depth={depth + 1}
                isFirstChild={index === 0}
                isLastChild={index === children.length - 1}
                siblingsCount={children.length}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}
