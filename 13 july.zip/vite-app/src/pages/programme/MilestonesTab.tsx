import { useState, useMemo } from "react"
import { useNavigate } from "react-router-dom"
import { motion, AnimatePresence } from "motion/react"
import { useForm, Controller } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useAppStore, MILESTONE_STATUSES } from "@/lib/store"
import { toast } from "sonner"
import {
  Plus,
  Pencil,
  Trash2,
  AlertTriangle,
  ArrowRight,
  Clock,
  ChevronRight,
  Award,
  CircleDollarSign,
  Settings,
  CheckCircle,
  BadgePercent,
  Boxes,
  Truck,
  CircleDot,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Field, FieldGroup, FieldError } from "@/components/ui/field"
import { Spinner } from "@/components/ui/spinner"
import { DatePicker } from "@/components/ui/date-picker"
import { Card, CardContent } from "@/components/ui/card"
import {
  Combobox,
  ComboboxContent,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { addMonths, format, startOfMonth, endOfMonth } from "date-fns"

const schema = z
  .object({
    name: z.string().min(2, "Name is required"),
    t0OffsetStart: z.coerce.number().min(0, "Offset must be positive"),
    t0OffsetEnd: z.coerce.number().min(0, "Offset must be positive"),
    deliverable: z.string().min(2, "Deliverable details are required"),
    paymentPercentage: z.coerce
      .number()
      .min(0, "Payment percentage must be positive")
      .max(100, "Payment percentage cannot exceed 100"),
    parentMilestoneId: z.string().nullable(),
    ownerorgnodeid: z.string().min(1, "Owner is required"),
    status: z.string().min(1, "Status is required"),
    remarks: z.string().optional(),
    assigneeNodeIds: z.array(z.string()).optional(),
  })
  .refine((data) => data.t0OffsetEnd >= data.t0OffsetStart, {
    message: "End offset must be on or after the start offset",
    path: ["t0OffsetEnd"],
  })

type FormData = z.infer<typeof schema>
type FormInput = z.input<typeof schema>

const STATUS_COLORS: Record<string, string> = {
  "Not Started":
    "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  "In Progress":
    "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  Completed:
    "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400",
  Delayed:
    "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400",
  "At Risk": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
}

export function MilestonesTab() {
  const navigate = useNavigate()
  const { programmeConfig, updateProgrammeConfig } = useAppStore()
  const programmeId = programmeConfig.programmeid
  const t0StartStr = programmeConfig.t0Start || "2026-09-01"

  const {
    milestones,
    programmeOrgNodes,
    dateChangeLogs,
    addMilestone,
    updateMilestone,
    deleteMilestone,
    addDateChangeLog,
    supplyChains,
  } = useAppStore()

  const [expandedSubId, setExpandedSubId] = useState<string | null>(null)

  const items = milestones.filter((m) => m.programmeid === programmeId)
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes"
  )
  const orgNodeNames = orgNodes.map((n) => n.displayname)
  const deliverableOrgNodes = useMemo(() => {
    return programmeOrgNodes.filter(
      (n) =>
        n.programmeid === programmeId &&
        n.orgtype === "deliverables" &&
        n.active === "Yes"
    )
  }, [programmeOrgNodes, programmeId])
  const statusItems = [...MILESTONE_STATUSES]

  // Component UI States
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Date shift audit states
  const [dateChangeReason, setDateChangeReason] = useState("")
  const [pendingDateChanges, setPendingDateChanges] = useState<
    Array<{ field: string; oldDate: string; newDate: string }>
  >([])
  const [showReasonDialog, setShowReasonDialog] = useState(false)
  const [pendingFormData, setPendingFormData] = useState<FormData | null>(null)

  // Collapsed main milestones map
  const [collapsedGates, setCollapsedGates] = useState<Record<string, boolean>>(
    {}
  )

  // T0 Editor modal state
  const [isT0ModalOpen, setIsT0ModalOpen] = useState(false)
  const [tempT0, setTempT0] = useState(t0StartStr)
  const [isT0Saving, setIsT0Saving] = useState(false)

  // Date History modal states
  const [historyMilestoneId, setHistoryMilestoneId] = useState<string | null>(
    null
  )

  const {
    register,
    handleSubmit,
    reset,
    control,
    formState: { errors },
  } = useForm<FormInput, unknown, FormData>({
    resolver: zodResolver(schema),
  })

  // Calculate dates from offset helper
  const calculateDates = (offsetStart: number, offsetEnd: number) => {
    const t0 = new Date(t0StartStr + "T00:00:00")
    const resolvedStart = startOfMonth(addMonths(t0, offsetStart))
    const resolvedEnd = endOfMonth(addMonths(t0, offsetEnd))
    return {
      startdate: format(resolvedStart, "yyyy-MM-dd"),
      targetedcompletiondate: format(resolvedEnd, "yyyy-MM-dd"),
    }
  }

  // Build Hierarchical Structure
  const mainMilestones = useMemo(() => {
    return items
      .filter((m) => m.parentMilestoneId === null)
      .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd)
  }, [items])

  const getSubMilestones = (parentId: string) => {
    return items
      .filter((m) => m.parentMilestoneId === parentId)
      .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd)
  }

  // Collapsed management
  const toggleCollapse = (id: string) => {
    setCollapsedGates((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  // Payment Calculations
  const paymentSummary = useMemo(() => {
    const advance = 20 // 20% flat advance
    const completedSubPercent = items
      .filter((m) => m.parentMilestoneId !== null && m.status === "Completed")
      .reduce((sum, m) => sum + m.paymentPercentage, 0)

    const totalInvoiced = advance + completedSubPercent
    const totalPotential = 100

    // Find next upcoming payment milestone
    const upcoming = items
      .filter(
        (m) =>
          m.parentMilestoneId !== null &&
          m.status !== "Completed" &&
          m.paymentPercentage > 0
      )
      .sort((a, b) => a.t0OffsetEnd - b.t0OffsetEnd)[0]

    return {
      totalInvoiced,
      totalPotential,
      upcoming,
    }
  }, [items])

  const openAddDialog = () => {
    reset({
      name: "",
      t0OffsetStart: 0,
      t0OffsetEnd: 1,
      deliverable: "",
      paymentPercentage: 0,
      parentMilestoneId: null,
      ownerorgnodeid: orgNodes[0]?.programmeorgnodeid || "",
      status: "Not Started",
      remarks: "",
      assigneeNodeIds: [],
    })
    setEditingId(null)
    setIsDialogOpen(true)
  }

  const openEditDialog = (id: string) => {
    const item = items.find((m) => m.milestoneid === id)
    if (item) {
      reset({
        name: item.name,
        t0OffsetStart: item.t0OffsetStart,
        t0OffsetEnd: item.t0OffsetEnd,
        deliverable: item.deliverable,
        paymentPercentage: item.paymentPercentage,
        parentMilestoneId: item.parentMilestoneId,
        ownerorgnodeid: item.ownerorgnodeid,
        status: item.status,
        remarks: item.remarks,
        assigneeNodeIds: item.assigneeNodeIds || [],
      })
      setEditingId(id)
      setIsDialogOpen(true)
    }
  }

  const onSubmit = async (data: FormData) => {
    const dates = calculateDates(data.t0OffsetStart, data.t0OffsetEnd)
    const finalData = {
      ...data,
      startdate: dates.startdate,
      originaltargetedcompletiondate: dates.targetedcompletiondate,
      targetedcompletiondate: dates.targetedcompletiondate,
    }

    if (editingId) {
      const existing = items.find((m) => m.milestoneid === editingId)
      if (
        existing &&
        existing.targetedcompletiondate !== finalData.targetedcompletiondate
      ) {
        setPendingDateChanges([
          {
            field: "targetedcompletiondate",
            oldDate: existing.targetedcompletiondate,
            newDate: finalData.targetedcompletiondate,
          },
        ])
        setPendingFormData(data)
        setDateChangeReason("")
        setShowReasonDialog(true)
        return
      }
    }
    await saveData(data, "")
  }

  const saveData = async (formData: FormData, reason: string) => {
    setIsSaving(true)
    try {
      const computedDates = calculateDates(
        formData.t0OffsetStart,
        formData.t0OffsetEnd
      )

      const payload = {
        ...formData,
        startdate: computedDates.startdate,
        targetedcompletiondate: computedDates.targetedcompletiondate,
        originaltargetedcompletiondate: computedDates.targetedcompletiondate,
        remarks: formData.remarks || "",
      }

      await new Promise((r) => setTimeout(r, 400))

      if (editingId) {
        const existing = items.find((m) => m.milestoneid === editingId)!
        if (reason && pendingDateChanges.length > 0) {
          addDateChangeLog({
            programmeid: programmeId,
            module: "milestone",
            recordid: editingId,
            recordname: existing.name,
            fieldname: "targetedcompletiondate",
            olddate: pendingDateChanges[0].oldDate,
            newdate: pendingDateChanges[0].newDate,
            reason,
          })
        }
        updateMilestone(editingId, {
          ...payload,
          changecount:
            existing.changecount + (pendingDateChanges.length > 0 ? 1 : 0),
          lastchangereason: reason || existing.lastchangereason,
        })
        toast.success("Milestone updated successfully")
      } else {
        addMilestone({
          ...payload,
          programmeid: programmeId,
        })
        toast.success("Milestone added successfully")
      }
      setIsDialogOpen(false)
      setPendingDateChanges([])
      setPendingFormData(null)
    } catch {
      toast.error("Failed to save milestone")
    } finally {
      setIsSaving(false)
    }
  }

  const handleReasonConfirm = async () => {
    if (!dateChangeReason.trim()) return
    setShowReasonDialog(false)
    if (pendingFormData) {
      await saveData(pendingFormData, dateChangeReason.trim())
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setIsDeleting(true)
    try {
      await new Promise((r) => setTimeout(r, 400))
      deleteMilestone(deleteTarget)
      toast.success("Milestone deleted successfully")
      setDeleteTarget(null)
    } catch {
      toast.error("Failed to delete milestone")
    } finally {
      setIsDeleting(false)
    }
  }

  // Base date shifter trigger
  const handleT0Shift = async () => {
    setIsT0Saving(true)
    try {
      // 1. Update t0Start in config
      updateProgrammeConfig({ t0Start: tempT0 })

      // 2. Loop over and recalculate actual target dates for all milestones in the store
      // Since recalculating depends on the offsets stored in milestones, we trigger updates
      for (const m of items) {
        const t0 = new Date(tempT0 + "T00:00:00")
        const newStart = startOfMonth(addMonths(t0, m.t0OffsetStart))
        const newEnd = endOfMonth(addMonths(t0, m.t0OffsetEnd))
        updateMilestone(m.milestoneid, {
          startdate: format(newStart, "yyyy-MM-dd"),
          targetedcompletiondate: format(newEnd, "yyyy-MM-dd"),
          originaltargetedcompletiondate: format(newEnd, "yyyy-MM-dd"),
        })
      }

      toast.success(
        "T0 timeline baseline adjusted. Dates shifted successfully."
      )
      setIsT0ModalOpen(false)
    } catch {
      toast.error("Failed to shift T0 timeline")
    } finally {
      setIsT0Saving(false)
    }
  }

  const formatDate = (d: string) => {
    if (!d) return "—"
    return new Date(d + "T00:00:00").toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    })
  }

  return (
    <div className="flex flex-col gap-5 pt-4">
      {/* ── TOP ACTION HEADER ── */}
      <div className="flex flex-col justify-between gap-4 rounded-xl border bg-slate-900/5 p-4.5 md:flex-row md:items-center dark:bg-slate-900/40">
        <div>
          <h3 className="text-lg font-bold tracking-tight">
            Relative Milestones (T0 Roadmap)
          </h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Timeline offsets mapped to baseline T0 start. Calendar dates shift
            dynamically based on T0.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setTempT0(t0StartStr)
              setIsT0ModalOpen(true)
            }}
            className="gap-2"
          >
            <Settings className="size-3.5 text-indigo-500" />
            Set T0: {formatDate(t0StartStr)}
          </Button>
          <Button onClick={openAddDialog} className="gap-2">
            <Plus className="size-4" /> Add Deliverable
          </Button>
        </div>
      </div>

      {/* ── PAYMENT & COMPLETION SUMMARY ── */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Card className="border-indigo-500/20 bg-indigo-500/5">
          <CardContent className="flex items-center gap-3.5 px-4 pt-4 pb-4">
            <div className="rounded-xl bg-indigo-500/10 p-3">
              <BadgePercent className="size-6 text-indigo-500" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider text-muted-foreground uppercase">
                Payments Released
              </span>
              <h4 className="text-2xl font-extrabold text-indigo-600 tabular-nums dark:text-indigo-400">
                {paymentSummary.totalInvoiced}%{" "}
                <span className="text-xs font-normal text-muted-foreground">
                  released
                </span>
              </h4>
              <p className="mt-0.5 text-[10px] text-muted-foreground">
                Includes 20% advance payment
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-emerald-500/20 bg-emerald-500/5">
          <CardContent className="flex items-center gap-3.5 px-4 pt-4 pb-4">
            <div className="rounded-xl bg-emerald-500/10 p-3">
              <CheckCircle className="size-6 text-emerald-500" />
            </div>
            <div>
              <span className="text-[10px] font-bold tracking-wider text-muted-foreground uppercase">
                Sub-milestones Completed
              </span>
              <h4 className="text-2xl font-extrabold text-emerald-600 tabular-nums dark:text-emerald-400">
                {
                  items.filter(
                    (m) =>
                      m.parentMilestoneId !== null && m.status === "Completed"
                  ).length
                }{" "}
                <span className="text-xs font-normal text-muted-foreground">
                  of {items.filter((m) => m.parentMilestoneId !== null).length}{" "}
                  done
                </span>
              </h4>
              <p className="mt-0.5 text-[10px] text-muted-foreground">
                10 main phases overall
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-amber-500/20 bg-amber-500/5">
          <CardContent className="flex items-center gap-3.5 px-4 pt-4 pb-4">
            <div className="rounded-xl bg-amber-500/10 p-3">
              <CircleDollarSign className="size-6 text-amber-500" />
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10px] font-bold tracking-wider text-muted-foreground uppercase">
                Next Payment Event
              </span>
              {paymentSummary.upcoming ? (
                <div className="truncate">
                  <h4 className="truncate text-sm leading-snug font-bold text-amber-600 dark:text-amber-400">
                    {paymentSummary.upcoming.name}
                  </h4>
                  <p className="text-[10px] text-muted-foreground">
                    Val:{" "}
                    <strong className="text-foreground">
                      {paymentSummary.upcoming.paymentPercentage}%
                    </strong>{" "}
                    · Offset:{" "}
                    <strong className="text-foreground">
                      T0+{paymentSummary.upcoming.t0OffsetEnd}M
                    </strong>
                  </p>
                </div>
              ) : (
                <p className="py-1 text-xs text-muted-foreground">
                  No pending payments.
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── HIERARCHICAL GATES & SUB-MILESTONES TABLE ── */}
      <div className="overflow-hidden rounded-md border bg-card">
        <Table>
          <TableHeader className="bg-slate-500/5">
            <TableRow>
              <TableHead className="w-[32px]"></TableHead>
              <TableHead className="min-w-[200px]">
                Milestone / Deliverable
              </TableHead>
              <TableHead className="w-[180px] text-center">
                Dates (Baseline)
              </TableHead>
              <TableHead className="min-w-[200px]">
                Contractual Deliverables
              </TableHead>
              <TableHead className="w-[100px] text-center">Payment %</TableHead>
              <TableHead className="w-[110px] text-center">Status</TableHead>
              <TableHead className="w-[100px] text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mainMilestones.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="h-28 text-center text-muted-foreground"
                >
                  No main milestones seeded. Press "Add Deliverable" to build
                  the T0 timeline.
                </TableCell>
              </TableRow>
            ) : (
              mainMilestones.map((gate) => {
                const subMilestones = getSubMilestones(gate.milestoneid)
                const isCollapsed = collapsedGates[gate.milestoneid] === true

                // Determine Main Gate overall status based on sub-milestones
                let gateStatus = "Not Started"
                const subStatuses = subMilestones.map((s) => s.status)
                if (subStatuses.length > 0) {
                  if (subStatuses.includes("At Risk")) gateStatus = "At Risk"
                  else if (subStatuses.includes("Delayed"))
                    gateStatus = "Delayed"
                  else if (subStatuses.every((s) => s === "Completed"))
                    gateStatus = "Completed"
                  else if (
                    subStatuses.includes("In Progress") ||
                    subStatuses.includes("Completed")
                  )
                    gateStatus = "In Progress"
                } else {
                  gateStatus = gate.status
                }

                return (
                  <>
                    {/* Main Gate Row */}
                    <TableRow
                      key={gate.milestoneid}
                      className="bg-slate-500/5 font-medium hover:bg-slate-500/10"
                    >
                      <TableCell className="p-0 text-center">
                        {subMilestones.length > 0 && (
                          <button
                            onClick={() => toggleCollapse(gate.milestoneid)}
                            className="cursor-pointer p-2"
                          >
                            <ChevronRight
                              className={`size-4 text-slate-500 transition-transform duration-200 ${
                                !isCollapsed ? "rotate-90" : ""
                              }`}
                            />
                          </button>
                        )}
                      </TableCell>
                      <TableCell className="py-3 font-semibold text-slate-900 dark:text-slate-100">
                        <div className="flex items-center gap-2">
                          <Award className="size-4 shrink-0 text-indigo-500" />
                          <span>{gate.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center text-xs whitespace-nowrap tabular-nums">
                        {formatDate(gate.startdate)}{" "}
                        <span className="text-slate-400">→</span>{" "}
                        {formatDate(gate.targetedcompletiondate)}
                      </TableCell>
                      <TableCell className="text-xs text-slate-600 italic dark:text-slate-400">
                        {gate.deliverable || "—"}
                      </TableCell>
                      <TableCell className="text-center text-xs font-semibold text-slate-400">
                        —
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge
                          className={`${STATUS_COLORS[gateStatus] || "bg-muted"} px-2 py-0.5 text-[10px]`}
                        >
                          {gateStatus}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(gate.milestoneid)}
                          >
                            <Pencil className="size-3.5" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive hover:bg-destructive/10"
                            onClick={() => setDeleteTarget(gate.milestoneid)}
                          >
                            <Trash2 className="size-3.5" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>

                    {/* Sub-milestone Rows */}
                    <TableRow className="border-0 hover:bg-transparent data-[state=selected]:bg-transparent">
                      <TableCell colSpan={7} className="border-0 p-0">
                        <AnimatePresence initial={false}>
                          {!isCollapsed && subMilestones.length > 0 && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{
                                duration: 0.22,
                                ease: [0.4, 0, 0.2, 1],
                              }}
                              className="overflow-hidden border-b bg-slate-500/[0.02] dark:bg-slate-900/10"
                            >
                              <Table className="w-full table-fixed">
                                <colgroup>
                                  <col style={{ width: "32px" }} />
                                  <col style={{ minWidth: "200px" }} />
                                  <col style={{ width: "180px" }} />
                                  <col style={{ minWidth: "200px" }} />
                                  <col style={{ width: "100px" }} />
                                  <col style={{ width: "110px" }} />
                                  <col style={{ width: "100px" }} />
                                </colgroup>
                                <TableBody>
                                  {subMilestones.map((sub) => {
                                    const isDateShifted =
                                      sub.targetedcompletiondate !==
                                      sub.originaltargetedcompletiondate
                                    const isSubExpanded =
                                      expandedSubId === sub.milestoneid
                                    const linkedScmItems = supplyChains.filter(
                                      (s) => s.milestoneid === sub.milestoneid
                                    )
                                    return (
                                      <>
                                        <TableRow
                                          key={sub.milestoneid}
                                          className={`cursor-pointer border-b transition-colors last:border-b-0 hover:bg-muted/40 ${
                                            linkedScmItems.length > 0
                                              ? "border-l-[3px] border-l-amber-500/40 bg-amber-500/[0.015] hover:bg-amber-500/[0.03] dark:bg-amber-500/[0.005] dark:hover:bg-amber-500/[0.01]"
                                              : ""
                                          }`}
                                          onClick={() =>
                                            setExpandedSubId(
                                              isSubExpanded
                                                ? null
                                                : sub.milestoneid
                                            )
                                          }
                                        >
                                          <TableCell className="py-2.5 text-center">
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation()
                                                setExpandedSubId(
                                                  isSubExpanded
                                                    ? null
                                                    : sub.milestoneid
                                                )
                                              }}
                                              className="inline-flex cursor-pointer items-center justify-center rounded p-1 hover:bg-muted"
                                            >
                                              <ChevronRight
                                                className={`size-3 text-slate-500 transition-transform ${isSubExpanded ? "rotate-90 text-foreground" : ""}`}
                                              />
                                            </button>
                                          </TableCell>
                                          <TableCell className="py-2.5 pl-6 text-xs font-medium text-foreground">
                                            <div className="flex items-center gap-2">
                                              <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                                              <span
                                                className={
                                                  linkedScmItems.length > 0
                                                    ? "font-semibold text-amber-900 dark:text-amber-300"
                                                    : ""
                                                }
                                              >
                                                {sub.name}
                                              </span>
                                              {linkedScmItems.length > 0 && (
                                                <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-500/25 bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-bold text-amber-600 shadow-xs select-none dark:bg-amber-500/20 dark:text-amber-400">
                                                  <Boxes className="size-2.5 text-amber-500" />
                                                  SCM Linked (
                                                  {linkedScmItems.length})
                                                </span>
                                              )}
                                            </div>
                                          </TableCell>
                                          <TableCell className="py-2.5 text-center text-xs font-semibold whitespace-nowrap tabular-nums">
                                            {isDateShifted ? (
                                              <button
                                                onClick={(e) => {
                                                  e.stopPropagation()
                                                  setHistoryMilestoneId(
                                                    sub.milestoneid
                                                  )
                                                }}
                                                className="group mx-auto flex cursor-pointer items-center gap-1.5 transition-colors hover:underline"
                                              >
                                                <span className="text-amber-600">
                                                  {formatDate(
                                                    sub.targetedcompletiondate
                                                  )}
                                                </span>
                                                <AlertTriangle className="size-3 text-amber-500" />
                                              </button>
                                            ) : (
                                              formatDate(
                                                sub.targetedcompletiondate
                                              )
                                            )}
                                          </TableCell>
                                          <TableCell
                                            className="max-w-[220px] truncate py-2.5 text-xs text-muted-foreground"
                                            title={sub.deliverable}
                                          >
                                            {sub.deliverable}
                                          </TableCell>
                                          <TableCell className="py-2.5 text-center font-mono text-xs font-bold text-indigo-500">
                                            {sub.paymentPercentage > 0
                                              ? `${sub.paymentPercentage}%`
                                              : "—"}
                                          </TableCell>
                                          <TableCell className="py-2.5 text-center">
                                            <Badge
                                              className={`${STATUS_COLORS[sub.status] || "bg-muted"} px-1.5 py-0 text-[9px]`}
                                            >
                                              {sub.status}
                                            </Badge>
                                          </TableCell>
                                          <TableCell className="py-2.5 text-right">
                                            <div
                                              className="flex items-center justify-end gap-1"
                                              onClick={(e) =>
                                                e.stopPropagation()
                                              }
                                            >
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                onClick={() =>
                                                  openEditDialog(
                                                    sub.milestoneid
                                                  )
                                                }
                                              >
                                                <Pencil className="size-3.5" />
                                              </Button>
                                              <Button
                                                variant="ghost"
                                                size="icon"
                                                className="text-destructive hover:bg-destructive/10"
                                                onClick={() =>
                                                  setDeleteTarget(
                                                    sub.milestoneid
                                                  )
                                                }
                                              >
                                                <Trash2 className="size-3.5" />
                                              </Button>
                                            </div>
                                          </TableCell>
                                        </TableRow>

                                        {/* Detailed SCM Expander row under sub-milestone */}
                                        {isSubExpanded && (
                                          <TableRow
                                            className={`transition-colors hover:bg-transparent ${linkedScmItems.length > 0 ? "bg-amber-500/[0.015] dark:bg-amber-500/[0.005]" : "bg-slate-500/[0.01]"}`}
                                          >
                                            <TableCell
                                              colSpan={7}
                                              className={`border-b p-4 transition-all ${linkedScmItems.length > 0 ? "border-l-[3px] border-l-amber-500" : ""}`}
                                            >
                                              <div className="flex flex-col gap-3">
                                                <div className="flex items-center justify-between">
                                                  <h5
                                                    className={`flex items-center gap-1.5 text-xs font-bold tracking-wider uppercase ${linkedScmItems.length > 0 ? "text-amber-600 dark:text-amber-400" : "text-muted-foreground"}`}
                                                  >
                                                    <Boxes
                                                      className={`size-3.5 ${linkedScmItems.length > 0 ? "text-amber-500" : ""}`}
                                                    />
                                                    Procurement & Vendor
                                                    Quantities (
                                                    {linkedScmItems.length})
                                                    {linkedScmItems.length >
                                                      0 && (
                                                      <span className="ml-2 inline-flex shrink-0 items-center gap-1 rounded-full border border-amber-500/25 bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-bold text-amber-600 normal-case shadow-xs select-none dark:bg-amber-500/20 dark:text-amber-400">
                                                        Supply Chain Tracked
                                                      </span>
                                                    )}
                                                  </h5>
                                                  <Button
                                                    variant="outline"
                                                    size="sm"
                                                    className="h-7 text-xs font-medium"
                                                    onClick={(e) => {
                                                      e.stopPropagation()
                                                      navigate(
                                                        `/supply-chain?add_linked_deliverable=${sub.milestoneid}`
                                                      )
                                                    }}
                                                  >
                                                    <Plus className="mr-1 size-3" />
                                                    Add Supply Vendor / Qty
                                                  </Button>
                                                </div>
                                                {linkedScmItems.length === 0 ? (
                                                  <div className="rounded-lg border bg-muted/20 p-3 text-xs text-muted-foreground italic">
                                                    No procurement items linked
                                                    to this deliverable. Click
                                                    "Add Supply Vendor / Qty" to
                                                    link vendors and track PO
                                                    timelines.
                                                  </div>
                                                ) : (
                                                  <div className="overflow-hidden rounded-lg border bg-card/60 shadow-sm backdrop-blur-xs">
                                                    <Table className="w-full text-xs">
                                                      <TableHeader className="bg-muted/40">
                                                        <TableRow>
                                                          <TableHead className="py-2 font-semibold">
                                                            Procurement Item
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            Supplier / Vendor
                                                          </TableHead>
                                                          <TableHead className="py-2 text-center font-semibold">
                                                            Qty
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            PR Details
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            PO Details
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            Value (CR)
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            Paid (CR)
                                                          </TableHead>
                                                          <TableHead className="py-2 font-semibold">
                                                            Expected Date
                                                          </TableHead>
                                                          <TableHead className="py-2 text-center font-semibold">
                                                            Status
                                                          </TableHead>
                                                        </TableRow>
                                                      </TableHeader>
                                                      <TableBody>
                                                        {linkedScmItems.map(
                                                          (scm) => {
                                                            const pct =
                                                              scm.poValueCr &&
                                                              scm.poValueCr > 0
                                                                ? Math.min(
                                                                    100,
                                                                    Math.round(
                                                                      ((scm.paymentReleasedCr ||
                                                                        0) /
                                                                        scm.poValueCr) *
                                                                        100
                                                                    )
                                                                  )
                                                                : 0
                                                            return (
                                                              <TableRow
                                                                key={
                                                                  scm.supplychainreadinessid
                                                                }
                                                                className="hover:bg-amber-500/[0.02] dark:hover:bg-amber-500/[0.01]"
                                                              >
                                                                <TableCell className="py-2 font-semibold text-foreground">
                                                                  {scm.item}
                                                                </TableCell>
                                                                <TableCell className="py-2">
                                                                  {scm.supplier}
                                                                </TableCell>
                                                                <TableCell className="bg-muted/15 py-2 text-center font-mono font-semibold">
                                                                  {scm.quantity ||
                                                                    "—"}
                                                                </TableCell>
                                                                <TableCell className="py-2 font-mono text-[10px]">
                                                                  {scm.prNumber ? (
                                                                    <div className="flex flex-col gap-0.5">
                                                                      <span className="block font-semibold">
                                                                        {
                                                                          scm.prNumber
                                                                        }
                                                                      </span>
                                                                      <span className="text-muted-foreground">
                                                                        {
                                                                          scm.prDate
                                                                        }
                                                                      </span>
                                                                      <span className="py-0.2 mt-0.5 inline-flex w-fit items-center rounded border border-emerald-500/20 bg-emerald-500/10 px-1 text-[8px] font-bold text-emerald-600 dark:text-emerald-400">
                                                                        Released
                                                                      </span>
                                                                    </div>
                                                                  ) : (
                                                                    <div className="flex flex-col gap-0.5">
                                                                      <span className="text-muted-foreground">
                                                                        —
                                                                      </span>
                                                                      <span className="py-0.2 mt-0.5 inline-flex w-fit items-center rounded border border-amber-500/20 bg-amber-500/10 px-1 text-[8px] font-bold text-amber-600 dark:text-amber-400">
                                                                        Awaiting
                                                                        PR
                                                                      </span>
                                                                    </div>
                                                                  )}
                                                                </TableCell>
                                                                <TableCell className="py-2 font-mono text-[10px]">
                                                                  {scm.poNumber ? (
                                                                    <div className="flex flex-col gap-0.5">
                                                                      <span className="block font-semibold">
                                                                        {
                                                                          scm.poNumber
                                                                        }
                                                                      </span>
                                                                      <span className="text-muted-foreground">
                                                                        {
                                                                          scm.poDate
                                                                        }
                                                                      </span>
                                                                      <span className="py-0.2 mt-0.5 inline-flex w-fit items-center rounded border border-emerald-500/20 bg-emerald-500/10 px-1 text-[8px] font-bold text-emerald-600 dark:text-emerald-400">
                                                                        Released
                                                                      </span>
                                                                    </div>
                                                                  ) : (
                                                                    <div className="flex flex-col gap-0.5">
                                                                      <span className="text-muted-foreground">
                                                                        —
                                                                      </span>
                                                                      <span className="py-0.2 mt-0.5 inline-flex w-fit items-center rounded border border-amber-500/20 bg-amber-500/10 px-1 text-[8px] font-bold text-amber-600 dark:text-amber-400">
                                                                        Awaiting
                                                                        PO
                                                                      </span>
                                                                    </div>
                                                                  )}
                                                                </TableCell>
                                                                <TableCell className="py-2 font-mono">
                                                                  {scm.poValueCr
                                                                    ? `${scm.poValueCr.toFixed(2)} Cr`
                                                                    : "—"}
                                                                </TableCell>
                                                                <TableCell className="py-2 font-mono text-emerald-600 dark:text-emerald-400">
                                                                  {scm.paymentReleasedCr ? (
                                                                    <div>
                                                                      <span className="block font-semibold">
                                                                        {scm.paymentReleasedCr.toFixed(
                                                                          2
                                                                        )}{" "}
                                                                        Cr
                                                                      </span>
                                                                      <span className="text-[10px] text-muted-foreground">
                                                                        ({pct}%)
                                                                      </span>
                                                                    </div>
                                                                  ) : (
                                                                    "—"
                                                                  )}
                                                                </TableCell>
                                                                <TableCell className="py-2">
                                                                  {
                                                                    scm.dateofdelivery
                                                                  }
                                                                </TableCell>
                                                                <TableCell className="py-2 text-center">
                                                                  <Badge
                                                                    variant="secondary"
                                                                    className={`py-0.2 inline-flex items-center gap-1 border-0 px-1.5 text-[9px] select-none ${
                                                                      scm.status ===
                                                                      "Delivered"
                                                                        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                                                                        : scm.status ===
                                                                            "In Transit"
                                                                          ? "bg-cyan-500/10 text-cyan-600 dark:text-cyan-400"
                                                                          : scm.status ===
                                                                              "Ordered"
                                                                            ? "bg-blue-500/10 text-blue-600 dark:text-blue-400"
                                                                            : scm.status ===
                                                                                "Delayed"
                                                                              ? "bg-red-500/10 text-red-600 dark:text-red-400"
                                                                              : "bg-amber-500/10 text-amber-600 dark:text-amber-400"
                                                                    }`}
                                                                  >
                                                                    {scm.status ===
                                                                      "Delivered" && (
                                                                      <CheckCircle className="size-2.5" />
                                                                    )}
                                                                    {scm.status ===
                                                                      "In Transit" && (
                                                                      <Truck className="size-2.5" />
                                                                    )}
                                                                    {scm.status ===
                                                                      "Delayed" && (
                                                                      <AlertTriangle className="size-2.5" />
                                                                    )}
                                                                    {scm.status ===
                                                                      "Sourcing" && (
                                                                      <CircleDot className="size-2.5" />
                                                                    )}
                                                                    {scm.status}
                                                                  </Badge>
                                                                </TableCell>
                                                              </TableRow>
                                                            )
                                                          }
                                                        )}
                                                      </TableBody>
                                                    </Table>
                                                  </div>
                                                )}
                                              </div>
                                            </TableCell>
                                          </TableRow>
                                        )}
                                      </>
                                    )
                                  })}
                                </TableBody>
                              </Table>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </TableCell>
                    </TableRow>
                  </>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* ── T0 TIMELINE CONFIGURATION MODAL ── */}
      <Dialog
        modal={false}
        open={isT0ModalOpen}
        onOpenChange={setIsT0ModalOpen}
      >
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Set T0 Base Date</DialogTitle>
            <DialogDescription>
              Changing T0 shifts the calendar timelines for all relative
              milestones.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Field>
              <Label>T0 Start Date</Label>
              <DatePicker
                value={tempT0}
                onChange={(val) => setTempT0(val || "2026-09-01")}
                placeholder="Select baseline date"
              />
            </Field>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline" disabled={isT0Saving}>
                Cancel
              </Button>
            </DialogClose>
            <Button onClick={handleT0Shift} disabled={isT0Saving}>
              {isT0Saving && <Spinner data-icon="inline-start" />} Apply Shift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── ADD/EDIT DIALOG ── */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit Milestone Item" : "Add Milestone Item"}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh] pr-4">
            <form onSubmit={handleSubmit(onSubmit)}>
              <FieldGroup>
                <Field data-invalid={!!errors.name || undefined}>
                  <Label htmlFor="ms-name">Milestone / Deliverable Name</Label>
                  <Input
                    id="ms-name"
                    {...register("name")}
                    placeholder="e.g., Preliminary Design Freeze"
                  />
                  {errors.name && (
                    <FieldError>{errors.name.message}</FieldError>
                  )}
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.t0OffsetStart || undefined}>
                    <Label htmlFor="ms-offset-start">
                      T0 Offset Start (Months)
                    </Label>
                    <Input
                      id="ms-offset-start"
                      type="number"
                      {...register("t0OffsetStart")}
                    />
                    {errors.t0OffsetStart && (
                      <FieldError>{errors.t0OffsetStart.message}</FieldError>
                    )}
                  </Field>
                  <Field data-invalid={!!errors.t0OffsetEnd || undefined}>
                    <Label htmlFor="ms-offset-end">
                      T0 Offset End (Months)
                    </Label>
                    <Input
                      id="ms-offset-end"
                      type="number"
                      {...register("t0OffsetEnd")}
                    />
                    {errors.t0OffsetEnd && (
                      <FieldError>{errors.t0OffsetEnd.message}</FieldError>
                    )}
                  </Field>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.parentMilestoneId || undefined}>
                    <Label>Parent Milestone (Main Gate)</Label>
                    <Controller
                      control={control}
                      name="parentMilestoneId"
                      render={({ field }) => {
                        const itemsList = mainMilestones.filter(
                          (m) => m.milestoneid !== editingId
                        )
                        const selectedVal = field.value || null
                        const selectedLabel =
                          itemsList.find((i) => i.milestoneid === selectedVal)
                            ?.name || "Main Milestone (None)"
                        return (
                          <Combobox
                            value={
                              selectedVal
                                ? selectedLabel
                                : "Main Milestone (None)"
                            }
                            onValueChange={(label) => {
                              const found = itemsList.find(
                                (i) => i.name === label
                              )
                              field.onChange(found ? found.milestoneid : null)
                            }}
                            items={[
                              "Main Milestone (None)",
                              ...itemsList.map((i) => i.name),
                            ]}
                          >
                            <ComboboxInput placeholder="Select parent" />
                            <ComboboxContent>
                              <ComboboxList>
                                {(item) => (
                                  <ComboboxItem key={item} value={item}>
                                    {item}
                                  </ComboboxItem>
                                )}
                              </ComboboxList>
                            </ComboboxContent>
                          </Combobox>
                        )
                      }}
                    />
                  </Field>
                  <Field data-invalid={!!errors.paymentPercentage || undefined}>
                    <Label htmlFor="ms-payment">Payment Percentage (%)</Label>
                    <Input
                      id="ms-payment"
                      type="number"
                      {...register("paymentPercentage")}
                      placeholder="0"
                    />
                    {errors.paymentPercentage && (
                      <FieldError>
                        {errors.paymentPercentage.message}
                      </FieldError>
                    )}
                  </Field>
                </div>

                <Field data-invalid={!!errors.deliverable || undefined}>
                  <Label htmlFor="ms-deliv">
                    Contractual Deliverable Details
                  </Label>
                  <Input
                    id="ms-deliv"
                    {...register("deliverable")}
                    placeholder="e.g. 2 sets of XY Unit, Acceptance Certificate"
                  />
                  {errors.deliverable && (
                    <FieldError>{errors.deliverable.message}</FieldError>
                  )}
                </Field>

                <div className="grid grid-cols-2 gap-4">
                  <Field data-invalid={!!errors.status || undefined}>
                    <Label>Status</Label>
                    <Controller
                      control={control}
                      name="status"
                      render={({ field }) => (
                        <Combobox
                          value={field.value || null}
                          onValueChange={(v: string | null) =>
                            field.onChange(v ?? "")
                          }
                          items={statusItems}
                        >
                          <ComboboxInput placeholder="Select status" />
                          <ComboboxContent>
                            <ComboboxList>
                              {(item: string) => (
                                <ComboboxItem key={item} value={item}>
                                  {item}
                                </ComboboxItem>
                              )}
                            </ComboboxList>
                          </ComboboxContent>
                        </Combobox>
                      )}
                    />
                    {errors.status && (
                      <FieldError>{errors.status.message}</FieldError>
                    )}
                  </Field>

                  <Field data-invalid={!!errors.ownerorgnodeid || undefined}>
                    <Label>Owner</Label>
                    <Controller
                      control={control}
                      name="ownerorgnodeid"
                      render={({ field }) => {
                        const selectedName =
                          orgNodes.find(
                            (n) => n.programmeorgnodeid === field.value
                          )?.displayname ?? null
                        return (
                          <Combobox
                            value={selectedName}
                            onValueChange={(name: string | null) => {
                              const node = orgNodes.find(
                                (n) => n.displayname === name
                              )
                              field.onChange(node?.programmeorgnodeid ?? "")
                            }}
                            items={orgNodeNames}
                          >
                            <ComboboxInput placeholder="Select owner" />
                            <ComboboxContent>
                              <ComboboxList>
                                {(name: string) => (
                                  <ComboboxItem key={name} value={name}>
                                    {name}
                                  </ComboboxItem>
                                )}
                              </ComboboxList>
                            </ComboboxContent>
                          </Combobox>
                        )
                      }}
                    />
                    {errors.ownerorgnodeid && (
                      <FieldError>{errors.ownerorgnodeid.message}</FieldError>
                    )}
                  </Field>
                </div>

                <div className="col-span-2">
                  <Field>
                    <Label>Assigned Team Members (Deliverables)</Label>
                    <Controller
                      control={control}
                      name="assigneeNodeIds"
                      render={({ field }) => {
                        const currentValues = field.value || []
                        return (
                          <div className="grid max-h-[140px] grid-cols-2 gap-2 overflow-y-auto rounded-lg border bg-background p-2.5">
                            {deliverableOrgNodes.map((node) => {
                              const isChecked = currentValues.includes(
                                node.programmeorgnodeid
                              )
                              return (
                                <label
                                  key={node.programmeorgnodeid}
                                  className={`flex cursor-pointer items-center gap-2 rounded-md border px-2 py-1.5 text-xs transition-colors ${
                                    isChecked
                                      ? "border-primary/20 bg-primary/5 font-medium text-foreground"
                                      : "border-transparent text-muted-foreground hover:bg-muted"
                                  } `}
                                >
                                  <input
                                    type="checkbox"
                                    checked={isChecked}
                                    onChange={(e) => {
                                      const next = e.target.checked
                                        ? [
                                            ...currentValues,
                                            node.programmeorgnodeid,
                                          ]
                                        : currentValues.filter(
                                            (id) =>
                                              id !== node.programmeorgnodeid
                                          )
                                      field.onChange(next)
                                    }}
                                    className="size-3.5 rounded border-input text-primary focus:ring-primary"
                                  />
                                  <div className="min-w-0">
                                    <div className="truncate font-semibold">
                                      {node.displayname}
                                    </div>
                                    <div className="truncate text-[10px] text-muted-foreground">
                                      {node.title}
                                    </div>
                                  </div>
                                </label>
                              )
                            })}
                          </div>
                        )
                      }}
                    />
                  </Field>
                </div>

                <Field>
                  <Label htmlFor="ms-remarks">Remarks</Label>
                  <Textarea
                    id="ms-remarks"
                    {...register("remarks")}
                    placeholder="Additional notes..."
                  />
                </Field>
              </FieldGroup>

              <DialogFooter className="mt-6">
                <DialogClose asChild>
                  <Button type="button" variant="outline" disabled={isSaving}>
                    Cancel
                  </Button>
                </DialogClose>
                <Button type="submit" disabled={isSaving}>
                  {isSaving && <Spinner data-icon="inline-start" />} Save
                </Button>
              </DialogFooter>
            </form>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* ── DATE AUDIT REASON DIALOG ── */}
      <Dialog open={showReasonDialog} onOpenChange={setShowReasonDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Date Shift Reason Required</DialogTitle>
            <DialogDescription>
              Modifying T0 offsets changes baseline schedules. Please log a
              reason for this audit event.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2">
            {pendingDateChanges.map((c) => (
              <div
                key={c.field}
                className="flex items-center gap-2 rounded-lg bg-muted px-3 py-2 text-xs"
              >
                <span className="font-semibold text-muted-foreground">
                  Target:
                </span>
                <span className="text-red-500 line-through">
                  {formatDate(c.oldDate)}
                </span>
                <ArrowRight className="size-3 text-muted-foreground" />
                <span className="font-bold">{formatDate(c.newDate)}</span>
              </div>
            ))}
          </div>
          <FieldGroup>
            <Field>
              <Label htmlFor="change-reason">Reason</Label>
              <Textarea
                id="change-reason"
                value={dateChangeReason}
                onChange={(e) => setDateChangeReason(e.target.value)}
                placeholder="e.g., Fabrication assembly delayed..."
              />
            </Field>
          </FieldGroup>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowReasonDialog(false)
                setPendingDateChanges([])
                setPendingFormData(null)
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleReasonConfirm}
              disabled={!dateChangeReason.trim()}
            >
              Confirm & Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DATE HISTORY MODAL ── */}
      <Dialog
        open={!!historyMilestoneId}
        onOpenChange={(open) => !open && setHistoryMilestoneId(null)}
      >
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Shift History Log</DialogTitle>
            <DialogDescription>
              Chronological schedule changes audited for this sub-milestone.
            </DialogDescription>
          </DialogHeader>

          {historyMilestoneId &&
          dateChangeLogs.filter(
            (l) => l.recordid === historyMilestoneId && l.module === "milestone"
          ).length === 0 ? (
            <div className="py-8 text-center text-xs text-muted-foreground">
              No date changes logged yet for this milestone.
            </div>
          ) : (
            <ScrollArea className="max-h-[50vh] pr-2">
              <div className="flex flex-col gap-3">
                {historyMilestoneId &&
                  dateChangeLogs
                    .filter(
                      (l) =>
                        l.recordid === historyMilestoneId &&
                        l.module === "milestone"
                    )
                    .sort(
                      (a, b) =>
                        new Date(b.changedon).getTime() -
                        new Date(a.changedon).getTime()
                    )
                    .map((log) => (
                      <div
                        key={log.datechangelogid}
                        className="rounded-lg border bg-muted/20 px-4 py-3"
                      >
                        <div className="mb-1.5 flex items-center justify-between">
                          <Badge
                            variant="secondary"
                            className="text-[10px] font-normal"
                          >
                            Target Date Shifted
                          </Badge>
                          <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                            <Clock className="size-3" />{" "}
                            {new Date(log.changedon).toLocaleString()}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-red-500 line-through">
                            {formatDate(log.olddate)}
                          </span>
                          <ArrowRight className="size-3 text-muted-foreground" />
                          <span className="font-semibold text-emerald-600">
                            {formatDate(log.newdate)}
                          </span>
                        </div>
                        <p className="mt-1.5 text-xs text-muted-foreground italic">
                          "{log.reason}"
                        </p>
                      </div>
                    ))}
              </div>
            </ScrollArea>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setHistoryMilestoneId(null)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DELETE ALERT ── */}
      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && !isDeleting && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete this milestone. If you delete a parent
              milestone, all nested sub-milestones will also be removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              disabled={isDeleting}
              onClick={handleDelete}
            >
              {isDeleting && <Spinner data-icon="inline-start" />} Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
