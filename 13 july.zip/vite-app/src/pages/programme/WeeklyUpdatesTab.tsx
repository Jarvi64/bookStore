import { useState, useMemo, useCallback, useEffect } from "react"
import { useAppStore, WEEKLY_CATEGORIES } from "@/lib/store"
import { toast } from "sonner"
import {
  Plus,
  Trash2,
  Save,
  ArrowLeftRight,
  CheckCircle2,
  XCircle,
  Calendar,
  ClipboardList,
  Settings,
  Link,
  Handshake,
  Users,
  Award,
  Building2,
  Package,
  Wallet,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Spinner } from "@/components/ui/spinner"
import {
  Combobox,
  ComboboxContent,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
  ComboboxEmpty,
} from "@/components/ui/combobox"

// ── Helpers ─────────────────────────────────────────────────
function getISOWeek(date: Date): number {
  const d = new Date(
    Date.UTC(date.getFullYear(), date.getMonth(), date.getDate())
  )
  const dayNum = d.getUTCDay() || 7
  d.setUTCDate(d.getUTCDate() + 4 - dayNum)
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1))
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7)
}

function getCurrentWeekKey(): string {
  const now = new Date()
  const week = getISOWeek(now)
  return `${now.getFullYear()}-W${String(week).padStart(2, "0")}`
}

function getNextWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number)
  const next = w + 1
  if (next > 52) return `${year + 1}-W01`
  return `${year}-W${String(next).padStart(2, "0")}`
}

function getPrevWeekKey(weekKey: string): string {
  const [year, w] = weekKey.split("-W").map(Number)
  const prev = w - 1
  if (prev < 1) return `${year - 1}-W52`
  return `${year}-W${String(prev).padStart(2, "0")}`
}

// ── Local item type for editing ─────────────────────────────
type LocalItem = {
  tempId: string
  category: string
  entrytype: "positive" | "negative"
  description: string
}

let tempCounter = 0
const nextTempId = () => `tmp_${++tempCounter}`

// Category icon/color config
const CATEGORY_STYLES: Record<
  string,
  { bg: string; border: string; icon: React.ReactNode }
> = {
  Program: {
    bg: "from-violet-500/8 to-violet-500/2",
    border: "border-violet-200 dark:border-violet-800/40",
    icon: <ClipboardList className="size-4" />,
  },
  Engineering: {
    bg: "from-blue-500/8 to-blue-500/2",
    border: "border-blue-200 dark:border-blue-800/40",
    icon: <Settings className="size-4" />,
  },
  SCM: {
    bg: "from-cyan-500/8 to-cyan-500/2",
    border: "border-cyan-200 dark:border-cyan-800/40",
    icon: <Link className="size-4" />,
  },
  Partner: {
    bg: "from-indigo-500/8 to-indigo-500/2",
    border: "border-indigo-200 dark:border-indigo-800/40",
    icon: <Handshake className="size-4" />,
  },
  Manpower: {
    bg: "from-emerald-500/8 to-emerald-500/2",
    border: "border-emerald-200 dark:border-emerald-800/40",
    icon: <Users className="size-4" />,
  },
  Certifications: {
    bg: "from-amber-500/8 to-amber-500/2",
    border: "border-amber-200 dark:border-amber-800/40",
    icon: <Award className="size-4" />,
  },
  "Infra/Project": {
    bg: "from-orange-500/8 to-orange-500/2",
    border: "border-orange-200 dark:border-orange-800/40",
    icon: <Building2 className="size-4" />,
  },
  "Supply Chain": {
    bg: "from-teal-500/8 to-teal-500/2",
    border: "border-teal-200 dark:border-teal-800/40",
    icon: <Package className="size-4" />,
  },
  Finance: {
    bg: "from-rose-500/8 to-rose-500/2",
    border: "border-rose-200 dark:border-rose-800/40",
    icon: <Wallet className="size-4" />,
  },
}

// ═══════════════════════════════════════════════════════════════
export function WeeklyUpdatesTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid)
  const {
    weeklyUpdates,
    weeklyUpdateItems,
    addWeeklyUpdate,
    updateWeeklyUpdate,
    bulkSetWeeklyUpdateItems,
  } = useAppStore()

  // Available weeks for this programme
  const programmeUpdates = useMemo(
    () =>
      weeklyUpdates
        .filter((u) => u.programmeid === programmeId)
        .sort((a, b) => a.weekkey.localeCompare(b.weekkey)),
    [weeklyUpdates, programmeId]
  )

  // Generate week options: existing weeks + next upcoming
  const weekOptions = useMemo(() => {
    const keys = new Set(programmeUpdates.map((u) => u.weekkey))
    const current = getCurrentWeekKey()
    const next = getNextWeekKey(current)
    // Always offer the current and next week
    keys.add(current)
    keys.add(next)
    return Array.from(keys).sort()
  }, [programmeUpdates])

  // Default to the latest existing week, or current
  const latestExistingWeek =
    programmeUpdates.length > 0
      ? programmeUpdates[programmeUpdates.length - 1].weekkey
      : getCurrentWeekKey()

  const [selectedWeek, setSelectedWeek] = useState(latestExistingWeek)
  const [localItems, setLocalItems] = useState<LocalItem[]>([])
  const [isSaving, setIsSaving] = useState(false)
  const [showChanges, setShowChanges] = useState(false)
  const [isDirty, setIsDirty] = useState(false)

  // Find the update record for selected week (if exists)
  const selectedUpdate = programmeUpdates.find(
    (u) => u.weekkey === selectedWeek
  )
  // Find previous week update
  const prevWeekKey = getPrevWeekKey(selectedWeek)
  const prevUpdate = programmeUpdates.find((u) => u.weekkey === prevWeekKey)
  const prevItems = useMemo(
    () =>
      prevUpdate
        ? weeklyUpdateItems.filter(
            (i) => i.weeklyupdateid === prevUpdate.weeklyupdateid
          )
        : [],
    [prevUpdate, weeklyUpdateItems]
  )

  // Load items when week changes
  useEffect(() => {
    let active = true
    queueMicrotask(() => {
      if (!active) return
      if (selectedUpdate) {
        // Load existing items
        const existing = weeklyUpdateItems.filter(
          (i) => i.weeklyupdateid === selectedUpdate.weeklyupdateid
        )
        setLocalItems(
          existing.map((i) => ({
            tempId: nextTempId(),
            category: i.category,
            entrytype: i.entrytype as "positive" | "negative",
            description: i.description,
          }))
        )
      } else {
        // New week — pre-fill from previous week
        if (prevItems.length > 0) {
          setLocalItems(
            prevItems.map((i) => ({
              tempId: nextTempId(),
              category: i.category,
              entrytype: i.entrytype as "positive" | "negative",
              description: i.description,
            }))
          )
        } else {
          // Start with one empty positive + negative for each category
          const starters: LocalItem[] = []
          for (const cat of WEEKLY_CATEGORIES) {
            starters.push({
              tempId: nextTempId(),
              category: cat,
              entrytype: "positive",
              description: "",
            })
            starters.push({
              tempId: nextTempId(),
              category: cat,
              entrytype: "negative",
              description: "",
            })
          }
          setLocalItems(starters)
        }
      }
      setIsDirty(false)
      setShowChanges(false)
    })
    return () => {
      active = false
    }
  }, [selectedUpdate, weeklyUpdateItems, prevItems])

  // Group items by category
  const itemsByCategory = useMemo(() => {
    const map: Record<
      string,
      { positive: LocalItem[]; negative: LocalItem[] }
    > = {}
    for (const cat of WEEKLY_CATEGORIES) {
      map[cat] = { positive: [], negative: [] }
    }
    for (const item of localItems) {
      if (map[item.category]) {
        map[item.category][item.entrytype].push(item)
      }
    }
    return map
  }, [localItems])

  // Group previous items by category for comparison
  const prevItemsByCategory = useMemo(() => {
    const map: Record<string, { positive: string[]; negative: string[] }> = {}
    for (const cat of WEEKLY_CATEGORIES) {
      map[cat] = { positive: [], negative: [] }
    }
    for (const item of prevItems) {
      if (map[item.category]) {
        map[item.category][item.entrytype as "positive" | "negative"].push(
          item.description
        )
      }
    }
    return map
  }, [prevItems])

  const addItem = useCallback(
    (category: string, entrytype: "positive" | "negative") => {
      setLocalItems((prev) => [
        ...prev,
        { tempId: nextTempId(), category, entrytype, description: "" },
      ])
      setIsDirty(true)
    },
    []
  )

  const removeItem = useCallback((tempId: string) => {
    setLocalItems((prev) => prev.filter((i) => i.tempId !== tempId))
    setIsDirty(true)
  }, [])

  const updateItemDesc = useCallback((tempId: string, desc: string) => {
    setLocalItems((prev) =>
      prev.map((i) => (i.tempId === tempId ? { ...i, description: desc } : i))
    )
    setIsDirty(true)
  }, [])

  const handleSave = async () => {
    setIsSaving(true)
    try {
      await new Promise((r) => setTimeout(r, 500))

      // Filter out empty descriptions
      const validItems = localItems.filter((i) => i.description.trim())

      if (selectedUpdate) {
        // Update existing
        updateWeeklyUpdate(selectedUpdate.weeklyupdateid, {
          submittedon: new Date().toISOString(),
          status: "Submitted",
        })
        bulkSetWeeklyUpdateItems(
          selectedUpdate.weeklyupdateid,
          validItems.map((i) => ({
            weeklyupdateid: selectedUpdate.weeklyupdateid,
            category: i.category,
            entrytype: i.entrytype,
            description: i.description.trim(),
          }))
        )
      } else {
        // Create new weekly update
        const createdUpdate = addWeeklyUpdate({
          programmeid: programmeId,
          weekkey: selectedWeek,
          submittedon: new Date().toISOString(),
          status: "Submitted",
        })
        bulkSetWeeklyUpdateItems(
          createdUpdate.weeklyupdateid,
          validItems.map((i) => ({
            weeklyupdateid: createdUpdate.weeklyupdateid,
            category: i.category,
            entrytype: i.entrytype,
            description: i.description.trim(),
          }))
        )
      }

      setIsDirty(false)
      toast.success(`Weekly update for ${selectedWeek} saved`)
    } catch {
      toast.error("Something went wrong")
    } finally {
      setIsSaving(false)
    }
  }

  // Stats
  const totalPositive = localItems.filter(
    (i) => i.entrytype === "positive" && i.description.trim()
  ).length
  const totalNegative = localItems.filter(
    (i) => i.entrytype === "negative" && i.description.trim()
  ).length
  const filledCategories = new Set(
    localItems.filter((i) => i.description.trim()).map((i) => i.category)
  ).size

  return (
    <div className="flex flex-col gap-5 pt-4">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-semibold">Weekly Updates</h3>
          <p className="text-sm text-muted-foreground">
            Track weekly positive developments and challenges across 9
            categories.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {prevUpdate && (
            <Button
              variant={showChanges ? "default" : "outline"}
              size="sm"
              onClick={() => setShowChanges(!showChanges)}
            >
              <ArrowLeftRight className="size-3.5" />
              {showChanges ? "Hide Changes" : "Show Changes"}
            </Button>
          )}
          <Button onClick={handleSave} disabled={isSaving || !isDirty}>
            {isSaving ? (
              <Spinner data-icon="inline-start" />
            ) : (
              <Save data-icon="inline-start" />
            )}
            Save Update
          </Button>
        </div>
      </div>

      {/* Week Selector + Stats */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="w-[240px]">
          <Combobox
            value={selectedWeek}
            onValueChange={(v: string | null) => {
              if (v) setSelectedWeek(v)
            }}
            items={weekOptions}
          >
            <ComboboxInput placeholder="Select week" />
            <ComboboxContent>
              <ComboboxEmpty>No weeks.</ComboboxEmpty>
              <ComboboxList>
                {(item: string) => {
                  const update = programmeUpdates.find(
                    (u) => u.weekkey === item
                  )
                  return (
                    <ComboboxItem key={item} value={item}>
                      <Calendar className="mr-1.5 size-3.5 text-muted-foreground" />
                      {item}
                      {update && (
                        <Badge
                          variant="secondary"
                          className="ml-auto px-1.5 text-[10px]"
                        >
                          {update.status}
                        </Badge>
                      )}
                    </ComboboxItem>
                  )
                }}
              </ComboboxList>
            </ComboboxContent>
          </Combobox>
        </div>

        {selectedUpdate && (
          <Badge variant="secondary" className="text-xs">
            Submitted:{" "}
            {new Date(selectedUpdate.submittedon).toLocaleDateString("en-GB", {
              day: "2-digit",
              month: "short",
              year: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            })}
          </Badge>
        )}
        {!selectedUpdate && (
          <Badge className="bg-amber-100 text-xs text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">
            New — {prevUpdate ? "pre-filled from " + prevWeekKey : "blank"}
          </Badge>
        )}

        <div className="ml-auto flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <div className="size-2 rounded-full bg-emerald-500" />
            {totalPositive} positive
          </span>
          <span className="flex items-center gap-1">
            <div className="size-2 rounded-full bg-red-500" />
            {totalNegative} challenges
          </span>
          <span>{filledCategories}/9 categories</span>
        </div>
      </div>

      {showChanges && !prevUpdate && (
        <div className="text-sm text-muted-foreground italic">
          No previous week data available for comparison.
        </div>
      )}

      {/* 9-Box Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...WEEKLY_CATEGORIES].map((category) => {
          const items = itemsByCategory[category]
          const style = CATEGORY_STYLES[category] || CATEGORY_STYLES["Program"]
          const prevCat = prevItemsByCategory[category]

          return (
            <Card
              key={category}
              className={`overflow-hidden border ${style.border} bg-gradient-to-b ${style.bg}`}
            >
              <CardContent className="p-0">
                {/* Category Header */}
                <div className="flex items-center justify-between border-b bg-card/50 px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{style.icon}</span>
                    <span className="text-sm font-semibold">{category}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <span className="font-medium text-emerald-600">
                      {
                        items.positive.filter((i) => i.description.trim())
                          .length
                      }
                    </span>
                    /
                    <span className="font-medium text-red-600">
                      {
                        items.negative.filter((i) => i.description.trim())
                          .length
                      }
                    </span>
                  </div>
                </div>

                <div className="flex flex-col gap-3 p-3">
                  {/* Positive Developments */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                        <CheckCircle2 className="size-3" />
                        Positive
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-5 text-emerald-600 hover:bg-emerald-100 dark:hover:bg-emerald-900/30"
                        onClick={() => addItem(category, "positive")}
                      >
                        <Plus className="size-3" />
                      </Button>
                    </div>
                    {items.positive.map((item) => {
                      const isNew =
                        showChanges &&
                        prevCat &&
                        !prevCat.positive.includes(item.description) &&
                        item.description.trim()
                      return (
                        <div
                          key={item.tempId}
                          className="group flex items-center gap-1.5"
                        >
                          <div
                            className={`size-1.5 shrink-0 rounded-full ${item.description.trim() ? "bg-emerald-500" : "bg-muted"}`}
                          />
                          <Input
                            value={item.description}
                            onChange={(e) =>
                              updateItemDesc(item.tempId, e.target.value)
                            }
                            placeholder="Enter positive development..."
                            className="h-7 border-transparent bg-transparent text-xs transition-colors hover:bg-card/50 focus:border-input focus:bg-card"
                          />
                          {isNew && (
                            <Badge className="shrink-0 bg-emerald-100 px-1 text-[9px] text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400">
                              New
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                            onClick={() => removeItem(item.tempId)}
                          >
                            <Trash2 className="size-3" />
                          </Button>
                        </div>
                      )
                    })}
                    {/* Show removed items from previous week */}
                    {showChanges &&
                      prevCat &&
                      prevCat.positive
                        .filter(
                          (desc) =>
                            !items.positive.some((i) => i.description === desc)
                        )
                        .map((desc, idx) => (
                          <div
                            key={`removed-pos-${idx}`}
                            className="flex items-center gap-1.5 opacity-60"
                          >
                            <div className="size-1.5 shrink-0 rounded-full bg-red-400" />
                            <span className="flex-1 truncate text-xs text-red-500 line-through">
                              {desc}
                            </span>
                            <Badge className="shrink-0 bg-red-100 px-1 text-[9px] text-red-800 dark:bg-red-900/30 dark:text-red-400">
                              Removed
                            </Badge>
                          </div>
                        ))}
                  </div>

                  <Separator className="opacity-40" />

                  {/* Challenges */}
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1 text-xs font-medium text-red-700 dark:text-red-400">
                        <XCircle className="size-3" />
                        Challenges
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-5 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/30"
                        onClick={() => addItem(category, "negative")}
                      >
                        <Plus className="size-3" />
                      </Button>
                    </div>
                    {items.negative.map((item) => {
                      const isNew =
                        showChanges &&
                        prevCat &&
                        !prevCat.negative.includes(item.description) &&
                        item.description.trim()
                      return (
                        <div
                          key={item.tempId}
                          className="group flex items-center gap-1.5"
                        >
                          <div
                            className={`size-1.5 shrink-0 rounded-full ${item.description.trim() ? "bg-red-500" : "bg-muted"}`}
                          />
                          <Input
                            value={item.description}
                            onChange={(e) =>
                              updateItemDesc(item.tempId, e.target.value)
                            }
                            placeholder="Enter challenge..."
                            className="h-7 border-transparent bg-transparent text-xs transition-colors hover:bg-card/50 focus:border-input focus:bg-card"
                          />
                          {isNew && (
                            <Badge className="shrink-0 bg-emerald-100 px-1 text-[9px] text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400">
                              New
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-5 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                            onClick={() => removeItem(item.tempId)}
                          >
                            <Trash2 className="size-3" />
                          </Button>
                        </div>
                      )
                    })}
                    {/* Show removed items from previous week */}
                    {showChanges &&
                      prevCat &&
                      prevCat.negative
                        .filter(
                          (desc) =>
                            !items.negative.some((i) => i.description === desc)
                        )
                        .map((desc, idx) => (
                          <div
                            key={`removed-neg-${idx}`}
                            className="flex items-center gap-1.5 opacity-60"
                          >
                            <div className="size-1.5 shrink-0 rounded-full bg-red-400" />
                            <span className="flex-1 truncate text-xs text-red-500 line-through">
                              {desc}
                            </span>
                            <Badge className="shrink-0 bg-red-100 px-1 text-[9px] text-red-800 dark:bg-red-900/30 dark:text-red-400">
                              Removed
                            </Badge>
                          </div>
                        ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Bottom Save Bar */}
      {isDirty && (
        <div className="sticky bottom-4 flex items-center justify-center">
          <div className="flex animate-in items-center gap-4 rounded-xl border bg-card px-6 py-3 shadow-lg duration-300 slide-in-from-bottom-4">
            <span className="text-sm text-muted-foreground">
              You have unsaved changes for <strong>{selectedWeek}</strong>
            </span>
            <Button onClick={handleSave} disabled={isSaving} size="sm">
              {isSaving ? (
                <Spinner data-icon="inline-start" />
              ) : (
                <Save data-icon="inline-start" />
              )}
              Save
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
