import { useState } from "react"
import { useForm, Controller } from "react-hook-form"
import { z } from "zod"
import { zodResolver } from "@hookform/resolvers/zod"
import { useAppStore } from "@/lib/store"
import { toast } from "sonner"
import { Plus, Pencil, Trash2, AlertTriangle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Field, FieldError } from "@/components/ui/field"
import { DatePicker } from "@/components/ui/date-picker"
import {
  Combobox,
  ComboboxContent,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
} from "@/components/ui/combobox"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { DateChangePopover } from "@/components/ui/date-change-popover"

const capexSchema = z.object({
  item: z.string().min(1, "Item is required"),
  budgetcr: z.coerce.number().min(0, "Budget cannot be negative"),
  actualcr: z.coerce.number().min(0, "Actual cannot be negative"),
  commisiongdate: z.string().min(1, "Commissioning Date is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
})

const opexSchema = z.object({
  item: z.string().min(1, "Item is required"),
  supplier: z.string().min(1, "Supplier is required"),
  unitcostcr: z.coerce.number().min(0, "Unit cost cannot be negative"),
  targetcostcr: z.coerce.number().min(0, "Target cost cannot be negative"),
  deadline: z.string().min(1, "Deadline is required"),
  ownerorgnodeid: z.string().min(1, "Owner is required"),
})
type CapexFormData = z.infer<typeof capexSchema>
type OpexFormData = z.infer<typeof opexSchema>
type CapexFormInput = z.input<typeof capexSchema>
type OpexFormInput = z.input<typeof opexSchema>
type BudgetFormData = CapexFormData | OpexFormData

export function BudgetTab() {
  const programmeId = useAppStore((s) => s.programmeConfig.programmeid)
  const {
    capexBudgets,
    opexBudgets,
    programmeOrgNodes,
    addCapexBudget,
    updateCapexBudget,
    deleteCapexBudget,
    addOpexBudget,
    updateOpexBudget,
    deleteOpexBudget,
    addDateChangeLog,
    dateChangeLogs,
  } = useAppStore()

  const capexItems = capexBudgets.filter((c) => c.programmeid === programmeId)
  const opexItems = opexBudgets.filter((o) => o.programmeid === programmeId)
  const orgNodes = programmeOrgNodes.filter(
    (n) => n.programmeid === programmeId && n.active === "Yes"
  )

  const [dialogType, setDialogType] = useState<"capex" | "opex">("capex")
  const [deleteType, setDeleteType] = useState<"capex" | "opex">("capex")

  // View state
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Totals calculations
  const totalCapexBudget = capexItems.reduce((acc, c) => acc + c.budgetcr, 0)
  const totalCapexActual = capexItems.reduce((acc, c) => acc + c.actualcr, 0)

  const totalOpexUnit = opexItems.reduce((acc, o) => acc + o.unitcostcr, 0)
  const totalOpexTarget = opexItems.reduce((acc, o) => acc + o.targetcostcr, 0)

  // Date Change Modal State
  const [dateChangeReason, setDateChangeReason] = useState("")
  const [pendingDateChangeData, setPendingDateChangeData] = useState<{
    formData: BudgetFormData
    changes: { field: string; oldDate: string; newDate: string }[]
    type: "capex" | "opex"
  } | null>(null)
  const [showReasonDialog, setShowReasonDialog] = useState(false)

  // Forms
  const capexForm = useForm<CapexFormInput, unknown, CapexFormData>({
    resolver: zodResolver(capexSchema),
  })
  const opexForm = useForm<OpexFormInput, unknown, OpexFormData>({
    resolver: zodResolver(opexSchema),
  })

  const getOwnerName = (nodeId: string) => {
    const node = programmeOrgNodes.find((n) => n.programmeorgnodeid === nodeId)
    return node ? node.displayname : "Unknown"
  }

  const openDialog = (type: "capex" | "opex", id?: string) => {
    setDialogType(type)
    setEditingId(id || null)
    if (type === "capex") {
      if (id) {
        const item = capexItems.find((c) => c.capexbudgetid === id)
        if (item) capexForm.reset({ ...item })
      } else {
        capexForm.reset({
          item: "",
          budgetcr: 0,
          actualcr: 0,
          commisiongdate: "",
          ownerorgnodeid: "",
        })
      }
    } else {
      if (id) {
        const item = opexItems.find((o) => o.programmebudgetid === id)
        if (item) opexForm.reset({ ...item })
      } else {
        opexForm.reset({
          item: "",
          supplier: "",
          unitcostcr: 0,
          targetcostcr: 0,
          deadline: "",
          ownerorgnodeid: "",
        })
      }
    }
    setIsDialogOpen(true)
  }

  const onSubmitCapex = async (data: CapexFormData) => {
    if (editingId) {
      const existing = capexItems.find((c) => c.capexbudgetid === editingId)
      if (existing && existing.commisiongdate !== data.commisiongdate) {
        setPendingDateChangeData({
          formData: data,
          changes: [
            {
              field: "commisiongdate",
              oldDate: existing.commisiongdate,
              newDate: data.commisiongdate,
            },
          ],
          type: "capex",
        })
        setShowReasonDialog(true)
        return
      }
    }
    await saveCapex(data)
  }

  const onSubmitOpex = async (data: OpexFormData) => {
    if (editingId) {
      const existing = opexItems.find((o) => o.programmebudgetid === editingId)
      if (existing && existing.deadline !== data.deadline) {
        setPendingDateChangeData({
          formData: data,
          changes: [
            {
              field: "deadline",
              oldDate: existing.deadline,
              newDate: data.deadline,
            },
          ],
          type: "opex",
        })
        setShowReasonDialog(true)
        return
      }
    }
    await saveOpex(data)
  }

  const saveCapex = async (data: CapexFormData, reason?: string) => {
    setIsSaving(true)
    try {
      if (editingId) {
        updateCapexBudget(editingId, data)
        if (pendingDateChangeData && reason) {
          addDateChangeLog({
            programmeid: programmeId,
            module: "capex",
            recordid: editingId,
            recordname: data.item,
            fieldname: "commisiongdate",
            olddate: pendingDateChangeData.changes[0].oldDate,
            newdate: pendingDateChangeData.changes[0].newDate,
            reason: reason,
          })
        }
        toast.success("Capex updated")
      } else {
        addCapexBudget({ ...data, programmeid: programmeId })
        toast.success("Capex added")
      }
      setIsDialogOpen(false)
      setPendingDateChangeData(null)
      setDateChangeReason("")
    } catch {
      toast.error("Failed to save Capex")
    } finally {
      setIsSaving(false)
    }
  }

  const saveOpex = async (data: OpexFormData, reason?: string) => {
    setIsSaving(true)
    try {
      if (editingId) {
        updateOpexBudget(editingId, data)
        if (pendingDateChangeData && reason) {
          addDateChangeLog({
            programmeid: programmeId,
            module: "opex",
            recordid: editingId,
            recordname: data.item,
            fieldname: "deadline",
            olddate: pendingDateChangeData.changes[0].oldDate,
            newdate: pendingDateChangeData.changes[0].newDate,
            reason: reason,
          })
        }
        toast.success("Opex updated")
      } else {
        addOpexBudget({ ...data, programmeid: programmeId })
        toast.success("Opex added")
      }
      setIsDialogOpen(false)
      setPendingDateChangeData(null)
      setDateChangeReason("")
    } catch {
      toast.error("Failed to save Opex")
    } finally {
      setIsSaving(false)
    }
  }

  const confirmDateChange = async () => {
    if (dateChangeReason.trim().length < 5)
      return toast.error("Please provide a valid reason")
    if (!pendingDateChangeData) return

    if (pendingDateChangeData.type === "capex") {
      await saveCapex(
        pendingDateChangeData.formData as CapexFormData,
        dateChangeReason
      )
    } else {
      await saveOpex(
        pendingDateChangeData.formData as OpexFormData,
        dateChangeReason
      )
    }
    setShowReasonDialog(false)
  }

  const confirmDelete = () => {
    if (!deleteTarget) return
    setIsDeleting(true)
    try {
      if (deleteType === "capex") deleteCapexBudget(deleteTarget)
      else deleteOpexBudget(deleteTarget)
      toast.success("Deleted successfully")
      setDeleteTarget(null)
    } catch {
      toast.error("Failed to delete")
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <div className="mt-6 space-y-8">
      {/* CAPEX Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg leading-none font-medium">CAPEX Tracker</h3>
          <Button onClick={() => openDialog("capex")} size="sm">
            <Plus className="mr-2 size-4" />
            Add CAPEX
          </Button>
        </div>

        <div className="overflow-x-auto rounded-md border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead className="text-right">Budget (CR)</TableHead>
                <TableHead className="text-right">Actual (CR)</TableHead>
                <TableHead className="text-right">Variance</TableHead>
                <TableHead>Comm. Date</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {capexItems.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    className="py-8 text-center text-muted-foreground"
                  >
                    No capex entries.
                  </TableCell>
                </TableRow>
              ) : (
                capexItems.map((c) => {
                  const capeLogs = dateChangeLogs.filter(
                    (l) =>
                      l.recordid === c.capexbudgetid &&
                      l.module === "capex" &&
                      l.fieldname === "commisiongdate"
                  )
                  const hasHistory = capeLogs.length > 0
                  return (
                    <TableRow key={c.capexbudgetid}>
                      <TableCell className="font-medium">{c.item}</TableCell>
                      <TableCell className="text-right tracking-tight">
                        {c.budgetcr.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right tracking-tight">
                        {c.actualcr.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right font-medium tracking-tight text-muted-foreground">
                        {(c.budgetcr - c.actualcr).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        {hasHistory ? (
                          <DateChangePopover logs={capeLogs}>
                            {c.commisiongdate}
                            <AlertTriangle className="size-3.5 text-amber-500" />
                          </DateChangePopover>
                        ) : (
                          c.commisiongdate
                        )}
                      </TableCell>
                      <TableCell>{getOwnerName(c.ownerorgnodeid)}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => openDialog("capex", c.capexbudgetid)}
                          >
                            <Pencil className="size-4 text-muted-foreground" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:bg-destructive/10"
                            onClick={() => {
                              setDeleteTarget(c.capexbudgetid)
                              setDeleteType("capex")
                            }}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
              {capexItems.length > 0 && (
                <TableRow className="border-t-2 bg-muted/50 font-bold">
                  <TableCell>Total CAPEX</TableCell>
                  <TableCell className="text-right">
                    {totalCapexBudget.toFixed(2)}
                  </TableCell>
                  <TableCell className="text-right">
                    {totalCapexActual.toFixed(2)}
                  </TableCell>
                  <TableCell className="text-right">
                    {(totalCapexBudget - totalCapexActual).toFixed(2)}
                  </TableCell>
                  <TableCell colSpan={3}></TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* OPEX Section */}
      <div className="space-y-4 border-t border-dashed pt-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg leading-none font-medium">OPEX Tracker</h3>
          <Button onClick={() => openDialog("opex")} size="sm">
            <Plus className="mr-2 size-4" />
            Add OPEX
          </Button>
        </div>

        <div className="overflow-x-auto rounded-md border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Item</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead className="text-right">Unit Cost (CR)</TableHead>
                <TableHead className="text-right">Target Cost (CR)</TableHead>
                <TableHead>Deadline</TableHead>
                <TableHead>Owner</TableHead>
                <TableHead className="w-[80px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {opexItems.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={7}
                    className="py-8 text-center text-muted-foreground"
                  >
                    No opex entries.
                  </TableCell>
                </TableRow>
              ) : (
                opexItems.map((o) => {
                  const opexLogs = dateChangeLogs.filter(
                    (l) =>
                      l.recordid === o.programmebudgetid &&
                      l.module === "opex" &&
                      l.fieldname === "deadline"
                  )
                  const hasHistory = opexLogs.length > 0
                  return (
                    <TableRow key={o.programmebudgetid}>
                      <TableCell className="font-medium">{o.item}</TableCell>
                      <TableCell>{o.supplier}</TableCell>
                      <TableCell className="text-right tracking-tight">
                        {o.unitcostcr.toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right tracking-tight">
                        {o.targetcostcr.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        {hasHistory ? (
                          <DateChangePopover logs={opexLogs}>
                            {o.deadline}
                            <AlertTriangle className="size-3.5 text-amber-500" />
                          </DateChangePopover>
                        ) : (
                          o.deadline
                        )}
                      </TableCell>
                      <TableCell>{getOwnerName(o.ownerorgnodeid)}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() =>
                              openDialog("opex", o.programmebudgetid)
                            }
                          >
                            <Pencil className="size-4 text-muted-foreground" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:bg-destructive/10"
                            onClick={() => {
                              setDeleteTarget(o.programmebudgetid)
                              setDeleteType("opex")
                            }}
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
              {opexItems.length > 0 && (
                <TableRow className="border-t-2 bg-muted/50 font-bold">
                  <TableCell colSpan={2}>Total OPEX</TableCell>
                  <TableCell className="text-right">
                    {totalOpexUnit.toFixed(2)}
                  </TableCell>
                  <TableCell className="text-right">
                    {totalOpexTarget.toFixed(2)}
                  </TableCell>
                  <TableCell colSpan={3}></TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Primary Add/Edit Dialog */}
      <Dialog modal={false} open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>
              {editingId ? "Edit" : "Add"} {dialogType.toUpperCase()}
            </DialogTitle>
            <DialogDescription className="sr-only">
              Budget details form
            </DialogDescription>
          </DialogHeader>

          {dialogType === "capex" ? (
            <form
              onSubmit={capexForm.handleSubmit(onSubmitCapex)}
              className="space-y-4 px-1 py-4"
            >
              <Field>
                <Label>Item</Label>
                <Input {...capexForm.register("item")} />
                {capexForm.formState.errors.item && (
                  <FieldError>
                    {capexForm.formState.errors.item.message}
                  </FieldError>
                )}
              </Field>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Budget (CR)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    {...capexForm.register("budgetcr")}
                  />
                  {capexForm.formState.errors.budgetcr && (
                    <FieldError>
                      {capexForm.formState.errors.budgetcr.message}
                    </FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Actual (CR)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    {...capexForm.register("actualcr")}
                  />
                  {capexForm.formState.errors.actualcr && (
                    <FieldError>
                      {capexForm.formState.errors.actualcr.message}
                    </FieldError>
                  )}
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Commissioning Date</Label>
                  <Controller
                    control={capexForm.control}
                    name="commisiongdate"
                    render={({ field }) => (
                      <DatePicker
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Pick date"
                      />
                    )}
                  />
                  {capexForm.formState.errors.commisiongdate && (
                    <FieldError>
                      {capexForm.formState.errors.commisiongdate.message}
                    </FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Owner (Org Node)</Label>
                  <Controller
                    control={capexForm.control}
                    name="ownerorgnodeid"
                    render={({ field }) => (
                      <Combobox
                        value={field.value}
                        onValueChange={field.onChange}
                        items={orgNodes.map((n) => n.programmeorgnodeid)}
                      >
                        <ComboboxInput placeholder="Select owner..." />
                        <ComboboxContent>
                          <ComboboxList>
                            {(id) => {
                              const n = orgNodes.find(
                                (x) => x.programmeorgnodeid === id
                              )
                              return (
                                <ComboboxItem key={id} value={id}>
                                  {n?.displayname}
                                </ComboboxItem>
                              )
                            }}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {capexForm.formState.errors.ownerorgnodeid && (
                    <FieldError>
                      {capexForm.formState.errors.ownerorgnodeid.message}
                    </FieldError>
                  )}
                </Field>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="outline">
                    Cancel
                  </Button>
                </DialogClose>
                <Button type="submit" disabled={isSaving}>
                  Save
                </Button>
              </DialogFooter>
            </form>
          ) : (
            <form
              onSubmit={opexForm.handleSubmit(onSubmitOpex)}
              className="space-y-4 px-1 py-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Item</Label>
                  <Input {...opexForm.register("item")} />
                  {opexForm.formState.errors.item && (
                    <FieldError>
                      {opexForm.formState.errors.item.message}
                    </FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Supplier</Label>
                  <Input {...opexForm.register("supplier")} />
                  {opexForm.formState.errors.supplier && (
                    <FieldError>
                      {opexForm.formState.errors.supplier.message}
                    </FieldError>
                  )}
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Unit Cost (CR)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    {...opexForm.register("unitcostcr")}
                  />
                  {opexForm.formState.errors.unitcostcr && (
                    <FieldError>
                      {opexForm.formState.errors.unitcostcr.message}
                    </FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Target Cost (CR)</Label>
                  <Input
                    type="number"
                    step="0.01"
                    {...opexForm.register("targetcostcr")}
                  />
                  {opexForm.formState.errors.targetcostcr && (
                    <FieldError>
                      {opexForm.formState.errors.targetcostcr.message}
                    </FieldError>
                  )}
                </Field>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <Label>Deadline</Label>
                  <Controller
                    control={opexForm.control}
                    name="deadline"
                    render={({ field }) => (
                      <DatePicker
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="Pick date"
                      />
                    )}
                  />
                  {opexForm.formState.errors.deadline && (
                    <FieldError>
                      {opexForm.formState.errors.deadline.message}
                    </FieldError>
                  )}
                </Field>
                <Field>
                  <Label>Owner</Label>
                  <Controller
                    control={opexForm.control}
                    name="ownerorgnodeid"
                    render={({ field }) => (
                      <Combobox
                        value={field.value}
                        onValueChange={field.onChange}
                        items={orgNodes.map((n) => n.programmeorgnodeid)}
                      >
                        <ComboboxInput placeholder="Select owner..." />
                        <ComboboxContent>
                          <ComboboxList>
                            {(id) => {
                              const n = orgNodes.find(
                                (x) => x.programmeorgnodeid === id
                              )
                              return (
                                <ComboboxItem key={id} value={id}>
                                  {n?.displayname}
                                </ComboboxItem>
                              )
                            }}
                          </ComboboxList>
                        </ComboboxContent>
                      </Combobox>
                    )}
                  />
                  {opexForm.formState.errors.ownerorgnodeid && (
                    <FieldError>
                      {opexForm.formState.errors.ownerorgnodeid.message}
                    </FieldError>
                  )}
                </Field>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="outline">
                    Cancel
                  </Button>
                </DialogClose>
                <Button type="submit" disabled={isSaving}>
                  Save
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Date Change Reason Dialog */}
      <Dialog
        open={showReasonDialog}
        onOpenChange={(open) => !open && setShowReasonDialog(false)}
      >
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Date Change Justification</DialogTitle>
            <DialogDescription>
              Please provide a reason to log this date modification.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {pendingDateChangeData?.changes.map((c, i) => (
              <div
                key={i}
                className="rounded-md border bg-muted/40 p-3 text-sm"
              >
                <strong>{c.field}:</strong>{" "}
                <span className="line-through opacity-70">{c.oldDate}</span>{" "}
                {" -> "}
                <span className="font-semibold text-primary">{c.newDate}</span>
              </div>
            ))}
            <div className="space-y-2">
              <Label>Reason</Label>
              <Textarea
                value={dateChangeReason}
                onChange={(e) => setDateChangeReason(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowReasonDialog(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDateChange}
              disabled={isSaving || dateChangeReason.trim().length < 5}
            >
              Confirm Change
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Budget Item?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={isDeleting}
            >
              Delete
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
