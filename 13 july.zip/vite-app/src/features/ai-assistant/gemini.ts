import type { ChatMessage } from "./types"

/**
 * The browser talks only to an authenticated application endpoint. The endpoint
 * owns the model provider key, authorization and data-access policy; no model
 * API key is ever exposed in the Vite bundle.
 */
const ASSISTANT_API_URL = import.meta.env.VITE_ASSISTANT_API_URL?.trim()

export const hasAssistantApi = Boolean(ASSISTANT_API_URL)

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(
      () =>
        reject(
          new Error(`Request timed out after ${timeoutMs / 1000} seconds`)
        ),
      timeoutMs
    )
    promise
      .then(resolve)
      .catch(reject)
      .finally(() => window.clearTimeout(timeoutId))
  })
}

export async function requestAssistantReply({
  history,
  systemContext,
  userText,
}: {
  history: ChatMessage[]
  systemContext: string
  userText: string
}): Promise<string> {
  if (!ASSISTANT_API_URL) {
    throw new Error(
      "AI replies require VITE_ASSISTANT_API_URL to be configured."
    )
  }

  const response = await withTimeout(
    fetch(ASSISTANT_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ history, systemContext, userText }),
    }),
    90_000
  )

  if (!response.ok) {
    throw new Error(`AI service request failed (${response.status}).`)
  }

  const payload: unknown = await response.json()
  if (!isAssistantResponse(payload)) {
    throw new Error("AI service returned an invalid response.")
  }

  return payload.reply
}

function isAssistantResponse(value: unknown): value is { reply: string } {
  return (
    typeof value === "object" &&
    value !== null &&
    "reply" in value &&
    typeof value.reply === "string"
  )
}
