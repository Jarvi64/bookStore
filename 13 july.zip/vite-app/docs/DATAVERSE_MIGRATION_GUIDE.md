# Production migration guide

## Current architecture

- `src/services/data/` has a typed asynchronous repository contract plus a development in-memory adapter and a Dataverse host-client adapter.
- `src/lib/validation.ts` contains shared validation primitives. UI validation gives fast feedback; repeat critical rules server-side.
- The Zustand store remains the single wireframe state source. It is deliberately not connected to a second repository source, which would risk divergent state.

## Migration sequence

1. Create/import the tables in [DATAVERSE_SCHEMA.md](DATAVERSE_SCHEMA.md), replacing `ada_` with the environment prefix.
2. Generate Code Apps typings and write a table-specific mapper. Pages must not use Dataverse logical column names directly.
3. Construct `DataverseRepository` with the authenticated Power Apps Code Apps/PCF Web API client. Never bundle connection strings, client secrets, or bearer tokens in Vite.
4. Replace one store slice at a time: load through its repository; await create/update/delete; update Zustand only after the returned Dataverse record is mapped and validated.
5. Move compound writes to a Dataverse transaction, custom API, plug-in or flow: weekly update + items, milestone cascade deletion, and date update + audit log.
6. Configure row-level security, table permissions, optimistic concurrency (ETags), `$select`/programme filters/paging, and tests before removing seed data.

## Mapper pattern

```ts
type DataverseMilestone = {
  ada_milestoneid: string
  ada_name: string
  ada_targetdate: string
}
type Milestone = {
  milestoneid: string
  name: string
  targetedcompletiondate: string
}

export const fromDataverseMilestone = (row: DataverseMilestone): Milestone => ({
  milestoneid: row.ada_milestoneid,
  name: row.ada_name,
  targetedcompletiondate: row.ada_targetdate,
})
```

## Security note

The app posts AI requests to `VITE_ASSISTANT_API_URL`. Implement that authenticated server, custom connector, or Power Automate endpoint with `POST { history, systemContext, userText }` and return `{ reply: string }`. Keep the model-provider key there and send the minimum necessary data. Do not make a Dataverse token or connection secret a `VITE_*` value.

## Deliberate scope boundary

The supply-chain table was left unchanged as requested. Migrate it using the same repository/mapper pattern once its requirements are approved.
