import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService, LineTvConfig } from '../data.service';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { CarouselComponent } from '../carousel/carousel.component';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-line-tv',
  standalone: true,
  imports: [CommonModule, DashboardComponent, CarouselComponent, RouterLink, MatIconModule],
  template: `
    @if (config()) {
      @if (config()!.mode === 'single' || config()!.mode === 'combined') {
        <app-dashboard [lineData]="computedData()" [forceAutoRotate]="true" [disableAutoRotate]="false" [isEmbedded]="true"></app-dashboard>
      } @else if (config()!.mode === 'carousel') {
        <app-carousel [workcenters]="workcenters()"></app-carousel>
      }
    } @else {
      <div class="h-screen w-screen flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400">
        <a routerLink="/" class="mb-8 w-16 h-16 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:border-indigo-300 dark:hover:border-indigo-700 shadow-sm transition-all hover:scale-105">
          <mat-icon class="scale-150">home</mat-icon>
        </a>
        <h2 class="text-3xl font-bold mb-4 text-slate-800 dark:text-slate-200">TV Dashboard Launcher</h2>
        <p class="text-lg">Select a configured line to launch the TV display.</p>
        <div class="mt-12 text-sm w-full max-w-md">
          <p class="font-semibold mb-4 text-slate-600 dark:text-slate-300 uppercase tracking-wider text-center">Available Displays</p>
          <ul class="flex flex-col gap-3">
            @for (c of availableConfigs(); track c.lineName) {
              <li>
                <a [routerLink]="[]" [queryParams]="{line: c.lineName}" class="text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-300 font-medium flex items-center gap-3 bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all hover:-translate-y-1 hover:shadow-md">
                  <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center">
                    <mat-icon>tv</mat-icon>
                  </div>
                  <div class="flex-1">
                    <div class="text-lg">{{ c.lineName }}</div>
                    <div class="text-slate-400 dark:text-slate-500 text-xs uppercase tracking-wider mt-0.5">{{ c.mode }} Mode</div>
                  </div>
                  <mat-icon class="text-slate-300 dark:text-slate-600">arrow_forward</mat-icon>
                </a>
              </li>
            }
          </ul>
        </div>
      </div>
    }
  `
})
export class LineTvComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private dataService = inject(DataService);

  config = signal<LineTvConfig | null>(null);
  availableConfigs = signal<LineTvConfig[]>(this.dataService.lineTvConfigs);

  workcenters = computed(() => {
    const cfg = this.config();
    if (!cfg) return [];
    return this.dataService.getWorkcentersByLine(cfg.lineName).map(l => l.workcenterName);
  });

  // We compute the data dynamically so it updates when the service updates
  computedData = computed(() => {
    const cfg = this.config();
    if (!cfg) return undefined;

    if (cfg.mode === 'single') {
      const wcs = this.dataService.getWorkcentersByLine(cfg.lineName);
      return wcs.length > 0 ? wcs[0] : undefined;
    } else if (cfg.mode === 'combined') {
      return this.dataService.getCombinedData(cfg.lineName);
    }
    return undefined;
  });

  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
      const lineParam = params.get('line');
      if (lineParam) {
        const foundConfig = this.dataService.lineTvConfigs.find(c => c.lineName === lineParam);
        this.config.set(foundConfig || null);
      } else {
        this.config.set(null);
      }

      if (params.has('theme')) {
        const isDark = params.get('theme') === 'dark';
        if (isDark) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    });
  }
}
