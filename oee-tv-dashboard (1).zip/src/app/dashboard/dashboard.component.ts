import { Component, inject, computed, ChangeDetectionStrategy, OnInit, OnDestroy, signal, input } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DataService } from '../data.service';
import { GaugeComponent } from '../components/gauge.component';
import { MetricCardComponent } from '../components/metric-card.component';
import { SpeedometerComponent } from '../components/speedometer.component';
import { AchievementCardComponent } from '../components/achievement-card.component';
import { ShiftTimelineComponent } from '../components/shift-timeline.component';
import { SparklineComponent } from '../components/sparkline.component';
import { MatIconModule } from '@angular/material/icon';
import { DatePipe, DecimalPipe } from '@angular/common';
import { LineHistory, LineData } from '../models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [GaugeComponent, MetricCardComponent, SpeedometerComponent, AchievementCardComponent, ShiftTimelineComponent, SparklineComponent, MatIconModule, DatePipe, DecimalPipe, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (line()) {
      @if (isAutoRotate()) {
        <div class="absolute top-0 left-0 right-0 h-1.5 bg-slate-200 dark:bg-slate-800 z-50">
          <div class="h-full bg-indigo-500 transition-all duration-75 ease-linear" [style.width.%]="rotateProgress()"></div>
        </div>
      }
      <div class="h-screen bg-slate-50 dark:bg-slate-950 p-6 flex flex-col gap-6 overflow-hidden transition-colors duration-500">
        <!-- Header -->
        <header class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between shrink-0 transition-colors duration-500">
          <div class="flex items-center gap-6">
            <a [routerLink]="isEmbedded() ? '/tv' : '/overview'" class="w-14 h-14 rounded-full bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 transition-colors">
              <mat-icon class="scale-125">arrow_back</mat-icon>
            </a>
            <div>
              <h1 class="text-4xl font-bold text-slate-900 dark:text-white tracking-tight">{{ line()!.lineName }}</h1>
              <div class="flex items-center gap-3 mt-2 text-slate-500 dark:text-slate-400 font-medium text-lg">
                <span class="flex items-center gap-1"><mat-icon class="text-[20px] w-[20px] h-[20px]">factory</mat-icon> {{ line()!.workcenterName }}</span>
                <span class="w-1.5 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700"></span>
                <span class="flex items-center gap-1"><mat-icon class="text-[20px] w-[20px] h-[20px]">inventory_2</mat-icon> {{ line()!.materialDesc }}</span>
              </div>
            </div>
          </div>
          
          <div class="flex items-center gap-8">
            <!-- Controls -->
            <div class="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-700">
              <button (click)="toggleDarkMode()" class="w-10 h-10 rounded-xl flex items-center justify-center transition-colors" [class]="isDarkMode() ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-500 hover:bg-slate-200 dark:text-slate-400 dark:hover:bg-slate-700'">
                <mat-icon>{{ isDarkMode() ? 'dark_mode' : 'light_mode' }}</mat-icon>
              </button>
              <button (click)="toggleView()" class="w-10 h-10 rounded-xl flex items-center justify-center transition-colors" [class]="currentView() !== 'main' ? 'bg-indigo-500 text-white shadow-md' : 'text-slate-500 hover:bg-slate-200 dark:text-slate-400 dark:hover:bg-slate-700'">
                <mat-icon>{{ isCombinedView() ? (currentView() === 'main' ? 'grid_view' : currentView() === 'workcenters' ? 'stacked_line_chart' : 'dashboard') : (currentView() === 'main' ? 'stacked_line_chart' : 'dashboard') }}</mat-icon>
              </button>
              @if (!disableAutoRotate()) {
                <button (click)="toggleAutoRotate()" class="w-10 h-10 rounded-xl flex items-center justify-center transition-colors relative" [class]="isAutoRotate() ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-500 hover:bg-slate-200 dark:text-slate-400 dark:hover:bg-slate-700'">
                  <mat-icon>{{ isAutoRotate() ? 'pause' : 'play_arrow' }}</mat-icon>
                  @if (isAutoRotate()) {
                    <span class="absolute -bottom-1 -right-1 flex h-3 w-3">
                      <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-200 opacity-75"></span>
                      <span class="relative inline-flex rounded-full h-3 w-3 bg-emerald-400 border-2 border-white dark:border-slate-800"></span>
                    </span>
                  }
                </button>
              }
            </div>

            <div class="w-px h-12 bg-slate-200 dark:bg-slate-700"></div>
            <div class="text-right">
              <div class="text-sm font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">Current Shift</div>
              <div class="text-3xl font-bold text-indigo-600 dark:text-indigo-400">Shift {{ currentShift() }}</div>
            </div>
            <div class="w-px h-12 bg-slate-200 dark:bg-slate-700"></div>
            <div class="text-right">
              <div class="text-sm font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">Local Time</div>
              <div class="text-3xl font-mono font-bold text-slate-700 dark:text-slate-200">{{ currentTime() | date:'HH:mm:ss' }}</div>
            </div>
          </div>
        </header>

        <!-- Status & Timeline Banner -->
        <div class="shrink-0">
          <app-shift-timeline
            [runTime]="line()!.runTime"
            [downtime]="line()!.downtimeMin"
            [isDown]="!!line()!.downtimeReason"
            [downtimeReason]="line()!.downtimeReason"
          ></app-shift-timeline>
        </div>

        @if (currentView() === 'main') {
          <!-- Main Content Grid -->
          <div class="flex-1 grid grid-cols-12 gap-6 min-h-0">
            
            <!-- Left Column: A, P, Q Gauges -->
            <div class="col-span-3 flex flex-col gap-6">
              <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex-1 flex flex-col items-center justify-center transition-colors duration-500">
                <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-4">Availability</h3>
                <app-gauge [value]="line()!.availabilityRate" [size]="180"></app-gauge>
              </div>
              <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex-1 flex flex-col items-center justify-center transition-colors duration-500">
                <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-4">Performance</h3>
                <app-gauge [value]="line()!.performanceRate" [size]="180"></app-gauge>
              </div>
              <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex-1 flex flex-col items-center justify-center transition-colors duration-500">
                <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-4">Quality</h3>
                <app-gauge [value]="line()!.qualityRate" [size]="180"></app-gauge>
              </div>
            </div>

            <!-- Center Column: Huge OEE -->
            <div class="col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center relative transition-colors duration-500">
              <h2 class="absolute top-8 left-8 text-2xl font-bold text-slate-700 dark:text-slate-200 tracking-tight">Overall Equipment Effectiveness</h2>
              <div class="flex-1 flex items-center justify-center w-full">
                <app-gauge [value]="line()!.oee" label="OEE" [size]="440"></app-gauge>
              </div>
            </div>

            <!-- Right Column: Horizontal KPI Cards & Speedometer -->
            <div class="col-span-4 flex flex-col gap-6">
              
              <!-- Speedometer -->
              <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex-1 flex flex-col items-center justify-center relative overflow-hidden min-h-[280px] transition-colors duration-500">
                <h3 class="absolute top-6 left-6 text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm z-10">Current Speed</h3>
                <div class="absolute top-6 right-6 text-slate-400 dark:text-slate-500">
                  <mat-icon>speed</mat-icon>
                </div>
                <div class="w-full h-full flex items-center justify-center mt-8">
                  <app-speedometer [value]="currentSpeed()" [max]="line()!.ppm"></app-speedometer>
                </div>
              </div>

              <!-- Achievement Card (combines Target and OK) -->
              <div class="flex-1 min-h-[200px]">
                <app-achievement-card
                  [target]="line()!.target"
                  [current]="line()!.okQty"
                ></app-achievement-card>
              </div>

              <!-- Defects Card -->
              <div class="shrink-0 h-[120px]">
                <app-metric-card 
                  title="Defects (NOK)" 
                  [value]="line()!.nokQty | number" 
                  icon="thumb_down" 
                  unit="pcs"
                  accentColor="rose"
                  [subtitle]="'Defect Rate: ' + ((line()!.nokQty / (line()!.okQty + line()!.nokQty)) * 100 | number:'1.1-2') + '%'"
                ></app-metric-card>
              </div>
            </div>

          </div>
        } @else if (currentView() === 'history') {
          <!-- History View -->
          <div class="flex-1 grid grid-cols-2 lg:grid-cols-4 auto-rows-fr gap-6 min-h-0 overflow-y-auto pb-6">
            <!-- OEE History -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">OEE Trend</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.oee | number:'1.1-1' }}%</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('oee')" color="#6366f1"></app-sparkline>
              </div>
            </div>
            <!-- Availability History -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">Availability Trend</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.availabilityRate | number:'1.1-1' }}%</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('availability')" color="#3b82f6"></app-sparkline>
              </div>
            </div>
            <!-- Performance History -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">Performance Trend</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.performanceRate | number:'1.1-1' }}%</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('performance')" color="#f59e0b"></app-sparkline>
              </div>
            </div>
            <!-- Quality History -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">Quality Trend</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.qualityRate | number:'1.1-1' }}%</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('quality')" color="#10b981"></app-sparkline>
              </div>
            </div>
            <!-- OK Qty -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">OK Parts (15m intervals)</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.okQty | number }}</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('okQty')" color="#10b981"></app-sparkline>
              </div>
            </div>
            <!-- NOK Qty -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">Defects (15m intervals)</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.nokQty | number }}</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('nokQty')" color="#f43f5e"></app-sparkline>
              </div>
            </div>
            <!-- Downtime -->
            <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col transition-colors duration-500">
              <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm mb-2">Downtime Minutes (15m intervals)</h3>
              <div class="text-3xl font-bold text-slate-800 dark:text-white mb-4">{{ line()!.downtimeMin }} min total</div>
              <div class="flex-1 min-h-[100px]">
                <app-sparkline [data]="getHistoryData('downtime')" color="#f43f5e"></app-sparkline>
              </div>
            </div>
          </div>
        } @else if (currentView() === 'workcenters') {
          <!-- Workcenters View -->
          <div class="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 min-h-0 overflow-y-auto pb-6">
            @for (wc of individualWorkcenters(); track wc.id) {
              <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col items-center justify-center transition-colors duration-500">
                <h3 class="text-xl font-bold text-slate-800 dark:text-white mb-2">{{ wc.workcenterName }}</h3>
                <div class="text-sm text-slate-500 dark:text-slate-400 mb-6">{{ wc.materialDesc }}</div>
                <app-gauge [value]="wc.oee" label="OEE" [size]="160"></app-gauge>
                <div class="grid grid-cols-3 gap-4 w-full mt-6 text-center">
                  <div>
                    <div class="text-xs text-slate-400 uppercase tracking-wider mb-1">Avail</div>
                    <div class="font-bold text-slate-700 dark:text-slate-300">{{ wc.availabilityRate | number:'1.0-1' }}%</div>
                  </div>
                  <div>
                    <div class="text-xs text-slate-400 uppercase tracking-wider mb-1">Perf</div>
                    <div class="font-bold text-slate-700 dark:text-slate-300">{{ wc.performanceRate | number:'1.0-1' }}%</div>
                  </div>
                  <div>
                    <div class="text-xs text-slate-400 uppercase tracking-wider mb-1">Qual</div>
                    <div class="font-bold text-slate-700 dark:text-slate-300">{{ wc.qualityRate | number:'1.0-1' }}%</div>
                  </div>
                </div>
              </div>
            }
          </div>
        }
      </div>
    } @else {
      <div class="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 transition-colors duration-500">
        <div class="text-slate-400 flex flex-col items-center gap-4">
          <mat-icon class="scale-[3]">error_outline</mat-icon>
          <p class="text-xl font-medium mt-4">Line not found</p>
          <a routerLink="/" class="text-indigo-500 hover:underline">Return to Overview</a>
        </div>
      </div>
    }
  `
})
export class DashboardComponent implements OnInit, OnDestroy {
  private route = inject(ActivatedRoute);
  private dataService = inject(DataService);
  
  lineId = input<string | null>(null);
  lineData = input<LineData | undefined>(undefined);
  isEmbedded = input<boolean>(false);
  disableAutoRotate = input<boolean>(false);
  forceAutoRotate = input<boolean>(false);

  currentLineId = signal<string | null>(null);
  currentTime = signal<Date>(new Date());
  isDarkMode = signal<boolean>(false);
  currentView = signal<'main' | 'history' | 'workcenters'>('main');
  isAutoRotate = signal<boolean>(false);
  rotateProgress = signal<number>(0);
  
  private timer: ReturnType<typeof setInterval> | undefined;
  private rotateInterval: ReturnType<typeof setInterval> | undefined;
  private rotateStartTime = 0;
  private readonly ROTATE_DURATION = 30000; // 30 seconds

  line = computed(() => {
    const providedData = this.lineData();
    if (providedData) return providedData;
    
    const id = this.lineId() || this.currentLineId();
    if (!id) return undefined;
    return this.dataService.getLine(id);
  });

  isCombinedView = computed(() => {
    const l = this.line();
    return l ? l.id.startsWith('combined-') : false;
  });

  individualWorkcenters = computed(() => {
    const l = this.line();
    if (!l || !this.isCombinedView()) return [];
    return this.dataService.getWorkcentersByLine(l.lineName);
  });

  currentSpeed = computed(() => {
    const l = this.line();
    if (!l || l.runTime === 0) return 0;
    return (l.okQty + l.nokQty) / l.runTime;
  });

  currentShift = computed(() => {
    const hours = this.currentTime().getHours();
    if (hours >= 6 && hours < 14) return 'A';
    if (hours >= 14 && hours < 22) return 'B';
    return 'C';
  });

  ngOnInit() {
    if (this.forceAutoRotate()) {
      this.setAutoRotate(true);
    }

    if (this.lineId()) {
      this.currentLineId.set(this.lineId());
    } else {
      this.route.paramMap.subscribe(params => {
        if (params.get('id')) {
          this.currentLineId.set(params.get('id'));
        }
      });
    }

    this.route.queryParamMap.subscribe(params => {
      // Only process theme/rotate if not embedded, or if embedded and we want to allow it
      if (!this.isEmbedded()) {
        if (params.has('theme')) {
          this.setDarkMode(params.get('theme') === 'dark');
        }
        if (params.has('rotate') && !this.disableAutoRotate()) {
          this.setAutoRotate(params.get('rotate') === 'true');
        }
      }
    });

    this.timer = setInterval(() => {
      this.currentTime.set(new Date());
    }, 1000);
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
    if (this.rotateInterval) clearInterval(this.rotateInterval);
  }

  setDarkMode(enabled: boolean) {
    this.isDarkMode.set(enabled);
    if (enabled) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }

  toggleDarkMode() {
    this.setDarkMode(!this.isDarkMode());
  }

  toggleView() {
    this.currentView.update(v => {
      if (this.isCombinedView()) {
        if (v === 'main') return 'workcenters';
        if (v === 'workcenters') return 'history';
        return 'main';
      } else {
        return v === 'main' ? 'history' : 'main';
      }
    });
  }

  setAutoRotate(enabled: boolean) {
    this.isAutoRotate.set(enabled);
    if (enabled) {
      if (!this.rotateInterval) {
        this.rotateProgress.set(0);
        this.rotateStartTime = Date.now();
        this.rotateInterval = setInterval(() => {
          const elapsed = Date.now() - this.rotateStartTime;
          if (elapsed >= this.ROTATE_DURATION) {
            this.toggleView();
            this.rotateStartTime = Date.now();
            this.rotateProgress.set(0);
          } else {
            this.rotateProgress.set((elapsed / this.ROTATE_DURATION) * 100);
          }
        }, 50);
      }
    } else {
      if (this.rotateInterval) {
        clearInterval(this.rotateInterval);
        this.rotateInterval = undefined;
      }
      this.rotateProgress.set(0);
    }
  }

  toggleAutoRotate() {
    this.setAutoRotate(!this.isAutoRotate());
  }

  getHistoryData(key: keyof LineHistory): number[] {
    const l = this.line();
    if (!l || !l.history) return [];
    return l.history.map(h => h[key] as number);
  }
}
