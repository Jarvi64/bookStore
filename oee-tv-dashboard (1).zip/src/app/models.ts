export interface LineHistory {
  time: string;
  oee: number;
  availability: number;
  performance: number;
  quality: number;
  okQty: number;
  nokQty: number;
  downtime: number;
}

export interface LineData {
  id: string;
  workcenterName: string;
  lineName: string;
  stage: number;
  stageName: string;
  ppm: number;
  target: number;
  okQty: number;
  nokQty: number;
  materialDesc: string;
  runTime: number;
  downtimeMin: number;
  downtimeReason: string | null;
  oee: number;
  qualityRate: number;
  performanceRate: number;
  availabilityRate: number;
  history: LineHistory[];
}
