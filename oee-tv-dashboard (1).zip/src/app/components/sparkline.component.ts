import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-sparkline',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <svg class="w-full h-full overflow-hidden" preserveAspectRatio="none" [attr.viewBox]="viewBox()">
      <defs>
        <linearGradient [id]="gradientId()" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" [attr.stop-color]="color()" stop-opacity="0.3"/>
          <stop offset="100%" [attr.stop-color]="color()" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <path [attr.d]="areaPath()" [attr.fill]="'url(#' + gradientId() + ')'" />
      <path [attr.d]="linePath()" fill="none" [attr.stroke]="color()" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
  `
})
export class SparklineComponent {
  data = input.required<number[]>();
  color = input<string>('#6366f1');
  id = input<string>(Math.random().toString(36).substring(2, 9));

  gradientId = computed(() => `sparkline-grad-${this.id()}`);

  minMax = computed(() => {
    const d = this.data();
    if (!d || !d.length) return { min: 0, max: 100 };
    const min = Math.min(...d);
    const max = Math.max(...d);
    return { min: min === max ? 0 : min, max: max === min ? max || 100 : max };
  });

  viewBox = computed(() => `-2 -2 104 44`);

  points = computed(() => {
    const d = this.data();
    if (!d || d.length < 2) return [];
    const { min, max } = this.minMax();
    const range = max - min || 1;
    return d.map((val, i) => {
      const x = (i / (d.length - 1)) * 100;
      const y = 40 - ((val - min) / range) * 40;
      return { x, y };
    });
  });

  linePath = computed(() => {
    const pts = this.points();
    if (!pts.length) return '';
    return `M ${pts.map(p => `${p.x},${p.y}`).join(' L ')}`;
  });

  areaPath = computed(() => {
    const pts = this.points();
    if (!pts.length) return '';
    const line = this.linePath();
    return `${line} L 100,40 L 0,40 Z`;
  });
}
