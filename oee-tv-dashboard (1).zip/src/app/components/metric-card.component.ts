import { Component, input, ChangeDetectionStrategy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-metric-card',
  standalone: true,
  imports: [MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex items-center justify-between h-full relative overflow-hidden transition-colors duration-500">
      <div class="flex items-center gap-5 z-10">
        <div class="w-16 h-16 rounded-2xl flex items-center justify-center shrink-0" [class]="iconBgClass()">
           <mat-icon class="scale-125" [class]="iconTextClass()">{{ icon() }}</mat-icon>
        </div>
        <div class="flex flex-col">
          <h3 class="text-slate-500 dark:text-slate-400 font-semibold tracking-wider uppercase text-sm">{{ title() }}</h3>
          @if (subtitle()) {
            <div class="text-sm text-slate-400 dark:text-slate-500 font-medium mt-1">{{ subtitle() }}</div>
          }
        </div>
      </div>
      <div class="flex items-baseline gap-2 z-10 text-right">
        <span class="text-5xl font-mono font-bold text-slate-800 dark:text-white tracking-tight">{{ value() }}</span>
        @if (unit()) {
          <span class="text-slate-400 dark:text-slate-500 font-medium text-lg">{{ unit() }}</span>
        }
      </div>
      <!-- Decorative accent line -->
      <div class="absolute left-0 top-0 bottom-0 w-2" [class]="accentClass()"></div>
    </div>
  `
})
export class MetricCardComponent {
  title = input.required<string>();
  value = input.required<string | number | null>();
  icon = input.required<string>();
  unit = input<string>();
  subtitle = input<string>();
  accentColor = input<'slate' | 'emerald' | 'rose' | 'amber' | 'blue'>('slate');

  get accentClass() {
    return () => {
      switch (this.accentColor()) {
        case 'emerald': return 'bg-emerald-500';
        case 'rose': return 'bg-rose-500';
        case 'amber': return 'bg-amber-500';
        case 'blue': return 'bg-blue-500';
        default: return 'bg-slate-400';
      }
    };
  }

  get iconBgClass() {
    return () => {
      switch (this.accentColor()) {
        case 'emerald': return 'bg-emerald-50 dark:bg-emerald-500/10';
        case 'rose': return 'bg-rose-50 dark:bg-rose-500/10';
        case 'amber': return 'bg-amber-50 dark:bg-amber-500/10';
        case 'blue': return 'bg-blue-50 dark:bg-blue-500/10';
        default: return 'bg-slate-50 dark:bg-slate-500/10';
      }
    };
  }

  get iconTextClass() {
    return () => {
      switch (this.accentColor()) {
        case 'emerald': return 'text-emerald-600 dark:text-emerald-400';
        case 'rose': return 'text-rose-600 dark:text-rose-400';
        case 'amber': return 'text-amber-600 dark:text-amber-400';
        case 'blue': return 'text-blue-600 dark:text-blue-400';
        default: return 'text-slate-600 dark:text-slate-400';
      }
    };
  }
}
