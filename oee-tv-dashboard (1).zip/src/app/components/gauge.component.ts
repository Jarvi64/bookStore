import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Component({
  selector: 'app-gauge',
  standalone: true,
  imports: [DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative flex items-center justify-center" [style.width.px]="size()" [style.height.px]="size()">
      <svg class="transform -rotate-90 w-full h-full">
        <circle
          class="text-slate-100 dark:text-slate-800 transition-colors duration-500"
          [attr.stroke-width]="strokeWidth()"
          stroke="currentColor"
          fill="transparent"
          [attr.r]="radius()"
          [attr.cx]="size() / 2"
          [attr.cy]="size() / 2"
        />
        <circle
          [class]="colorClass()"
          [attr.stroke-width]="strokeWidth()"
          [attr.stroke-dasharray]="circumference()"
          [attr.stroke-dashoffset]="strokeDashoffset()"
          stroke-linecap="round"
          stroke="currentColor"
          fill="transparent"
          [attr.r]="radius()"
          [attr.cx]="size() / 2"
          [attr.cy]="size() / 2"
          class="transition-all duration-1000 ease-out"
        />
      </svg>
      <div class="absolute flex flex-col items-center justify-center text-center">
        <span class="font-mono font-bold tracking-tighter" [style.font-size.px]="size() * 0.22" [class]="textColorClass()">
          {{ value() | number:'1.1-1' }}<span class="text-sm opacity-50">%</span>
        </span>
        @if (label()) {
          <span class="text-slate-500 font-medium uppercase tracking-wider mt-1" [style.font-size.px]="size() * 0.08">
            {{ label() }}
          </span>
        }
      </div>
    </div>
  `
})
export class GaugeComponent {
  value = input.required<number>();
  label = input<string>('');
  size = input<number>(200);
  
  strokeWidth = computed(() => Math.max(8, this.size() * 0.06));
  radius = computed(() => (this.size() - this.strokeWidth()) / 2);
  circumference = computed(() => this.radius() * 2 * Math.PI);
  strokeDashoffset = computed(() => this.circumference() - (this.value() / 100) * this.circumference());

  colorClass = computed(() => {
    const v = this.value();
    if (v >= 85) return 'text-emerald-500';
    if (v >= 70) return 'text-amber-500';
    return 'text-rose-500';
  });

  textColorClass = computed(() => {
    const v = this.value();
    if (v >= 85) return 'text-emerald-600 dark:text-emerald-400';
    if (v >= 70) return 'text-amber-600 dark:text-amber-400';
    return 'text-rose-600 dark:text-rose-400';
  });
}
