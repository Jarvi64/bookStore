import { Component, input, computed, ChangeDetectionStrategy } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-achievement-card',
  standalone: true,
  imports: [DecimalPipe, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-100 dark:border-slate-800 flex flex-col h-full relative overflow-hidden transition-colors duration-500">
      <div class="flex items-center justify-between z-10 mb-2">
        <div class="flex items-center gap-4">
          <div class="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center text-amber-500 shrink-0 shadow-inner border border-amber-100/50 dark:border-amber-500/20">
             <mat-icon class="scale-125">emoji_events</mat-icon>
          </div>
          <div>
            <h3 class="text-slate-500 dark:text-slate-400 font-bold tracking-wider uppercase text-sm">Production Target</h3>
            <div class="text-slate-400 dark:text-slate-500 font-medium text-sm mt-0.5">Shift Achievement</div>
          </div>
        </div>
        <div class="text-right">
          <span class="text-5xl font-mono font-bold text-slate-800 dark:text-white tracking-tight" [class.text-emerald-600]="percentage() >= 100" [class.dark:text-emerald-400]="percentage() >= 100">{{ percentage() | number:'1.1-1' }}</span>
          <span class="text-slate-400 dark:text-slate-500 font-bold text-xl ml-1">%</span>
        </div>
      </div>
      
      <div class="flex-1 flex flex-col justify-end z-10 mt-6">
        <!-- Progress Bar -->
        <div class="h-8 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden relative mb-4 shadow-inner border border-slate-200/50 dark:border-slate-700/50">
          <div class="absolute top-0 left-0 bottom-0 rounded-full transition-all duration-1000 ease-out flex items-center justify-end px-3"
               [class]="progressColorClass()"
               [style.width.%]="progressWidth()">
               <!-- Shine effect -->
               <div class="absolute top-0 left-0 right-0 h-1/2 bg-white opacity-20 rounded-t-full"></div>
               @if (progressWidth() > 15) {
                 <mat-icon class="text-white/70 scale-75">bolt</mat-icon>
               }
          </div>
        </div>
        
        <div class="flex justify-between items-end px-1">
          <div>
            <div class="text-sm text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-1">Produced (OK)</div>
            <div class="text-3xl font-mono font-bold text-emerald-600 dark:text-emerald-400">{{ current() | number }} <span class="text-base text-slate-400 dark:text-slate-500 font-medium">pcs</span></div>
          </div>
          <div class="text-right">
            <div class="text-sm text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-1">Target</div>
            <div class="text-3xl font-mono font-bold text-blue-600 dark:text-blue-400">{{ target() | number }} <span class="text-base text-slate-400 dark:text-slate-500 font-medium">pcs</span></div>
          </div>
        </div>
      </div>
      
      <!-- Decorative background element -->
      <mat-icon class="absolute -bottom-10 -right-10 text-[200px] text-slate-50 dark:text-slate-800 opacity-60 dark:opacity-40 z-0 rotate-12 pointer-events-none">emoji_events</mat-icon>
    </div>
  `
})
export class AchievementCardComponent {
  target = input.required<number>();
  current = input.required<number>();

  percentage = computed(() => {
    if (this.target() === 0) return 0;
    return (this.current() / this.target()) * 100;
  });

  progressWidth = computed(() => {
    return Math.min(100, this.percentage());
  });

  progressColorClass = computed(() => {
    const p = this.percentage();
    if (p >= 100) return 'bg-emerald-500';
    if (p >= 75) return 'bg-amber-400';
    return 'bg-blue-500';
  });
}
