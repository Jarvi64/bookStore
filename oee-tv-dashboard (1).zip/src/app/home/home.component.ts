import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, MatIconModule],
  template: `
    <div class="min-h-screen bg-[#0a0f16] text-slate-200 flex flex-col items-center justify-center relative overflow-hidden font-sans">
      <!-- Deep Background Gradient -->
      <div class="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-[#0a0f16] to-black opacity-80"></div>
      
      <!-- Thematic Background Elements -->
      <div class="absolute inset-0 z-0 opacity-[0.03] pointer-events-none flex items-center justify-center">
        <!-- Giant Crosshair SVG -->
        <svg viewBox="0 0 100 100" class="w-[80vw] h-[80vw] max-w-[800px] max-h-[800px] text-amber-500 animate-[spin_120s_linear_infinite]">
          <circle cx="50" cy="50" r="48" fill="none" stroke="currentColor" stroke-width="0.5" stroke-dasharray="2 4" />
          <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" stroke-width="0.2" />
          <circle cx="50" cy="50" r="20" fill="none" stroke="currentColor" stroke-width="0.5" stroke-dasharray="1 2" />
          <circle cx="50" cy="50" r="2" fill="currentColor" />
          <line x1="50" y1="0" x2="50" y2="40" stroke="currentColor" stroke-width="0.5" />
          <line x1="50" y1="60" x2="50" y2="100" stroke="currentColor" stroke-width="0.5" />
          <line x1="0" y1="50" x2="40" y2="50" stroke="currentColor" stroke-width="0.5" />
          <line x1="60" y1="50" x2="100" y2="50" stroke="currentColor" stroke-width="0.5" />
        </svg>
      </div>
      
      <!-- Grid Pattern -->
      <div class="absolute inset-0 z-0 opacity-10 pointer-events-none" style="background-image: linear-gradient(#334155 1px, transparent 1px), linear-gradient(90deg, #334155 1px, transparent 1px); background-size: 60px 60px; transform: perspective(500px) rotateX(60deg) translateY(-100px) translateZ(-200px);"></div>

      <div class="z-10 text-center max-w-5xl mx-auto px-6 w-full">
        <!-- Logo / Icon -->
        <div class="mb-10 relative inline-flex items-center justify-center">
          <div class="absolute inset-0 bg-amber-500/20 blur-2xl rounded-full"></div>
          <div class="relative w-28 h-28 rounded-full bg-gradient-to-b from-slate-800 to-slate-950 border border-slate-700 shadow-[0_0_50px_rgba(245,158,11,0.15)] flex items-center justify-center">
            <div class="absolute inset-1 rounded-full border border-slate-600/50"></div>
            <mat-icon class="text-6xl text-amber-500 w-16 h-16 flex items-center justify-center drop-shadow-[0_0_15px_rgba(245,158,11,0.5)]">precision_manufacturing</mat-icon>
          </div>
        </div>
        
        <h1 class="text-5xl md:text-7xl lg:text-8xl font-black tracking-tighter text-white mb-6 uppercase font-display">
          Ammunition <br/>
          <span class="text-transparent bg-clip-text bg-gradient-to-r from-amber-600 via-amber-400 to-amber-200 drop-shadow-sm">Manufacturing</span>
        </h1>
        
        <p class="text-lg md:text-xl text-slate-400 mb-20 max-w-2xl mx-auto font-light tracking-widest uppercase">
          Small Caliber Production Control & Monitoring System
        </p>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <!-- Plant Overview Button -->
          <a routerLink="/overview" class="group relative flex flex-col items-center p-12 bg-slate-900/40 backdrop-blur-md border border-slate-800/80 rounded-[2rem] hover:bg-slate-800/60 hover:border-amber-500/50 transition-all duration-700 overflow-hidden shadow-2xl">
            <!-- Hover Gradient -->
            <div class="absolute inset-0 bg-gradient-to-br from-amber-500/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            
            <!-- Corner Accents -->
            <div class="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-slate-700 group-hover:border-amber-500/50 transition-colors duration-500 rounded-tl-[2rem]"></div>
            <div class="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-slate-700 group-hover:border-amber-500/50 transition-colors duration-500 rounded-br-[2rem]"></div>
            
            <div class="w-24 h-24 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center mb-8 group-hover:scale-110 group-hover:border-amber-500/40 transition-all duration-500 shadow-xl relative z-10">
              <mat-icon class="text-5xl text-amber-400 w-12 h-12 flex items-center justify-center group-hover:drop-shadow-[0_0_10px_rgba(251,191,36,0.5)] transition-all duration-500">factory</mat-icon>
            </div>
            
            <h2 class="text-3xl font-bold text-white mb-4 tracking-tight relative z-10">Plant Overview</h2>
            <p class="text-slate-400 text-center text-base leading-relaxed relative z-10 font-light">
              Comprehensive view of all production lines, workcenters, and real-time OEE metrics.
            </p>
            
            <div class="mt-10 flex items-center text-amber-400 text-sm font-bold uppercase tracking-[0.2em] opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500 relative z-10">
              Enter Overview <mat-icon class="ml-3 text-base w-5 h-5 flex items-center justify-center">arrow_forward</mat-icon>
            </div>
          </a>

          <!-- TV Dashboard Button -->
          <a routerLink="/line-tv" class="group relative flex flex-col items-center p-12 bg-slate-900/40 backdrop-blur-md border border-slate-800/80 rounded-[2rem] hover:bg-slate-800/60 hover:border-indigo-500/50 transition-all duration-700 overflow-hidden shadow-2xl">
            <!-- Hover Gradient -->
            <div class="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            
            <!-- Corner Accents -->
            <div class="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-slate-700 group-hover:border-indigo-500/50 transition-colors duration-500 rounded-tr-[2rem]"></div>
            <div class="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-slate-700 group-hover:border-indigo-500/50 transition-colors duration-500 rounded-bl-[2rem]"></div>
            
            <div class="w-24 h-24 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border border-slate-700 flex items-center justify-center mb-8 group-hover:scale-110 group-hover:border-indigo-500/40 transition-all duration-500 shadow-xl relative z-10">
              <mat-icon class="text-5xl text-indigo-400 w-12 h-12 flex items-center justify-center group-hover:drop-shadow-[0_0_10px_rgba(129,140,248,0.5)] transition-all duration-500">tv</mat-icon>
            </div>
            
            <h2 class="text-3xl font-bold text-white mb-4 tracking-tight relative z-10">TV Dashboard</h2>
            <p class="text-slate-400 text-center text-base leading-relaxed relative z-10 font-light">
              Auto-cycling, high-visibility displays optimized for shop floor monitors and large screens.
            </p>
            
            <div class="mt-10 flex items-center text-indigo-400 text-sm font-bold uppercase tracking-[0.2em] opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all duration-500 relative z-10">
              Launch Display <mat-icon class="ml-3 text-base w-5 h-5 flex items-center justify-center">arrow_forward</mat-icon>
            </div>
          </a>
        </div>
      </div>
      
      <!-- Footer details -->
      <div class="absolute bottom-8 left-8 text-slate-600 text-xs font-mono uppercase tracking-widest flex items-center gap-3">
        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        System Active
      </div>
      <div class="absolute bottom-8 right-8 text-slate-600 text-xs font-mono uppercase tracking-widest">
        v2.4.1 • Secure Connection
      </div>
    </div>
  `
})
export class HomeComponent {}
