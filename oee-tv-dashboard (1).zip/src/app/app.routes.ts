import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { OverviewComponent } from './overview/overview.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CarouselComponent } from './carousel/carousel.component';
import { LineTvComponent } from './line-tv/line-tv.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'overview', component: OverviewComponent },
  { path: 'line/:id', component: DashboardComponent },
  { path: 'line-tv', component: LineTvComponent },
  { path: 'carousel', component: CarouselComponent },
  { path: '**', redirectTo: '' }
];
