import { Component, inject, computed, ChangeDetectionStrategy, OnInit, OnDestroy, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { DataService } from '../data.service';
import { MatIconModule } from '@angular/material/icon';
import { DatePipe, DecimalPipe } from '@angular/common';
import { LineData } from '../models';

interface StageGroup {
  stage: number;
  stageName: string;
  workcenters: LineData[];
}

interface LineFlow {
  lineName: string;
  stages: StageGroup[];
}

@Component({
  selector: 'app-overview',
  standalone: true,
  imports: [RouterLink, MatIconModule, DatePipe, DecimalPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-slate-50 p-6 flex flex-col gap-6 text-slate-900 font-sans selection:bg-indigo-500/30">
      
      <!-- Header -->
      <header class="bg-white/80 backdrop-blur-xl rounded-3xl p-6 border border-slate-200/80 flex items-center justify-between shadow-xl shadow-slate-200/50 relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-transparent to-transparent opacity-100"></div>
        
        <div class="flex items-center gap-6 relative z-10">
          <a routerLink="/" class="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 hover:border-indigo-200 transition-all shadow-sm">
            <mat-icon>home</mat-icon>
          </a>
          <div>
            <h1 class="text-3xl font-bold text-slate-900 tracking-tight font-display uppercase">Plant Schematic</h1>
            <p class="text-slate-500 font-medium mt-1 text-sm tracking-wide">Live Production Flow</p>
          </div>
        </div>
        
        <div class="flex items-center gap-8 relative z-10">
          <div class="text-right">
            <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Current Shift</div>
            <div class="text-2xl font-black text-indigo-600 font-display">SHIFT {{ currentShift() }}</div>
          </div>
          <div class="w-px h-12 bg-slate-200"></div>
          <div class="text-right">
            <div class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Local Time</div>
            <div class="text-2xl font-mono font-bold text-slate-700 tracking-tight">{{ currentTime() | date:'HH:mm:ss' }}</div>
          </div>
        </div>
      </header>

      <!-- Schematic Flow -->
      <div class="flex flex-col gap-8">
        @for (line of flowData(); track line.lineName; let lineIdx = $index) {
          <div class="bg-white/60 backdrop-blur-sm border border-slate-200 rounded-3xl p-8 relative overflow-hidden shadow-sm">
            
            <!-- Line Header -->
            <div class="flex items-center justify-between mb-12 relative z-10">
              <div class="flex items-center gap-4">
                <div class="w-10 h-10 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shadow-sm">
                  <mat-icon>account_tree</mat-icon>
                </div>
                <h2 class="text-2xl font-bold text-slate-800 font-display uppercase tracking-wider">{{ line.lineName }}</h2>
              </div>
              <a [routerLink]="['/line', 'combined-' + line.lineName]" class="flex items-center gap-2 text-sm font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-100 px-5 py-2.5 rounded-xl transition-all uppercase tracking-wider shadow-sm">
                <mat-icon class="scale-75">analytics</mat-icon>
                Line Dashboard
              </a>
            </div>

            <!-- Flow Diagram -->
            <div class="relative z-10 flex items-stretch justify-start gap-0 overflow-x-auto pb-6 pt-12 snap-x hide-scrollbar">
              
              @for (stage of line.stages; track stage.stage; let isLast = $last; let isFirst = $first) {
                <!-- Stage Column -->
                <div class="flex flex-col min-w-[280px] snap-start relative z-10 justify-center">
                  
                  <!-- Stage Label -->
                  <div class="absolute top-0 left-0 right-0 text-center -mt-10">
                    <div class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Stage {{ stage.stage }}</div>
                    <div class="text-sm font-bold text-slate-700 uppercase tracking-wider">{{ stage.stageName }}</div>
                  </div>

                  <!-- Workcenters in Parallel -->
                  <div class="flex flex-col gap-4 relative">
                    <!-- Left Bracket Vertical Line -->
                    @if (stage.workcenters.length > 1 && !isFirst) {
                      <div class="absolute -left-4 top-[80px] bottom-[80px] w-[2px] bg-slate-300 -z-10">
                        <!-- Animated dots splitting -->
                        <div class="absolute left-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-y-up_1.5s_linear_infinite]"></div>
                        <div class="absolute left-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-y-down_1.5s_linear_infinite]"></div>
                      </div>
                    }
                    <!-- Right Bracket Vertical Line -->
                    @if (stage.workcenters.length > 1 && !isLast) {
                      <div class="absolute -right-4 top-[80px] bottom-[80px] w-[2px] bg-slate-300 -z-10">
                        <!-- Animated dots combining -->
                        <div class="absolute left-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-y-combine-down_1.5s_linear_infinite]"></div>
                        <div class="absolute left-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-y-combine-up_1.5s_linear_infinite]"></div>
                      </div>
                    }

                    @for (wc of stage.workcenters; track wc.id) {
                      <div class="relative group">
                        <!-- Horizontal connector left -->
                        @if (!isFirst) {
                          <div class="absolute top-1/2 -left-4 w-4 h-[2px] bg-slate-300 -z-10">
                            <div class="absolute top-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-x_1.5s_linear_infinite]"></div>
                          </div>
                        }
                        <!-- Horizontal connector right -->
                        @if (!isLast) {
                          <div class="absolute top-1/2 -right-4 w-4 h-[2px] bg-slate-300 -z-10">
                            <div class="absolute top-[-2px] w-1.5 h-1.5 bg-slate-900 rounded-full animate-[flow-dot-x_1.5s_linear_infinite]"></div>
                          </div>
                        }
                        
                        <a [routerLink]="['/line', wc.id]" 
                           class="block bg-white rounded-2xl p-4 border transition-all relative overflow-hidden hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50 h-[160px] flex flex-col justify-between"
                         [class.border-slate-200]="!wc.downtimeReason && wc.oee >= 75"
                         [class.border-amber-300]="!wc.downtimeReason && wc.oee < 75"
                         [class.border-rose-300]="wc.downtimeReason"
                         [class.hover:border-indigo-300]="!wc.downtimeReason && wc.oee >= 75">
                        
                        <!-- Status Glow -->
                        <div class="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-500"
                             [class.bg-indigo-500]="!wc.downtimeReason && wc.oee >= 75"
                             [class.bg-amber-500]="!wc.downtimeReason && wc.oee < 75"
                             [class.bg-rose-500]="wc.downtimeReason"></div>

                        <!-- Top Row: Name & Status -->
                        <div class="flex items-start justify-between mb-3 relative z-10">
                          <div>
                            <h3 class="text-sm font-bold text-slate-800 truncate max-w-[160px]" [title]="wc.workcenterName">{{ wc.workcenterName }}</h3>
                            <p class="text-[10px] text-slate-500 font-medium uppercase tracking-wider mt-0.5 truncate max-w-[160px]" [title]="wc.materialDesc">{{ wc.materialDesc }}</p>
                          </div>
                          @if (wc.downtimeReason) {
                            <div class="w-6 h-6 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center animate-pulse shrink-0 border border-rose-200">
                              <mat-icon class="text-[16px] w-4 h-4">warning</mat-icon>
                            </div>
                          } @else {
                            <div class="w-2 h-2 rounded-full mt-1 shrink-0"
                                 [class.bg-emerald-500]="wc.oee >= 75"
                                 [class.shadow-[0_0_8px_rgba(16,185,129,0.4)]]="wc.oee >= 75"
                                 [class.bg-amber-500]="wc.oee < 75"
                                 [class.shadow-[0_0_8px_rgba(245,158,11,0.4)]]="wc.oee < 75"></div>
                          }
                        </div>

                        <!-- Metrics -->
                        <div class="flex items-end justify-between relative z-10">
                          <div>
                            <div class="text-[10px] text-slate-400 uppercase tracking-widest mb-0.5">OEE</div>
                            <div class="text-xl font-mono font-bold tracking-tighter"
                                 [class.text-emerald-600]="wc.oee >= 85"
                                 [class.text-amber-500]="wc.oee >= 70 && wc.oee < 85"
                                 [class.text-rose-500]="wc.oee < 70">
                              {{ wc.oee | number:'1.1-1' }}<span class="text-xs text-slate-400 ml-0.5">%</span>
                            </div>
                          </div>
                          <div class="text-right">
                            <div class="text-[10px] text-slate-400 uppercase tracking-widest mb-0.5">Output</div>
                            <div class="text-sm font-mono font-medium text-slate-700">
                              {{ wc.okQty | number }}
                            </div>
                          </div>
                        </div>
                        
                        @if (wc.downtimeReason) {
                           <div class="mt-3 text-[10px] font-bold text-rose-600 uppercase tracking-wider truncate bg-rose-50 px-2 py-1 rounded border border-rose-100 text-center">
                             {{ wc.downtimeReason }}
                           </div>
                        }
                      </a>
                      </div>
                    }
                  </div>
                </div>

                <!-- SVG Connection Line to Next Stage -->
                @if (!isLast) {
                  <div class="flex flex-col justify-center w-16 shrink-0 relative z-0 mx-1">
                    <svg width="100%" height="24" viewBox="0 0 64 24" class="overflow-visible">
                      <!-- Base Track -->
                      <line x1="0" y1="12" x2="64" y2="12" stroke="#cbd5e1" stroke-width="2" stroke-linecap="round" stroke-dasharray="4 4" />
                      
                      <!-- Animated Particle (Black) -->
                      <circle cy="12" r="3" fill="#0f172a">
                        <animate attributeName="cx" values="0;64" dur="1.5s" repeatCount="indefinite" />
                        <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.1;0.9;1" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                      
                      <!-- Connection Nodes -->
                      <circle cx="0" cy="12" r="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
                      <circle cx="64" cy="12" r="4" fill="#ffffff" stroke="#cbd5e1" stroke-width="2" />
                      <circle cx="0" cy="12" r="1.5" fill="#0f172a" />
                      <circle cx="64" cy="12" r="1.5" fill="#0f172a" />
                    </svg>
                  </div>
                }
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .hide-scrollbar::-webkit-scrollbar {
      display: none;
    }
    .hide-scrollbar {
      -ms-overflow-style: none;
      scrollbar-width: none;
    }
    @keyframes dash {
      0% { stroke-dashoffset: 200; }
      100% { stroke-dashoffset: 0; }
    }
  `]
})
export class OverviewComponent implements OnInit, OnDestroy {
  private dataService = inject(DataService);
  
  lines = this.dataService.lines;
  
  flowData = computed(() => {
    const allLines = this.lines();
    const lineMap = new Map<string, Map<number, StageGroup>>();
    
    // Group by Line -> Stage
    for (const wc of allLines) {
      if (!lineMap.has(wc.lineName)) {
        lineMap.set(wc.lineName, new Map());
      }
      
      const stagesMap = lineMap.get(wc.lineName)!;
      if (!stagesMap.has(wc.stage)) {
        stagesMap.set(wc.stage, {
          stage: wc.stage,
          stageName: wc.stageName,
          workcenters: []
        });
      }
      
      stagesMap.get(wc.stage)!.workcenters.push(wc);
    }
    
    // Convert to Array and sort
    const result: LineFlow[] = [];
    
    // Define the exact order of lines we want to display
    const lineOrder = ['Cup Line', 'Case Line', 'Priming Line', 'Sealing Line', 'Bullet Line', 'Loading Line'];
    
    for (const lineName of lineOrder) {
      if (lineMap.has(lineName)) {
        const stagesMap = lineMap.get(lineName)!;
        const stages = Array.from(stagesMap.values()).sort((a, b) => a.stage - b.stage);
        
        // Sort workcenters within a stage by name
        stages.forEach(s => s.workcenters.sort((a, b) => a.workcenterName.localeCompare(b.workcenterName)));
        
        result.push({
          lineName,
          stages
        });
      }
    }
    
    return result;
  });

  currentTime = signal<Date>(new Date());
  private timer: ReturnType<typeof setInterval> | undefined;

  currentShift = computed(() => {
    const hours = this.currentTime().getHours();
    if (hours >= 6 && hours < 14) return 'A';
    if (hours >= 14 && hours < 22) return 'B';
    return 'C';
  });

  ngOnInit() {
    this.timer = setInterval(() => {
      this.currentTime.set(new Date());
    }, 1000);
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }
}
