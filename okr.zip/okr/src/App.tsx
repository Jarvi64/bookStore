import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from '@/components/layout/app-layout';
import { ObjectivesPage } from '@/pages/objectives/ObjectivesPage';
import { LabelsSettingsPage } from '@/pages/settings/LabelsSettingsPage';
import { TeamsSettingsPage } from '@/pages/settings/TeamsSettingsPage';

/**
 * App — Root component with routing.
 * All routes are wrapped in AppLayout which provides sidebar + header.
 */
export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<AppLayout />}>
          {/* Default redirect to "My Objectives" */}
          <Route path="/" element={<Navigate to="/objectives/my" replace />} />

          {/* Objectives — same page component, different scope via URL */}
          <Route path="/objectives/my" element={<ObjectivesPage />} />
          <Route path="/objectives/team" element={<ObjectivesPage />} />
          <Route path="/objectives/department" element={<ObjectivesPage />} />
          <Route path="/objectives/company" element={<ObjectivesPage />} />
          <Route path="/objectives/all" element={<ObjectivesPage />} />

          {/* Settings */}
          <Route path="/settings/labels" element={<LabelsSettingsPage />} />
          <Route path="/settings/teams" element={<TeamsSettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
