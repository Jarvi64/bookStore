/**
 * ScorecardPage — Individual performance scorecard for any user.
 *
 * Shows a comprehensive OKR performance view including:
 * - User profile header with avatar, role, department, team
 * - Overall progress gauge (animated circular indicator)
 * - Status distribution chart (donut + breakdown)
 * - Objectives list with inline KR progress
 * - Key metrics summary cards
 *
 * URL: /scorecard/:userId (defaults to current user)
 */
import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import {
  Target,
  TrendingUp,
  ChevronDown,
  ChevronRight,
  Award,
  BarChart3,
  User as UserIcon,
  Building2,
  Users,
  Mail,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ObjectiveStatusBadge } from '@/components/objectives/objective-status-badge';
import { ObjectiveProgressBar } from '@/components/objectives/objective-progress-bar';
import { STATUS_CONFIG, OBJECTIVE_TYPE_CONFIG } from '@/lib/constants';
import { useObjectiveStore } from '@/store/objective.store';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { useUIStore } from '@/store/ui.store';
import { DUMMY_DEPARTMENTS } from '@/services/dummy/data/departments.data';
import { DUMMY_TEAMS } from '@/services/dummy/data/teams.data';
import type { Objective, KeyResult, ObjectiveStatus, User } from '@/models';

// ── Animation variants ──────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
  }),
};

// ── Animated circular gauge ─────────────────────────────────────────
function ScoreGauge({ value, size = 140, label }: { value: number; size?: number; label: string }) {
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (Math.min(value, 100) / 100) * circumference;
  const color =
    value >= 75 ? 'text-emerald-500' : value >= 50 ? 'text-amber-500' : value >= 25 ? 'text-orange-500' : 'text-red-500';

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke="currentColor" strokeWidth={strokeWidth}
          className="text-muted/30"
        />
        <motion.circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke="currentColor" strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeLinecap="round"
          className={color}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1.2, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.3 }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <motion.span
          className="text-3xl font-bold tabular-nums"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
        >
          {Math.round(value)}%
        </motion.span>
        <span className="text-[11px] text-muted-foreground font-medium">{label}</span>
      </div>
    </div>
  );
}

// ── Status donut chart ──────────────────────────────────────────────
function StatusDonut({ counts, total }: { counts: Record<ObjectiveStatus, number>; total: number }) {
  const statuses: ObjectiveStatus[] = ['on_track', 'at_risk', 'off_track', 'closed', 'no_status'];
  const colors: Record<ObjectiveStatus, string> = {
    on_track: '#10b981', at_risk: '#f59e0b', off_track: '#ef4444', closed: '#6b7280', no_status: '#a1a1aa',
  };
  const size = 100;
  const strokeWidth = 12;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  let accumulatedOffset = 0;

  return (
    <div className="flex items-center gap-5">
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="currentColor" strokeWidth={strokeWidth} className="text-muted/20" />
        {total > 0 && statuses.map((status) => {
          const count = counts[status] || 0;
          if (count === 0) return null;
          const segmentLength = (count / total) * circumference;
          const dashOffset = circumference - segmentLength;
          const rotation = (accumulatedOffset / circumference) * 360;
          accumulatedOffset += segmentLength;
          return (
            <motion.circle
              key={status} cx={size/2} cy={size/2} r={radius}
              fill="none" stroke={colors[status]} strokeWidth={strokeWidth}
              strokeDasharray={`${segmentLength} ${circumference - segmentLength}`}
              strokeLinecap="butt"
              style={{ transform: `rotate(${rotation}deg)`, transformOrigin: 'center' }}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.4 }}
            />
          );
        })}
      </svg>
      <div className="space-y-1.5">
        {statuses.map((status) => {
          const count = counts[status] || 0;
          if (count === 0) return null;
          const config = STATUS_CONFIG[status];
          return (
            <div key={status} className="flex items-center gap-2 text-xs">
              <span className={cn('size-2.5 rounded-full', config.dotColor)} />
              <span className="text-muted-foreground w-16">{config.label}</span>
              <span className="font-semibold tabular-nums">{count}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Expandable objective row with KRs ───────────────────────────────
function ScorecardObjectiveRow({
  objective, keyResults, index,
}: {
  objective: Objective; keyResults: KeyResult[]; index: number;
}) {
  const [expanded, setExpanded] = useState(false);
  const { setSelectedObjectiveId } = useUIStore();
  const typeConfig = OBJECTIVE_TYPE_CONFIG[objective.type];
  // Dynamic icon lookup — same pattern as ObjectiveTableRow
  const IconComponent =
    (LucideIcons[typeConfig.icon as keyof typeof LucideIcons] as React.ComponentType<{
      className?: string;
    }>) || LucideIcons.Target;

  return (
    <motion.div
      custom={index} variants={fadeUp} initial="hidden" animate="visible"
      className="group"
    >
      {/* Objective row */}
      <div
        className={cn(
          'flex items-center gap-3 px-4 py-3 rounded-lg transition-colors cursor-pointer',
          'hover:bg-muted/50',
          expanded && 'bg-muted/30',
        )}
        onClick={() => setSelectedObjectiveId(objective.id)}
      >
        {/* Expand icon */}
        <button 
          className="shrink-0 text-muted-foreground flex items-center justify-center size-6 rounded hover:bg-muted/60 transition-colors"
          onClick={(e) => {
            e.stopPropagation();
            setExpanded(!expanded);
          }}
        >
          {keyResults.length > 0 ? (
            expanded ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />
          ) : (
            <div className="size-4" />
          )}
        </button>

        {/* Type icon — matches the objectives table row style */}
        <div className={cn('shrink-0 flex items-center justify-center size-7 rounded-md', typeConfig.bgColor)}>
          <IconComponent className={cn('size-3.5', typeConfig.color)} />
        </div>

        {/* Title */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate">{objective.title}</p>
          <p className="text-[11px] text-muted-foreground">
            {objective.quarter} · {keyResults.length} key result{keyResults.length !== 1 ? 's' : ''}
          </p>
        </div>

        {/* Progress */}
        <div className="w-32 shrink-0">
          <ObjectiveProgressBar progress={objective.progress} status={objective.status} size="sm" />
        </div>

        {/* Status */}
        <ObjectiveStatusBadge status={objective.status} />
      </div>

      {/* Expanded KRs */}
      {expanded && keyResults.length > 0 && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="ml-12 mr-4 mb-2 space-y-0.5"
        >
          {keyResults.map((kr) => (
            <div
              key={kr.id}
              className="flex items-center gap-3 px-3 py-2 rounded-md text-sm hover:bg-muted/30 transition-colors"
            >
              <div className="size-1.5 rounded-full bg-primary/40 shrink-0" />
              <span className="flex-1 min-w-0 truncate text-muted-foreground">{kr.title}</span>
              <span className="text-xs tabular-nums text-muted-foreground shrink-0 w-20 text-right">
                {kr.currentValue} / {kr.targetValue}
              </span>
              <div className="w-24 shrink-0">
                <ObjectiveProgressBar progress={kr.progress} status={kr.status} size="sm" showLabel={false} />
              </div>
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 shrink-0">
                {kr.weight}%
              </Badge>
            </div>
          ))}
        </motion.div>
      )}
    </motion.div>
  );
}

// ── Metric card ─────────────────────────────────────────────────────
function MetricCard({
  icon: Icon, label, value, sub, color, index,
}: {
  icon: React.ElementType; label: string; value: string | number; sub?: string; color: string; index: number;
}) {
  return (
    <motion.div custom={index} variants={fadeUp} initial="hidden" animate="visible">
      <Card className="border-border/50 bg-card/80 backdrop-blur-sm hover:shadow-md transition-shadow">
        <CardContent className="p-4 flex items-start gap-3">
          <div className={cn('flex items-center justify-center size-10 rounded-lg', color)}>
            <Icon className="size-5" />
          </div>
          <div>
            <p className="text-2xl font-bold tabular-nums leading-none">{value}</p>
            <p className="text-xs text-muted-foreground mt-1">{label}</p>
            {sub && <p className="text-[10px] text-muted-foreground/70 mt-0.5">{sub}</p>}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

// ── Main page component ─────────────────────────────────────────────
export function ScorecardPage() {
  const { userId } = useParams<{ userId: string }>();
  const { objectives, isLoading, fetchObjectives } = useObjectiveStore();
  const { keyResults, fetchKeyResults } = useKeyResultStore();
  const { users, currentUser, fetchUsers, fetchCurrentUser } = useUserStore();
  const { fetchLabels } = useLabelStore();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  // Load data on mount
  useEffect(() => {
    fetchObjectives();
    fetchKeyResults();
    fetchUsers();
    fetchCurrentUser();
    fetchLabels();
  }, [fetchObjectives, fetchKeyResults, fetchUsers, fetchCurrentUser, fetchLabels]);

  // Determine which user to show
  useEffect(() => {
    if (userId) {
      setSelectedUserId(userId);
    } else if (currentUser && !selectedUserId) {
      setSelectedUserId(currentUser.id);
    }
  }, [userId, currentUser, selectedUserId]);

  const user = useMemo(
    () => users.find((u) => u.id === selectedUserId),
    [users, selectedUserId],
  );

  const department = useMemo(
    () => user ? DUMMY_DEPARTMENTS.find((d) => d.id === user.departmentId) : undefined,
    [user],
  );

  const team = useMemo(
    () => user ? DUMMY_TEAMS.find((t) => t.id === user.teamId) : undefined,
    [user],
  );

  // Filter objectives owned by this user
  const userObjectives = useMemo(
    () => objectives.filter((o) => o.ownerIds.includes(selectedUserId || '')),
    [objectives, selectedUserId],
  );

  // All KRs under the user's objectives (for display in the expandable rows)
  const krsByObjective = useMemo(() => {
    const objectiveIds = new Set(userObjectives.map((o) => o.id));
    const map = new Map<string, KeyResult[]>();
    for (const kr of keyResults) {
      if (objectiveIds.has(kr.objectiveId)) {
        const existing = map.get(kr.objectiveId) || [];
        existing.push(kr);
        map.set(kr.objectiveId, existing);
      }
    }
    return map;
  }, [keyResults, userObjectives]);

  // KRs personally owned by this user (for the metrics cards)
  const userOwnedKRs = useMemo(
    () => keyResults.filter((kr) => kr.ownerId === selectedUserId),
    [keyResults, selectedUserId],
  );

  // Total KRs across all the user's objectives (for display count)
  const allUserObjKRs = useMemo(
    () => Array.from(krsByObjective.values()).flat(),
    [krsByObjective],
  );

  // Overall progress
  const overallProgress = useMemo(() => {
    if (userObjectives.length === 0) return 0;
    const sum = userObjectives.reduce((acc, o) => acc + o.progress, 0);
    return Math.round((sum / userObjectives.length) * 10) / 10;
  }, [userObjectives]);

  // Status counts
  const statusCounts = useMemo(() => {
    const counts: Record<ObjectiveStatus, number> = {
      no_status: 0, on_track: 0, at_risk: 0, off_track: 0, closed: 0,
    };
    for (const o of userObjectives) counts[o.status]++;
    return counts;
  }, [userObjectives]);

  // KR completion rate
  const krCompletionRate = useMemo(() => {
    if (allUserObjKRs.length === 0) return 0;
    const completed = allUserObjKRs.filter((kr) => kr.progress >= 100).length;
    return Math.round((completed / allUserObjKRs.length) * 100);
  }, [allUserObjKRs]);

  // Average KR progress
  const avgKrProgress = useMemo(() => {
    if (allUserObjKRs.length === 0) return 0;
    return Math.round(allUserObjKRs.reduce((s, kr) => s + kr.progress, 0) / allUserObjKRs.length);
  }, [allUserObjKRs]);

  if (isLoading) return <ScorecardSkeleton />;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* ── User selector (when no userId in URL) ── */}
      {!userId && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Viewing scorecard for:</span>
          <Select value={selectedUserId || ''} onValueChange={setSelectedUserId}>
            <SelectTrigger className="w-64 h-9">
              <SelectValue placeholder="Select a person..." />
            </SelectTrigger>
            <SelectContent>
              {users.map((u) => (
                <SelectItem key={u.id} value={u.id}>
                  <span className="flex items-center gap-2">
                    <span>{u.name}</span>
                    <span className="text-muted-foreground text-xs capitalize">({u.role})</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </motion.div>
      )}

      {user && (
        <>
          {/* ── Profile header card ── */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Card className="overflow-hidden border-border/50">
              {/* Gradient banner */}
              <div className="h-24 bg-gradient-to-r from-primary/20 via-primary/10 to-violet-500/10 relative">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(var(--primary),0.15),transparent_70%)]" />
              </div>
              <CardContent className="px-6 pb-6 -mt-10">
                <div className="flex flex-col sm:flex-row items-start gap-5">
                  {/* Avatar */}
                  <Avatar className="size-20 ring-4 ring-background shadow-lg">
                    <AvatarImage src={user.avatar} alt={user.name} className="object-cover" />
                    <AvatarFallback className="text-xl font-bold bg-primary/10 text-primary">
                      {user.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>

                  {/* Info */}
                  <div className="flex-1 pt-2">
                    <h1 className="text-2xl font-bold tracking-tight">{user.name}</h1>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1.5 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <UserIcon className="size-3.5" />
                        <span className="capitalize">{user.role}</span>
                      </span>
                      {department && (
                        <span className="flex items-center gap-1.5">
                          <Building2 className="size-3.5" />
                          {department.name}
                        </span>
                      )}
                      {team && (
                        <span className="flex items-center gap-1.5">
                          <Users className="size-3.5" />
                          {team.name}
                        </span>
                      )}
                      <span className="flex items-center gap-1.5">
                        <Mail className="size-3.5" />
                        {user.email}
                      </span>
                    </div>
                  </div>

                  {/* Overall gauge */}
                  <div className="shrink-0 self-center">
                    <ScoreGauge value={overallProgress} label="Overall" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* ── Metric cards row ── */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <MetricCard
              icon={Target} label="Total Objectives"
              value={userObjectives.length}
              sub={`${statusCounts.closed} completed`}
              color="bg-primary/10 text-primary" index={0}
            />
            <MetricCard
              icon={BarChart3} label="Key Results"
              value={allUserObjKRs.length}
              sub={`${avgKrProgress}% avg progress`}
              color="bg-violet-500/10 text-violet-500" index={1}
            />
            <MetricCard
              icon={TrendingUp} label="On Track Rate"
              value={`${userObjectives.length > 0 ? Math.round((statusCounts.on_track / userObjectives.length) * 100) : 0}%`}
              sub={`${statusCounts.on_track} objectives`}
              color="bg-emerald-500/10 text-emerald-500" index={2}
            />
            <MetricCard
              icon={Award} label="KR Completion"
              value={`${krCompletionRate}%`}
              sub={`${allUserObjKRs.filter(kr => kr.progress >= 100).length} of ${allUserObjKRs.length} done`}
              color="bg-amber-500/10 text-amber-500" index={3}
            />
          </div>

          {/* ── Status distribution + objectives ── */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Status distribution */}
            <motion.div custom={5} variants={fadeUp} initial="hidden" animate="visible">
              <Card className="border-border/50 h-full">
                <CardContent className="p-5">
                  <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                    <BarChart3 className="size-4 text-muted-foreground" />
                    Status Distribution
                  </h3>
                  <StatusDonut counts={statusCounts} total={userObjectives.length} />
                </CardContent>
              </Card>
            </motion.div>

            {/* Objectives list */}
            <motion.div
              custom={6} variants={fadeUp} initial="hidden" animate="visible"
              className="lg:col-span-2"
            >
              <Card className="border-border/50">
                <CardContent className="p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold flex items-center gap-2">
                      <Target className="size-4 text-muted-foreground" />
                      Objectives & Key Results
                    </h3>
                    <Badge variant="secondary" className="text-xs">
                      {userObjectives.length} objective{userObjectives.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>

                  {userObjectives.length === 0 ? (
                    <div className="text-center py-10 text-muted-foreground text-sm">
                      No objectives assigned to this user.
                    </div>
                  ) : (
                    <div className="space-y-0.5 -mx-1">
                      {userObjectives.map((obj, i) => (
                        <ScorecardObjectiveRow
                          key={obj.id}
                          objective={obj}
                          keyResults={krsByObjective.get(obj.id) || []}
                          index={i}
                        />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      )}
    </div>
  );
}

// ── Loading skeleton ────────────────────────────────────────────────
function ScorecardSkeleton() {
  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="rounded-xl border overflow-hidden">
        <Skeleton className="h-24 w-full" />
        <div className="p-6 flex items-start gap-5">
          <Skeleton className="size-20 rounded-full" />
          <div className="space-y-2 flex-1">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-72" />
          </div>
          <Skeleton className="size-[140px] rounded-full" />
        </div>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
    </div>
  );
}
