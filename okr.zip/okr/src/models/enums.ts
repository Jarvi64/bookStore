/**
 * Enums and union types for the OKR application.
 * Centralized here so models, services, and components all share one source of truth.
 */

/** The 4 objective types that drive the cascading hierarchy */
export type ObjectiveType = 'individual' | 'team' | 'department' | 'company';

/** Status badges — determines the color-coded indicator */
export type ObjectiveStatus =
  | 'no_status'
  | 'on_track'
  | 'at_risk'
  | 'off_track'
  | 'closed';

/** How a key result or objective is measured */
export type MetricType = 'percent' | 'number' | 'currency';

/**
 * Ownership mode for multi-owner objectives.
 * - `shared`:     All owners collectively work toward ONE target
 * - `individual`: Each owner has their OWN copy of the target
 */
export type OwnershipMode = 'individual' | 'shared';

/** Objective visibility — controls who can see it */
export type Visibility = 'public' | 'private';

/** User role — determines what objective types the user can create */
export type UserRole = 'ceo' | 'manager' | 'member';

/** Predefined time period presets for objective date ranges */
export type TimePeriodPreset =
  | 'Q1'
  | 'Q2'
  | 'Q3'
  | 'Q4'
  | 'H1'
  | 'H2'
  | 'full_year'
  | 'custom';

/** View mode for the objectives list page */
export type ViewMode = 'list' | 'board';

/** Scope tab for filtering objectives by ownership level */
export type ScopeTab =
  | 'my_objectives'
  | 'my_team'
  | 'department'
  | 'company'
  | 'all';
