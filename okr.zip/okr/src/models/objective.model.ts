import type {
  MetricType,
  ObjectiveStatus,
  ObjectiveType,
  OwnershipMode,
  Visibility,
} from './enums';

/** Core Objective entity — the primary domain object of the OKR app */
export interface Objective {
  id: string;
  title: string;
  description: string | null;
  type: ObjectiveType;
  status: ObjectiveStatus;

  /** 0–100, auto-calculated from weighted children (KRs + sub-objectives) */
  progress: number;

  startDate: string; // ISO date string
  endDate: string; // ISO date string

  /** Display label e.g. "Q1 Jan-Mar 2026" */
  quarter: string;

  /** FK to parent objective for cascading. null = top-level */
  parentObjectiveId: string | null;

  /** FK(s) to User — supports multiple owners */
  ownerIds: string[];

  /** How multi-owner progress is tracked */
  ownershipMode: OwnershipMode;

  /** FK(s) to Label */
  labelIds: string[];

  /** FK to Team/Group */
  groupId: string | null;

  visibility: Visibility;
  commentsPrivate: boolean;

  /** Measurement configuration */
  metricType: MetricType;
  initialValue: number;
  targetValue: number;
  currentValue: number;

  /** Audit fields */
  createdBy: string; // FK to User
  createdAt: string; // ISO timestamp
  updatedAt: string; // ISO timestamp
}

/** DTO for creating a new objective — omits auto-generated fields */
export interface CreateObjectiveDTO {
  title: string;
  description?: string | null;
  type: ObjectiveType;
  startDate: string;
  endDate: string;
  quarter: string;
  parentObjectiveId?: string | null;
  ownerIds: string[];
  ownershipMode: OwnershipMode;
  labelIds?: string[];
  groupId?: string | null;
  visibility: Visibility;
  commentsPrivate?: boolean;
  metricType: MetricType;
  initialValue: number;
  targetValue: number;
}

/** DTO for updating an existing objective — all fields optional */
export interface UpdateObjectiveDTO {
  title?: string;
  description?: string | null;
  type?: ObjectiveType;
  status?: ObjectiveStatus;
  startDate?: string;
  endDate?: string;
  quarter?: string;
  parentObjectiveId?: string | null;
  ownerIds?: string[];
  ownershipMode?: OwnershipMode;
  labelIds?: string[];
  groupId?: string | null;
  visibility?: Visibility;
  commentsPrivate?: boolean;
  metricType?: MetricType;
  initialValue?: number;
  targetValue?: number;
  currentValue?: number;
}
