import { create } from 'zustand';
import type { Label, CreateLabelDTO } from '@/models';
import { labelService } from '@/services/service-registry';

interface LabelState {
  labels: Label[];
  isLoading: boolean;

  fetchLabels: () => Promise<void>;
  createLabel: (data: CreateLabelDTO) => Promise<Label>;
  updateLabel: (id: string, data: Partial<CreateLabelDTO>) => Promise<void>;
  deleteLabel: (id: string) => Promise<void>;
  getLabelById: (id: string) => Label | undefined;
}

export const useLabelStore = create<LabelState>((set, get) => ({
  labels: [],
  isLoading: false,

  fetchLabels: async () => {
    set({ isLoading: true });
    const labels = await labelService.getAll();
    set({ labels, isLoading: false });
  },

  createLabel: async (data) => {
    const created = await labelService.create(data);
    set({ labels: [...get().labels, created] });
    return created;
  },

  updateLabel: async (id, data) => {
    const updated = await labelService.update(id, data);
    set({
      labels: get().labels.map((l) => (l.id === id ? updated : l)),
    });
  },

  deleteLabel: async (id) => {
    await labelService.delete(id);
    set({ labels: get().labels.filter((l) => l.id !== id) });
  },

  getLabelById: (id) => get().labels.find((l) => l.id === id),
}));
