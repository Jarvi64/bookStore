import { create } from 'zustand';
import type { KeyResult, CreateKeyResultDTO, UpdateKeyResultDTO } from '@/models';
import { keyResultService } from '@/services/service-registry';

interface KeyResultState {
  keyResults: KeyResult[];
  isLoading: boolean;
  error: string | null;

  fetchKeyResults: () => Promise<void>;
  getByObjectiveId: (objectiveId: string) => KeyResult[];
  createKeyResult: (data: CreateKeyResultDTO) => Promise<KeyResult>;
  updateKeyResult: (id: string, data: UpdateKeyResultDTO) => Promise<void>;
  deleteKeyResult: (id: string) => Promise<void>;
  updateWeights: (objectiveId: string, weights: { id: string; weight: number }[]) => Promise<void>;
}

/**
 * Zustand store for Key Results.
 */
export const useKeyResultStore = create<KeyResultState>((set, get) => ({
  keyResults: [],
  isLoading: false,
  error: null,

  fetchKeyResults: async () => {
    set({ isLoading: true, error: null });
    try {
      const keyResults = await keyResultService.getAll();
      set({ keyResults, isLoading: false });
    } catch (e) {
      set({ error: (e as Error).message, isLoading: false });
    }
  },

  /** Synchronous getter — filters from already-fetched data */
  getByObjectiveId: (objectiveId) => {
    return get().keyResults.filter((kr) => kr.objectiveId === objectiveId);
  },

  createKeyResult: async (data) => {
    const created = await keyResultService.create(data);
    set({ keyResults: [...get().keyResults, created] });
    return created;
  },

  updateKeyResult: async (id, data) => {
    const updated = await keyResultService.update(id, data);
    set({
      keyResults: get().keyResults.map((kr) => (kr.id === id ? updated : kr)),
    });
  },

  deleteKeyResult: async (id) => {
    await keyResultService.delete(id);
    set({
      keyResults: get().keyResults.filter((kr) => kr.id !== id),
    });
  },

  updateWeights: async (objectiveId, weights) => {
    await keyResultService.updateWeights(objectiveId, weights);
    // Update local state
    const updatedKRs = get().keyResults.map((kr) => {
      const weightUpdate = weights.find((w) => w.id === kr.id);
      return weightUpdate ? { ...kr, weight: weightUpdate.weight } : kr;
    });
    set({ keyResults: updatedKRs });
  },
}));
