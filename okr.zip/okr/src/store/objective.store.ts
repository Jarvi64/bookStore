import { create } from 'zustand';
import type { Objective, CreateObjectiveDTO, UpdateObjectiveDTO, ObjectiveStatus } from '@/models';
import { objectiveService } from '@/services/service-registry';

interface ObjectiveState {
  /** All objectives loaded from the service */
  objectives: Objective[];
  /** Loading state */
  isLoading: boolean;
  /** Error message */
  error: string | null;

  // ---- Actions ----
  fetchObjectives: () => Promise<void>;
  createObjective: (data: CreateObjectiveDTO) => Promise<Objective>;
  updateObjective: (id: string, data: UpdateObjectiveDTO) => Promise<void>;
  deleteObjective: (id: string) => Promise<void>;
  updateStatus: (id: string, status: ObjectiveStatus) => Promise<void>;
  updateProgress: (id: string, currentValue: number) => Promise<void>;
}

/**
 * Zustand store for Objectives.
 * All data operations go through the service layer — making the Dataverse swap trivial.
 */
export const useObjectiveStore = create<ObjectiveState>((set, get) => ({
  objectives: [],
  isLoading: false,
  error: null,

  fetchObjectives: async () => {
    set({ isLoading: true, error: null });
    try {
      const objectives = await objectiveService.getAll();
      set({ objectives, isLoading: false });
    } catch (e) {
      set({ error: (e as Error).message, isLoading: false });
    }
  },

  createObjective: async (data) => {
    const created = await objectiveService.create(data);
    set({ objectives: [...get().objectives, created] });
    return created;
  },

  updateObjective: async (id, data) => {
    const updated = await objectiveService.update(id, data);
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },

  deleteObjective: async (id) => {
    await objectiveService.delete(id);
    set({
      objectives: get().objectives.filter((o) => o.id !== id),
    });
  },

  updateStatus: async (id, status) => {
    const updated = await objectiveService.update(id, { status });
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },

  updateProgress: async (id, currentValue) => {
    const objective = get().objectives.find((o) => o.id === id);
    if (!objective) return;

    const range = objective.targetValue - objective.initialValue;
    const progress =
      range === 0
        ? 0
        : Math.round(
            ((currentValue - objective.initialValue) / range) * 1000,
          ) / 10;

    const updated = await objectiveService.update(id, {
      currentValue,
      status:
        progress >= 100 ? 'closed' : objective.status === 'no_status' ? 'on_track' : undefined,
    });
    // Manually set progress since it's calculated
    updated.progress = progress;
    set({
      objectives: get().objectives.map((o) => (o.id === id ? updated : o)),
    });
  },
}));
