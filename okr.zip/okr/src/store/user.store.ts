import { create } from 'zustand';
import type { User } from '@/models';
import { userService } from '@/services/service-registry';

interface UserState {
  users: User[];
  currentUser: User | null;
  isLoading: boolean;

  fetchUsers: () => Promise<void>;
  fetchCurrentUser: () => Promise<void>;
  getUserById: (id: string) => User | undefined;
}

export const useUserStore = create<UserState>((set, get) => ({
  users: [],
  currentUser: null,
  isLoading: false,

  fetchUsers: async () => {
    set({ isLoading: true });
    const users = await userService.getAll();
    set({ users, isLoading: false });
  },

  fetchCurrentUser: async () => {
    const currentUser = await userService.getCurrentUser();
    set({ currentUser });
  },

  getUserById: (id) => get().users.find((u) => u.id === id),
}));
