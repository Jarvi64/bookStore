import { create } from 'zustand';
import type { ScopeTab, ViewMode, ObjectiveStatus } from '@/models';

/**
 * UI state store — controls view preferences, filters, and selected items.
 * Separate from domain stores to keep concerns clean.
 */
interface UIState {
  /** Currently active scope tab */
  activeTab: ScopeTab;
  /** List vs Board view */
  viewMode: ViewMode;
  /** Selected objective ID (for detail sheet) */
  selectedObjectiveId: string | null;
  /** History stack for navigating parent/child objectives in the detail sheet */
  objectiveHistory: string[];
  /** ID of the objective currently being edited in the form dialog */
  editingObjectiveId: string | null;
  /** Whether the create objective dialog is open */
  isCreateDialogOpen: boolean;
  /** Search query for filtering objectives */
  searchQuery: string;
  /** Status filter (null = show all) */
  statusFilter: ObjectiveStatus | null;
  /** Whether the sidebar is collapsed */
  sidebarCollapsed: boolean;
  /** Whether to show key results in the hierarchy views */
  showKeyResults: boolean;

  // ---- Actions ----
  setActiveTab: (tab: ScopeTab) => void;
  setViewMode: (mode: ViewMode) => void;
  setSelectedObjectiveId: (id: string | null, pushToHistory?: boolean) => void;
  goBackObjective: () => void;
  setEditingObjectiveId: (id: string | null) => void;
  setCreateDialogOpen: (open: boolean) => void;
  setSearchQuery: (query: string) => void;
  setStatusFilter: (status: ObjectiveStatus | null) => void;
  toggleSidebar: () => void;
  toggleShowKeyResults: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  activeTab: 'my_objectives',
  viewMode: 'list',
  selectedObjectiveId: null,
  objectiveHistory: [],
  editingObjectiveId: null,
  isCreateDialogOpen: false,
  searchQuery: '',
  statusFilter: null,
  sidebarCollapsed: false,
  showKeyResults: false,

  setActiveTab: (activeTab) => set({ activeTab }),
  setViewMode: (viewMode) => set({ viewMode }),
  setSelectedObjectiveId: (id, pushToHistory = false) =>
    set((state) => {
      // If closing the sheet, clear history
      if (!id) {
        return { selectedObjectiveId: null, objectiveHistory: [] };
      }
      
      // If pushing to history (e.g. clicking sub-objective inside the sheet)
      if (pushToHistory && state.selectedObjectiveId && state.selectedObjectiveId !== id) {
        return {
          selectedObjectiveId: id,
          objectiveHistory: [...state.objectiveHistory, state.selectedObjectiveId],
        };
      }
      
      // If just selecting a new objective from the outside, reset history
      return { selectedObjectiveId: id, objectiveHistory: [] };
    }),
  goBackObjective: () =>
    set((state) => {
      if (state.objectiveHistory.length === 0) return state;
      const newHistory = [...state.objectiveHistory];
      const previousId = newHistory.pop()!;
      return { selectedObjectiveId: previousId, objectiveHistory: newHistory };
    }),
  setEditingObjectiveId: (editingObjectiveId) => set({ editingObjectiveId }),
  setCreateDialogOpen: (isCreateDialogOpen) => set({ isCreateDialogOpen }),
  setSearchQuery: (searchQuery) => set({ searchQuery }),
  setStatusFilter: (statusFilter) => set({ statusFilter }),
  toggleSidebar: () =>
    set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
  toggleShowKeyResults: () =>
    set((state) => ({ showKeyResults: !state.showKeyResults })),
}));
