import { useNavigate } from 'react-router-dom';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { User } from '@/models';

interface UserAvatarProps {
  user: User | undefined;
  size?: 'sm' | 'md' | 'lg';
  showTooltip?: boolean;
  className?: string;
  interactive?: boolean;
}

/** Size classes — carefully tuned so initials never overflow */
const sizeClasses = {
  sm: 'size-6 text-[10px]',
  md: 'size-7 text-[11px]',
  lg: 'size-9 text-xs',
};

/** Colors for avatar fallbacks to make them less boring */
const fallbackColors = [
  'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-400',
  'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-400',
  'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400',
];

function getFallbackColor(id: string) {
  const index = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return fallbackColors[index % fallbackColors.length];
}

/**
 * Extracts max 2-char initials from a user's name.
 * "Benny Matteo" → "BM", "Alex" → "AL"
 */
function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
}

/**
 * UserAvatar — Compact circle with 2-char initials + tooltip.
 * Support images and better fallbacks.
 */
export function UserAvatar({
  user,
  size = 'sm',
  showTooltip = true,
  interactive = true,
  className,
}: UserAvatarProps) {
  const navigate = useNavigate();
  if (!user) return null;

  const initials = getInitials(user.name);
  const isUrl = user.avatar.startsWith('http') || user.avatar.startsWith('/');

  const avatar = (
    <Avatar
      onClick={(e) => {
        if (interactive) {
          e.stopPropagation();
          navigate(`/scorecard/${user.id}`);
        }
      }}
      className={cn(
        sizeClasses[size],
        'shrink-0 ring-1 ring-border',
        interactive && 'cursor-pointer hover:opacity-85 hover:ring-primary/40 transition-all',
        className,
      )}
    >
      {isUrl && <AvatarImage src={user.avatar} alt={user.name} className="object-cover" />}
      <AvatarFallback
        className={cn(
          'font-semibold leading-none',
          getFallbackColor(user.id),
          sizeClasses[size],
        )}
      >
        {initials}
      </AvatarFallback>
    </Avatar>
  );

  if (!showTooltip) return avatar;

  return (
    <Tooltip>
      <TooltipTrigger asChild>{avatar}</TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        {user.name}
      </TooltipContent>
    </Tooltip>
  );
}

interface UserAvatarGroupProps {
  users: (User | undefined)[];
  maxDisplay?: number;
  size?: 'sm' | 'md';
}

/**
 * UserAvatarGroup — Stacked avatar circles with "+N" overflow.
 */
export function UserAvatarGroup({
  users,
  maxDisplay = 3,
  size = 'sm',
}: UserAvatarGroupProps) {
  const validUsers = users.filter(Boolean) as User[];
  const displayed = validUsers.slice(0, maxDisplay);
  const remaining = validUsers.length - maxDisplay;

  return (
    <div className="flex items-center -space-x-1.5">
      {displayed.map((user) => (
        <UserAvatar key={user.id} user={user} size={size} className="ring-2 ring-background" />
      ))}
      {remaining > 0 && (
        <Tooltip>
          <TooltipTrigger asChild>
            <div
              className={cn(
                'flex items-center justify-center rounded-full border-2 border-background bg-muted text-muted-foreground font-semibold shrink-0',
                size === 'sm'
                  ? 'size-6 text-[9px]'
                  : 'size-7 text-[10px]',
              )}
            >
              +{remaining}
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            {validUsers
              .slice(maxDisplay)
              .map((u) => u.name)
              .join(', ')}
          </TooltipContent>
        </Tooltip>
      )}
    </div>
  );
}

