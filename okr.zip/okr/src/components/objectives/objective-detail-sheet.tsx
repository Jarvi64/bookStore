import { useState, useMemo } from 'react';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import {
  X,
  Pencil,
  Calendar,
  Eye,
  Clock,
  LinkIcon,
  GitBranch,
  GitFork,
  Plus,
} from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ObjectiveStatusBadge } from './objective-status-badge';
import { ObjectiveProgressBar } from './objective-progress-bar';
import { UserAvatarGroup } from '@/components/shared/user-avatar';
import { useObjectiveStore } from '@/store/objective.store';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { useUIStore } from '@/store/ui.store';
import { OBJECTIVE_TYPE_CONFIG, METRIC_TYPE_CONFIG } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { KeyResultFormDialog } from './key-result-form';
import { CommentsSection } from './comments-section';

/**
 * ObjectiveDetailSheet — Premium slide-over panel for viewing objective details.
 * Single-column layout optimized for the sheet's constrained width.
 */
export function ObjectiveDetailSheet() {
  const { selectedObjectiveId, setSelectedObjectiveId, setCreateDialogOpen, setEditingObjectiveId } = useUIStore();
  const { objectives } = useObjectiveStore();
  const { getByObjectiveId } = useKeyResultStore();
  const { getUserById } = useUserStore();
  const { labels } = useLabelStore();
  const [isAddKROpen, setIsAddKROpen] = useState(false);

  const objective = objectives.find((o) => o.id === selectedObjectiveId);
  const keyResults = objective ? getByObjectiveId(objective.id) : [];
  const subObjectives = objectives.filter(
    (o) => o.parentObjectiveId === objective?.id,
  );
  const parentObjective = objective?.parentObjectiveId
    ? objectives.find((o) => o.id === objective.parentObjectiveId)
    : null;

  const owners = useMemo(
    () => (objective?.ownerIds ?? []).map((id) => getUserById(id)),
    [objective?.ownerIds, getUserById],
  );

  const objectiveLabels = useMemo(
    () =>
      (objective?.labelIds ?? [])
        .map((id) => labels.find((l) => l.id === id))
        .filter(Boolean),
    [objective?.labelIds, labels],
  );

  if (!objective) {
    return (
      <Sheet
        open={!!selectedObjectiveId}
        onOpenChange={() => setSelectedObjectiveId(null)}
      >
        <SheetContent className="w-full max-w-[600px] p-0 sm:max-w-[600px] border-l shadow-2xl" side="right">
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            Objective not found
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  const typeConfig = OBJECTIVE_TYPE_CONFIG[objective.type];
  const metricConfig = METRIC_TYPE_CONFIG[objective.metricType];
  const IconComponent =
    (LucideIcons[typeConfig.icon as keyof typeof LucideIcons] as React.ComponentType<{
      className?: string;
    }>) || LucideIcons.Target;

  const hasChildren = keyResults.length > 0 || subObjectives.length > 0;

  return (
    <Sheet
      open={!!selectedObjectiveId}
      onOpenChange={() => setSelectedObjectiveId(null)}
    >
      <SheetContent
        className="w-full max-w-[600px] p-0 sm:max-w-[600px] [&>button]:hidden border-l shadow-2xl"
        side="right"
      >
        {/* ---- Sticky header ---- */}
        <div className="flex items-center justify-between px-5 py-3 border-b bg-card/80 backdrop-blur-sm sticky top-0 z-10">
          <div
            className={cn(
              'flex items-center gap-1.5 text-xs font-semibold',
              typeConfig.color,
            )}
          >
            <IconComponent className="size-3.5" />
            {typeConfig.label}
          </div>
          <div className="flex items-center gap-0.5">
            <Button 
              variant="ghost" 
              size="icon-sm" 
              className="size-7"
              onClick={() => {
                setEditingObjectiveId(objective.id);
                setCreateDialogOpen(true);
              }}
            >
              <Pencil className="size-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              className="size-7"
              onClick={() => setSelectedObjectiveId(null)}
            >
              <X className="size-3.5" />
            </Button>
          </div>
        </div>

        <ScrollArea className="h-[calc(100vh-48px)]">
          <div className="px-5 py-5 space-y-5">
            {/* ---- Title ---- */}
            <SheetHeader className="text-left p-0">
              <SheetTitle className="text-lg font-bold leading-tight tracking-tight text-foreground pr-4">
                {objective.title}
              </SheetTitle>
            </SheetHeader>

            {/* ---- Description ---- */}
            {objective.description && (
              <p className="text-sm text-muted-foreground leading-relaxed">
                {objective.description}
              </p>
            )}

            {/* ---- Metadata chips row ---- */}
            <div className="flex flex-wrap items-center gap-2">
              <ObjectiveStatusBadge status={objective.status} />
              <Badge variant="outline" className="text-[10px] font-medium gap-1 h-5">
                <Calendar className="size-3" />
                {objective.quarter}
              </Badge>
              <Badge variant="outline" className="text-[10px] font-medium gap-1 h-5 capitalize">
                <Eye className="size-3" />
                {objective.visibility}
              </Badge>
              {objectiveLabels.map((label) => (
                <Badge
                  key={label!.id}
                  variant="secondary"
                  className="text-[10px] font-medium px-2 py-0 h-5"
                  style={{
                    backgroundColor: `${label!.color}12`,
                    color: label!.color,
                    borderColor: `${label!.color}25`,
                  }}
                >
                  {label!.name}
                </Badge>
              ))}
            </div>

            {/* ---- Owners ---- */}
            <div className="flex items-center gap-3">
              <UserAvatarGroup users={owners} maxDisplay={4} size="sm" />
              <span className="text-xs text-muted-foreground">
                {owners
                  .filter(Boolean)
                  .map((u) => u!.name)
                  .slice(0, 2)
                  .join(', ')}
                {owners.length > 2 && ` +${owners.length - 2}`}
              </span>
            </div>

            {/* ---- Progress ---- */}
            <div className="rounded-lg border bg-muted/20 p-3 space-y-1.5">
              <ObjectiveProgressBar
                progress={objective.progress}
                status={objective.status}
                size="md"
              />
              {hasChildren ? (
                <p className="text-[10px] text-muted-foreground">
                  Progress calculated from key results & sub-objectives
                </p>
              ) : (
                <p className="text-[10px] text-muted-foreground">
                  {metricConfig.prefix}{objective.currentValue}{metricConfig.suffix} / {metricConfig.prefix}{objective.targetValue}{metricConfig.suffix}
                </p>
              )}
            </div>

            {/* ---- Parent objective ---- */}
            {parentObjective && (
              <button
                className="flex items-center gap-2 w-full text-left rounded-lg border px-3 py-2 text-xs hover:bg-accent/50 transition-colors"
                onClick={() => setSelectedObjectiveId(parentObjective.id)}
              >
                <LinkIcon className="size-3 text-muted-foreground shrink-0" />
                <span className="text-muted-foreground shrink-0">Parent:</span>
                <span className="font-medium line-clamp-1">{parentObjective.title}</span>
              </button>
            )}

            <Separator />

            {/* ---- Key Results ---- */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="flex items-center gap-1.5 text-sm font-semibold">
                  <GitBranch className="size-3.5 text-muted-foreground" />
                  Key results
                  {keyResults.length > 0 && (
                    <span className="text-muted-foreground font-normal text-xs">
                      ({keyResults.length})
                    </span>
                  )}
                </h3>
                <Button
                  variant="outline"
                  size="xs"
                  className="gap-1 h-6 text-[11px]"
                  onClick={() => setIsAddKROpen(true)}
                >
                  <Plus className="size-3" />
                  Add
                </Button>
              </div>

              {keyResults.length === 0 ? (
                <div className="rounded-lg border border-dashed py-6 text-center">
                  <p className="text-xs text-muted-foreground">
                    No key results yet
                  </p>
                </div>
              ) : (
                <div className="space-y-1.5">
                  {keyResults.map((kr, index) => {
                    const krOwner = getUserById(kr.ownerId);
                    return (
                      <motion.div
                        key={kr.id}
                        initial={{ opacity: 0, x: -4 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.04 }}
                        className="flex items-center gap-2.5 rounded-lg border px-3 py-2.5 hover:bg-accent/30 transition-colors"
                      >
                        <span className="text-[10px] font-mono text-muted-foreground bg-muted rounded px-1 py-0.5 shrink-0">
                          {kr.weight}%
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium line-clamp-2 leading-snug">{kr.title}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {krOwner?.name} · {format(new Date(kr.endDate), 'MMM d')}
                          </p>
                        </div>
                        <div className="w-16 shrink-0">
                          <ObjectiveProgressBar progress={kr.progress} status={kr.status} />
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* ---- Sub-objectives ---- */}
            {subObjectives.length > 0 && (
              <>
                <Separator />
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="flex items-center gap-1.5 text-sm font-semibold">
                      <GitFork className="size-3.5 text-muted-foreground" />
                      Sub-objectives
                      <span className="text-muted-foreground font-normal text-xs">
                        ({subObjectives.length})
                      </span>
                    </h3>
                  </div>
                  <div className="space-y-1.5">
                    {subObjectives.map((sub) => {
                      const subOwners = sub.ownerIds.map((id) => getUserById(id));
                      return (
                        <div
                          key={sub.id}
                          className="flex items-center gap-2.5 rounded-lg border px-3 py-2.5 hover:bg-accent/30 transition-colors cursor-pointer"
                          onClick={() => setSelectedObjectiveId(sub.id)}
                        >
                          <UserAvatarGroup users={subOwners} maxDisplay={2} />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium line-clamp-2 leading-snug">{sub.title}</p>
                            <p className="text-[10px] text-muted-foreground">
                              {format(new Date(sub.endDate), 'MMM d, yyyy')}
                            </p>
                          </div>
                          <div className="w-16 shrink-0">
                            <ObjectiveProgressBar progress={sub.progress} status={sub.status} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            )}

            <Separator />

            {/* ---- Comments ---- */}
            <CommentsSection objectiveId={objective.id} />

            {/* ---- Audit footer ---- */}
            <div className="flex items-center gap-3 pt-2 text-[10px] text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="size-2.5" />
                Created {format(new Date(objective.createdAt), 'MMM d, yyyy')}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="size-2.5" />
                Updated {format(new Date(objective.updatedAt), 'MMM d, yyyy')}
              </span>
            </div>
          </div>
        </ScrollArea>
      </SheetContent>

      {/* Key Result Form Dialog */}
      {objective && (
        <KeyResultFormDialog
          objectiveId={objective.id}
          defaultStartDate={objective.startDate}
          defaultEndDate={objective.endDate}
          open={isAddKROpen}
          onOpenChange={setIsAddKROpen}
        />
      )}
    </Sheet>
  );
}
