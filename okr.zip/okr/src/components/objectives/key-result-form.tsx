/* eslint-disable react-hooks/set-state-in-effect */
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Info } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { METRIC_TYPE_CONFIG, STATUS_CONFIG } from '@/lib/constants';
import { UserAvatar } from '@/components/shared/user-avatar';
import type { KeyResult, MetricType, ObjectiveStatus } from '@/models';
import { toast } from 'sonner';

interface KeyResultFormDialogProps {
  objectiveId: string;
  /** Start/end dates inherited from the parent objective */
  defaultStartDate: string;
  defaultEndDate: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  keyResult?: KeyResult | null;
}

/**
 * KeyResultFormDialog — Modal for adding a key result to an objective.
 * Includes title, description, owner, metric type, initial/target values.
 */
export function KeyResultFormDialog({
  objectiveId,
  defaultStartDate,
  defaultEndDate,
  open,
  onOpenChange,
  keyResult,
}: KeyResultFormDialogProps) {
  const { createKeyResult, updateKeyResult } = useKeyResultStore();
  const { users } = useUserStore();
  const isEditing = !!keyResult;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [weight, setWeight] = useState<number | ''>('');
  const [metricType, setMetricType] = useState<MetricType>('percent');
  const [initialValue, setInitialValue] = useState(0);
  const [targetValue, setTargetValue] = useState(100);
  const [currentValue, setCurrentValue] = useState(0);
  const [status, setStatus] = useState<ObjectiveStatus>('no_status');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (!open || !keyResult) return;

    setTitle(keyResult.title);
    setDescription(keyResult.description ?? '');
    setOwnerId(keyResult.ownerId);
    setWeight(keyResult.weight);
    setMetricType(keyResult.metricType);
    setInitialValue(keyResult.initialValue);
    setTargetValue(keyResult.targetValue);
    setCurrentValue(keyResult.currentValue);
    setStatus(keyResult.status);
  }, [keyResult, open]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setOwnerId('');
    setWeight('');
    setMetricType('percent');
    setInitialValue(0);
    setTargetValue(100);
    setCurrentValue(0);
    setStatus('no_status');
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error('Please enter a key result title');
      return;
    }
    if (!ownerId) {
      toast.error('Please select an owner');
      return;
    }

    setIsSubmitting(true);
    try {
      if (keyResult) {
        await updateKeyResult(keyResult.id, {
          title: title.trim(),
          description: description.trim() || null,
          ownerId,
          weight: weight === '' ? undefined : weight,
          metricType,
          initialValue,
          targetValue,
          currentValue,
          status,
          startDate: defaultStartDate,
          endDate: defaultEndDate,
        });
        toast.success('Key result updated');
      } else {
        await createKeyResult({
          title: title.trim(),
          description: description.trim() || undefined,
          objectiveId,
          ownerId,
          weight: weight === '' ? undefined : weight,
          metricType,
          initialValue,
          targetValue,
          startDate: defaultStartDate,
          endDate: defaultEndDate,
        });
        toast.success('Key result added');
      }
      resetForm();
      onOpenChange(false);
    } catch {
      toast.error(isEditing ? 'Failed to update key result' : 'Failed to add key result');
    } finally {
      setIsSubmitting(false);
    }
  };

  const selectedOwner = ownerId ? users.find(u => u.id === ownerId) : null;

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) resetForm();
        onOpenChange(v);
      }}
    >
      <DialogContent className="max-w-lg" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="text-base font-semibold">
            {isEditing ? 'Edit key result' : 'Add key result'}
          </DialogTitle>
        </DialogHeader>

        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-5 pt-2"
        >
          {/* Title */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Title</Label>
            <Input
              placeholder="e.g., Increase organic leads by 25%"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="text-sm h-10 bg-muted/30 border-muted"
              autoFocus
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <Label className="text-sm font-medium">Description (optional)</Label>
            <Textarea
              placeholder="What does success look like?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="text-sm resize-none bg-muted/30 border-muted"
            />
          </div>

          {/* Owner + Weight row */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2 space-y-1.5">
              <Label className="text-sm font-medium">Owner</Label>
              <Select value={ownerId} onValueChange={setOwnerId}>
                <SelectTrigger className="text-sm h-10 bg-muted/30 border-muted">
                  <SelectValue placeholder="Select owner">
                    {selectedOwner && (
                      <div className="flex items-center gap-2">
                        <UserAvatar user={selectedOwner} size="sm" showTooltip={false} className="size-5" />
                        <span>{selectedOwner.name}</span>
                      </div>
                    )}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {users.map((user) => (
                    <SelectItem key={user.id} value={user.id} className="text-sm">
                      <div className="flex items-center gap-2">
                        <UserAvatar user={user} size="sm" showTooltip={false} className="size-5" />
                        <span>{user.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-sm font-medium flex items-center gap-1">
                Weight
                <span className="text-muted-foreground text-[10px]" title="How much this KR contributes to the parent objective's progress. Leave blank for auto-distribution.">
                  <Info className="size-3 inline" />
                </span>
              </Label>
              <div className="relative">
                <Input
                  type="number"
                  min={0}
                  max={100}
                  placeholder="Auto"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value === '' ? '' : Number(e.target.value))}
                  className="h-10 text-sm pr-7 bg-muted/30 border-muted"
                />
                <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-medium">%</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Measurement */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Measurement</Label>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">
                  Metric
                </Label>
                <Select
                  value={metricType}
                  onValueChange={(v) => setMetricType(v as MetricType)}
                >
                  <SelectTrigger className="h-9 text-xs bg-muted/30 border-muted">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(METRIC_TYPE_CONFIG).map(([key, config]) => (
                      <SelectItem key={key} value={key}>
                        <span className="font-mono mr-1">{config.icon}</span>
                        {config.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">
                  Initial
                </Label>
                <Input
                  type="number"
                  value={initialValue}
                  onChange={(e) => setInitialValue(Number(e.target.value))}
                  className="h-9 text-xs bg-muted/30 border-muted"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">
                  Target
                </Label>
                <Input
                  type="number"
                  value={targetValue}
                  onChange={(e) => setTargetValue(Number(e.target.value))}
                  className="h-9 text-xs bg-muted/30 border-muted"
                />
              </div>
            </div>
            {isEditing && (
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">
                    Current
                  </Label>
                  <Input
                    type="number"
                    value={currentValue}
                    onChange={(e) => setCurrentValue(Number(e.target.value))}
                    className="h-9 text-xs bg-muted/30 border-muted"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-muted-foreground uppercase tracking-wider">
                    Status
                  </Label>
                  <Select
                    value={status}
                    onValueChange={(v) => setStatus(v as ObjectiveStatus)}
                  >
                    <SelectTrigger className="h-9 text-xs bg-muted/30 border-muted">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(STATUS_CONFIG).map(([key, config]) => (
                        <SelectItem key={key} value={key}>
                          {config.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                resetForm();
                onOpenChange(false);
              }}
              className="font-medium"
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="gap-1 font-bold shadow-sm shadow-primary/20"
            >
              <Plus className="size-3" />
              {isSubmitting
                ? isEditing ? 'Updating...' : 'Adding...'
                : isEditing ? 'Update key result' : 'Add key result'}
            </Button>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
