import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { METRIC_TYPE_CONFIG } from '@/lib/constants';
import type { MetricType } from '@/models';
import { toast } from 'sonner';

interface KeyResultFormDialogProps {
  objectiveId: string;
  /** Start/end dates inherited from the parent objective */
  defaultStartDate: string;
  defaultEndDate: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/**
 * KeyResultFormDialog — Modal for adding a key result to an objective.
 * Includes title, description, owner, metric type, initial/target values.
 */
export function KeyResultFormDialog({
  objectiveId,
  defaultStartDate,
  defaultEndDate,
  open,
  onOpenChange,
}: KeyResultFormDialogProps) {
  const { createKeyResult } = useKeyResultStore();
  const { users } = useUserStore();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ownerId, setOwnerId] = useState('');
  const [metricType, setMetricType] = useState<MetricType>('percent');
  const [initialValue, setInitialValue] = useState(0);
  const [targetValue, setTargetValue] = useState(100);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setOwnerId('');
    setMetricType('percent');
    setInitialValue(0);
    setTargetValue(100);
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error('Please enter a key result title');
      return;
    }
    if (!ownerId) {
      toast.error('Please select an owner');
      return;
    }

    setIsSubmitting(true);
    try {
      await createKeyResult({
        title: title.trim(),
        description: description.trim() || undefined,
        objectiveId,
        ownerId,
        metricType,
        initialValue,
        targetValue,
        startDate: defaultStartDate,
        endDate: defaultEndDate,
      });
      toast.success('Key result added');
      resetForm();
      onOpenChange(false);
    } catch {
      toast.error('Failed to add key result');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) resetForm();
        onOpenChange(v);
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base font-semibold">
            Add key result
          </DialogTitle>
        </DialogHeader>

        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 pt-2"
        >
          {/* Title */}
          <div className="space-y-1.5">
            <Label className="text-sm">Title</Label>
            <Input
              placeholder="e.g., Increase organic leads by 25%"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="text-sm"
              autoFocus
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <Label className="text-sm">Description (optional)</Label>
            <Textarea
              placeholder="What does success look like?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              className="text-sm resize-none"
            />
          </div>

          {/* Owner */}
          <div className="space-y-1.5">
            <Label className="text-sm">Owner</Label>
            <Select value={ownerId} onValueChange={setOwnerId}>
              <SelectTrigger className="text-sm">
                <SelectValue placeholder="Select owner" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Measurement */}
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label className="text-[11px] text-muted-foreground">
                Metric
              </Label>
              <Select
                value={metricType}
                onValueChange={(v) => setMetricType(v as MetricType)}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(METRIC_TYPE_CONFIG).map(([key, config]) => (
                    <SelectItem key={key} value={key}>
                      <span className="font-mono mr-1">{config.icon}</span>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-[11px] text-muted-foreground">
                Initial
              </Label>
              <Input
                type="number"
                value={initialValue}
                onChange={(e) => setInitialValue(Number(e.target.value))}
                className="h-8 text-xs"
              />
            </div>
            <div className="space-y-1">
              <Label className="text-[11px] text-muted-foreground">
                Target
              </Label>
              <Input
                type="number"
                value={targetValue}
                onChange={(e) => setTargetValue(Number(e.target.value))}
                className="h-8 text-xs"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                resetForm();
                onOpenChange(false);
              }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="gap-1"
            >
              <Plus className="size-3" />
              {isSubmitting ? 'Adding...' : 'Add key result'}
            </Button>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
