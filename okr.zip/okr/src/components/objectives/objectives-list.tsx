import { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { List, LayoutGrid, ArrowUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ProgressCircle } from '@/components/shared/progress-circle';
import { StatusSummaryCards } from './status-summary-cards';
import { ObjectiveTableRow, TABLE_GRID_CLASSES } from './objective-table-row';
import { ObjectiveCard } from './objective-card';
import { useObjectiveStore } from '@/store/objective.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUIStore } from '@/store/ui.store';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import type { Objective, ObjectiveStatus, ScopeTab } from '@/models';

/** Map route paths to scope tabs */
const ROUTE_TO_TAB: Record<string, ScopeTab> = {
  '/objectives/my': 'my_objectives',
  '/objectives/team': 'my_team',
  '/objectives/department': 'department',
  '/objectives/company': 'company',
};

/** Tab labels for header display */
const TAB_LABELS: Record<ScopeTab, string> = {
  my_objectives: 'My Objectives',
  my_team: 'My Team',
  department: 'Department',
  company: 'Company',
  all: 'All Objectives',
};

/**
 * ObjectivesList — Main container component for the Objectives page.
 *
 * Responsibilities:
 * 1. Reads the current route to determine the scope tab (my/team/dept/company/all)
 * 2. Applies a filtering pipeline: scope → search → status → sort
 * 3. Builds a tree of top-level objectives (parentObjectiveId === null)
 * 4. Renders either List (table) or Board (cards) view based on user preference
 * 5. Shows summary metrics: overall progress circle + status count cards
 *
 * The component does NOT fetch data — that's handled by ObjectivesPage.
 * It receives pre-fetched data from the Zustand stores.
 */
export function ObjectivesList() {
  const location = useLocation();
  const { objectives } = useObjectiveStore();
  const { users, currentUser } = useUserStore();
  const { labels } = useLabelStore();
  const { keyResults } = useKeyResultStore();
  const { viewMode, setViewMode, searchQuery, statusFilter, setStatusFilter } =
    useUIStore();

  const activeTab = ROUTE_TO_TAB[location.pathname] ?? 'all';

  // ---- Scope filter ----
  const scopedObjectives = useMemo(() => {
    switch (activeTab) {
      case 'my_objectives':
        return objectives.filter(
          (o) => currentUser && o.ownerIds.includes(currentUser.id),
        );
      case 'my_team': {
        const teamIds = currentUser?.teamId
          ? users.filter((u) => u.teamId === currentUser.teamId).map((u) => u.id)
          : [];
        return objectives.filter((o) =>
          o.ownerIds.some((id) => teamIds.includes(id)),
        );
      }
      case 'department': {
        const deptIds = currentUser
          ? users
              .filter((u) => u.departmentId === currentUser.departmentId)
              .map((u) => u.id)
          : [];
        return objectives.filter((o) =>
          o.ownerIds.some((id) => deptIds.includes(id)),
        );
      }
      case 'company':
        return objectives.filter((o) => o.type === 'company');
      default:
        return objectives;
    }
  }, [activeTab, objectives, currentUser, users]);

  // ---- Search filter ----
  const searchedObjectives = useMemo(() => {
    if (!searchQuery.trim()) return scopedObjectives;
    const q = searchQuery.toLowerCase();
    return scopedObjectives.filter((o) => {
      const ownerNames = o.ownerIds
        .map((id) => users.find((u) => u.id === id)?.name ?? '')
        .join(' ')
        .toLowerCase();
      return o.title.toLowerCase().includes(q) || ownerNames.includes(q);
    });
  }, [scopedObjectives, searchQuery, users]);

  // ---- Status filter ----
  const filteredObjectives = useMemo(() => {
    if (!statusFilter) return searchedObjectives;
    return searchedObjectives.filter((o) => o.status === statusFilter);
  }, [searchedObjectives, statusFilter]);

  // ---- Top-level only (children render inside their parent rows) ----
  const topLevelObjectives = useMemo(
    () =>
      filteredObjectives.filter(
        (o) =>
          !o.parentObjectiveId ||
          !filteredObjectives.some((p) => p.id === o.parentObjectiveId),
      ),
    [filteredObjectives],
  );

  // ---- Status counts ----
  const statusCounts = useMemo(() => {
    const c: Record<ObjectiveStatus, number> = {
      no_status: 0,
      on_track: 0,
      at_risk: 0,
      off_track: 0,
      closed: 0,
    };
    searchedObjectives.forEach((o) => c[o.status]++);
    return c;
  }, [searchedObjectives]);

  // ---- Overall progress ----
  const overallProgress = useMemo(() => {
    if (searchedObjectives.length === 0) return 0;
    return (
      Math.round(
        (searchedObjectives.reduce((s, o) => s + o.progress, 0) /
          searchedObjectives.length) *
          10,
      ) / 10
    );
  }, [searchedObjectives]);

  // ---- Handlers ----
  const { setSelectedObjectiveId, showKeyResults, toggleShowKeyResults } = useUIStore();
  const handleSelect = (id: string) => setSelectedObjectiveId(id);
  const handleEdit = (id: string) => setSelectedObjectiveId(id);
  const handleDelete = async (id: string) => {
    await useObjectiveStore.getState().deleteObjective(id);
  };

  // ---- Resolvers ----
  const getOwners = (obj: Objective) =>
    obj.ownerIds.map((id) => users.find((u) => u.id === id));
  const getLabels = (obj: Objective) =>
    obj.labelIds.map((id) => labels.find((l) => l.id === id));
  const getChildCount = (obj: Objective) =>
    objectives.filter((o) => o.parentObjectiveId === obj.id).length;
  const getChildObjectives = (obj: Objective) =>
    objectives.filter((o) => o.parentObjectiveId === obj.id);

  return (
    <div className="space-y-5">
      {/* ---- Page header ---- */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <ProgressCircle value={overallProgress} size={52} strokeWidth={4} />
          <div>
            <h1 className="text-lg font-semibold tracking-tight">
              {TAB_LABELS[activeTab]}
            </h1>
            <p className="text-xs text-muted-foreground">
              {searchedObjectives.length} objective
              {searchedObjectives.length !== 1 ? 's' : ''} ·{' '}
              {Math.round(overallProgress)}% overall progress
            </p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          {/* Key Results Toggle */}
          <div className="flex items-center gap-2">
            <Switch
              id="show-krs-toggle"
              checked={showKeyResults}
              onCheckedChange={toggleShowKeyResults}
              className="scale-75 data-[state=checked]:bg-primary"
            />
            <Label htmlFor="show-krs-toggle" className="text-xs font-medium text-muted-foreground cursor-pointer">
              Show Key Results
            </Label>
          </div>

          {/* View toggle */}
          <div className="flex items-center rounded-lg border bg-card p-0.5">
          <Button
            variant={viewMode === 'list' ? 'secondary' : 'ghost'}
            size="icon-xs"
            onClick={() => setViewMode('list')}
            aria-label="List view"
          >
            <List className="size-3.5" />
          </Button>
          <Button
            variant={viewMode === 'board' ? 'secondary' : 'ghost'}
            size="icon-xs"
            onClick={() => setViewMode('board')}
            aria-label="Board view"
          >
            <LayoutGrid className="size-3.5" />
          </Button>
        </div>
        </div>
      </div>

      {/* ---- Status filter cards ---- */}
      <StatusSummaryCards
        counts={statusCounts}
        activeFilter={statusFilter}
        onFilterClick={setStatusFilter}
      />

      <div className="border-t" />

      {/* ---- Content ---- */}
      <AnimatePresence mode="wait">
        {viewMode === 'list' ? (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            {/* Table header — uses SAME grid template as rows */}
            <div
              className={cn(
                TABLE_GRID_CLASSES,
                'py-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground border-b bg-muted/30 rounded-t-lg',
              )}
            >
              <span /> {/* expand */}
              <span /> {/* type */}
              <span>Owner</span>
              <span className="flex items-center gap-1 cursor-pointer hover:text-foreground transition-colors">
                Title
                <ArrowUpDown className="size-3" />
              </span>
              <span>Labels</span>
              <span className="text-center">Progress</span>
              <span>Status</span>
              <span className="text-right">Period</span>
              <span /> {/* actions */}
            </div>

            {/* Rows */}
            <div className="rounded-b-lg border border-t-0 bg-card overflow-hidden">
              {topLevelObjectives.length === 0 ? (
                <EmptyState />
              ) : (
                topLevelObjectives.map((obj) => (
                  <ObjectiveTableRow
                    key={obj.id}
                    objective={obj}
                    childCount={getChildCount(obj)}
                    childObjectives={getChildObjectives(obj)}
                    owners={getOwners(obj)}
                    labels={getLabels(obj)}
                    onSelect={handleSelect}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                    allObjectives={objectives}
                    allUsers={users}
                    allLabels={labels}
                    allKeyResults={keyResults}
                  />
                ))
              )}
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="board"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="flex flex-row flex-wrap items-start justify-center gap-12 p-8"
          >
            {topLevelObjectives.length === 0 ? (
              <EmptyState />
            ) : (
              topLevelObjectives.map((obj, i) => (
                <ObjectiveCard
                  key={obj.id}
                  objective={obj}
                  allObjectives={objectives}
                  allUsers={users}
                  allLabels={labels}
                  allKeyResults={keyResults}
                  onSelect={handleSelect}
                  index={i}
                  level={0}
                />
              ))
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/** Empty state */
function EmptyState() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 text-center"
    >
      <div className="mb-3 flex size-12 items-center justify-center rounded-full bg-muted">
        <List className="size-5 text-muted-foreground" />
      </div>
      <h3 className="text-sm font-medium">No objectives found</h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Try adjusting your filters or create a new objective
      </p>
    </motion.div>
  );
}
