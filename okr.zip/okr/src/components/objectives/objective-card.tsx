import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import * as LucideIcons from 'lucide-react';
import { GitFork, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { OBJECTIVE_TYPE_CONFIG } from '@/lib/constants';
import { ObjectiveStatusBadge } from './objective-status-badge';
import { ObjectiveProgressBar } from './objective-progress-bar';
import { UserAvatarGroup } from '@/components/shared/user-avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import type { Objective, Label, User } from '@/models';

interface ObjectiveCardProps {
  objective: Objective;
  allObjectives: Objective[];
  allUsers: User[];
  allLabels: Label[];
  onSelect: (id: string) => void;
  index: number;
  level?: number;
}

/**
 * ObjectiveCard — Board view card with consistent height.
 * Uses flex-col with justify-between so all cards align regardless of content length.
 */
export function ObjectiveCard({
  objective,
  allObjectives,
  allUsers,
  allLabels,
  onSelect,
  index,
  level = 0,
}: ObjectiveCardProps) {
  const [isExpanded, setIsExpanded] = useState(level < 1);
  const typeConfig = OBJECTIVE_TYPE_CONFIG[objective.type];
  const IconComponent =
    (LucideIcons[typeConfig.icon as keyof typeof LucideIcons] as React.ComponentType<{
      className?: string;
    }>) || LucideIcons.Target;
  
  const childObjectives = allObjectives.filter(o => o.parentObjectiveId === objective.id);
  const childCount = childObjectives.length;
  
  const owners = objective.ownerIds.map(id => allUsers.find(u => u.id === id));
  const labels = objective.labelIds.map(id => allLabels.find(l => l.id === id));
  const validLabels = labels.filter(Boolean) as Label[];

  return (
    <div className="flex flex-col items-center">
      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: index * 0.04, duration: 0.3 }}
        className="relative z-20 w-[340px]"
      >
        <Card
          className={cn(
            "group flex cursor-pointer flex-col transition-all duration-200 hover:shadow-xl hover:border-primary/30 bg-card border-muted/60",
            level === 0 ? "shadow-md" : "shadow-sm",
          )}
          onClick={() => onSelect(objective.id)}
        >
          <CardContent className="flex flex-1 flex-col p-5">
            {/* Top — type */}
            <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider mb-4">
              <div className={cn("p-1.5 rounded-md", typeConfig.bgColor)}>
                <IconComponent className={cn("size-4", typeConfig.color)} />
              </div>
              <span className="text-muted-foreground">{typeConfig.label}</span>
            </div>

            {/* Title */}
            <h3 className="text-sm font-bold leading-snug mb-4 line-clamp-2 min-h-[2.5rem]">
              {objective.title}
            </h3>

            {/* Progress */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <div className="h-2 flex-1 bg-muted rounded-full overflow-hidden mr-3">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${objective.progress}%` }}
                    className={cn(
                      "h-full rounded-full",
                      objective.status === 'at_risk' ? "bg-amber-500" : 
                      objective.status === 'off_track' ? "bg-destructive" : "bg-primary"
                    )}
                  />
                </div>
                <span className="text-xs font-bold tabular-nums">{objective.progress}%</span>
              </div>
            </div>

            {/* Footer — avatars + date + status */}
            <div className="flex items-center justify-between pt-4 border-t border-border/40">
              <div className="flex items-center gap-2">
                <UserAvatarGroup users={owners} maxDisplay={3} />
                <span className="text-[10px] font-semibold text-muted-foreground">
                  {format(new Date(objective.endDate), 'MMM d, yyyy')}
                </span>
              </div>
              <ObjectiveStatusBadge status={objective.status} />
            </div>

            {/* Last Updated */}
            <div className="mt-3 text-right">
              <span className="text-[9px] text-muted-foreground/60 italic">Last updated yesterday</span>
            </div>

            {/* Labels */}
            {validLabels.length > 0 ? (
              <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-border/40 border-dashed">
                {validLabels.map((label) => (
                  <Badge
                    key={label.id}
                    variant="outline"
                    className="text-[9px] font-semibold px-2 py-0 h-5 rounded-md border-muted-foreground/20"
                    style={{ backgroundColor: `${label.color}08`, color: label.color }}
                  >
                    {label.name}
                  </Badge>
                ))}
              </div>
            ) : (
              <div className="mt-3 pt-3 border-t border-border/40 border-dashed">
                <span className="text-[9px] text-muted-foreground/30 italic">No labels</span>
              </div>
            )}
          </CardContent>

          {/* Expansion Button at Bottom Center */}
          {childCount > 0 && (
            <div className="absolute left-1/2 -bottom-3.5 -translate-x-1/2 z-30">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className={cn(
                  "flex items-center justify-center gap-1.5 h-7 px-2.5 rounded-md text-[10px] font-bold transition-all shadow-md",
                  isExpanded 
                    ? "bg-violet-700 text-white" 
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
              >
                <GitFork className="size-3" />
                {childCount}
              </button>
            </div>
          )}
        </Card>
      </motion.div>

      {/* Tree Connections and Children */}
      <AnimatePresence>
        {isExpanded && childCount > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-col items-center w-full"
          >
            {/* Vertical Line down from parent */}
            <div className="h-10 w-px bg-border/80" />
            
            {/* Horizontal Line across children */}
            {childCount > 1 && (
              <div className="relative w-full flex justify-center">
                <div className="absolute top-0 h-px bg-border/80 w-[calc(100%-340px)]" />
              </div>
            )}

            {/* Children Row */}
            <div className="flex flex-row gap-8 pt-0">
              {childObjectives.map((child, i) => (
                <div key={child.id} className="flex flex-col items-center">
                  {/* Vertical Line down to child */}
                  <div className="h-8 w-px bg-border/80" />
                  
                  <ObjectiveCard
                    objective={child}
                    allObjectives={allObjectives}
                    allUsers={allUsers}
                    allLabels={allLabels}
                    onSelect={onSelect}
                    index={i}
                    level={level + 1}
                  />
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
