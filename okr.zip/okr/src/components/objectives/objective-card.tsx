import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useUIStore } from '@/store/ui.store';
import { ObjectiveStatusBadge } from './objective-status-badge';
import * as LucideIcons from 'lucide-react';
import { GitFork } from 'lucide-react';
import { cn } from '@/lib/utils';
import { OBJECTIVE_TYPE_CONFIG } from '@/lib/constants';
import { UserAvatarGroup } from '@/components/shared/user-avatar';
import { ProgressCircle } from '@/components/shared/progress-circle';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import type { Objective, Label, User, KeyResult } from '@/models';

/**
 * Props for ObjectiveCard — a recursive card component in the Board view.
 *
 * The card renders itself for the given objective, then recursively
 * renders child ObjectiveCards for any sub-objectives. This creates
 * a cascading tree visualization with connector lines.
 */
interface ObjectiveCardProps {
  /** The objective to render */
  objective: Objective;
  /** Full list of all objectives (needed to find children recursively) */
  allObjectives: Objective[];
  /** Full list of all users (needed to resolve owner avatars) */
  allUsers: User[];
  /** Full list of all labels (needed to render label badges) */
  allLabels: Label[];
  /** Callback when a card is clicked (opens the detail sheet) */
  onSelect: (id: string) => void;
  /** Position index for staggered animation delay */
  index: number;
  /** Tree depth level — controls initial expansion and card sizing */
  level?: number;
  /** Full list of all key results (needed to render KR rows) */
  allKeyResults: KeyResult[];
}

/**
 * ObjectiveCard — Recursive card component for the Board/Grid view.
 *
 * Renders an objective as a premium card with:
 * - Type icon and label (Company/Department/Team/Individual)
 * - Status badge and progress bar
 * - Owner avatar group
 * - Expandable children tree with branching connector lines
 *
 * At level 0, children are auto-expanded. Deeper levels start collapsed
 * and show a fork button with child count at the bottom center.
 */
export function ObjectiveCard({
  objective,
  allObjectives,
  allUsers,
  allLabels,
  onSelect,
  index,
  level = 0,
  allKeyResults,
}: ObjectiveCardProps) {
  const [isExpanded, setIsExpanded] = useState(level < 1);
  const typeConfig = OBJECTIVE_TYPE_CONFIG[objective.type];
  const IconComponent =
    (LucideIcons[typeConfig.icon as keyof typeof LucideIcons] as React.ComponentType<{
      className?: string;
    }>) || LucideIcons.Target;
  
  const childObjectives = allObjectives.filter(o => o.parentObjectiveId === objective.id);
  
  // Sort child objectives by type: company → department → team → individual
  const TYPE_SORT_ORDER: Record<string, number> = {
    company: 0, department: 1, team: 2, individual: 3,
  };
  const sortedChildren = [...childObjectives].sort(
    (a, b) => (TYPE_SORT_ORDER[a.type] ?? 9) - (TYPE_SORT_ORDER[b.type] ?? 9),
  );

  const { showKeyResults } = useUIStore();
  const objectiveKRs = showKeyResults
    ? allKeyResults.filter(kr => kr.objectiveId === objective.id)
    : [];
  const childCount = sortedChildren.length;
  const totalExpandable = childCount + objectiveKRs.length;
  
  const owners = objective.ownerIds.map(id => allUsers.find(u => u.id === id));
  const labels = objective.labelIds.map(id => allLabels.find(l => l.id === id));
  const validLabels = labels.filter(Boolean) as Label[];

  return (
    <div className="flex flex-col items-center">
      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: index * 0.04, duration: 0.3 }}
        className="relative z-20 w-[280px]"
      >
        <Card
          className={cn(
            "group flex cursor-pointer flex-col transition-all duration-200 hover:shadow-xl hover:border-primary/30 bg-card border-muted/60 min-h-[140px]",
            level === 0 ? "shadow-md" : "shadow-sm",
          )}
          onClick={() => onSelect(objective.id)}
        >
          <CardContent className="flex flex-col p-4 gap-3">
            {/* Header: Type and Progress */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider">
                <div className={cn("p-1.5 rounded-md", typeConfig.bgColor)}>
                  <IconComponent className={cn("size-3.5", typeConfig.color)} />
                </div>
                <span className="text-muted-foreground">{typeConfig.label}</span>
              </div>
              <ProgressCircle
                value={objective.progress}
                size={36}
                strokeWidth={4}
                className={
                  objective.status === 'at_risk' ? 'text-amber-500' :
                  objective.status === 'off_track' ? 'text-destructive' :
                  objective.status === 'closed' ? 'text-muted-foreground' : 'text-emerald-500'
                }
              />
            </div>

            {/* Title */}
            <h3 className="text-sm font-semibold leading-snug line-clamp-3">
              {objective.title}
            </h3>

            {/* Footer: Avatars, Period, Status */}
            <div className="flex items-center justify-between pt-2 border-t border-border/40 mt-auto">
              <div className="flex items-center gap-2">
                <UserAvatarGroup users={owners} maxDisplay={2} />
                <span className="text-[10px] font-medium text-muted-foreground">
                  {objective.quarter}
                </span>
              </div>
              <ObjectiveStatusBadge status={objective.status} />
            </div>
          </CardContent>

          {/* Expansion Button at Bottom Center */}
          {totalExpandable > 0 && (
            <div className="absolute left-1/2 -bottom-3.5 -translate-x-1/2 z-30">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setIsExpanded(!isExpanded);
                }}
                className={cn(
                  "flex items-center justify-center gap-1.5 h-7 px-2.5 rounded-md text-[10px] font-bold transition-all shadow-md",
                  isExpanded 
                    ? "bg-violet-700 text-white" 
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
              >
                <GitFork className="size-3" />
                {totalExpandable}
              </button>
            </div>
          )}
        </Card>
      </motion.div>

      {/* Tree Connections and Children */}
      <AnimatePresence>
        {isExpanded && totalExpandable > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex flex-col items-center w-full"
          >
            {/* Vertical Line down from parent */}
            <div className="h-10 w-px bg-border/80" />

            {/* Horizontal Line across children */}
            {childCount > 1 && (
              <div className="relative w-full flex justify-center">
                <div className="absolute top-0 h-px bg-border/80 w-[calc(100%-280px)]" />
              </div>
            )}

            {/* Children Row */}
            {childCount > 0 && (
              <div className="flex flex-row gap-8 pt-0">
                {sortedChildren.map((child, i) => (
                  <div key={child.id} className="flex flex-col items-center">
                    {/* Vertical Line down to child */}
                    <div className="h-8 w-px bg-border/80" />
                    
                    <ObjectiveCard
                      objective={child}
                      allObjectives={allObjectives}
                      allUsers={allUsers}
                      allLabels={allLabels}
                      allKeyResults={allKeyResults}
                      onSelect={onSelect}
                      index={i}
                      level={level + 1}
                    />
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
