import { useState } from 'react';
import { useUIStore } from '@/store/ui.store';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronRight, MoreHorizontal } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { cn } from '@/lib/utils';
import { OBJECTIVE_TYPE_CONFIG } from '@/lib/constants';
import { ObjectiveStatusBadge } from './objective-status-badge';
import { ProgressCircle } from '@/components/shared/progress-circle';
import { UserAvatarGroup } from '@/components/shared/user-avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { Objective, Label, User, KeyResult } from '@/models';

/**
 * Shared CSS grid template for table header + rows.
 * This constant ensures every column lines up perfectly between the
 * header (in objectives-list.tsx) and each row.
 *
 * Columns: expand | type | avatars | title (flex) | labels | progress | status | date | actions
 */
export const TABLE_GRID_CLASSES =
  'grid items-center gap-x-3 px-4' +
  ' grid-cols-[20px_28px_56px_1fr_minmax(80px,140px)_64px_100px_90px_28px]';

/**
 * Props for ObjectiveTableRow — a recursive row component in the List/Table view.
 *
 * Each row renders itself for the given objective, then recursively
 * renders child rows with increased indentation and vertical connector
 * lines to visualize the parent-child hierarchy.
 */
interface ObjectiveTableRowProps {
  /** The objective to render in this row */
  objective: Objective;
  /** Number of direct children (used for expand button visibility) */
  childCount: number;
  /** Direct child objectives (sub-objectives only, not KRs) */
  childObjectives: Objective[];
  /** Resolved owner User objects for avatar display */
  owners: (User | undefined)[];
  /** Resolved Label objects for badge display */
  labels: (Label | undefined)[];
  /** Tree depth level — controls indentation and connector lines */
  level?: number;
  /** Callback when row title is clicked (opens detail sheet) */
  onSelect: (id: string) => void;
  /** Callback for edit action from dropdown menu */
  onEdit: (id: string) => void;
  /** Callback for delete action from dropdown menu */
  onDelete: (id: string) => void;
  /** Full list of all objectives (needed for recursive child rendering) */
  allObjectives: Objective[];
  /** Full list of all users (needed to resolve child row owners) */
  allUsers: User[];
  /** Full list of all labels (needed to resolve child row labels) */
  allLabels: Label[];
  /** Full list of all key results (needed to render KR rows) */
  allKeyResults: KeyResult[];
  /** Whether this is the last child in its parent's list (for L-shaped connector) */
  isLastChild?: boolean;
}

/**
 * ObjectiveTableRow — Recursive, grid-aligned expandable row for the List view.
 *
 * Features:
 * - Uses the shared TABLE_GRID_CLASSES to align with the table header
 * - Renders vertical connector lines between parent and children
 * - Supports infinite nesting depth with increasing indentation
 * - Expand/collapse animation via framer-motion AnimatePresence
 * - Dropdown menu for edit/delete actions
 */
export function ObjectiveTableRow({
  objective,
  childCount,
  childObjectives,
  owners,
  labels,
  level = 0,
  onSelect,
  onEdit,
  onDelete,
  allObjectives,
  allUsers,
  allLabels,
  allKeyResults,
  isLastChild = false,
}: ObjectiveTableRowProps) {
  const [isExpanded, setIsExpanded] = useState(level < 1); // Expand top-level by default
  const typeConfig = OBJECTIVE_TYPE_CONFIG[objective.type];
  const IconComponent =
    (LucideIcons[typeConfig.icon as keyof typeof LucideIcons] as React.ComponentType<{
      className?: string;
    }>) || LucideIcons.Target;
  const validLabels = labels.filter(Boolean) as Label[];

  const { showKeyResults } = useUIStore();
  
  // KRs belonging to this objective
  const objectiveKRs = showKeyResults 
    ? allKeyResults.filter((kr) => kr.objectiveId === objective.id)
    : [];

  // Sort child objectives by type: company → department → team → individual
  const TYPE_SORT_ORDER: Record<string, number> = {
    company: 0, department: 1, team: 2, individual: 3,
  };
  const sortedChildren = [...childObjectives].sort(
    (a, b) => (TYPE_SORT_ORDER[a.type] ?? 9) - (TYPE_SORT_ORDER[b.type] ?? 9),
  );

  const hasChildren = childCount > 0 || objectiveKRs.length > 0;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, x: -6 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.2 }}
        className={cn(
          TABLE_GRID_CLASSES,
          'group py-2.5 border-b transition-colors cursor-pointer relative',
          'hover:bg-accent/40',
          level > 0 && 'bg-muted/5',
        )}
        style={{ paddingLeft: `${16 + level * 28}px` }}
        onClick={() => onSelect(objective.id)}
      >
        {/* Connector line for nested items */}
        {level > 0 && (
          <div 
            className="absolute left-0 top-0 w-px bg-border/60"
            style={{ 
              left: `${16 + (level - 1) * 28 + 10}px`,
              bottom: isLastChild ? '50%' : 0
            }}
          />
        )}
        {level > 0 && (
          <div 
            className="absolute h-px bg-border/60"
            style={{ 
              left: `${16 + (level - 1) * 28 + 10}px`, 
              top: '50%',
              width: '18px',
            }}
          />
        )}

        {/* 1 — Expand toggle */}
        <button
          className={cn(
            'flex size-5 items-center justify-center rounded hover:bg-muted transition-colors relative z-10',
            childCount === 0 && objectiveKRs.length === 0 && 'invisible',
          )}
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
        >
          <ChevronRight
            className={cn(
              'size-3.5 text-muted-foreground transition-transform duration-200',
              isExpanded && 'rotate-90',
            )}
          />
        </button>

        {/* 2 — Type icon */}
        <div
          className={cn(
            'flex size-7 items-center justify-center rounded-md relative z-10',
            typeConfig.bgColor,
          )}
        >
          <IconComponent className={cn('size-3.5', typeConfig.color)} />
        </div>

        {/* 3 — Owners */}
        <div onClick={(e) => e.stopPropagation()} className="relative z-10">
          <UserAvatarGroup users={owners} maxDisplay={2} />
        </div>

        {/* 4 — Title */}
        <div className="min-w-0 flex items-center gap-1.5 relative z-10">
          <span className={cn(
            "truncate text-sm font-medium",
            level === 0 ? "text-foreground font-bold" : "text-foreground/90"
          )}>
            {objective.title}
          </span>
          {childCount > 0 && (
            <Badge variant="outline" className="text-[9px] h-4 px-1 text-muted-foreground font-normal border-muted/50">
              {childCount}
            </Badge>
          )}
        </div>

        {/* 5 — Labels */}
        <div className="flex items-center gap-1 overflow-hidden relative z-10">
          {validLabels.slice(0, 2).map((label) => (
            <Badge
              key={label.id}
              variant="secondary"
              className="text-[10px] font-medium px-1.5 py-0 shrink-0 max-w-[100px] truncate"
              style={{
                backgroundColor: `${label.color}15`,
                color: label.color,
                borderColor: `${label.color}25`,
              }}
            >
              {label.name}
            </Badge>
          ))}
        </div>

        {/* 6 — Progress */}
        <div className="relative z-10 flex justify-center">
          <ProgressCircle
            value={objective.progress}
            size={32}
            strokeWidth={3.5}
            className={
              objective.status === 'at_risk' ? 'text-amber-500' :
              objective.status === 'off_track' ? 'text-destructive' :
              objective.status === 'closed' ? 'text-muted-foreground' : 'text-emerald-500'
            }
          />
        </div>

        {/* 7 — Status */}
        <div className="relative z-10">
          <ObjectiveStatusBadge status={objective.status} />
        </div>

        {/* 8 — Date (Period) */}
        <span className="text-right text-xs text-muted-foreground tabular-nums relative z-10 truncate">
          {objective.quarter}
        </span>

        {/* 9 — Actions */}
        <div onClick={(e) => e.stopPropagation()} className="relative z-10">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon-xs"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <MoreHorizontal className="size-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onSelect(objective.id)}>
                View details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEdit(objective.id)}>
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive"
                onClick={() => onDelete(objective.id)}
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </motion.div>

      {/* Children */}
      <AnimatePresence initial={false}>
        {isExpanded && (
          <>
            {/* Key Results — shown FIRST, before sub-objectives */}
            {objectiveKRs.map((kr, krIndex) => {
              const krOwner = allUsers.find(u => u.id === kr.ownerId);
              const isLastKr = krIndex === objectiveKRs.length - 1;
              const isAbsolutelyLast = isLastKr && sortedChildren.length === 0;

              return (
                <motion.div
                  key={kr.id}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.15, delay: krIndex * 0.03 }}
                  className="overflow-hidden"
                >
                  <div
                    className={cn(
                      TABLE_GRID_CLASSES,
                      'py-2 border-b relative',
                      'bg-primary/[0.02] hover:bg-primary/[0.05] transition-colors',
                    )}
                    style={{ paddingLeft: `${16 + (level + 1) * 28}px` }}
                  >
                    {/* Connector lines (placed absolutely relative to the row) */}
                    <div
                      className="absolute left-0 top-0 w-px bg-primary/15"
                      style={{ 
                        left: `${16 + level * 28 + 10}px`,
                        bottom: isAbsolutelyLast ? '50%' : 0
                      }}
                    />
                    <div
                      className="absolute border-t border-primary/15"
                      style={{
                        left: `${16 + level * 28 + 10}px`,
                        top: '50%',
                        width: '18px',
                      }}
                    />

                    {/* 1 - Expand (Empty for KR) */}
                    <div />

                    {/* 2 - Type icon (KR Badge) */}
                    <div className="flex justify-center relative z-10">
                      <Badge
                        variant="secondary"
                        className="h-5 px-1.5 text-[9px] font-bold bg-primary/10 text-primary border-primary/20 shrink-0 uppercase"
                      >
                        KR
                      </Badge>
                    </div>

                    {/* 3 - Owners */}
                    <div className="relative z-10">
                      <UserAvatarGroup users={[krOwner]} maxDisplay={1} />
                    </div>

                    {/* 4 - Title */}
                    <div className="min-w-0 flex items-center gap-2 relative z-10">
                      <span className="truncate text-sm text-muted-foreground font-medium">
                        {kr.title}
                      </span>
                      <Badge variant="outline" className="text-[9px] px-1 h-4 text-muted-foreground bg-background shrink-0">
                        {kr.weight}%
                      </Badge>
                    </div>

                    {/* 5 - Labels (Metrics) */}
                    <div className="text-xs text-muted-foreground tabular-nums truncate relative z-10">
                      {kr.currentValue} / {kr.targetValue}
                    </div>

                    {/* 6 - Progress */}
                    <div className="flex justify-center relative z-10">
                      <ProgressCircle
                        value={kr.progress}
                        size={32}
                        strokeWidth={3.5}
                        className={
                          kr.status === 'at_risk' ? 'text-amber-500' :
                          kr.status === 'off_track' ? 'text-destructive' :
                          kr.status === 'closed' ? 'text-muted-foreground' : 'text-emerald-500'
                        }
                      />
                    </div>

                    {/* 7 - Status */}
                    <div className="relative z-10">
                      <ObjectiveStatusBadge status={kr.status} />
                    </div>

                    {/* 8 - Date (Period) */}
                    <div className="text-xs text-muted-foreground truncate relative z-10">
                      {format(new Date(kr.endDate), 'MMM d, yyyy')}
                    </div>

                    {/* 9 - Actions */}
                    <div className="w-7" />
                  </div>
              </motion.div>
            )})}

            {/* Child objectives — sorted: department → team → individual */}
            {sortedChildren.map((child, childIndex) => {
              const isLastSub = childIndex === sortedChildren.length - 1;
              const cc = allObjectives.filter(
                (o) => o.parentObjectiveId === child.id,
              );
              return (
                <motion.div
                  key={child.id}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <ObjectiveTableRow
                    objective={child}
                    childCount={cc.length}
                    childObjectives={cc}
                    owners={child.ownerIds.map((id) =>
                      allUsers.find((u) => u.id === id),
                    )}
                    labels={child.labelIds.map((id) =>
                      allLabels.find((l) => l.id === id),
                    )}
                    level={level + 1}
                    onSelect={onSelect}
                    onEdit={onEdit}
                    onDelete={onDelete}
                    allObjectives={allObjectives}
                    allUsers={allUsers}
                    allLabels={allLabels}
                    allKeyResults={allKeyResults}
                    isLastChild={isLastSub}
                  />
                </motion.div>
              );
            })}
          </>
        )}
      </AnimatePresence>
    </>
  );
}

