import { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  User,
  Users,
  Building2,
  Landmark,
  Calendar,
  Plus,
  X,
  Check,
  ChevronsUpDown,
  Wand2,
  Info,
  Lock,
  Globe,
  ArrowRight,
  Target,
  Search,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { useObjectiveStore } from '@/store/objective.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { useUIStore } from '@/store/ui.store';
import { TIME_PERIOD_PRESETS, METRIC_TYPE_CONFIG } from '@/lib/constants';
import type {
  ObjectiveType,
  MetricType,
  OwnershipMode,
  Visibility,
  TimePeriodPreset,
} from '@/models';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { UserAvatar } from '@/components/shared/user-avatar';

/** Type selector config */
const OBJECTIVE_TYPES: {
  value: ObjectiveType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
}[] = [
  {
    value: 'individual',
    label: 'Individual',
    icon: User,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50 dark:bg-blue-950/30',
  },
  {
    value: 'team',
    label: 'Development',
    icon: Users,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/30',
  },
  {
    value: 'department',
    label: 'Department',
    icon: Building2,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50 dark:bg-rose-950/30',
  },
  {
    value: 'company',
    label: 'Company',
    icon: Landmark,
    color: 'text-violet-600',
    bgColor: 'bg-violet-50 dark:bg-violet-950/30',
  },
];

/**
 * ObjectiveFormDialog — High-fidelity two-column objective creation modal.
 */
export function ObjectiveFormDialog() {
  const { isCreateDialogOpen, setCreateDialogOpen, editingObjectiveId, setEditingObjectiveId } = useUIStore();
  const { createObjective, updateObjective, objectives } = useObjectiveStore();
  const { users } = useUserStore();
  const { labels } = useLabelStore();

  // ---- Form state ----
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [showDescription, setShowDescription] = useState(false);
  const [objectiveType, setObjectiveType] = useState<ObjectiveType>('individual');
  const [selectedOwnerIds, setSelectedOwnerIds] = useState<string[]>([]);
  const [ownershipMode, setOwnershipMode] = useState<OwnershipMode>('shared');
  const [metricType, setMetricType] = useState<MetricType>('percent');
  const [initialValue, setInitialValue] = useState(0);
  const [targetValue, setTargetValue] = useState(100);
  const [timePeriod, setTimePeriod] = useState<TimePeriodPreset>('Q1');
  const [visibility, setVisibility] = useState<Visibility>('public');
  const [selectedLabelIds, setSelectedLabelIds] = useState<string[]>([]);
  const [parentObjectiveId, setParentObjectiveId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ownerPopoverOpen, setOwnerPopoverOpen] = useState(false);
  const [labelPopoverOpen, setLabelPopoverOpen] = useState(false);
  const [parentPopoverOpen, setParentPopoverOpen] = useState(false);

  const isEditing = !!editingObjectiveId;
  const preset = TIME_PERIOD_PRESETS[timePeriod];

  // Populate form if editing
  useEffect(() => {
    if (editingObjectiveId && isCreateDialogOpen) {
      const obj = objectives.find((o) => o.id === editingObjectiveId);
      if (obj) {
        setTitle(obj.title);
        setDescription(obj.description || '');
        setShowDescription(!!obj.description);
        setObjectiveType(obj.type);
        setSelectedOwnerIds(obj.ownerIds);
        setOwnershipMode(obj.ownershipMode);
        setMetricType(obj.metricType);
        setInitialValue(obj.initialValue);
        setTargetValue(obj.targetValue);
        setTimePeriod(obj.quarter as TimePeriodPreset || 'Q1');
        setVisibility(obj.visibility);
        setSelectedLabelIds(obj.labelIds);
        setParentObjectiveId(obj.parentObjectiveId || null);
      }
    }
  }, [editingObjectiveId, isCreateDialogOpen, objectives]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setShowDescription(false);
    setObjectiveType('individual');
    setSelectedOwnerIds([]);
    setOwnershipMode('shared');
    setMetricType('percent');
    setInitialValue(0);
    setTargetValue(100);
    setTimePeriod('Q1');
    setVisibility('public');
    setSelectedLabelIds([]);
    setParentObjectiveId(null);
    setEditingObjectiveId(null);
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error('Please enter an objective title');
      return;
    }
    if (selectedOwnerIds.length === 0) {
      toast.error('Please select at least one owner');
      return;
    }

    setIsSubmitting(true);
    try {
      const data = {
        title: title.trim(),
        description: description.trim() || null,
        type: objectiveType,
        startDate: preset.startDate || new Date().toISOString().split('T')[0],
        endDate: preset.endDate || new Date().toISOString().split('T')[0],
        quarter: preset.quarter,
        ownerIds: selectedOwnerIds,
        ownershipMode,
        labelIds: selectedLabelIds,
        visibility,
        metricType,
        initialValue,
        targetValue,
        parentObjectiveId,
      };

      if (isEditing) {
        await updateObjective(editingObjectiveId!, data);
        toast.success('Objective updated successfully');
      } else {
        await createObjective(data);
        toast.success('Objective created successfully');
      }
      
      resetForm();
      setCreateDialogOpen(false);
    } catch {
      toast.error(isEditing ? 'Failed to update objective' : 'Failed to create objective');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleOwner = (id: string) => {
    setSelectedOwnerIds((prev) =>
      prev.includes(id) ? prev.filter((o) => o !== id) : [...prev, id],
    );
  };

  const toggleLabel = (id: string) => {
    setSelectedLabelIds((prev) =>
      prev.includes(id) ? prev.filter((l) => l !== id) : [...prev, id],
    );
  };

  const parentObjective = parentObjectiveId 
    ? objectives.find(o => o.id === parentObjectiveId) 
    : null;

  return (
    <Dialog
      open={isCreateDialogOpen}
      onOpenChange={(open) => {
        if (!open) resetForm();
        setCreateDialogOpen(open);
      }}
    >
      <DialogContent className="max-w-4xl p-0 gap-0 overflow-hidden border shadow-2xl rounded-xl">
        <DialogHeader className="hidden">
          <DialogTitle>{isEditing ? "Edit objective" : "New objective"}</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col md:flex-row h-full max-h-[90vh]">
          {/* ---- Left Column: Main Form ---- */}
          <div className="flex-1 flex flex-col min-w-0 bg-background">
            <ScrollArea className="flex-1">
              <div className="p-8 space-y-8">
                {/* Section: Title */}
                <div className="space-y-3">
                  <Label htmlFor="obj-title" className="text-sm font-semibold text-foreground/80">
                    Objective title
                  </Label>
                  <Input
                    id="obj-title"
                    placeholder="e.g., Increase revenue by 20% in Q2"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="text-base h-12 px-4 bg-muted/30 border-muted focus:bg-background transition-all"
                    autoFocus
                  />
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                    <button
                      type="button"
                      className="text-xs text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5"
                      onClick={() => setShowDescription(!showDescription)}
                    >
                      <Plus className={cn("size-3.5 transition-transform", showDescription && "rotate-45")} />
                      {showDescription ? "Hide description" : "Add description"}
                    </button>
                  </div>
                </div>

                {/* Section: Description (Collapsible) */}
                {showDescription && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-3"
                  >
                    <Label className="text-sm font-semibold text-foreground/80">
                      Description (optional)
                    </Label>
                    <Textarea
                      placeholder="Describe what this objective aims to achieve..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className="text-sm resize-none bg-muted/30 border-muted focus:bg-background transition-all p-4"
                    />
                  </motion.div>
                )}

                {/* Section: Objective Type */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold text-foreground/80">
                      Objective type
                    </Label>
                  </div>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    {OBJECTIVE_TYPES.map((type) => {
                      const isSelected = objectiveType === type.value;
                      return (
                        <button
                          key={type.value}
                          type="button"
                          onClick={() => setObjectiveType(type.value)}
                          className={cn(
                            'flex flex-col items-center justify-center gap-3 rounded-xl border p-4 transition-all text-center group',
                            isSelected
                              ? 'border-primary bg-primary/5 ring-1 ring-primary'
                              : 'border-muted bg-card hover:border-primary/30 hover:bg-muted/50'
                          )}
                        >
                          <div className={cn(
                            'p-2 rounded-full transition-colors',
                            isSelected ? type.bgColor : 'bg-muted group-hover:bg-primary/10'
                          )}>
                            <type.icon className={cn('size-5', isSelected ? type.color : 'text-muted-foreground')} />
                          </div>
                          <span className={cn(
                            'text-[10px] sm:text-xs font-semibold leading-tight px-1',
                            isSelected ? 'text-primary' : 'text-muted-foreground'
                          )}>
                            {type.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Section: Owner(s) */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-foreground/80">
                    Owner(s)
                  </Label>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2 p-2 rounded-xl border bg-muted/30 focus-within:bg-background focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                      <div className="flex flex-wrap gap-1.5 flex-1 min-w-0">
                        {selectedOwnerIds.map((id) => {
                          const user = users.find((u) => u.id === id);
                          if (!user) return null;
                          return (
                            <Badge
                              key={id}
                              variant="secondary"
                              className="pl-1 pr-1.5 py-0.5 h-8 gap-1.5 bg-background border rounded-full hover:bg-muted transition-colors"
                            >
                              <UserAvatar user={user} size="sm" showTooltip={false} className="size-6 border-0" />
                              <span className="text-xs font-medium">{user.name}</span>
                              <button
                                type="button"
                                onClick={() => toggleOwner(id)}
                                className="text-muted-foreground hover:text-destructive transition-colors"
                              >
                                <X className="size-3" />
                              </button>
                            </Badge>
                          );
                        })}
                        <Popover open={ownerPopoverOpen} onOpenChange={setOwnerPopoverOpen}>
                          <PopoverTrigger asChild>
                            <div className="flex-1 min-w-[120px] flex items-center px-2 cursor-text">
                              <span className="text-xs text-muted-foreground">
                                {selectedOwnerIds.length === 0 ? "Select owners..." : ""}
                              </span>
                              <Search className="ml-auto size-3.5 text-muted-foreground/50" />
                            </div>
                          </PopoverTrigger>
                          <PopoverContent className="w-[300px] p-0" align="start">
                            <Command>
                              <CommandInput placeholder="Search people..." className="h-9 text-xs" />
                              <CommandList>
                                <CommandEmpty>No users found.</CommandEmpty>
                                <CommandGroup>
                                  {users.map((user) => (
                                    <CommandItem
                                      key={user.id}
                                      onSelect={() => toggleOwner(user.id)}
                                      className="text-xs py-2 px-3"
                                    >
                                      <div className="flex items-center gap-2 flex-1">
                                        <UserAvatar user={user} size="sm" showTooltip={false} />
                                        <span>{user.name}</span>
                                      </div>
                                      {selectedOwnerIds.includes(user.id) && <Check className="size-3.5 text-primary" />}
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>
                      </div>
                      <button 
                        type="button"
                        className="text-[11px] text-primary hover:underline px-2 font-medium shrink-0"
                      >
                        Add my team
                      </button>
                    </div>

                    {selectedOwnerIds.length > 1 && (
                      <div className="p-4 rounded-xl border bg-muted/20 space-y-3">
                        <Label className="text-xs font-semibold text-foreground/70">Ownership mode</Label>
                        <RadioGroup 
                          value={ownershipMode} 
                          onValueChange={(v) => setOwnershipMode(v as OwnershipMode)}
                          className="flex gap-4"
                        >
                          <div className="flex items-center gap-2">
                            <RadioGroupItem value="shared" id="shared" />
                            <Label htmlFor="shared" className="text-xs cursor-pointer">Shared responsibility</Label>
                          </div>
                          <div className="flex items-center gap-2">
                            <RadioGroupItem value="individual" id="individual" />
                            <Label htmlFor="individual" className="text-xs cursor-pointer">Individual targets</Label>
                          </div>
                        </RadioGroup>
                      </div>
                    )}
                  </div>
                </div>

                {/* Section: Measurement */}
                <div className="space-y-4">
                  <Label className="text-sm font-semibold text-foreground/80">
                    How do you want to measure this objective?
                  </Label>
                  <Select
                    value={metricType}
                    onValueChange={(v) => setMetricType(v as MetricType)}
                  >
                    <SelectTrigger className="h-11 bg-muted/30 border-muted rounded-xl text-sm px-4">
                      <div className="flex items-center gap-2">
                        <Target className="size-4 text-muted-foreground" />
                        <SelectValue />
                      </div>
                    </SelectTrigger>
                    <SelectContent className="rounded-xl">
                      {Object.entries(METRIC_TYPE_CONFIG).map(([key, config]) => (
                        <SelectItem key={key} value={key} className="text-sm py-2">
                          <span className="font-mono mr-2">{config.icon}</span>
                          {config.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                        Metric
                      </Label>
                      <Select value={metricType} onValueChange={(v) => setMetricType(v as MetricType)}>
                        <SelectTrigger className="h-10 bg-muted/30 border-muted rounded-lg text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(METRIC_TYPE_CONFIG).map(([key, config]) => (
                            <SelectItem key={key} value={key} className="text-xs">
                              {config.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                        Initial
                      </Label>
                      <Input
                        type="number"
                        value={initialValue}
                        onChange={(e) => setInitialValue(Number(e.target.value))}
                        className="h-10 bg-muted/30 border-muted rounded-lg text-sm"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                        Target
                      </Label>
                      <Input
                        type="number"
                        value={targetValue}
                        onChange={(e) => setTargetValue(Number(e.target.value))}
                        className="h-10 bg-muted/30 border-muted rounded-lg text-sm"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>

            {/* Footer Actions */}
            <div className="p-6 border-t flex items-center justify-between bg-muted/10">
              <Button
                variant="ghost"
                onClick={() => setCreateDialogOpen(false)}
                className="text-muted-foreground font-medium"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-10 h-11 rounded-xl shadow-lg shadow-primary/20 font-bold"
              >
                {isSubmitting ? (isEditing ? 'Updating...' : 'Creating...') : (isEditing ? 'Update' : 'Create')}
              </Button>
            </div>
          </div>

          {/* ---- Right Column: Sidebar Metadata ---- */}
          <div className="w-full md:w-[320px] bg-muted/30 border-l flex flex-col min-w-0">
            <ScrollArea className="flex-1">
              <div className="p-6 space-y-8">
                {/* Metadata: Date */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                    <Calendar className="size-4" />
                    <span>Start/End date</span>
                  </div>
                  <Select
                    value={timePeriod}
                    onValueChange={(v) => setTimePeriod(v as TimePeriodPreset)}
                  >
                    <SelectTrigger className="h-11 bg-background border-muted rounded-xl text-xs px-4">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(TIME_PERIOD_PRESETS).map(([key, val]) => (
                        <SelectItem key={key} value={key} className="text-xs">
                          {val.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Metadata: Parent */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                      <Target className="size-4" />
                      <span>Parent objective</span>
                    </div>
                    <Popover open={parentPopoverOpen} onOpenChange={setParentPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="xs" className="h-7 text-[10px] rounded-md gap-1">
                          <Plus className="size-3" />
                          {parentObjectiveId ? "Change" : "Add"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[300px] p-0" align="end">
                        <Command>
                          <CommandInput placeholder="Search objectives..." className="h-8 text-xs" />
                          <CommandList>
                            <CommandEmpty>No objectives found.</CommandEmpty>
                            <CommandGroup>
                              <CommandItem onSelect={() => { setParentObjectiveId(null); setParentPopoverOpen(false); }} className="text-xs">
                                <span className="text-muted-foreground italic">No parent</span>
                                {!parentObjectiveId && <Check className="ml-auto size-3.5 text-primary" />}
                              </CommandItem>
                              {objectives.filter(o => o.id !== editingObjectiveId).map((obj) => (
                                <CommandItem
                                  key={obj.id}
                                  onSelect={() => { setParentObjectiveId(obj.id); setParentPopoverOpen(false); }}
                                  className="text-xs"
                                >
                                  <span className="truncate">{obj.title}</span>
                                  {parentObjectiveId === obj.id && <Check className="ml-auto size-3.5 text-primary" />}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className={cn(
                    "p-3 rounded-xl border border-dashed transition-colors",
                    parentObjective 
                      ? "border-primary/30 bg-primary/5 text-left" 
                      : "border-muted-foreground/30 bg-muted/50 text-center"
                  )}>
                    {parentObjective ? (
                      <div className="space-y-1">
                        <p className="text-[11px] font-medium text-primary uppercase tracking-wider">Parent</p>
                        <p className="text-xs font-semibold line-clamp-2">{parentObjective.title}</p>
                        <button 
                          onClick={() => setParentObjectiveId(null)}
                          className="text-[10px] text-muted-foreground hover:text-destructive underline"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">No parent objective selected</span>
                    )}
                  </div>
                </div>

                {/* Metadata: Labels */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                      <Plus className="size-4 rotate-45" />
                      <span>Labels</span>
                    </div>
                    <Popover open={labelPopoverOpen} onOpenChange={setLabelPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="xs" className="h-7 text-[10px] rounded-md gap-1">
                          <Plus className="size-3" />
                          Add
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[200px] p-0" align="end">
                        <Command>
                          <CommandInput placeholder="Search labels..." className="h-8 text-xs" />
                          <CommandList>
                            <CommandEmpty>No labels found.</CommandEmpty>
                            <CommandGroup>
                              {labels.map((label) => (
                                <CommandItem
                                  key={label.id}
                                  onSelect={() => toggleLabel(label.id)}
                                  className="text-xs"
                                >
                                  <div className="flex items-center gap-2 flex-1">
                                    <div className="size-2.5 rounded-full" style={{ backgroundColor: label.color }} />
                                    <span>{label.name}</span>
                                  </div>
                                  {selectedLabelIds.includes(label.id) && <Check className="size-3.5 text-primary" />}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedLabelIds.length === 0 ? (
                      <span className="text-[11px] text-muted-foreground pl-1">No labels added</span>
                    ) : (
                      selectedLabelIds.map((id) => {
                        const label = labels.find((l) => l.id === id);
                        if (!label) return null;
                        return (
                          <Badge
                            key={id}
                            variant="outline"
                            className="text-[10px] px-2 py-0.5 rounded-full border"
                            style={{ 
                              backgroundColor: `${label.color}15`, 
                              color: label.color,
                              borderColor: `${label.color}30`
                            }}
                          >
                            {label.name}
                          </Badge>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Metadata: Related Groups */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                    <Users className="size-4" />
                    <span>Related groups</span>
                    <Info className="size-3 text-muted-foreground/50 cursor-help" />
                  </div>
                  <Select>
                    <SelectTrigger className="h-11 bg-background border-muted rounded-xl text-xs px-4">
                      <SelectValue placeholder="Select group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="group1" className="text-xs">Product Team</SelectItem>
                      <SelectItem value="group2" className="text-xs">Marketing Dept</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Separator className="bg-muted-foreground/10" />

                {/* Metadata: Visibility */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                    <Globe className="size-4" />
                    <span>Visibility</span>
                  </div>
                  <div className="flex p-1 rounded-xl bg-background border border-muted shadow-inner">
                    <button
                      type="button"
                      onClick={() => setVisibility('private')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all",
                        visibility === 'private' ? "bg-muted shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Lock className="size-3.5" />
                      Private
                    </button>
                    <button
                      type="button"
                      onClick={() => setVisibility('public')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all",
                        visibility === 'public' ? "bg-primary/10 text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Globe className="size-3.5" />
                      Public
                      {visibility === 'public' && <Check className="size-3 ml-0.5" />}
                    </button>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-relaxed pl-1 italic">
                    Public objectives are visible to everyone in the organization. Private objectives are only visible to owners and members.
                  </p>
                </div>
              </div>
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
