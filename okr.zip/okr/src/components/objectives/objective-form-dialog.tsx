/* eslint-disable react-hooks/set-state-in-effect */
import { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  User,
  Users,
  Building2,
  Landmark,
  Calendar,
  ArrowDown,
  ArrowRight,
  ArrowUp,
  Plus,
  X,
  Check,
  CheckCircle2,
  GitBranch,
  GitFork,
  Trash2,
  Lock,
  Globe,
  Target,
  Search,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Checkbox } from '@/components/ui/checkbox';
import { useObjectiveStore } from '@/store/objective.store';
import { useKeyResultStore } from '@/store/key-result.store';
import { useUserStore } from '@/store/user.store';
import { useLabelStore } from '@/store/label.store';
import { useUIStore } from '@/store/ui.store';
import {
  TIME_PERIOD_PRESETS,
  METRIC_TYPE_CONFIG,
  TARGET_TRACKING_CONFIG,
} from '@/lib/constants';
import {
  canObjectiveHaveParent,
  getMetricBounds,
  getObjectiveUpdateValidationError,
  getObjectiveValidationError,
  getParentRuleMessage,
  isValidParentType,
} from '@/lib/okr-validation';
import type {
  ObjectiveType,
  MetricType,
  OwnershipMode,
  ProgressMode,
  TargetTrackingType,
  Visibility,
  TimePeriodPreset,
} from '@/models';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { UserAvatar } from '@/components/shared/user-avatar';

/** Type selector config */
const OBJECTIVE_TYPES: {
  value: ObjectiveType;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  bgColor: string;
}[] = [
  {
    value: 'individual',
    label: 'Individual',
    icon: User,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50 dark:bg-blue-950/30',
  },
  {
    value: 'team',
    label: 'Team',
    icon: Users,
    color: 'text-emerald-600',
    bgColor: 'bg-emerald-50 dark:bg-emerald-950/30',
  },
  {
    value: 'department',
    label: 'Department',
    icon: Building2,
    color: 'text-rose-600',
    bgColor: 'bg-rose-50 dark:bg-rose-950/30',
  },
  {
    value: 'company',
    label: 'Company',
    icon: Landmark,
    color: 'text-violet-600',
    bgColor: 'bg-violet-50 dark:bg-violet-950/30',
  },
];

const TRACKING_ICONS: Record<TargetTrackingType, React.ComponentType<{ className?: string }>> = {
  reach: ArrowRight,
  stay_above: ArrowUp,
  stay_below: ArrowDown,
  completed: CheckCircle2,
  rollup_key_results: GitBranch,
  rollup_children: GitFork,
};

interface DraftKeyResult {
  id: string;
  title: string;
  ownerId: string;
  weight: number;
  metricType: MetricType;
  initialValue: number;
  targetValue: number;
}

/**
 * ObjectiveFormDialog — High-fidelity two-column objective creation modal.
 */
export function ObjectiveFormDialog() {
  const { isCreateDialogOpen, setCreateDialogOpen, editingObjectiveId, setEditingObjectiveId } = useUIStore();
  const { createObjective, updateObjective, objectives } = useObjectiveStore();
  const { createKeyResult } = useKeyResultStore();
  const { users } = useUserStore();
  const { labels } = useLabelStore();

  // ---- Form state ----
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [showDescription, setShowDescription] = useState(false);
  const [objectiveType, setObjectiveType] = useState<ObjectiveType>('individual');
  const [selectedOwnerIds, setSelectedOwnerIds] = useState<string[]>([]);
  const [ownershipMode, setOwnershipMode] = useState<OwnershipMode>('shared');
  const [progressMode, setProgressMode] = useState<ProgressMode>('rollup');
  const [targetTrackingType, setTargetTrackingType] =
    useState<TargetTrackingType>('rollup_key_results');
  const [weight, setWeight] = useState<number | ''>('');
  const [metricType, setMetricType] = useState<MetricType>('percent');
  const [initialValue, setInitialValue] = useState(0);
  const [targetValue, setTargetValue] = useState(100);
  const [timePeriod, setTimePeriod] = useState<TimePeriodPreset>('Q1');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [visibility, setVisibility] = useState<Visibility>('public');
  const [commentsPrivate, setCommentsPrivate] = useState(false);
  const [selectedLabelIds, setSelectedLabelIds] = useState<string[]>([]);
  const [parentObjectiveId, setParentObjectiveId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [ownerPopoverOpen, setOwnerPopoverOpen] = useState(false);
  const [labelPopoverOpen, setLabelPopoverOpen] = useState(false);
  const [parentPopoverOpen, setParentPopoverOpen] = useState(false);
  const [draftKeyResults, setDraftKeyResults] = useState<DraftKeyResult[]>([]);

  const isEditing = !!editingObjectiveId;
  const preset = TIME_PERIOD_PRESETS[timePeriod];
  const startDate = timePeriod === 'custom' ? customStartDate : preset.startDate;
  const endDate = timePeriod === 'custom' ? customEndDate : preset.endDate;
  const metricConfig = METRIC_TYPE_CONFIG[metricType];
  const canHaveParent = canObjectiveHaveParent(objectiveType);
  const isCompanyObjective = objectiveType === 'company';
  const showManualMeasurement = progressMode === 'manual';
  const showInlineKeyResults =
    !isEditing && !isCompanyObjective && targetTrackingType === 'rollup_key_results';
  const draftWeightTotal = draftKeyResults.reduce((sum, kr) => sum + kr.weight, 0);
  const parentObjective = parentObjectiveId
    ? objectives.find((o) => o.id === parentObjectiveId)
    : null;

  const parentOptions = useMemo(
    () =>
      objectives.filter(
        (objective) =>
          objective.id !== editingObjectiveId &&
          isValidParentType(objective.type, objectiveType),
      ),
    [editingObjectiveId, objectiveType, objectives],
  );

  // Populate form if editing
  useEffect(() => {
    if (editingObjectiveId && isCreateDialogOpen) {
      const obj = objectives.find((o) => o.id === editingObjectiveId);
      if (obj) {
        setTitle(obj.title);
        setDescription(obj.description || '');
        setShowDescription(!!obj.description);
        setObjectiveType(obj.type);
        setSelectedOwnerIds(obj.ownerIds);
        setOwnershipMode(obj.ownershipMode);
        setProgressMode(obj.progressMode);
        setTargetTrackingType(
          obj.targetTrackingType ??
            (obj.progressMode === 'manual' ? 'reach' : 'rollup_key_results'),
        );
        setWeight(obj.parentObjectiveId ? obj.weight : '');
        setMetricType(obj.metricType);
        setInitialValue(obj.initialValue);
        setTargetValue(obj.targetValue);
        setTimePeriod(resolveTimePeriodPreset(obj.startDate, obj.endDate));
        setCustomStartDate(obj.startDate);
        setCustomEndDate(obj.endDate);
        setVisibility(obj.visibility);
        setCommentsPrivate(obj.commentsPrivate);
        setSelectedLabelIds(obj.labelIds);
        setParentObjectiveId(obj.parentObjectiveId || null);
      }
    }
  }, [editingObjectiveId, isCreateDialogOpen, objectives]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setShowDescription(false);
    setObjectiveType('individual');
    setSelectedOwnerIds([]);
    setOwnershipMode('shared');
    setProgressMode('rollup');
    setTargetTrackingType('rollup_key_results');
    setWeight('');
    setMetricType('percent');
    setInitialValue(0);
    setTargetValue(100);
    setTimePeriod('Q1');
    setCustomStartDate('');
    setCustomEndDate('');
    setVisibility('public');
    setCommentsPrivate(false);
    setSelectedLabelIds([]);
    setParentObjectiveId(null);
    setDraftKeyResults([]);
    setEditingObjectiveId(null);
  };

  const handleMetricTypeChange = (nextMetricType: MetricType) => {
    setMetricType(nextMetricType);
    const bounds = getMetricBounds(nextMetricType);
    setInitialValue(bounds.initial);
    setTargetValue(bounds.target);
  };

  const handleObjectiveTypeChange = (nextType: ObjectiveType) => {
    setObjectiveType(nextType);

    if (!canObjectiveHaveParent(nextType)) {
      setParentObjectiveId(null);
      setWeight('');
    } else if (parentObjective && !isValidParentType(parentObjective.type, nextType)) {
      setParentObjectiveId(null);
    }

    if (nextType === 'company') {
      setProgressMode('rollup');
      setTargetTrackingType('rollup_children');
      setDraftKeyResults([]);
      setMetricType('percent');
      setInitialValue(0);
      setTargetValue(100);
    }
  };

  const handleTargetTrackingTypeChange = (nextType: TargetTrackingType) => {
    setTargetTrackingType(nextType);
    setProgressMode(
      nextType === 'rollup_key_results' || nextType === 'rollup_children'
        ? 'rollup'
        : 'manual',
    );

    if (nextType === 'completed') {
      setMetricType('percent');
      setInitialValue(0);
      setTargetValue(100);
    }

    if (nextType !== 'rollup_key_results') {
      setDraftKeyResults([]);
    }
  };

  const addDraftKeyResult = () => {
    const remainingWeight = Math.max(0, 100 - draftWeightTotal);
    setDraftKeyResults((prev) => [
      ...prev,
      {
        id: crypto.randomUUID(),
        title: '',
        ownerId: selectedOwnerIds[0] ?? users[0]?.id ?? '',
        weight: prev.length === 0 ? 100 : remainingWeight,
        metricType: 'percent',
        initialValue: 0,
        targetValue: 100,
      },
    ]);
  };

  const updateDraftKeyResult = (id: string, data: Partial<DraftKeyResult>) => {
    setDraftKeyResults((prev) =>
      prev.map((kr) => (kr.id === id ? { ...kr, ...data } : kr)),
    );
  };

  const removeDraftKeyResult = (id: string) => {
    setDraftKeyResults((prev) => prev.filter((kr) => kr.id !== id));
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast.error('Please enter an objective title');
      return;
    }
    if (selectedOwnerIds.length === 0) {
      toast.error('Please select at least one owner');
      return;
    }

    const data = {
      title: title.trim(),
      description: description.trim() || null,
      type: objectiveType,
      startDate: startDate || new Date().toISOString().split('T')[0],
      endDate: endDate || new Date().toISOString().split('T')[0],
      quarter: timePeriod === 'custom' ? 'Custom' : preset.quarter,
      ownerIds: selectedOwnerIds,
      ownershipMode,
      labelIds: selectedLabelIds,
      visibility,
      commentsPrivate,
      progressMode,
      targetTrackingType,
      weight: weight === '' ? undefined : weight,
      metricType,
      initialValue,
      targetValue,
      parentObjectiveId,
    };
    const validationError = isEditing
      ? getObjectiveUpdateValidationError(editingObjectiveId!, data, objectives)
      : getObjectiveValidationError(data, objectives);

    if (validationError) {
      toast.error(validationError);
      return;
    }
    if (draftWeightTotal > 100) {
      toast.error('Key result weights cannot exceed 100%');
      return;
    }
    if (draftKeyResults.some((kr) => !kr.title.trim() || !kr.ownerId)) {
      toast.error('Each draft key result needs a title and owner');
      return;
    }

    setIsSubmitting(true);
    try {
      if (isEditing) {
        await updateObjective(editingObjectiveId!, data);
        toast.success('Objective updated successfully');
      } else {
        const createdObjective = await createObjective(data);
        await Promise.all(
          draftKeyResults.map((kr) =>
            createKeyResult({
              title: kr.title.trim(),
              objectiveId: createdObjective.id,
              ownerId: kr.ownerId,
              weight: kr.weight,
              metricType: kr.metricType,
              initialValue: kr.initialValue,
              targetValue: kr.targetValue,
              startDate: createdObjective.startDate,
              endDate: createdObjective.endDate,
            }),
          ),
        );
        toast.success('Objective created successfully');
      }
      
      resetForm();
      setCreateDialogOpen(false);
    } catch {
      toast.error(isEditing ? 'Failed to update objective' : 'Failed to create objective');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleOwner = (id: string) => {
    setSelectedOwnerIds((prev) =>
      prev.includes(id) ? prev.filter((o) => o !== id) : [...prev, id],
    );
  };

  const toggleLabel = (id: string) => {
    setSelectedLabelIds((prev) =>
      prev.includes(id) ? prev.filter((l) => l !== id) : [...prev, id],
    );
  };

  return (
    <Dialog
      open={isCreateDialogOpen}
      onOpenChange={(open) => {
        if (!open) resetForm();
        setCreateDialogOpen(open);
      }}
    >
      <DialogContent className="max-w-4xl p-0 gap-0 overflow-hidden border shadow-2xl rounded-xl" style={{ maxHeight: '85vh' }} aria-describedby={undefined}>
        <DialogHeader className="hidden">
          <DialogTitle>{isEditing ? "Edit objective" : "New objective"}</DialogTitle>
        </DialogHeader>

        <div className="flex flex-col md:flex-row" style={{ height: '85vh' }}>
          {/* ---- Left Column: Main Form ---- */}
          <div className="flex-1 flex flex-col min-w-0 bg-background overflow-hidden">
            <ScrollArea className="flex-1" style={{ maxHeight: 'calc(85vh - 72px)' }}>
              <div className="p-6 space-y-6">
                {/* Section: Title */}
                <div className="space-y-3">
                  <Label htmlFor="obj-title" className="text-sm font-semibold text-foreground/80">
                    Objective title
                  </Label>
                  <Input
                    id="obj-title"
                    placeholder="e.g., Increase revenue by 20% in Q2"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="text-base h-12 px-4 bg-muted/30 border-muted focus:bg-background transition-all"
                    autoFocus
                  />
                  <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                    <button
                      type="button"
                      className="text-xs text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5"
                      onClick={() => setShowDescription(!showDescription)}
                    >
                      <Plus className={cn("size-3.5 transition-transform", showDescription && "rotate-45")} />
                      {showDescription ? "Hide description" : "Add description"}
                    </button>
                  </div>
                </div>

                {/* Section: Description (Collapsible) */}
                {showDescription && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="space-y-3"
                  >
                    <Label className="text-sm font-semibold text-foreground/80">
                      Description (optional)
                    </Label>
                    <Textarea
                      placeholder="Describe what this objective aims to achieve..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={4}
                      className="text-sm resize-none bg-muted/30 border-muted focus:bg-background transition-all p-4"
                    />
                  </motion.div>
                )}

                {/* Section: Objective Type */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold text-foreground/80">
                      Objective type
                    </Label>
                  </div>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    {OBJECTIVE_TYPES.map((type) => {
                      const isSelected = objectiveType === type.value;
                      return (
                        <button
                          key={type.value}
                          type="button"
                          onClick={() => handleObjectiveTypeChange(type.value)}
                          className={cn(
                            'flex flex-col items-center justify-center gap-3 rounded-xl border p-4 transition-all text-center group',
                            isSelected
                              ? 'border-primary bg-primary/5 ring-1 ring-primary'
                              : 'border-muted bg-card hover:border-primary/30 hover:bg-muted/50'
                          )}
                        >
                          <div className={cn(
                            'p-2 rounded-full transition-colors',
                            isSelected ? type.bgColor : 'bg-muted group-hover:bg-primary/10'
                          )}>
                            <type.icon className={cn('size-5', isSelected ? type.color : 'text-muted-foreground')} />
                          </div>
                          <span className={cn(
                            'text-[10px] sm:text-xs font-semibold leading-tight px-1',
                            isSelected ? 'text-primary' : 'text-muted-foreground'
                          )}>
                            {type.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Section: Owner(s) */}
                <div className="space-y-3">
                  <Label className="text-sm font-semibold text-foreground/80">
                    Owner(s)
                  </Label>
                  <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2 p-2 rounded-xl border bg-muted/30 focus-within:bg-background focus-within:ring-2 focus-within:ring-primary/20 transition-all">
                      <div className="flex flex-wrap gap-1.5 flex-1 min-w-0">
                        {selectedOwnerIds.map((id) => {
                          const user = users.find((u) => u.id === id);
                          if (!user) return null;
                          return (
                            <Badge
                              key={id}
                              variant="secondary"
                              className="pl-1 pr-1.5 py-0.5 h-8 gap-1.5 bg-background border rounded-full hover:bg-muted transition-colors"
                            >
                              <UserAvatar user={user} size="sm" showTooltip={false} className="size-6 border-0" />
                              <span className="text-xs font-medium">{user.name}</span>
                              <button
                                type="button"
                                onClick={() => toggleOwner(id)}
                                className="text-muted-foreground hover:text-destructive transition-colors"
                              >
                                <X className="size-3" />
                              </button>
                            </Badge>
                          );
                        })}
                        <Popover open={ownerPopoverOpen} onOpenChange={setOwnerPopoverOpen}>
                          <PopoverTrigger asChild>
                            <div className="flex-1 min-w-[120px] flex items-center px-2 cursor-text">
                              <span className="text-xs text-muted-foreground">
                                {selectedOwnerIds.length === 0 ? "Select owners..." : ""}
                              </span>
                              <Search className="ml-auto size-3.5 text-muted-foreground/50" />
                            </div>
                          </PopoverTrigger>
                          <PopoverContent className="w-[300px] p-0" align="start">
                            <Command>
                              <CommandInput placeholder="Search people..." className="h-9 text-xs" />
                              <CommandList>
                                <CommandEmpty>No users found.</CommandEmpty>
                                <CommandGroup>
                                  {users.map((user) => (
                                    <CommandItem
                                      key={user.id}
                                      onSelect={() => toggleOwner(user.id)}
                                      className="text-xs py-2 px-3"
                                    >
                                      <div className="flex items-center gap-2 flex-1">
                                        <UserAvatar user={user} size="sm" showTooltip={false} />
                                        <span>{user.name}</span>
                                      </div>
                                      {selectedOwnerIds.includes(user.id) && <Check className="size-3.5 text-primary" />}
                                    </CommandItem>
                                  ))}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl border bg-muted/20 space-y-3">
                      <Label className="text-xs font-semibold text-foreground/70">Ownership mode</Label>
                      <RadioGroup 
                        value={ownershipMode} 
                        onValueChange={(v) => setOwnershipMode(v as OwnershipMode)}
                        className="flex flex-col gap-3"
                      >
                        <div className="flex items-start gap-2">
                          <RadioGroupItem value="shared" id="shared" className="mt-0.5" />
                          <div>
                            <Label htmlFor="shared" className="text-xs font-medium cursor-pointer">Shared responsibility</Label>
                            <p className="text-[10px] text-muted-foreground leading-snug mt-0.5">All owners share one progress bar. Anyone can update.</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <RadioGroupItem value="individual" id="individual" className="mt-0.5" />
                          <div>
                            <Label htmlFor="individual" className="text-xs font-medium cursor-pointer">Individual targets</Label>
                            <p className="text-[10px] text-muted-foreground leading-snug mt-0.5">Split into Key Results per owner with weighted contributions.</p>
                          </div>
                        </div>
                      </RadioGroup>
                    </div>
                  </div>
                </div>

                {/* Section: Progress */}
                <div className="space-y-4">
                  <Label className="text-sm font-semibold text-foreground/80">
                    Target and progress tracking
                  </Label>
                  <Select
                    value={targetTrackingType}
                    onValueChange={(value) =>
                      handleTargetTrackingTypeChange(value as TargetTrackingType)
                    }
                  >
                    <SelectTrigger className="h-11 bg-muted/30 border-muted rounded-xl text-sm px-4">
                      <div className="flex items-center gap-2">
                        {(() => {
                          const Icon = TRACKING_ICONS[targetTrackingType];
                          return <Icon className="size-4 text-muted-foreground" />;
                        })()}
                        <SelectValue />
                      </div>
                    </SelectTrigger>
                    <SelectContent className="w-[520px] rounded-xl">
                      <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                        Target
                      </div>
                      {(['reach', 'stay_above', 'stay_below', 'completed'] as TargetTrackingType[]).map((type) => {
                        const config = TARGET_TRACKING_CONFIG[type];
                        const Icon = TRACKING_ICONS[type];
                        return (
                          <SelectItem
                            key={type}
                            value={type}
                            disabled={isCompanyObjective}
                            className="py-2"
                          >
                            <div className="flex items-start gap-3">
                              <Icon className="mt-0.5 size-4 text-muted-foreground" />
                              <div>
                                <p className="text-sm font-medium">{config.label}</p>
                                <p className="text-xs text-muted-foreground">{config.description}</p>
                              </div>
                            </div>
                          </SelectItem>
                        );
                      })}
                      <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                        Aggregated progress
                      </div>
                      {(['rollup_key_results', 'rollup_children'] as TargetTrackingType[]).map((type) => {
                        const config = TARGET_TRACKING_CONFIG[type];
                        const Icon = TRACKING_ICONS[type];
                        return (
                          <SelectItem
                            key={type}
                            value={type}
                            disabled={isCompanyObjective && type === 'rollup_key_results'}
                            className="py-2"
                          >
                            <div className="flex items-start gap-3">
                              <Icon className="mt-0.5 size-4 text-muted-foreground" />
                              <div>
                                <p className="text-sm font-medium">{config.label}</p>
                                <p className="text-xs text-muted-foreground">{config.description}</p>
                              </div>
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>

                  {showManualMeasurement && (
                    <>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                            Metric
                          </Label>
                          <Select
                            value={metricType}
                            onValueChange={(v) => handleMetricTypeChange(v as MetricType)}
                            disabled={targetTrackingType === 'completed'}
                          >
                            <SelectTrigger className="h-10 bg-muted/30 border-muted rounded-lg text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Object.entries(METRIC_TYPE_CONFIG).map(([key, config]) => (
                                <SelectItem key={key} value={key} className="text-xs">
                                  <span className="font-mono mr-1">{config.icon}</span>
                                  {config.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                            Initial {metricConfig.suffix || metricConfig.prefix}
                          </Label>
                          <Input
                            type="number"
                            value={initialValue}
                            onChange={(e) => setInitialValue(Number(e.target.value))}
                            className="h-10 bg-muted/30 border-muted rounded-lg text-sm"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                            Target {metricConfig.suffix || metricConfig.prefix}
                          </Label>
                          <Input
                            type="number"
                            value={targetValue}
                            onChange={(e) => setTargetValue(Number(e.target.value))}
                            className="h-10 bg-muted/30 border-muted rounded-lg text-sm"
                          />
                        </div>
                      </div>
                    </>
                  )}

                  {showInlineKeyResults && (
                    <div className="rounded-xl border bg-muted/20 p-4 space-y-3">
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <Label className="text-xs font-semibold text-foreground/80">
                            Key results
                          </Label>
                          <p className="text-[10px] text-muted-foreground">
                            Add measurable results now. Weights must stay at or below 100%.
                          </p>
                        </div>
                        <Badge
                          variant={draftWeightTotal > 100 ? 'destructive' : 'outline'}
                          className="text-[10px]"
                        >
                          {draftWeightTotal}% allocated
                        </Badge>
                      </div>

                      <div className="space-y-2">
                        {draftKeyResults.map((kr) => (
                          <div
                            key={kr.id}
                            className="grid grid-cols-[minmax(0,1fr)_92px_76px_32px] gap-2 rounded-lg border bg-background p-2"
                          >
                            <Input
                              value={kr.title}
                              onChange={(event) =>
                                updateDraftKeyResult(kr.id, { title: event.target.value })
                              }
                              placeholder="Key result title"
                              className="h-9 text-xs"
                            />
                            <Select
                              value={kr.ownerId}
                              onValueChange={(value) => updateDraftKeyResult(kr.id, { ownerId: value })}
                            >
                              <SelectTrigger className="h-9 text-xs">
                                <SelectValue placeholder="Owner" />
                              </SelectTrigger>
                              <SelectContent>
                                {users.map((user) => (
                                  <SelectItem key={user.id} value={user.id} className="text-xs">
                                    {user.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <div className="relative">
                              <Input
                                type="number"
                                min={0}
                                max={100}
                                value={kr.weight}
                                onChange={(event) =>
                                  updateDraftKeyResult(kr.id, { weight: Number(event.target.value) })
                                }
                                className="h-9 pr-6 text-xs"
                              />
                              <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-muted-foreground">
                                %
                              </span>
                            </div>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon-sm"
                              className="size-9 text-muted-foreground hover:text-destructive"
                              onClick={() => removeDraftKeyResult(kr.id)}
                            >
                              <Trash2 className="size-3" />
                            </Button>
                          </div>
                        ))}
                      </div>

                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 gap-1 text-xs"
                        onClick={addDraftKeyResult}
                        disabled={draftWeightTotal >= 100}
                      >
                        <Plus className="size-3" />
                        Add key result
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </ScrollArea>

            {/* Footer Actions */}
            <div className="p-6 border-t flex items-center justify-between bg-muted/10">
              <Button
                variant="ghost"
                onClick={() => setCreateDialogOpen(false)}
                className="text-muted-foreground font-medium"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="px-10 h-11 rounded-xl shadow-lg shadow-primary/20 font-bold"
              >
                {isSubmitting ? (isEditing ? 'Updating...' : 'Creating...') : (isEditing ? 'Update' : 'Create')}
              </Button>
            </div>
          </div>

          {/* ---- Right Column: Sidebar Metadata ---- */}
          <div className="w-full md:w-[320px] bg-muted/30 border-l flex flex-col min-w-0 overflow-hidden">
            <ScrollArea className="flex-1" style={{ maxHeight: '85vh' }}>
              <div className="p-6 space-y-8">
                {/* Metadata: Date */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                    <Calendar className="size-4" />
                    <span>Start/End date</span>
                  </div>
                  <Select
                    value={timePeriod}
                    onValueChange={(v) => {
                      const nextPeriod = v as TimePeriodPreset;
                      setTimePeriod(nextPeriod);
                      if (nextPeriod !== 'custom') {
                        setCustomStartDate(TIME_PERIOD_PRESETS[nextPeriod].startDate);
                        setCustomEndDate(TIME_PERIOD_PRESETS[nextPeriod].endDate);
                      }
                    }}
                  >
                    <SelectTrigger className="h-11 bg-background border-muted rounded-xl text-xs px-4">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(TIME_PERIOD_PRESETS).map(([key, val]) => (
                        <SelectItem key={key} value={key} className="text-xs">
                          {val.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {timePeriod === 'custom' && (
                    <div className="grid grid-cols-2 gap-2">
                      <Input
                        type="date"
                        value={customStartDate}
                        onChange={(event) => setCustomStartDate(event.target.value)}
                        className="h-10 bg-background border-muted rounded-lg text-xs"
                      />
                      <Input
                        type="date"
                        value={customEndDate}
                        onChange={(event) => setCustomEndDate(event.target.value)}
                        className="h-10 bg-background border-muted rounded-lg text-xs"
                      />
                    </div>
                  )}
                </div>

                {/* Metadata: Parent */}
                {canHaveParent ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                      <Target className="size-4" />
                      <span>Parent objective</span>
                    </div>
                    <Popover open={parentPopoverOpen} onOpenChange={setParentPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="xs" className="h-7 text-[10px] rounded-md gap-1">
                          <Plus className="size-3" />
                          {parentObjectiveId ? "Change" : "Add"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[300px] p-0" align="end">
                        <Command>
                          <CommandInput placeholder="Search objectives..." className="h-8 text-xs" />
                          <CommandList>
                            <CommandEmpty>No objectives found.</CommandEmpty>
                            <CommandGroup>
                              <CommandItem onSelect={() => { setParentObjectiveId(null); setParentPopoverOpen(false); }} className="text-xs">
                                <span className="text-muted-foreground italic">No parent</span>
                                {!parentObjectiveId && <Check className="ml-auto size-3.5 text-primary" />}
                              </CommandItem>
                              {parentOptions.map((obj) => (
                                <CommandItem
                                  key={obj.id}
                                  onSelect={() => { setParentObjectiveId(obj.id); setParentPopoverOpen(false); }}
                                  className="text-xs"
                                >
                                  <span className="truncate">{obj.title}</span>
                                  {parentObjectiveId === obj.id && <Check className="ml-auto size-3.5 text-primary" />}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className={cn(
                    "p-3 rounded-xl border border-dashed transition-colors",
                    parentObjective 
                      ? "border-primary/30 bg-primary/5 text-left" 
                      : "border-muted-foreground/30 bg-muted/50 text-center"
                  )}>
                    {parentObjective ? (
                      <div className="space-y-1">
                        <p className="text-[11px] font-medium text-primary uppercase tracking-wider">Parent</p>
                        <p className="text-xs font-semibold line-clamp-2">{parentObjective.title}</p>
                        <button 
                          onClick={() => setParentObjectiveId(null)}
                          className="text-[10px] text-muted-foreground hover:text-destructive underline"
                        >
                          Remove
                        </button>
                      </div>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">No parent objective selected</span>
                    )}
                  </div>
                  {parentObjective && (
                    <div className="space-y-2">
                      <Label className="text-[11px] font-medium text-muted-foreground uppercase tracking-wider pl-1">
                        Contribution weight
                      </Label>
                      <div className="relative">
                        <Input
                          type="number"
                          min={0}
                          max={100}
                          placeholder="Auto"
                          value={weight}
                          onChange={(event) =>
                            setWeight(event.target.value === '' ? '' : Number(event.target.value))
                          }
                          className="h-10 bg-background border-muted rounded-lg pr-7 text-xs"
                        />
                        <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs font-medium text-muted-foreground">
                          %
                        </span>
                      </div>
                    </div>
                  )}
                </div>
                ) : (
                  <div className="rounded-xl border border-dashed bg-muted/40 p-3 text-[11px] text-muted-foreground">
                    {getParentRuleMessage(objectiveType)}
                  </div>
                )}

                {/* Metadata: Labels */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                      <Plus className="size-4 rotate-45" />
                      <span>Labels</span>
                    </div>
                    <Popover open={labelPopoverOpen} onOpenChange={setLabelPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="xs" className="h-7 text-[10px] rounded-md gap-1">
                          <Plus className="size-3" />
                          Add
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[200px] p-0" align="end">
                        <Command>
                          <CommandInput placeholder="Search labels..." className="h-8 text-xs" />
                          <CommandList>
                            <CommandEmpty>No labels found.</CommandEmpty>
                            <CommandGroup>
                              {labels.map((label) => (
                                <CommandItem
                                  key={label.id}
                                  onSelect={() => toggleLabel(label.id)}
                                  className="text-xs"
                                >
                                  <div className="flex items-center gap-2 flex-1">
                                    <div className="size-2.5 rounded-full" style={{ backgroundColor: label.color }} />
                                    <span>{label.name}</span>
                                  </div>
                                  {selectedLabelIds.includes(label.id) && <Check className="size-3.5 text-primary" />}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedLabelIds.length === 0 ? (
                      <span className="text-[11px] text-muted-foreground pl-1">No labels added</span>
                    ) : (
                      selectedLabelIds.map((id) => {
                        const label = labels.find((l) => l.id === id);
                        if (!label) return null;
                        return (
                          <Badge
                            key={id}
                            variant="outline"
                            className="text-[10px] px-2 py-0.5 rounded-full border"
                            style={{ 
                              backgroundColor: `${label.color}15`, 
                              color: label.color,
                              borderColor: `${label.color}30`
                            }}
                          >
                            {label.name}
                          </Badge>
                        );
                      })
                    )}
                  </div>
                </div>

                <Separator className="bg-muted-foreground/10" />

                {/* Metadata: Visibility */}
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-foreground/80 font-semibold text-sm">
                    <Globe className="size-4" />
                    <span>Visibility</span>
                  </div>
                  <div className="flex p-1 rounded-xl bg-background border border-muted shadow-inner">
                    <button
                      type="button"
                      onClick={() => setVisibility('private')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all",
                        visibility === 'private' ? "bg-muted shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Lock className="size-3.5" />
                      Private
                    </button>
                    <button
                      type="button"
                      onClick={() => setVisibility('public')}
                      className={cn(
                        "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all",
                        visibility === 'public' ? "bg-primary/10 text-primary shadow-sm" : "text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <Globe className="size-3.5" />
                      Public
                      {visibility === 'public' && <Check className="size-3 ml-0.5" />}
                    </button>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-relaxed pl-1 italic">
                    Public objectives are visible to everyone in the organization. Private objectives are only visible to owners and members.
                  </p>
                  <div className="flex items-start gap-2 rounded-lg border bg-background p-3">
                    <Checkbox
                      id="comments-private"
                      checked={commentsPrivate}
                      onCheckedChange={(checked) => setCommentsPrivate(checked === true)}
                      className="mt-0.5"
                    />
                    <Label htmlFor="comments-private" className="text-xs leading-snug text-muted-foreground">
                      Keep comments visible only to objective owners
                    </Label>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function resolveTimePeriodPreset(startDate: string, endDate: string): TimePeriodPreset {
  const match = Object.entries(TIME_PERIOD_PRESETS).find(
    ([key, value]) =>
      key !== 'custom' &&
      value.startDate === startDate &&
      value.endDate === endDate,
  );

  return (match?.[0] as TimePeriodPreset | undefined) ?? 'custom';
}
