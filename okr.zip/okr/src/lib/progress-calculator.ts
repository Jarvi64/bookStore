import type { KeyResult, Objective } from '@/models';

/**
 * Calculate the weighted progress of an objective from its children.
 * Children = key results + sub-objectives, sharing a weight pool that sums to 100.
 *
 * @param keyResults - Key results belonging to this objective
 * @param subObjectives - Sub-objectives (child objectives) of this objective
 * @returns Weighted progress 0-100
 */
export function calculateObjectiveProgress(
  keyResults: KeyResult[],
  subObjectives: Objective[],
): number {
  const children: { weight: number; progress: number }[] = [];

  // Add key results
  for (const kr of keyResults) {
    children.push({ weight: kr.weight, progress: kr.progress });
  }

  // Add sub-objectives (they participate in the same weight pool)
  for (const sub of subObjectives) {
    // Sub-objectives get their weight from a separate mechanism (stored on the parent relationship)
    // For now, we treat them as equal weight if no specific weight is set
    children.push({ weight: sub.progress > 0 ? 50 : 0, progress: sub.progress });
  }

  if (children.length === 0) return 0;

  const totalWeight = children.reduce((sum, c) => sum + c.weight, 0);
  if (totalWeight === 0) return 0;

  const weightedSum = children.reduce(
    (sum, c) => sum + (c.weight / totalWeight) * c.progress,
    0,
  );

  return Math.round(weightedSum * 10) / 10;
}

/**
 * Calculate key result progress from its metric values.
 *
 * @returns Progress as a percentage (0-100)
 */
export function calculateKeyResultProgress(
  currentValue: number,
  initialValue: number,
  targetValue: number,
): number {
  const range = targetValue - initialValue;
  if (range === 0) return 0;

  const progress = ((currentValue - initialValue) / range) * 100;
  return Math.round(Math.max(0, Math.min(100, progress)) * 10) / 10;
}

/**
 * Auto-distribute weights evenly among children.
 *
 * @param count Number of children
 * @returns Array of weights that sum to 100
 */
export function distributeWeightsEvenly(count: number): number[] {
  if (count === 0) return [];

  const baseWeight = Math.floor((100 / count) * 10) / 10;
  const weights = Array(count).fill(baseWeight) as number[];

  // Distribute remainder to last item
  const total = weights.reduce((sum, w) => sum + w, 0);
  const remainder = Math.round((100 - total) * 10) / 10;
  weights[weights.length - 1] += remainder;

  return weights;
}
