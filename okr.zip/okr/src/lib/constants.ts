import type { ObjectiveStatus, ObjectiveType, MetricType, TimePeriodPreset } from '@/models';

// ============================================================
// STATUS CONFIGURATION
// ============================================================

/** Status display config — label, color, and dot color for each status */
export const STATUS_CONFIG: Record<
  ObjectiveStatus,
  { label: string; color: string; bgColor: string; dotColor: string }
> = {
  no_status: {
    label: 'No status',
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
    dotColor: 'bg-gray-400',
  },
  on_track: {
    label: 'On track',
    color: 'text-emerald-700 dark:text-emerald-400',
    bgColor: 'bg-emerald-100 dark:bg-emerald-950',
    dotColor: 'bg-emerald-500',
  },
  at_risk: {
    label: 'At risk',
    color: 'text-amber-700 dark:text-amber-400',
    bgColor: 'bg-amber-100 dark:bg-amber-950',
    dotColor: 'bg-amber-500',
  },
  off_track: {
    label: 'Off track',
    color: 'text-red-700 dark:text-red-400',
    bgColor: 'bg-red-100 dark:bg-red-950',
    dotColor: 'bg-red-500',
  },
  closed: {
    label: 'Closed',
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
    dotColor: 'bg-gray-500',
  },
};

// ============================================================
// OBJECTIVE TYPE CONFIGURATION
// ============================================================

/** Objective type display config — label, icon identifier, and color */
export const OBJECTIVE_TYPE_CONFIG: Record<
  ObjectiveType,
  { label: string; icon: string; color: string; bgColor: string }
> = {
  individual: {
    label: 'Individual',
    icon: 'User',
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-100 dark:bg-blue-950',
  },
  team: {
    label: 'Team',
    icon: 'Users',
    color: 'text-emerald-600 dark:text-emerald-400',
    bgColor: 'bg-emerald-100 dark:bg-emerald-950',
  },
  department: {
    label: 'Department',
    icon: 'Building2',
    color: 'text-rose-600 dark:text-rose-400',
    bgColor: 'bg-rose-100 dark:bg-rose-950',
  },
  company: {
    label: 'Company',
    icon: 'Landmark',
    color: 'text-violet-600 dark:text-violet-400',
    bgColor: 'bg-violet-100 dark:bg-violet-950',
  },
};

// ============================================================
// METRIC TYPE CONFIGURATION
// ============================================================

export const METRIC_TYPE_CONFIG: Record<
  MetricType,
  { label: string; icon: string; prefix: string; suffix: string }
> = {
  percent: { label: 'Percent', icon: '%', prefix: '', suffix: '%' },
  number: { label: 'Number', icon: '#', prefix: '', suffix: '' },
  currency: { label: 'Currency', icon: '$', prefix: '$', suffix: '' },
};

// ============================================================
// TIME PERIOD PRESETS
// ============================================================

/** Get the year for time period calculations */
const CURRENT_YEAR = new Date().getFullYear();

export const TIME_PERIOD_PRESETS: Record<
  TimePeriodPreset,
  { label: string; startDate: string; endDate: string; quarter: string }
> = {
  Q1: {
    label: 'Q1 Jan-Mar',
    startDate: `${CURRENT_YEAR}-01-01`,
    endDate: `${CURRENT_YEAR}-03-31`,
    quarter: `Q1 Jan-Mar ${CURRENT_YEAR}`,
  },
  Q2: {
    label: 'Q2 Apr-Jun',
    startDate: `${CURRENT_YEAR}-04-01`,
    endDate: `${CURRENT_YEAR}-06-30`,
    quarter: `Q2 Apr-Jun ${CURRENT_YEAR}`,
  },
  Q3: {
    label: 'Q3 Jul-Sep',
    startDate: `${CURRENT_YEAR}-07-01`,
    endDate: `${CURRENT_YEAR}-09-30`,
    quarter: `Q3 Jul-Sep ${CURRENT_YEAR}`,
  },
  Q4: {
    label: 'Q4 Oct-Dec',
    startDate: `${CURRENT_YEAR}-10-01`,
    endDate: `${CURRENT_YEAR}-12-31`,
    quarter: `Q4 Oct-Dec ${CURRENT_YEAR}`,
  },
  H1: {
    label: 'H1 Jan-Jun',
    startDate: `${CURRENT_YEAR}-01-01`,
    endDate: `${CURRENT_YEAR}-06-30`,
    quarter: `H1 Jan-Jun ${CURRENT_YEAR}`,
  },
  H2: {
    label: 'H2 Jul-Dec',
    startDate: `${CURRENT_YEAR}-07-01`,
    endDate: `${CURRENT_YEAR}-12-31`,
    quarter: `H2 Jul-Dec ${CURRENT_YEAR}`,
  },
  full_year: {
    label: 'Full Year',
    startDate: `${CURRENT_YEAR}-01-01`,
    endDate: `${CURRENT_YEAR}-12-31`,
    quarter: `Full Year ${CURRENT_YEAR}`,
  },
  custom: {
    label: 'Custom',
    startDate: '',
    endDate: '',
    quarter: 'Custom',
  },
};

// ============================================================
// PROGRESS BAR COLORS
// ============================================================

/** Returns the Tailwind color class for a progress bar based on status */
export function getProgressBarColor(status: ObjectiveStatus): string {
  switch (status) {
    case 'on_track':
      return 'bg-emerald-500';
    case 'at_risk':
      return 'bg-amber-500';
    case 'off_track':
      return 'bg-red-500';
    case 'closed':
      return 'bg-gray-400';
    default:
      return 'bg-violet-500';
  }
}
