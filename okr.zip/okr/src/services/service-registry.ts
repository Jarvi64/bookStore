/**
 * Service Registry — Central dependency injection point.
 *
 * To switch from dummy data to Dataverse:
 * 1. Create new service classes in `services/dataverse/`
 * 2. Swap the imports below
 * 3. Everything else stays the same
 */

import { DummyObjectiveService } from './dummy/objective.service';
import { DummyKeyResultService } from './dummy/key-result.service';
import { DummyUserService } from './dummy/user.service';
import { DummyLabelService } from './dummy/label.service';
import { DummyCommentService } from './dummy/comment.service';

// Singleton instances — one per service for the app lifetime
export const objectiveService = new DummyObjectiveService();
export const keyResultService = new DummyKeyResultService();
export const userService = new DummyUserService();
export const labelService = new DummyLabelService();
export const commentService = new DummyCommentService();
