import { v4 as uuidv4 } from 'uuid';
import type {
  KeyResult,
  CreateKeyResultDTO,
  UpdateKeyResultDTO,
} from '@/models';
import type { IKeyResultService } from '../interfaces/key-result.service.interface';
import { DUMMY_KEY_RESULTS } from './data/key-results.data';

/**
 * Dummy implementation of IKeyResultService.
 */
export class DummyKeyResultService implements IKeyResultService {
  private keyResults: KeyResult[] = [...DUMMY_KEY_RESULTS];

  async getAll(): Promise<KeyResult[]> {
    return [...this.keyResults];
  }

  async getById(id: string): Promise<KeyResult | null> {
    return this.keyResults.find((kr) => kr.id === id) ?? null;
  }

  async create(data: CreateKeyResultDTO): Promise<KeyResult> {
    const now = new Date().toISOString();
    const newKR: KeyResult = {
      id: uuidv4(),
      title: data.title,
      description: data.description ?? null,
      objectiveId: data.objectiveId,
      ownerId: data.ownerId,
      weight: data.weight ?? 0,
      metricType: data.metricType,
      initialValue: data.initialValue,
      targetValue: data.targetValue,
      currentValue: data.initialValue,
      progress: 0,
      startDate: data.startDate,
      endDate: data.endDate,
      status: 'no_status',
      createdAt: now,
      updatedAt: now,
    };
    this.keyResults.push(newKR);
    return { ...newKR };
  }

  async update(id: string, data: UpdateKeyResultDTO): Promise<KeyResult> {
    const index = this.keyResults.findIndex((kr) => kr.id === id);
    if (index === -1) throw new Error(`Key Result ${id} not found`);

    const updated: KeyResult = {
      ...this.keyResults[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };

    // Recalculate progress if metric values changed
    if (
      data.currentValue !== undefined ||
      data.initialValue !== undefined ||
      data.targetValue !== undefined
    ) {
      const range = updated.targetValue - updated.initialValue;
      updated.progress =
        range === 0
          ? 0
          : Math.round(
              ((updated.currentValue - updated.initialValue) / range) * 1000,
            ) / 10;
    }

    this.keyResults[index] = updated;
    return { ...updated };
  }

  async delete(id: string): Promise<void> {
    this.keyResults = this.keyResults.filter((kr) => kr.id !== id);
  }

  async getByObjectiveId(objectiveId: string): Promise<KeyResult[]> {
    return this.keyResults.filter((kr) => kr.objectiveId === objectiveId);
  }

  async updateWeights(
    objectiveId: string,
    weights: { id: string; weight: number }[],
  ): Promise<void> {
    for (const { id, weight } of weights) {
      const kr = this.keyResults.find(
        (k) => k.id === id && k.objectiveId === objectiveId,
      );
      if (kr) kr.weight = weight;
    }
  }
}
