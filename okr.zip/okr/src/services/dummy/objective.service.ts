import { v4 as uuidv4 } from 'uuid';
import type {
  Objective,
  CreateObjectiveDTO,
  UpdateObjectiveDTO,
} from '@/models';
import type { IObjectiveService } from '../interfaces/objective.service.interface';
import { DUMMY_OBJECTIVES } from './data/objectives.data';
import { DUMMY_USERS } from './data/users.data';

/**
 * Dummy implementation of IObjectiveService.
 * Uses in-memory array — all changes persist only for the session.
 */
export class DummyObjectiveService implements IObjectiveService {
  private objectives: Objective[] = [...DUMMY_OBJECTIVES];

  async getAll(): Promise<Objective[]> {
    return [...this.objectives];
  }

  async getById(id: string): Promise<Objective | null> {
    return this.objectives.find((o) => o.id === id) ?? null;
  }

  async create(data: CreateObjectiveDTO): Promise<Objective> {
    const now = new Date().toISOString();
    const newObjective: Objective = {
      id: uuidv4(),
      title: data.title,
      description: data.description ?? null,
      type: data.type,
      status: 'no_status',
      progress: 0,
      startDate: data.startDate,
      endDate: data.endDate,
      quarter: data.quarter,
      parentObjectiveId: data.parentObjectiveId ?? null,
      ownerIds: data.ownerIds,
      ownershipMode: data.ownershipMode,
      labelIds: data.labelIds ?? [],
      groupId: data.groupId ?? null,
      visibility: data.visibility,
      commentsPrivate: data.commentsPrivate ?? false,
      metricType: data.metricType,
      initialValue: data.initialValue,
      targetValue: data.targetValue,
      currentValue: data.initialValue,
      createdBy: DUMMY_USERS[1].id, // current user
      createdAt: now,
      updatedAt: now,
    };
    this.objectives.push(newObjective);
    return { ...newObjective };
  }

  async update(id: string, data: UpdateObjectiveDTO): Promise<Objective> {
    const index = this.objectives.findIndex((o) => o.id === id);
    if (index === -1) throw new Error(`Objective ${id} not found`);

    const updated: Objective = {
      ...this.objectives[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    this.objectives[index] = updated;
    return { ...updated };
  }

  async delete(id: string): Promise<void> {
    this.objectives = this.objectives.filter((o) => o.id !== id);
  }

  async getByParentId(parentId: string): Promise<Objective[]> {
    return this.objectives.filter((o) => o.parentObjectiveId === parentId);
  }

  async getByOwnerId(ownerId: string): Promise<Objective[]> {
    return this.objectives.filter((o) => o.ownerIds.includes(ownerId));
  }

  async getByDepartment(departmentId: string): Promise<Objective[]> {
    // Filter by objectives whose owners belong to the given department
    const deptUserIds = DUMMY_USERS
      .filter((u) => u.departmentId === departmentId)
      .map((u) => u.id);
    return this.objectives.filter((o) =>
      o.ownerIds.some((id) => deptUserIds.includes(id)),
    );
  }

  async getCompanyObjectives(): Promise<Objective[]> {
    return this.objectives.filter((o) => o.type === 'company');
  }
}
